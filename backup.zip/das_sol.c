#include "ldefns.h"
integer		DAS_Sol_nout=0;
integer		DAS_Sol_msg=0;
integer		DAS_Sol_istart=0;
real		DAS_Sol_parm[10]={0.0};
real		DAS_Sol_asize=0.0;
real		DAS_Sol_dtmax=0.0;
real		DAS_Sol_dtmin=0.0;
integer		DAS_Sol_nrowrt=0;
integer		DAS_Sol_ncolrt=0;
integer		DAS_Sol_nq=0;
void		*DAS_Sol_ploc[15]={0};
integer		DAS_Sol_locnp[30]={0};
integer		DAS_Sol_loclc[15]={0};
integer		DAS_Sol_ncqp=0;
integer		DAS_Sol_nrowqp=0;
logical		DAS_Sol_scldqp=0;
real		DAS_Sol_zgfacc=-1.0;
#ifdef	__DLL__
__declspec( dllexport )	char		*DAS_Sol_errmsg[]={
			"Optimal Solution Found",
			"Weak local minimum found, the solution is not unique",
			"Solution appears to be unbounded",
			"Local minimum found, active set may not be correct",
			"QP phase may be cycling, possibly redundant/dependant constraints",
			"QP phase reached limit iterations, change ITMAX and/or constraints",
			"LP phase could not find a feasible point, check the constraints",
			"LP phase may be cycling, possibly redundant/dependant constraints",
			"LP phase reached limit iterations, change ITMAX and/or constraints",
			"An input parameter was invalid",
			"Invalid Simple Bounds",
			"Piecewise costs optimisation did not converge"
			};
#else
char		*DAS_Sol_errmsg[]={
			"Optimal Solution Found",
			"Weak local minimum found, the solution is not unique",
			"Solution appears to be unbounded",
			"Local minimum found, active set may not be correct",
			"QP phase may be cycling, possibly redundant/dependant constraints",
			"QP phase reached limit iterations, change ITMAX and/or constraints",
			"LP phase couldn't find a feasible point, check the constraints",
			"LP phase may be cycling, possibly redundant/dependant constraints",
			"LP phase reached limit iterations, change ITMAX and/or constraints",
			"An input parameter was invalid",
			"Invalid Simple Bounds",
			"Piecewise costs optimisation did not converge"

			};
#endif
