#! /bin/env python
from Optn import *


lab=[]
ns=0
pen=[]
def Alam(l,A):
    m=len(l)
    n=len(A)/m
    al=[0]*n
    for i in range(n):
        al[i]=dot(l,A,i*m)
    return al
def utility(c,Q,x,tt):
    n=len(x)
    imp=[0]*n
    tt(n,1,1,1,Q,x,imp)
    return dot(c,x)+0.5*dot(x,imp)
def zerosplit(x):
    n=len(x)
    ns=n/2
    for i in range(ns):
        if abs(x[i]) > abs(x[i+ns]):x[i+ns]=0
        else:x[i]=0
def squareup(x):
    n=len(x)
    ns=n/2
    xx=[0]*n
    for i in range(ns):
        xx[i]=-x[i]*x[i]
        xx[i+ns]=x[i+ns]*x[i+ns]
    return xx
def patutilsq(n,x):
    return utility(patc,H,squareup(x),patmul)
def patutil(n,x):
    return utility(patc,H,x,patmul)
def addvec(a,b,s=1):
    n=min(len(a),len(b))
    c=[0]*n
    for i in range(n):c[i]=a[i]+s*b[i]
    return c
def combine(x):
    n=len(x)/2
    xx=[0]*n
    for i in range(n):xx[i]=x[i]+x[i+n]
    return xx
def lscheck(a):
    L=0
    S=0
    N=0
    G=0
    for i in a:
        N+=i
        if i < 0:S+=i;G-=i
        else:L+=i;G+=i
    print 'Long %-.8e Short %-.8e Net %-.8e Gross %-.8e' % (L,S,N,G)
    return (L,S,N,G)
def x2print(x,name=''):
    if name != '':
        print name
    n=len(x)/2
    for i in range(n):print '%4d %20.8e %20.8e'%(i+1,x[i],x[i+n])
def xprint(x,name=''):
    if name != '':
        print name
    n=len(x)
    for i in range(n):print '%4d %20.8e'%(i+1,x[i])
def testmul(n,n1,n2,n3,H,x,y):
    ij = 0
    for i in range(n):
        y[i] = 0
        for j in range(i+1):
            y[i] += H[ij] * x[j]
            if i != j:
                y[j] += H[ij] * x[i]
            ij+=1
def lsmul(n,n1,n2,n3,H,x,y):
    w=[0]*ns
    j=0
    for i in range(ns):
        w[i]=x[i]
        if lab[j] == i:
            w[i]+=x[ns+j]
            j+=1
    testmul(ns,n1,n2,n3,H,w,y)
    j=0
    for i in range(ns):
        if lab[j] == i:
            y[ns+j]=y[i]
            y[i]-=x[ns+j]*pen[i]
            y[ns+j]-=x[i]*pen[i]
            j+=1
def makepen(n,pen,tt):
    x=[0]*n
    y=[0]*n
    for i in range(n):
        x[i]=1
        tt(n,n,n,n,H,x,y)
        pen[i]=2*y[i]
        x[i]=0
        
ns=10
H=[.1,
   1e-5,.2,
   1e-5,-1e-5,.3,
   1e-5,1e-5,1e-5,.4,
   1e-5,-1e-5,1e-5,1e-5,.5,
   1e-5,1e-5,1e-5,1e-5,1e-5,.6,
   1e-5,-1e-5,1e-5,-1e-5,1e-5,1e-5,.7,
   -1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.8,
   1e-5,1e-5,4e-5,-1e-5,2e-5,1e-5,1e-5,1e-5,.9,
   1e-5,1e-5,-1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,-1e-5,1]
A=[1]*ns
m=1
L=[-100]*ns+[0]
U=[100]*ns+[0]
L[0]=0
x=[]
lamda=[]
c=[.11,.12,.13,.14,.15,-.5,-.4,-.3,-.2,-.1]

O=Optimise()
"""
    First optimise with budget constraint setting budget to 0 and have first variable non negative
"""
O.hmul=testmul
O.H=H
print O.OptAdvanced(ns,m,x,A,L,U,c,lamda)
xprint(x,'budget = 0')
lscheck(x)
print 'Utility %-.8e'%utility(c,H,x,testmul)
xprint(lamda,'multipliers for budget = 0')
"""
    Now modify the linear terms using the Langrangian multipliers so that an unconstrained
    optimisation will give the same x
"""
newc=addvec(c,A,-lamda[ns+m-1])
newc=addvec(newc,lamda,-1)
L[0]=-100
m=0
lamda=[]
x=[]
print O.OptAdvanced(ns,m,x,A,L,U,newc,lamda)
xprint(x,'budget = 0')
lscheck(x)
print 'Utility %-.8e'%utility(newc,H,x,testmul)
xprint(lamda,'multipliers for budget = 0')
"""
    Show that the same result is obtained using a general unconstrained optimisation method
"""
wp=[]
step=[.001]*ns
f=[1]
scale=10
patmul=testmul
patc=newc
PatternMin(ns,wp,step,f,scale,patutil,0)
xprint(wp,'budget = 0 using pattern optimiser')
lscheck(wp)
print 'Utility %-.8e'%patutil(ns,wp)

"""
    Set up a long/short optimisation with budget constrained to +-0.1 and gross value less than 2
"""
O.hmul=lsmul
A=[1,-1]*ns+[1,1]*ns
m=2
L=[-100]*ns+[0]*ns+[-.1]+[0]
U=[0]*ns+[100]*ns+[0.1]+[2]
lab=[i for i in range(ns)]
pen=[0]*ns
makepen(ns,pen,testmul)
x=[]
CC=c+c
lp = 0
n=2*ns

x=[]
lamda=[]
print O.OptAdvanced(n,m,x,A,L,U,CC,lamda)
x2print(x,'budget = 0 with +value 1')
print 'Utility %-.8e'%utility(CC,H,x,lsmul)
xprint(combine(x),'budget = 0 with +value 1 (combined)')
lscheck(combine(x))
xprint(lamda,'multipliers for budget = 0 with +value 1')
CAL=Alam([lamda[i+n] for i in range(m)],A)
#xprint(CAL)
newCC=addvec(CC,CAL,-1)
#x2print(CC+newCC)
#newCC=addvec(newCC,lamda,-1)
#x2print(CC+newCC)
"""
    Modify the linear terms as above and do an optimisation with no general linear constraints
"""
m=0
L=[-100]*ns+[0]*ns
U=[0]*ns+[100]*ns
x=[]
lamda=[]
print O.OptAdvanced(n,m,x,A,L,U,newCC,lamda)
x2print(x,'budget = 0 with +value 1')
print 'Utility %-.8e'%utility(newCC,H,x,lsmul)
x2print(lamda,'Multipliers')
xprint(combine(x),'budget = 0 with +value 1 (combined)')
lscheck(combine(x))
x2print(newCC,'New split linear part')
tryc=combine(newCC)

"""
    Finally show that we cannot combine the split linear terms above to get an unconstrained problem
    which gives the above combined x
"""
wp=[0.5]
step=[1e-2]*ns
f=[1]
scale=1
patmul=testmul
patc=tryc
PatternMin(ns,wp,step,f,scale,patutil,0,20,1)
xprint(wp,'budget = 0 using pattern optimiser')
print 'Utility %-.8e'%patutil(ns,wp)
scale=1e0
step=[wp[i]*5e-3 for i in range(ns)]
PatternMin(ns,wp,step,f,scale,patutil,0,200,1)
xprint(wp,'budget = 0 using pattern optimiser')
lscheck(wp)
print 'Utility %-.8e'%patutil(ns,wp)

x=[0.5]*n
f=[1]
step=[5e-3]*n
scale=1e0
patmul=lsmul
patc=newCC
PatternMin(n,x,step,f,scale,patutilsq,0,100,1)
print 'Utility %-.8e'%patutilsq(n,x)
step=[x[i]*5e-3 for i in range(n)]
#zerosplit(x)
scale=1e0
#PatternMin(n,x,step,f,scale,patutilsq,0,200,1)
x=[1]*n
if QuasiNewton(n,x,1,n*100,f,patutilsq,pow(epsget(),0.5),2):print 'Quasi-Newton step failed'
xx=squareup(x)
x2print(xx,'budget = 0 using pattern optimiser')
lscheck(combine(xx))
print 'Utility %-.8e'%patutilsq(n,x)


