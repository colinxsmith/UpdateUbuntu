#include "ldefns.h"
/*
	Apply a plane rotation to vectors
*/
void drotvec(dimen n, vector x, vector y, real c, real s)
{
	register real t;
	while(n--){
		t  = c * *x + s * *y;
		*y = c * *y - s * *x;
		*x++ = t;
		y++;
    		}
}
