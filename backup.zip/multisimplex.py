from Opt import *
#from branch import va04a_
printit=0
def multi(Growth,Yield,LIAB,lbound,ubound,DATA,COV,first,desiredturnover,maxrisk,*d,**extras):
    """
    Growth is a list of lists; Growth[t][i] is the growth in period t for asset i
    Yield is a list of lists; Yield[t][i] is the yield in period t for asset i
    LIAB is a list of liabilities for each period
    NumberYears (optional) is a list containing the number of years that each period lasts
    
    lbound and ubound are lists of asset lower and upper bounds
    DATA is a list of names of assets (one asset must be called CASH)
    COV is the asset covariance matrix in lower triangular form
    
    first is a list containing the initial weights of the assets
    desiredturnover is the desired turnover in each period optimisation
    maxrisk is the maximum allowed risk in each period optimisation

    meth decides whether to optimise all alphas (with gamma 0.5) for the first n-1 periods (meth=1) or use
    alphas calculated from growth and yield and optimise gammas for the first n-1 periods (meth=0).
    
    """
    try:NumberYears=d[0]
    except:NumberYears=[]
    meth=0
    for i in extras.keys():
        if i == 'NumberYears':
            NumberYears=extras['NumberYears']
        elif i == 'meth':
            meth=extras['meth']
    opt=Opt()
    opt.n=len(DATA)
    opt.mask=[1,1,1]
    cashnum=0
    for i in range(opt.n):
        if DATA[i]=='CASH':opt.mask[i]=0;cashnum=i
    opt.names=DATA
    opt.bench=[0]*opt.n
    nyears=len(LIAB)

    opt.nfac=-1
    opt.Q=COV
    opt.revise=1
    opt.maxrisk=maxrisk
    opt.minrisk=0
    OldValue=FinalWealth=1e23
    FirstFinalWealth=0
    Conv=1e-10
    Converged=0


    Alphas=[[]]*nyears
    Alphas[nyears-1]=[1]*opt.n
    for i in range(1,nyears):
        j=nyears-i
        ntime=1
        if NumberYears!=[]:ntime=NumberYears[j]
        Alphas[j-1]=map(lambda t:(pow((1+Growth[j][t]+Yield[j][t]),ntime)*Alphas[j][t]),range(opt.n))
    def finalwealth(n,x):
        """
        If meth is 0, x holds the gammas for the first nyears-1 optimisations.
        If meth is 1, x holds the alphas for the first nyears-1 optimisations.
        """
        prob=0
        opt.initial=[i for i in first]
        if meth==1:
            nyears=n/opt.n+1
            usegamma=[0.5]*nyears
            xx=x+[1]*opt.n
        else:
            nyears=n+1
            usegamma=[(i*i)/(i*i+1) for i in x]
            usegamma.append(0.5)
        for year in range(nyears):
            if printit:
                print '&'*20+' year %d '%year +'&'*20
            ntime=1
            if NumberYears!=[]:ntime=NumberYears[year]
            if meth==1:
                opt.alpha=[xx[i+year*opt.n] for i in range(opt.n)]
            else:
                opt.alpha=map(lambda t:t,Alphas[year])
            WealthFactor=map(lambda t:pow((1+Growth[year][t]+Yield[year][t]),ntime),range(opt.n))
            wealthnow=sum(opt.initial)
            SetWealth=dot(opt.initial,WealthFactor)
            opt.m=1
            opt.A=[1]*opt.n
            opt.L=lbound+[SetWealth]
            opt.U=ubound+[SetWealth]
            opt.L[cashnum]=LIAB[year]
            opt.delta=desiredturnover*wealthnow
            opt.gamma=usegamma[year]
            opt.log=0

            back=opt.opt()
            if back>1:prob=1
            if printit:
                print opt.returnmessage
                print '%20s %20s %20s %20s'%('Asset Class','Initial','Final','Alphas used')
                for i in range(opt.n):
                    print '%20s %20.8e %20.8e %20.8e'%(opt.names[i],opt.initial[i],opt.w[i],opt.alpha[i])

            opt.props()
            EWealth=opt.rreturn
            for i in range(year,nyears):
                EWealth-=LIAB[i]*Alphas[i][cashnum]

            if printit:
                print 'Initial Wealth\t\t%20.8e'%sum(opt.initial)
                print 'Wealth Now\t\t%20.8e'%sum(opt.w)
                print 'Wealth Less Liability\t%20.8e'%(sum(opt.w)-LIAB[year])
                print 'Gamma\t\t\t%20.8e'%opt.ogamma
                print 'Risk\t\t\t%20.8e'%opt.risk
                if year==nyears-1:print 'Expected Final Wealth\t%20.8e'%EWealth
                print 'Turnover\t\t%20.8e'%(turnover(opt.w,opt.initial,opt.mask)/wealthnow)
                print 'Total Turnover\t\t%20.8e'%(turnover(opt.w,first,opt.mask))

            opt.initial=map(lambda t:t,opt.w)
            opt.initial[cashnum]-=LIAB[year]

                    
        if not prob:return -EWealth
        else:return 1e3
    printit=1
    if meth==1:
        """We must generate a starting guess for the alphas which leads to a feasible result"""
        start=[0]*((nyears-1)*opt.n)
        N=(nyears-1)*opt.n
        E=finalwealth(N,start)
        if E>0:
            """No good most likely due to risk constraint not being met so use negative alphas (NOT ALL EQUAL)"""
            for t in range(N):
                start[t]=-(t+1)
                E=finalwealth(N,start)
                if E<0:break
        if E>0:
            print '%'*20+' Could not get a good starting point '+'%'*20
    else:
        start=[0]*(nyears-1)
        N=nyears-1
    printit=0
    if 1:
        xmin=[]
        ynewlo=[0]
        reqmin=epsget()
        step=[1e-4]*N
        konvge=10
        kcount=1000
        icount=[0]
        numres=[0]
        ifault=[0]
        simplex(N,start,xmin,ynewlo,reqmin,
                    step,konvge,kcount,icount,numres,ifault,finalwealth)
        print 'ERROR code; %d, count; %d, number of restarts; %d'%(ifault[0],icount[0],numres[0])
#    else:
#        NN=[N]
#        xmin=start
#        E=[1e15]*(N)
#        F=[0]
#        ESCAL=[1e-6]
#        IPRNT=[1]
#        ICON=[1]
#        MAXIT=[100]

#        va04a_BITA(NN,xmin,E,F,ESCAL,IPRNT,ICON,MAXIT,finalwealth)
#        va04a_BITA(NN,xmin,E,F,ESCAL,IPRNT,ICON,MAXIT,finalwealth)

    printit=1
    if meth==1:
        finalwealth((nyears-1)*opt.n,xmin)
    else:
        finalwealth((nyears-1),xmin)
    
        
if __name__ == '__main__':
    DATA=['CASH','EQUITIES','BONDS']
    COV=[0.085291178592080463, -0.0010384120058427593, 0.079105769342181526,
         0.00963279430037145, 0.00098092427209120481, 0.077833750263356677]
    LIAB=[.01,.02,0.1,.15]
    Growth=[[0,.06,.001],[0,.06,.01],[0,.04,.02],[0,.06,.03]]
    Yield=[[.02,.001,.02],[.02,.01,.02],[.03,.02,.02],[.02,.03,.04]]
    Growtha=[0,.06,.001,0,.06,.01,0,.04,.02,0,.06,.03]
    Yielda=[.02,.001,.02,.02,.01,.02,.03,.02,.02,.02,.03,.04]
    NumberYears=[1,2,3,0]
    lbound=[0,.2,.2]
    ubound=[.6,.6,.6]
    first=[0,.5,.5]
    desiredturnover=.05
    maxrisk=.2141
    meth=1
#    multi(Growth,Yield,LIAB,lbound,ubound,DATA,COV,first,desiredturnover,maxrisk,NumberYears,meth=meth)
    w=[]
    multistage(len(DATA),len(LIAB),w,Growtha,Yielda,LIAB,lbound,ubound,DATA,COV,first,desiredturnover,maxrisk,NumberYears,meth)
    print w
