#include "baseoptimise.h"
size_t simplex_BITA(pUtility fn, size_t n,double*start,double*xmin,double* ynewlo,double reqmin,
			 double* step,size_t konvge,size_t kcount,size_t* icount,size_t* numres,
			 size_t* ifault,double* p,double* pstar,double* p2star,double*  pbar,double* y,
			 void*info)
{
	bool restart;
    double rcoeff = 1.;
    double ecoeff = 2.;
    double ccoeff = .5;
    double one = 1.;
    double half = .5;
    double eps = .001;


    size_t i, j, l;
    double x, z, ystar, dn, y2star;
    size_t nn;
    double rq;
    size_t jcount;
    double del;
    size_t ihi;
    double dnn;
    size_t ilo;
    double ylo;


/*     Simplex function minimisation procedure due to Nelder+Mead(1965), */
/*     as implemented by O'Neill(1971, Appl.Statist. 20, 338-45), with */
/*     subsequent comments by Chambers+Ertel(1974, 23, 250-1), Benyon(1976, */
/*     25, 97) and Hill(1978, 27, 380-2) */

/*        Algorithm AS 47  Applied Statistics (J.R. Statist. Soc. C), */
/*        (1971) Vol.20, No. 3 */

/*     The Nelder-Mead Simplex Minimisation Procedure */


/*        Purpose :: To find the minimum value of a user-specified */
/*                   function */

/*        Formal parameters :: */

/*            fn :        : The name of the function to be minimized. */
/*             n :  input : The number of variables over which we are */
/*                        : minimising */
/*         start :  input : Array; Contains the coordinates of the */
/*                          starting point. */
/*                 output : The values may be overwritten. */
/*          xmin : output : Array; Contains the coordinates of the */
/*                        : minimum. */
/*        ynewlo : output : The minimum value of the function. */
/*        reqmin :  input : The terminating limit for the variance of */
/*                        : function values. */
/*          step :  input : Array; Determines the size and shape of the */
/*                        : initial simplex.  The relative magnitudes of */
/*                        : its n elements should reflect the units of */
/*                        : the n variables. */
/*        konvge :  input : The convergence check is carried out every */
/*                        : konvge iterations. */
/*        kcount :  input : Maximum number of function evaluations. */
/*        icount : output : Function evaluations performed */
/*        numres : output : Number of restarts. */
/*        ifault : output : 1 if reqmin, n, or konvge has illegal value; */
/*                        : 2 if terminated because kcount was exceeded */
/*                        :   without convergence; */
/*                        : 0 otherwise. */

/*        All variables and arrays are to be declared in the calling */
/*        program as double precision. */


/*        Auxiliary algorithm :: The double precision function */
/*        subprogram fn(n,a) calculates the function value at point a. */
/*        a is double precision with n elements. */


/*        Reference :: Nelder,J.A. and Mead,R.(1965).  A simplex method */
/*        for function minimization.  Computer J., Vol.7,308-313. */

/* ************************************************************************ */

/*     1   p(20,21), pstar(20), p2star(20), pbar(20), y(21), */


    *ifault = 1;
    if (reqmin <= 0 || n < 1 || konvge < 1) {return 0;}
    *ifault = 2;
    *icount = 0;
    *numres = 0;

    jcount = konvge;
    dn = (double) (n);
    nn = n + 1;
    dnn = (double) nn;
    del = one;
    rq = reqmin * dn;

/*        construction of initial simplex. */

	bool do260=0;
	while(1)
	{
		dcopyvec(n,start,p+n*n);
		y[n] = fn(n, start,info);
		for (j = 0; j < n; ++j) 
		{
			x = start[j];
			start[j] += step[j] * del;
			dcopyvec(n,start,p+j*n);
			y[j] = fn(n, start,info);
			start[j] = x;
		}
		*icount += nn;

	/*       simplex construction complete */

	/*       find highest and lowest y values.  ynewlo (=y(ihi) ) indicates */
	/*       the vertex of the simplex to be replaced. */

		do260=0;
		while(1)
		{
			ylo = y[0];
			ilo = 0;
			for (i = 1; i < nn; ++i)
			{
				if (y[i] >= ylo) {continue;}
				ylo = y[i];
				ilo = i;
			}
		L50:
			*ynewlo = y[0];
			ihi = 0;
			for (i = 1; i < nn; ++i)
			{
				if (y[i] <= *ynewlo){continue;}
				*ynewlo = y[i];
				ihi = i;
			}

		/*      calculate pbar,the centroid of the simplex vertices */
		/*          excepting that with y value ynewlo. */

			for (i = 0; i < n; ++i)
			{
				z=dsum(nn,p+i,n);
				z -= p[i + ihi * n];
				pbar[i] = z / dn;
			}

		/*      reflection through the centroid */

			for (i = 0; i < n; ++i)
			{
				pstar[i] = pbar[i] + rcoeff * (pbar[i] - p[i + ihi * n]);
			}
			ystar = fn(n, pstar,info);
			++(*icount);
			if (ystar < ylo)
			{

			/*      successful reflection,so extension */

				for (i = 0; i < n; ++i)
				{
					p2star[i] = pbar[i] + ecoeff * (pstar[i] - pbar[i]);
				}
				y2star = fn(n, p2star,info);
				++(*icount);

			/*       check extension */

				if (y2star < ystar)
				{

			/*       retain extension or contraction. */

					dcopyvec(n,p2star,p+ihi*n);
					y[ihi] = y2star;
					break;
				}

			/*     retain reflection */

				dcopyvec(n,pstar,p+ihi*n);
				y[ihi] = ystar;
				break;
			}

		/*     no extension */

			l = 0;
			for (i = 0; i < nn; ++i) {if (y[i] > ystar){++l;}}
			if (l > 1) 
			{
				dcopyvec(n,pstar,p+ihi*n);
				y[ihi] = ystar;
				break;
			}
			if (l != 0)
			{
			/*     contraction on the reflection side of the centroid. */

				for (i = 0; i < n; ++i) 
				{
					p2star[i] = pbar[i] + ccoeff * (pstar[i] - pbar[i]);
				}
				y2star = fn(n, p2star,info);
				++(*icount);
				if (y2star <= ystar) 
				{
					dcopyvec(n,p2star,p+ihi*n);
					y[ihi] = y2star;
					break;
				}

			/*        retain reflection */

				dcopyvec(n,pstar,p+ihi*n);
				y[ihi] = ystar;
				break;
			}

		/*      contraction on the  y(ihi) side of the centriod. */

			for (i = 0; i < n; ++i) 
			{
				p2star[i] = pbar[i] + ccoeff * (p[i + ihi * n] - pbar[i]);
			}
			y2star = fn(n, p2star,info);
			++(*icount);
			if (y2star <= y[ihi]) 
			{
		/*        retain contraction */

				dcopyvec(n,p2star,p+ihi*n);
				y[ihi] = y2star;
				break;
			}

		/*       contract whole simplex. */

			for (j = 0; j < nn; ++j)
			{
				for (i = 0; i < n; ++i)
				{
					p[i + j * n] = (p[i + j * n] + p[i + ilo * n]) * half;
					xmin[i] = p[i + j * n];
				}
				y[j] = fn(n, xmin,info);
			}
			*icount += nn;
			if (*icount > kcount){do260=1;break;}//{goto L260;}
		}

	/*        Check if ylo improved */

		if(!do260)
		{
			if (y[ihi] < ylo) 
			{
				ylo = y[ihi];
				ilo = ihi;
			}
			--jcount;
			if (jcount != 0) 
			{goto L50;}

		/*     check to see if minimum reached. */

			if (*icount <= kcount)// {goto L260;}
			{
				jcount = konvge;
				x=dsumvec(nn,y)/dnn;
				z=ddotvec(nn,y,y)-x*x*dnn;
				/*printf("z = %-.15e, x = %-.15e\n",z,x);*/
				if (z > rq){goto L50;}
			}
		}

	/*       factorial tests to check that ynewlo is a local minimum. */

//	L260:
		dcopyvec(n,p+ilo*n,xmin);
		*ynewlo = y[ilo];
		if (*icount > kcount)
		{
			return 0;
		}
		restart=0;
		for (i = 0; i < n; ++i) 
		{
			del = step[i] * eps;
			xmin[i] += del;
			z = fn(n, xmin,info);
			++(*icount);
			if (z < *ynewlo) {restart=1;break;}
			xmin[i] -= (del + del);
			z = fn(n, xmin,info);
			++(*icount);
			if (z < *ynewlo){restart=1;break;}
			xmin[i] += del;
		}
		if(!restart)
		{
			*ifault = 0;
			return 0;
		}

	/*     restart procedure */

		dcopyvec(n,xmin,start);
		del = eps;
		++(*numres);
	}
}

void simplex(dimen n,double* start,double* xmin,double* ynewlo,
		double reqmin,double* step,dimen konvge,dimen kcount,dimen* icount,dimen* numres,
		dimen* ifault,pUtility fn,void* info)
{
	size_t n1=n+1;
	double* p = new double[n*n1];
	double* pstar = new double[n];
	double* p2star = new double[n];
	double* pbar = new double[n];
	double* y = new double[n1];

	simplex_BITA(fn,n,start,xmin,ynewlo,reqmin,step,konvge,kcount,(size_t*)icount,(size_t*)numres,
		(size_t*)ifault,p,pstar,p2star,pbar,y,info);

	delete [] p;
	delete [] pstar;
	delete [] p2star;
	delete [] pbar;
	delete [] y;
}
