#include "ldefns.h"
/*
	scale a general vector by a constant alpha
*/


void BITA_dscal(dimen n, real alpha, vector x, increment incx)
{
	if(n>0 && alpha!=1){
		if(incx<0) incx = -incx;	/*cannot matter which order*/
		if(alpha==0) dzero(n,x,incx);
		else if(alpha==-1) while(n--){ *x = -*x; x += incx;}
		else while(n--){ 
			*x = alpha* *x; x += incx; }
		}
}
void BITA_sscal(dimen n, float alpha, float* x, increment incx)//single precision
{
	if(n>0 && alpha!=1){
		if(incx<0) incx = -incx;	/*cannot matter which order*/
		if(alpha==0) szero(n,x,incx);
		else if(alpha==-1) while(n--){ *x = -*x; x += incx;}
		else while(n--){ 
			*x = alpha* *x; x += incx; 
		}
		}
}
