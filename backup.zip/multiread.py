#! /bin/env python
try:
    from java.lang import *
    from jarray import *
    from safejava import *
    jython=1
except:
    from safe import *
    jython=0
from sys import argv,stdin
from re import sub,split
"""
DATA
CASH EQUITIES BONDS
first
.2 .5 .3
lbound
0 .2 .2
ubound
.6 .6 .6
Growth
0 .06 .01
0 .04 .02
0 .06 .03
Yield
.02 .01 .02
.03 .02 .02
.02 .03 .04
LIAB
.02 0 .03
desiredturnover
.2
maxrisk
.2
COV
0.085291178592080463
-0.0010384120058427593 0.079105769342181526
0.00963279430037145 0.00098092427209120481 0.077833750263356677
"""
def turnover(w,wi,mask=[],start=0,stop=-1):
    """The turnover between w and wi (possibly masked)"""
    n=len(w)
    if stop!=-1:n=stop+start
    s=0
    if mask==[]:
        for i in range(start,n):s+=abs(w[i]-wi[i])
    else:
        for i in range(start,n):s+=abs((w[i]-wi[i])*mask[i-start])
    return s*0.5
def listlist2list(L):
    """Convert a list of lists to a list"""
    l=[]
    for i in L:
        for j in i:
            l.append(j)
    return l
def numline(llist=[],func=float):
    """Converts a string to number if possible
    To get an int list something like

    func=lambda t:int(float(t))
    
    may be best to convert a string float to an int"""
    for i in range(len(llist)):
        try:llist[i]=func(llist[i])
        except:pass
    return llist

class DATA:
    def __init__(self,file,sep=' *'):
        """
        file is a file object and sep is the data separator. Maybe you prefer sep=','.
        This handles multiple spaces in the data file properly now (using split() function
        from re rather than split() method of string).
        """
        items=['DATA','first','lbound','ubound','Growth','Yield','LIAB','desiredturnover','maxrisk','COV','NumberYears']
        for line in file.readlines():
            line=sub('[#;].*','',line)  #get rid of comments; these are designated by # or ;
            line=line.strip()           #get of spaces at beginning and end of a line
            line=sub(',*$','',line)     #get rid of ,,,,,,,,,,,, at the end of a line
            if line in items:
                item=line
                setattr(self,line,[])
            elif len(line)>0:
                if item in ['Growth','Yield']:
                    getattr(self,item).append(numline(split(sep,line)))
                elif item in ['desiredturnover','maxrisk']:
                    setattr(self,item,numline(split(sep,line))[0])
                elif item in ['COV']:
                    for i in numline(split(sep,line)):
                        getattr(self,item).append(i)
                else:
                    setattr(self,item,numline(split(sep,line)))

if __name__ == '__main__':
    log=0
    meth=1  #meth determines whether to optimise gammas (meth=0) or alphas (meth=1) in the simplex optimisation
    del argv[0]
    while len(argv) and argv[0].find('-')==0:
        if argv[0].find('-l')>-1:
            log=1
        elif argv[0].find('-m')>-1:
            meth=int(argv[0].replace('-m',''))
        del argv[0]
    if len(argv):
        model=DATA(open(argv[0]))
        dowindow=1
    else:
        model=DATA(stdin)
        argv.append('stdin')
        dowindow=0

    if len(model.Growth) != len(model.Yield) or len(model.LIAB) != len(model.Growth):raise 'DATA ERROR in Growth,Yield, LIAB data'
    if hasattr(model,'NumberYears'):
        if len(model.NumberYears) != len(model.LIAB):raise 'DATA ERROR wrong amount of data in NumberYears'
        model.NumberYears=numline(model.NumberYears,int)
    else:
        setattr(model,'NumberYears',[])
        

    Growthn=listlist2list(model.Growth)
    Yieldn=listlist2list(model.Yield)
    title='Multi-stage optimisation results'
    if jython:
        wout=array([0]*len(model.LIAB)*len(model.DATA),'d')
        win=array([0]*len(model.LIAB)*len(model.DATA),'d')
        wreb=array([0]*len(model.LIAB)*len(model.DATA),'d')
        risks=array([0]*len(model.LIAB),'d')
    else:
        wout=[]
        win=[]
        wreb=[]
        risks=[]

    
    back = multistage(len(model.DATA),len(model.LIAB),wout,win,wreb,risks,Growthn,Yieldn,model.LIAB,model.lbound,model.ubound,model.DATA,
          model.COV,model.first,model.desiredturnover,model.maxrisk,model.NumberYears,meth,log)
    
    mask=[1]*len(model.DATA)
    for i in range(len(model.DATA)):
        if model.DATA[i]=='CASH':mask[i]=0
    for year in range(len(model.LIAB)):
        print '\t\t\tPeriod %d'%(year+1)
        print '%20s\t%20s\t%20s\t%20s'%('Asset','Initial','Rebalanced','Evolved')
        initialvalue=0
        finalvalue=0
        for i in range(len(model.DATA)):
            initialvalue+=win[i+year*len(model.DATA)]
            finalvalue+=wout[i+year*len(model.DATA)]
            print '%20s\t%20.4f%20.4f\t%20.4f'%(model.DATA[i],win[i+year*len(model.DATA)],wreb[i+year*len(model.DATA)],wout[i+year*len(model.DATA)])
        print 'Initial Wealth\t\t%20.4f'%(initialvalue)
        print 'Evolved Wealth\t\t%20.4f'%(finalvalue)
        print '(less liability)\t%20.4f'%((finalvalue-model.LIAB[year]))
        print 'Risk\t\t\t\t%20.8e'%risks[year]
        print 'Turnover\t\t\t%20.8e'%(turnover(win,wreb,mask,year*len(model.DATA),len(model.DATA))/initialvalue)
    print MultiStageMessage(back)

    if dowindow:
        if jython:
            import javax.swing as swing
            import java

            class MyFrame(swing.JFrame):
                def __init__(self):
                    swing.JFrame.__init__(self,size=(700,400),title=title,
                                          defaultCloseOperation = swing.JFrame.EXIT_ON_CLOSE)
                    quitter=swing.JButton('Quit (I wonder if this would shut down CURVE?)',
                                          actionPerformed=lambda t:java.lang.System.exit(0))
                    self.display=swing.JTextArea(editable=0)
                    self.status=swing.JTextArea(editable=0)
                    self.display.setFont(java.awt.Font('monospaced',0,12))
                    pane=swing.JScrollPane(self.display)
                    self.getContentPane().add(pane,java.awt.BorderLayout.CENTER)
                    self.getContentPane().add(self.status,java.awt.BorderLayout.NORTH)
                    self.getContentPane().add(quitter,java.awt.BorderLayout.SOUTH)
                    
                    

            frame=MyFrame()
    #        font=frame.display.getFont()
    #        print 'Font name ',font.getFontName()

            for year in range(len(model.LIAB)):
                frame.display.append('                                  Period %d\n'%(year+1))
                frame.display.append('  %20s%20s%20s%20s\n'%('Asset','Initial','Re-balanced','Evolved'))
                initialvalue=0
                finalvalue=0
                for i in range(len(model.DATA)):
                    initialvalue+=win[i+year*len(model.DATA)]
                    finalvalue+=wout[i+year*len(model.DATA)]
                    frame.display.append('  %20s%20.4f%20.4f%20.4f\n'%(model.DATA[i],win[i+year*len(model.DATA)],wreb[i+year*len(model.DATA)],wout[i+year*len(model.DATA)]))
                frame.display.append('  %20s%20.4f%20s%20.4f\n'%('Wealth',initialvalue,' ',finalvalue))
                frame.display.append('  Final wealth less liability %9.4f\n'%((finalvalue-model.LIAB[year])))
                frame.display.append('  Risk     %15.8e\n'%risks[year])
                frame.display.append('  Turnover %15.8e\n'%(turnover(win,wreb,mask,year*len(model.DATA),len(model.DATA))/initialvalue))
                frame.display.append('  ___________________________________________________________________________________\n')
            frame.status.append('Optimisation status: '+MultiStageMessage(back))

            frame.show()
        else:
            from Tkinter import *
            class ScrolledFrame(Frame):
                def __init__(self, prev=None,cnf={},**kw):
                    for i in kw.keys():
                        cnf[i]=kw[i]
                    Frame.__init__(self,prev,cnf)
                    text=Text(self,wrap='none')
                    sbx=Scrollbar(self,orient=HORIZONTAL)
                    sby=Scrollbar(self)
                    sbx.config(command=text.xview)
                    sby.config(command=text.yview)
                    text.config(xscrollcommand=sbx.set,yscrollcommand=sby.set,relief=SUNKEN,font='-*-Courier-Bold-R-Bold--*-120-*-*-*-*-*-*')
                    sbx.pack(side=BOTTOM,fill=X)
                    text.pack(side=LEFT,fill=BOTH,expand=YES)
                    sby.pack(side=LEFT,fill=Y)
                    self.text=text
                def printf(self,a):
                    self.text.insert(END,a)
            root = Tk()
            root.title(title)
            frame=ScrolledFrame(root,relief=SUNKEN)
            frame.text.config(width=90,height=40)
            mess=Entry(root,relief=SUNKEN)

            for year in range(len(model.LIAB)):
                frame.printf('                                         Period %d\n'%(year+1))
                frame.printf('  %20s%20s%20s%20s\n'%('Asset','Initial','Re-balanced','Evolved'))
                initialvalue=0
                finalvalue=0
                for i in range(len(model.DATA)):
                    initialvalue+=win[i+year*len(model.DATA)]
                    finalvalue+=wout[i+year*len(model.DATA)]
                    frame.printf('  %20s%20.4f%20.4f%20.4f\n'%(model.DATA[i],win[i+year*len(model.DATA)],wreb[i+year*len(model.DATA)],wout[i+year*len(model.DATA)]))
                frame.printf('  %20s%20.4f%20s%20.4f\n'%('Wealth',initialvalue,' ',finalvalue))
                frame.printf('  Final wealth less liability %9.4f\n'%((finalvalue-model.LIAB[year])))
                frame.printf('  Risk     %15.8e\n'%risks[year])
                frame.printf('  Turnover %15.8e\n'%(turnover(win,wreb,mask,year*len(model.DATA),len(model.DATA))/initialvalue))
                frame.printf('  ___________________________________________________________________________________\n')
            mess.delete(0,END)
            mess.insert(END,'Optimisation status: '+MultiStageMessage(back))

            mess.pack(expand=1,fill=X)
            frame.pack(expand=1,fill=BOTH)
            finish=Button(root,command=root.destroy,text='Finish')
            finish.pack(expand=1,fill=X)
            root.mainloop()
        
