#include "baseoptimise.h"
/*
	dqpdump prints quantities defining the quadratic function
	given to dqpcore i.e. qphess
*/
void Base_Optimise::dqpdump(dimen n, dimen nrowh, dimen ncolh, vector cvec, real *hess, vector wrk, vector hx)
{
	dimen	j, i;

	lm_wmsg("\n\n\n\n\n\nOUTPUT FROM QPDUMP\n******************");
	lm_mdvwri("\nCVEC ...", n, cvec);

	/*PRINT  HESS  UNLESS IT APPEARS TO BE IMPLICIT. */
	lm_wmsg("\nNROWH =%6ld NCOLH =%6ld", CL(nrowh), CL(ncolh));
	if(nrowh > 1 || ncolh > 1) {
		if (ncolh == 1) lm_mdvwri("\nHESS ...", nrowh, hess);
		else	{
			i = min(ncolh,n);
			for (j = 1; j <= i; ++j) {
				lm_wmsg("\nCOLUMN%6ld OF  HESS ...", CL(j));
				lm_gdvwri(i, hess+j-1, CI(nrowh));
				}
			}
		}
	/*CALL  QPHESS  TO COMPUTE EACH COLUMN OF THE HESSIAN. */
	lm_wmsg("\n\n THE FOLLOWING IS RETURNED BY  QPHESS.");
	dzerovec(n, wrk);
	for (j = 1; j <= n; ++j) {
		wrk[i=j-1] = 1.;
		qphess(n, nrowh, ncolh, j, hess, wrk, hx);
		lm_wmsg("\nCOLUMN%6ld FROM  QPHESS ...",CL(j));
		lm_dvwrit(n, hx);
		wrk[i] = 0.;
		}
}
