#!/usr/bin/env python
#Colin Smith
#July 29th. 2005
#Maximise return subject to budget constraint and risk constraint using SOCP

from sys import stdin
from re import sub
from Opt import *
def getcov(file=stdin):
    Q=[]
    n=0
    while 1:
        line=file.readline()
        if not len(line):break
        line=sub(',*$','',line.strip())
        Q+=[float(i) for i in line.split(',')]
        n+=1
    return (n,Q)
        

    
(n,Q)=getcov(open('covafterf.csv'))
m=1+n+1
md=[1]+[2]*(n)+[n+1]
md=[2]+[2]*(n)+[n+1]
c=[-(i+1)*.0001 for i in range(n)]
L=[0]*n
U=[1]*n
U[-1]=.3
L[0]=.1
A=[-1]*n
A+=[0]*n
for i in range(n):#bounds on w
    s=[0]*n
    s[i]=1
    A+=s
    A+=[0]*n
rQ=[]
rQm1=[]
RootProcessQ(n,Q,rQ,rQm1)
#rQ=rootQ(n,Q)
A+=rQ
A+=[0]*n
err=.4e-3
ss=[]
for i in range(n):
    ss.append(-(U[i]+L[i])*.5)
    ss.append((U[i]-L[i])*.5)
b=[1]+ss+[0]*n+[.02]
b=[1-err,err*.5]+ss+[0]*n+[.02]
w=[]


opt=Opt()
opt.log=0
for i in ['n','m','md','c','A','b','Q']:setattr(opt,i,eval(i))

opt.SOCPopt()    
print opt.w,sum(opt.w),dot(opt.w,c)
y=[0]*n
Sym_mult(n,Q,opt.w,y)
opt.nfac=-1
opt.risks()

#Checks
print dot(opt.w,y),pow(dot(opt.w,y),.5),opt.arisk
S=[]
for i in range(n):
    for j in range(i+1):
        S.append(rQ[i+n*j])

Sym_mult(n,S,opt.w,y)
print dot(y,y)
