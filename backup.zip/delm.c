/*
	If  orthog  is true, delm  applies a plane rotation.  otherwise,
	elm computes the transformation (x y)*e  and returns the result
	in  (x y),  where the 2 by 2 matrix  e  is defined by  cs  and  sn 

	as follows...
	e  = 	( 1  sn )	if  cs>0 else	e  =	(     1 )
		(     1 )				( 1  sn )
*/
#include "ldefns.h"

void delm(int orthog, dimen n, vector x, increment incx, vector y, increment incy, real cs, real sn)
{
	if(!orthog){
    		if(cs <= 0) dswap(n, x, incx, y, incy);
    		if(sn != 0) BITA_daxpy(n, sn, x, incx, y, incy);
    		}
	else dsymplanerotate(n, x, incx, y, incy, cs, sn);
}
