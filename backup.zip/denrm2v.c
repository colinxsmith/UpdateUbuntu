#include "ldefns.h"
/*
	returns the value of || x - y || for n-vectors x and y

	here || . || is the standard 2 norm
*/

real denrm2vec(dimen n, vector x, vector y)
{
    	real ssq;
	if (n == 1){
		ssq = *x - *y;
		return (ssq<0.0 ? -ssq : ssq);
		}
	else if(n>0){
		real absxi, d, scale = 0.0;
		ssq=1.0;
		while(n--){
			absxi = *x++ - *y++;
			if(absxi==0) continue;
			if(absxi<0) absxi = -absxi;
			if(scale < absxi){
				/* Computing 2nd power */
		    		d = scale / absxi;
		    		ssq = ssq * (d * d) + 1;
		    		scale = absxi;
				}
			else	{
				/* Computing 2nd power */
				d = absxi / scale;
				ssq += d * d;
				}
			}
		return sc_norm(scale, ssq);
    		}
	else	return 0.0;
}
