#!/usr/bin/env python

from Opt import *
"""
extern "C" int SOCPopt(size_t n,size_t m,size_t *md,vector c,vector A,vector b,vector w)
"""
norm=lambda x:pow(dot(x,x),.5)

"""
Solve the SOCP

min c.w len(w)=n
st
sum(w)<=1
|w|<=1.5

that is we are minimising the linear term such that the sum of the variables is at most 1
and the length of the w vector is at most 1.5.

First try to find a feasible starting point by solving
min c'.w len(w)=n+1
sum(w)<=1
|w|<=1.5

where c' = [0]*n+[1]
For the original problem to be feasible the optimum value of w[n] must be negative.
w[0].....w[n-1] are then feasible for the original problem.
"""
n=10
m=2
md=[1]+[n+1]
c=[0]*(n-1)+[1]
A=[1]*n
for i in range(n):
    s=[0]*n
    s[i]=1
    A+=s
A+=[0]*n
b=[-1]+[0]*n+[1.5]
w=[0]*(n-1)+[1.1]

SOCPopt1(n,m,md,c,A,b,w,1e-2,10)
print w,sum(w),norm(w)

del w[-1]
n=9
m=2
md=[1]+[n+1]
c=[(i+1) for i in range(n)]
A=[1]*n
for i in range(n):
    s=[0]*n
    s[i]=1
    A+=s
A+=[0]*n
b=[-1]+[0]*n+[1.5]

SOCPopt1(n,m,md,c,A,b,w,1e-2,10)
print w,sum(w),norm(w)
