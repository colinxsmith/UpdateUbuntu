#!/bin/env python

class asset:
    n=0
    w=[]
    def __init__(self,n,w):
        for i in ['w','n']:setattr(self,i,eval(i))
    def __str__(self):
        back=''
        for i in range(self.n):back+= '\nAsset Class %4d\t%-.8e'%((i+1),self.w[i])
        return back
    def value(self):
        return sum(self.w)
def TotalAssetValue(funds,i):
    val=0
    for fund in funds:val+=fund.w[i]
    return val
def TotalValue(funds):
    val=0
    nf=len(funds)
    for i in range(nf):val+=funds[i].value()
    return val
def report(np,nf,initial):
    RPF=[None]*nf
    print '+++++ %d Funds\t\t\t%d Asset Classes +++++++++'%(nf,np)
    for i in range(nf):RPF[i]=asset(np,initial[i*np:i*np+np])
    print '\n'
    for i in range(np):print 'Asset %4d Value\t%-.8e'%((i+1),TotalAssetValue(RPF,i))
    for i in range(nf):
        print '\nFund %4d'%(i+1)
        print RPF[i]
        for j in range(RPF[i].n):print 'Asset Class %d weight\t%-.8e'%((j+1),RPF[i].w[j]/TotalAssetValue(RPF,j))
        print 'Value %-.8e\n__________'%RPF[i].value()
    print '\nTotal Value %-.8e'%TotalValue(RPF)

nf=5
np=10
targetvalue=1.0
target=[float(i)+1 for i in range(nf*np)]
ss=sum(target)
target=[targetvalue*i/ss for i in target]
report(np,nf,target)
from Opt import *
V=100
O=Opt()
O.n=nf*np
ij=0
Q=[0]*((np*nf)*(np*nf+1)/2)
for i in range(nf*np):
    for j in range(i+1):
        if i==j:Q[ij]=1
        ij+=1
O.Q=Q
O.m=nf*np+1
A=[0]*(O.n*O.m)
for i in range(O.n):
    A[O.m*i]=1
    for j in range(nf*np):
        if i%np==j%np:A[O.m*i + j + 1] = -0.25
        else:A[O.m*i + j + 1] = 0
        if j==i:A[O.m*i + j + 1] += 1
O.A=A
O.L=[0]*(O.n)+[targetvalue]+[-1]*(O.m-1)
O.U=[V]*(O.n)+[V]+[0]*(O.m-1)
O.bench=target
O.nfac=-1
O.gamma=0
O.log=1
print Return_Message(O.opt())
report(np,nf,O.w)


print Return_Message(OptFundClass(nf,np,target,targetvalue,V,O.w,0.25,1))       
report(np,nf,O.w)
