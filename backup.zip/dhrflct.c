#include "ldefns.h"

/*
	dhhrflctgen generates details of a householder reflection, p, such that
		p*( alpha ) = ( beta ),   p'*p = i
		  (   x   )   (   0  )

	p is given in the form
		p = i - ( 1/z( 1 ) )*z*z',

	where z is an ( n + 1 ) element vector
	z( 1 ) is returned in z1. if the elements of x are all zero, or if
	the elements of x are all less than tol*abs( alpha ) in absolute
	value, then z1 is returned as zero and p can be taken to be the
	unit matrix. otherwise z1 always lies in the range ( 1.0, 2.0 )
	if tol is not in the range ( 0.0, 1.0 ) then the value 0.0 is used in
	place of tol
	the remaining elements of z are overwritten on x and beta is
	overwritten on alpha
*/
void dhhrflctgen(integer *n, real *alpha, real *x, integer *incx, real *tol, real *z1)
{

    real beta, work[1];
    real scale, tl, ssq;

    --x;

    if (*n < 1) {
	*z1 = 0;
    } else {
	if (*tol <= 0 || *tol > 1) {
	    tl = 0;
	} else {
	    tl = fabs(*alpha) * *tol;
	}
	ssq = 1;
	scale = 0;
	dsssq(*n, &x[1], *incx, &scale, &ssq);
	if (scale == 0 || scale < tl) {
	    *z1 = 0;
	} else {
	    if (*alpha != 0) {
		work[0] = *alpha;
		dsssqvec(1, work, &scale, &ssq);
		beta = -dsign(sc_norm(scale, ssq), *alpha);
		*z1 = (beta - *alpha) / beta;
	    } else {
		beta = -sc_norm(scale, ssq);
		*z1 = 1;
	    }
	    BITA_dscal(*n, -1/beta, &x[1], *incx);
	    *alpha = beta;
	}
    }
}
