#include "ldefns.h"
void wdinky(char *name, real ztgnrm, real dinky)
{
    lm_wmsg("\n//%s//         ZTGNRM         DINKY\n//%s//%14.5lg%14.5lg",
	name,name,ztgnrm,dinky);
}
