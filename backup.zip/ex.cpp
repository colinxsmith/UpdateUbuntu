#include<iostream>
#include<string>
using namespace std;

class Tester
{
public:
	Tester(string a,int b);
	string mess;
	int value;
};
Tester::Tester(string a,int b)
{
	mess=a;
	value=b;
}
int main(int aa,char** bb)
{
	int i = 0;
	cout << aa << " " << bb[1] << endl;
	if(aa > 1)
		i = atoi(bb[1]);
	try
	{
		if(i == 2)
			throw Tester("Error here",i);
	}
	catch(Tester ee)
	{
		cout << ee.mess << " value =(char*)" << ee.value << endl;
		i = 1;
	}
	cout << "i =(char*)" << i << endl;
	return(0);
}
