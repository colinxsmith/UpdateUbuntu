#include "ldefns.h"


/*
	if numinf > 0,	lpgrad	finds the number and weighted sum of
	infeasibilities for the bounds and linear constraints. an
	appropriate gradient vector is returned in  grad
	if numinf = 0,	and if an lp problem is being solved,  grad  will
	be loaded with the true linear objective
	positive values of  istate(j)  will not be altered.  these mean
	the following..

		1	   2	     3
		a*x = bl   a*x = bu   bl = bu

	other values of	 istate(j)  will be reset as follows..

		a*x < bl   a*x > bu	a*x free
		- 2	    - 1		0
*/
void dlpgrad(	int lp, dimen n, dimen nctotl, dimen nrowa, real bigbnd, real feamin,
		integer	*numinf, real *suminf, short_vec istate, matrix a, vector bl,
		vector bu, vector cvec, vector featol, vector grad, vector x)
{

    integer j, k;
    real s, feasj;
    logical nolow, noupp;
    real weight, atx=1e9;

    --x;
    --grad;
    --featol;
    --cvec;
    --bu;
    --bl;
    a -= nrowa + 1;
    --istate;

    if (*numinf != 0) {
    *numinf = 0;
    *suminf = 0;
    dzerovec(n, &grad[1]);
    for (j = 1; j <=  (integer)nctotl; ++j) {
	/* do nothing if the variable or constraint is at a bound */
	if(istate[j] > 0) goto L60;
	feasj = featol[j];
	nolow = bl[j] <= -bigbnd;
	noupp = bu[j] >= bigbnd;
	k = j - n;
	if (j <=  (integer)n) {
	    atx = x[j];
	}
	if (j >  (integer)n) {
	    atx = BITA_ddot(n, &a[k + nrowa], nrowa, &x[1], 1);
	}
	istate[j] = 0;
	/* see if the lower bound is violated */
	if (nolow) {
	    goto L20;
	}
	s = bl[j] - atx;
	if (s <= feasj) {
	    goto L20;
	}
	istate[j] = -2;
	weight = -feamin / feasj;
	goto L40;
	/*see if the upper bound is violated*/
L20:
	if (noupp) {
	    goto L60;
	}
	s = atx - bu[j];
	if (s <= feasj) {
	    goto L60;
	}
	istate[j] = -1;
	weight = feamin / feasj;
	/* add the infeasibility */
L40:
	++(*numinf);
	*suminf += fabs(weight) * s;
	if (j <=  (integer)n) {
	    grad[j] = weight;
	}
	if(j >  (integer)n) BITA_daxpy(n, weight, &a[k + nrowa], nrowa, &grad[1], 1);
L60:
	;
    }
    }
	/* if feasible, install true objective */
    if(lp && *numinf == 0) dcopyvec(n, &cvec[1], &grad[1]);
}
