from os import system
from Opt import *

def func(n,b):

    if n == 1:
        print    n,b[0]
        bpoint=0.5
    elif n == 2:
        print    n,b[0],b[1]
        bpoint=abs(b[1])/(1+abs(b[1]))

    maxset=int(abs(b[0]))
    print  'breakpoint =\t%-.8e'%  bpoint 
    print  'maxset =\t%-.8e'%  maxset 
    sss='BPOINT=%f;MSET=%d;export BPOINT MSET;sed "2s/\\.012/.012/" < threshlog > templog;python CURVE.py  templog >tempinp'%(bpoint,maxset)

    system( sss )

    system('grep -i "ot round" < tempinp > tempinpu')
    system('grep Utility < tempinp >> tempinpu')
    file=open('tempinpu')

    line=file.readline().strip()
    if line.find('Utility') >-1:
        utility=float(line.split()[1])
    else:utility=1000

    print utility
    return utility


N=2
mm=1
bb=1
start=[mm,bb]
xmin=[]
ynewlo=[0]
reqmin=epsget()
step=[10,1]
konvge=10
kcount=30
icount=[0]
numres=[0]
ifault=[0]
simplex(N,start,xmin,ynewlo,reqmin,step,konvge,kcount,icount,numres,ifault,func)
start=[i for i in xmin]
print 'return code %d restarts %d count %d'%(ifault[0],numres[0],icount[0])
print xmin,ynewlo[0]
print func(N,xmin)

kcount=100
step=[1,1]
simplex(N,start,xmin,ynewlo,reqmin,step,konvge,kcount,icount,numres,ifault,func)

print 'return code %d, restarts %d, count %d'%(ifault[0],numres[0],icount[0])
print xmin,ynewlo[0]
print func(N,xmin)
