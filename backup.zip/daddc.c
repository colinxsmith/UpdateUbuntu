/*
	x = y + constant for general vectors x and y
*/
#include "ldefns.h"
void daddc(dimen n, vector y, increment incy, real c, vector x, increment incx)
{
	if (!c)return;
	while(n--){
		*x = *y + c;
		y += incy;
		x += incx;
		}
}
