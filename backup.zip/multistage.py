from Opt import *

def multi(Growth,Yield,LIAB,lbound,ubound,DATA,COV,first,desiredturnover,maxrisk,NumberYears=[]):
    """
    Growth is a list of lists; Growth[t][i] is the growth in period t for asset i
    Yield is a list of lists; Yield[t][i] is the yield in period t for asset i
    LIAB is a list of liabilities for each period
    NumberYears (optional) is a list containing the number of years that each period lasts
    
    lbound and ubound are lists of asset lower and upper bounds
    DATA is a list of names of assets (one asset must be called CASH)
    COV is the asset covariance matrix in lower triangular form
    
    first is a list containing the initial weights of the assets
    desiredturnover is the desired turnover in each period optimisation
    maxrisk is the maximum allowed risk in each period optimisation
    """
    opt=Opt()
    opt.n=len(DATA)
    opt.mask=[1,1,1]
    cashnum=0
    for i in range(opt.n):
        if DATA[i]=='CASH':opt.mask[i]=0;cashnum=i
    opt.names=DATA
    opt.bench=[0]*opt.n
    nyears=len(LIAB)

    opt.nfac=-1
    opt.Q=COV
    opt.revise=1
    opt.maxrisk=maxrisk
    opt.minrisk=0
    OldValue=FinalWealth=1e23
    FirstFinalWealth=0
    Conv=1e-10
    Converged=0


    Alphas=[[]]*nyears
    Alphas[nyears-1]=[1]*opt.n
    for i in range(1,nyears):
        j=nyears-i
        ntime=1
        if NumberYears!=[]:ntime=NumberYears[j]
        Alphas[j-1]=map(lambda t:(pow((1+Growth[j][t]+Yield[j][t]),ntime)*Alphas[j][t]),range(opt.n))
    for kk in range(100):
        print '$'*20+(' Iteration %d '%kk)+'$'*20
        opt.initial=map(lambda t:t,first)
        
        for year in range(nyears):
            ntime=1
            if NumberYears!=[]:ntime=NumberYears[year]            
            opt.alpha=map(lambda t:t,Alphas[year])
            WealthFactor=map(lambda t:pow((1+Growth[year][t]+Yield[year][t]),ntime),range(opt.n))
            TotalYield=dot([Yield[year][t]*ntime for t in range(opt.n)],opt.initial)
            wealthnow=sum(opt.initial)
            SetWealth=dot(opt.initial,WealthFactor)
            if kk>0 and year<(nyears-2):
                DesiredExpectedAlpha=FinalWealth
                for i in range(year,nyears):DesiredExpectedAlpha+=LIAB[i]*Alphas[i][cashnum]
                opt.m=2
                opt.A=[1]*(opt.m*opt.n)
                for i in range(opt.n):
                    opt.A[opt.m*i+1]=opt.alpha[i]
                opt.L=lbound+[SetWealth,DesiredExpectedAlpha]
                opt.U=ubound+[SetWealth,DesiredExpectedAlpha]
            elif year>=(nyears-2) or (kk==0 and year>0):
                DesiredExpectedAlpha=FirstFinalWealth
                for i in range(year,nyears):DesiredExpectedAlpha+=LIAB[i]*Alphas[i][cashnum]                
                opt.m=2
                opt.A=[1]*(opt.m*opt.n)
                for i in range(opt.n):
                    opt.A[opt.m*i+1]=opt.alpha[i]
                opt.L=lbound+[SetWealth,0]
                opt.U=ubound+[SetWealth,DesiredExpectedAlpha]
            else:
                opt.m=1
                opt.A=[1]*opt.n
                opt.L=lbound+[SetWealth]
                opt.U=ubound+[SetWealth]
            opt.L[cashnum]=LIAB[year]
            opt.delta=desiredturnover*wealthnow
            opt.gamma=.9999
            opt.log=0

            back=opt.opt()
            print opt.returnmessage
            print '%20s %20s %20s %20s'%('Asset Class','Initial','Final','Alphas used')
            for i in range(opt.n):
                print '%20s %20.8e %20.8e %20.8e'%(opt.names[i],opt.initial[i],opt.w[i],opt.alpha[i])

            opt.props()
            EWealth=opt.rreturn
            for i in range(year,nyears):
                EWealth-=LIAB[i]*Alphas[i][cashnum]

            print 'Initial Wealth\t\t%20.8e'%sum(opt.initial)
            print 'Wealth Now\t\t%20.8e'%sum(opt.w)
            print 'Wealth Less Liability\t%20.8e'%(sum(opt.w)-LIAB[year])
            print 'Gamma\t\t\t%20.8e'%opt.ogamma
            print 'Risk\t\t\t%20.8e'%opt.risk
            print 'Expected Final Wealth\t%20.8e'%EWealth
            print 'Turnover\t\t%20.8e'%(turnover(opt.w,opt.initial,opt.mask)/wealthnow)
            print 'Total Turnover\t\t%20.8e'%(turnover(opt.w,first,opt.mask))

            opt.initial=map(lambda t:t,opt.w)
            opt.initial[cashnum]-=LIAB[year]

            if year==0:FirstFinalWealth=EWealth
            if year==(nyears-1):
                OldValue=FinalWealth
                FinalWealth=EWealth
                print 'Difference %-.8e'%(FinalWealth-OldValue)
                if abs(FinalWealth-OldValue)/FinalWealth < Conv:
                    Converged=1
                    print '$'*20+(' Converged on iteration %d '%kk)+'$'*20
                    
            if back==6 or back==8 or back==9:break
        if back==6 or back==8 or back==9:break
        elif Converged:break
    if not Converged:print 'Needs more than %d iterations'%kk
        
if __name__ == '__main__':
    DATA=['CASH','EQUITIES','BONDS']
    COV=[0.085291178592080463, -0.0010384120058427593, 0.079105769342181526,
         0.00963279430037145, 0.00098092427209120481, 0.077833750263356677]
    LIAB=[.01,.02,0.1,.15]
    Growth=[[0,.06,.001],[0,.06,.01],[0,.04,.02],[0,.06,.03]]
    Yield=[[.02,.001,.02],[.02,.01,.02],[.03,.02,.02],[.02,.03,.04]]
    NumberYears=[1,2,3,0]
    lbound=[0,.2,.2]
    ubound=[.6,.6,.6]
    first=[0,.5,.5]
    desiredturnover=.15
    maxrisk=.5
    multi(Growth,Yield,LIAB,lbound,ubound,DATA,COV,first,desiredturnover,maxrisk,NumberYears)
    
