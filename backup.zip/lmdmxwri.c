#include "ldefns.h"
void lm_dmxwri(dimen n, dimen m, matrix x)
{
	dimen	i;
	for(i=0;i<n;i++) lm_gdvwri(m,x++,n);
}
