#include "ldefns.h"
void lm_mdsmxwri(const char *name, dimen n, sym_matrix S)
{
	if(n){
		lm_name_write(name,5,16);
		lm_dsmxwri(n, S);
		}
}
