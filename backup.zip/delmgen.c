#include "ldefns.h"
/*
	If orthog delmgen generates a plane rotation.  Otherwise,
	delmgen  generates an elimination transformation  E  such that
	(X Y)*E  =  (X  0)   OR   (Y  0),  depending on the relative
	sizes of  X  &  Y.
*/
void delmgen(int orthog, real *x, real *y, real *cs, real *sn)
{
	if(orthog) BITA_drotg(x, y, cs, sn);
	else	{
		*cs = 1;
		*sn = 0;
		if(*y != 0){
			if(fabs(*x) < fabs(*y)){
				*cs = 0;
				*sn = -(*x) / *y;
				*x = *y;
				}
			else	*sn = -(*y) / *x;
			}
		}
	*y = 0;
}
