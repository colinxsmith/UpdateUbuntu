#include "ldefns.h"
void lm_ivwrit(dimen n, short_vec x)
{
	dimen	i;
	for(i=0;i<n;i++)
		lm_item_write(10,"%5d",x[i]);
	__lm_item_write_count=0;
	lm_putc('\n');
}
