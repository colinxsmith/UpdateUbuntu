#! /bin/env python
from safe import *
def qmul(n,n1,n2,n3,q,x,y):
	ij=0
	for i in range(n):
		y[i]=0
		for j in range(i+1):
			y[i]+=q[ij]*x[j]
			if i!=j:y[j]+=q[ij]*x[i]
			ij+=1
	print x
	print y
Q=[1,.1,2]
x=[1,0]
y=[0,0]
qmul(2,1,1,1,Q,x,y)
print y
a=Optimise()
a.n=2
a.m=1
a.A=[1,1]
a.hmul=qmul
a.lower=[0,0,1]
a.upper=[1,1,1]
a.c=[-1,1]
a.H=[1,.1,2]
a.OptSetup(2)
print a.x
