#include <string.h>
#include "ldefns.h"
void lm_mdmxwri(const char *name, dimen n, dimen m, real *x)
{
	if(n&&m){
		lm_name_write(name,5,16);
		lm_dmxwri(n, m, x);
		}
}
