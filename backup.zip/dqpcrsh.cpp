#include "baseoptimise.h"
/*
     dqpcrsh  computes the cholesky factor  r  of the projected hessian
     z(t) h z,  given  z  and its dimensions  nfree by ncolz
     if the projected hessian is indefinite, a smaller cholesky
     factorization  r1(t) r1 = z1(t) h z1  is returned, where  z1  is
     composed of  ncolr  columns of  z.  column interchanges are
     used to maximize  ncolr.  these are applied to  z
*/
dimen Base_Optimise::dqpcrsh(int unitq, dimen n, dimen ncolz, dimen nfree, dimen *nhess, dimen Nq, dimen nrowh, dimen ncolh, dimen Nrowrt, short_vec kfree, real *hsize, real *hess, matrix rt, vector scale, matrix zy, vector hz1, vector wrk)
{

#ifdef	__SYSNT1__
	MSG	message;
#endif
	dimen	zy_offset;
	real	dmin_, dmax_, d, t;
	dimen	i, j, k, kmax, ksave, jthcol, ncolr;


	if (ncolz == 0) return 0;
	--wrk;
	zy_offset = Nq + 1;
	zy -= zy_offset;
	--scale;
	rt -= Nrowrt + 1;
	--kfree;
	ncolr = 0;
	/*
	compute  z(t) h z  and store the upper-triangular symmetric part
	in the first  ncolz  columns of  rt
	*/
	for (k = 1; k <= ncolz; ++k) {
#ifdef	__SYSNT1__
	if(PeekMessage(&message,NULL,0,0,PM_REMOVE))
	{
		lm_fflushall();
		switch(message.message)
		{
/*		case WM_NULL:
		case 4167:message when using COM and close
			lm_wmsg((char*)"qp message %d %d %d %d",message.message,WM_LBUTTONUP,WM_KEYDOWN,WM_LBUTTONDOWN);
			exit(14);*/
		case WM_LBUTTONUP:
		case WM_RBUTTONUP:
		case WM_LBUTTONDOWN:
		case WM_RBUTTONDOWN:
		case WM_KEYDOWN:
			break;
		default:
			TranslateMessage(&message);
			DispatchMessage(&message);
		}
	}
#endif
		dzerovec(n, &wrk[1]);
		if( !unitq){
			/* expand the column of  z  into an  n-vector */
			for (i = 1; i <= nfree; ++i) {
	    			j = kfree[i];
	    			wrk[j] = zy[i + k * Nq];
				}
			if(scldqp) ddmxmulv(n, &scale[1], 1, &wrk[1], 1);
			jthcol = 0;
			}
		else	{
			/*
	       		only bounds are in the working set.  the  k-th column of  z is
	       		just a column of the identity matrix
			*/
			jthcol = kfree[k];
			wrk[jthcol] = 1;
			}
		/*set  rt(*,k)  =  top of   h * (column of  z)*/
		qphess(n, nrowh, ncolh, jthcol, hess, &wrk[1], hz1);
		++(*nhess);
		if(unitq && scldqp) dscalvec(n, scale[jthcol], hz1);
		if(scldqp) ddmxmulv(n, &scale[1], 1, hz1, 1);
		dzyprod(4, n, nfree, ncolz, nfree, Nq, unitq, &kfree[1], &kfree[1],
			hz1, &zy[zy_offset], &wrk[1]);
		dcopyvec(ncolz, hz1, &rt[k * Nrowrt + 1]);
		/*update an estimate of the size of the projected hessian*/
		t = fabs(rt[k + k * Nrowrt]);
		if( t > *hsize ) *hsize = t;
		}
	/*
	     form the cholesky factorization  r(t) r  =  z(t) h z  as far as
	     possible, using symmetric row and column interchanges
	*/
	dmin_ = lm_eps * *hsize;
	for (j = 1; j <= ncolz; ++j){
		/*FIND THE MAXIMUM REMAINING DIAGONAL*/
		kmax = j;
		dmax_ = rt[j + j * Nrowrt];
		for (k = j; k <= ncolz; ++k) {
	    		d = rt[k + k * Nrowrt];
	    		if (dmax_ < d) {
	    			dmax_ = d;
	    			kmax = k;
	    			}
			}
		/*see if the diagonal is big enough*/
		if (dmax_ <= dmin_) break;
		ncolr = j;
		/*permute the columns of z*/
		if(kmax != j) {
			if(!unitq) {
				dcopyvec(nfree, &zy[kmax * Nq + 1], &wrk[1]);
				dcopyvec(nfree, &zy[j * Nq + 1], &zy[kmax * Nq + 1]);
				dcopyvec(nfree, &wrk[1], &zy[j * Nq + 1]);
				}
			else	{
				/*Z is not stored explicitly*/
				ksave = kfree[kmax];
				kfree[kmax] = kfree[j];
				kfree[j] = ksave;
				}
			/*interchange rows and columns of the projected hessian*/
#if	1
			dswapvec( j, &rt[1+kmax*Nrowrt], &rt[1+j*Nrowrt]);
			dswap(kmax-j+1,&rt[j+kmax*Nrowrt], 1, &rt[j+j*Nrowrt], Nrowrt );
			dswap(ncolz+1-kmax,&rt[kmax+kmax*Nrowrt], Nrowrt, &rt[j+kmax*Nrowrt], Nrowrt );
#else
			for (i = 1; i <= j; ++i) {
	    			t = rt[i + kmax * Nrowrt];
	    			rt[i + kmax * Nrowrt] = rt[i + j * Nrowrt];
	    			rt[i + j * Nrowrt] = t;
				}
			for (k = j; k <= kmax; ++k) {
	    			t = rt[k + kmax * Nrowrt];
	    			rt[k + kmax * Nrowrt] = rt[j + k * Nrowrt];
	    			rt[j + k * Nrowrt] = t;
				}
			for (k = kmax; k <= ncolz; ++k) {
	    			t = rt[kmax + k * Nrowrt];
	    			rt[kmax + k * Nrowrt] = rt[j + k * Nrowrt];
	    			rt[j + k * Nrowrt] = t;
				}
#endif
			rt[kmax + kmax * Nrowrt] = rt[j + j * Nrowrt];
			}
		/*set the diagonal element of R*/
		d = sqrt(dmax_);
		rt[j + j * Nrowrt] = d;
		if (j == ncolz) continue;
		/*
		set the above-diagonal elements of the k-th row of  r,
		and update the elements of all remaining rows
		*/
		i = j + 1;
		for (k = i; k <= ncolz; ++k) {
	    		t = rt[j + k * Nrowrt] / d;
	    		rt[j + k * Nrowrt] = t;
			/*R(I,K)  =  R(I,K)  - T * R(J,I),   I = i, k. */
	    		if (t != 0) BITA_daxpy(k-j, -t, &rt[j+i*Nrowrt],Nrowrt,&rt[i+k*Nrowrt], 1);
			}
		}
	if(ncolr != ncolz &&msg>=80 )
		lm_wmsg((char*)"\n//QPCRSH//  INDEFINITE PROJECTED HESSIAN.\n//QPCRSH// NCOLR=%6ld      NCOLZ=%6ld",
			CL(ncolr),CL(ncolz));
	return ncolr;
}
