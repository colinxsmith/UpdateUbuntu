/*

	clockit(1)	Start Timer return 0.0
	clockit(0)	Return Elapsed Time as seconds

	Unfortunately this routine has to have a state since we have systems
	eg DEC mips RISC architecture which wrap around real quick. I.e. we
	overflow the (32bit?) counter of nano-secs.

	Also some dumbo systems don't have POSIX/ANSI headers.
*/
#include "ldefns.h"
#ifdef	sun
#	define CLOCKS_PER_SEC 1000000
#	if defined(__svr4__)
#		define ulong Ulong
#		define ushort Ushort
#	endif
#endif
#ifdef	MSDOSS
#	define CLOCKS_PER_SEC 1000
#endif
#include <time.h>
static	double	seconds;
static	clock_t	t0;

double clockit(int start)
{
	clock_t	t = clock();
	if(!start)
		/*we are getting difference since we started*/
		seconds += CD(t-t0)/CLOCKS_PER_SEC;
	else	/*we're resetting*/
		seconds = 0;
	t0 = t;
	return seconds;
}
