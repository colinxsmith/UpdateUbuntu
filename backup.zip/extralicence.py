#! /bin/env python
"""
Colin 17-3-2003 Python script to ease the multi validation task
"""

from Tkinter import *
from os import system,sep
if sep == '\\':
    licfile='c:/safeqp2.dll'
else:
    licfile='~/.safeqp2.so'
class ScrolledText(Frame):
    """Scrolled Text class. 
    """
    def __init__(self, prev=None,cnf={},**kw):
        for i in kw.keys():
            cnf[i]=kw[i]
        Frame.__init__(self,prev,cnf)
        text=Text(self,wrap='none')
        sbx=Scrollbar(self,orient=HORIZONTAL)
        sby=Scrollbar(self)
        sbx.config(command=text.xview)
        sby.config(command=text.yview)
        text.config(xscrollcommand=sbx.set,yscrollcommand=sby.set,relief=SUNKEN,
                    font='-*-Courier-Regular-R-Regular--*-140-*-*-*-*-*-*')
        sbx.pack(side=BOTTOM,fill=X)
        text.pack(side=LEFT,fill=BOTH,expand=YES)
        sby.pack(side=LEFT,fill=Y)
        self.text=text
class Info(Frame):
    def __init__(self,root,name,cnf={},**kw):
        """Associate a text entry with a label"""
        for i in kw.keys():
            cnf[i]=kw[i]
        Frame.__init__(self,root,cnf)
        l=Label(self,bg='#33ee22',text=name,justify=LEFT,anchor=W)
        l.config(width=12,relief=SUNKEN)
        l.pack(side=LEFT)
        ents=Entry(self,bg='#dddd22')
        ents.config(relief=SUNKEN)
        ents.pack(side=LEFT)
        self.ents=ents
        self.l=l

components=['Data Loader','Data Manager','ADI Builder','Portfolio Generator','Backtester',
            'Optimiser','Easy Reporter','Reporter and Grapher','TASC']
top=Tk()
base = Frame(top)
top.title('Multihost Validation')
F1=Frame(base)
F2=Frame(base)
atribs={}
comps={}
comps['Start']='Now'
comps['Stop']='+28'
comps['Hosts'] = ''

for iii in 'Start Stop Hosts'.split():
    atribs[iii] = Info(F1,iii)
    atribs[iii].ents.insert(0,comps[iii])
    atribs[iii].pack()

for iii in components:    
    atribs[iii] = Info(F2,iii)
    atribs[iii].l.config(width=20,relief=FLAT,bg='grey')
    atribs[iii].ents.config(width=1,relief=SUNKEN,bg='white')
    atribs[iii].ents.insert(0,'0')
    atribs[iii].pack()

F1.pack(fill=X,expand=1)
F2.pack()

def doall(a):
    for iii in components:
        atribs[iii].ents.delete(0,END)
        atribs[iii].ents.insert(0,a)
def do1():
    doall('1')
def do0():
    doall('0')
def doit():
    hosts=atribs['Hosts'].ents.get().lower()
    if hosts.lower().find('everywhere') != -1:
        hosts='13101955'
    keys=''
    for iii in components:
        keys+=atribs[iii].ents.get()
    
    keynum=long(keys,2) + 512
    print hosts.replace(' ','').replace('-','')
    fh=open('hfile','w')
    fh.writelines(hosts.replace(' ','').replace('-',''))
    fh.close()
    print('hostlist -w %s %s %d < hfile > %s' %
            (atribs['Start'].ents.get().replace('-','/'),atribs['Stop'].ents.get().replace('-','/'),keynum,licfile))
    system('hostlist -w %s %s %d < hfile > %s' %
            (atribs['Start'].ents.get().replace('-','/'),atribs['Stop'].ents.get().replace('-','/'),keynum,licfile))
    
checktext=ScrolledText(top)
checktext.text.config(width=40)

def checker():
    print('hostlist -r < %s > checked.txt'%licfile)
    system('hostlist -r < %s > checked.txt'%licfile)
    fh=open('checked.txt')
    checktext.text.delete(1.0,END)
    for iii in fh.readlines():
        checktext.text.insert(END,iii)
    fh.close()
    
    
Button(base,command=do0,text='All to 0',bg='green').pack(fill=X)
Button(base,command=do1,text='All to 1',bg='green').pack(fill=X)
Button(base,command=doit,text='Validate',bg='yellow').pack(fill=X)
Button(base,command=checker,text='Check',bg='yellow').pack(fill=X)
Button(base,command=top.destroy,text='Quit',bg='red').pack(fill=X)

base.pack(side=LEFT,fill=Y)
checktext.pack(side=RIGHT)

top.mainloop()
