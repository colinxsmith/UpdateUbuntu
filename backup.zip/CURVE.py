#!/bin/env python
"""
Colin 30-8-2002
Python program for running an optimisation/risk report using a COR-RS Curve output trace log
as input

Run this by typing:
python CURVE.py logfile1 logfile2 .......
for as many logs as you like (don't put the trailing dots in!)

Modified for Tkinter 29-01-2003
Modified for new optimiser 17-9-2003

Now does full covariance properly 19-9-2003

Piece-wise cost support 2004

With jython use Opt to use Double and Integer for receiving array values (via safajavajy),
or use Optn to use double and int (via safejava) 17-6-2005

Ironpython support July 2009  (Optd.py)
"""
try:
    import clr# must be ironpython!
    from Optd import *
except:
    from Optn import *
        
import getf,sys
from math import sqrt
from time import localtime, strftime
annorm=252
annorm=1
annorm=12
#annorm=52

def wprint(relrisk):
    weights=[]
    na=relrisk.n-relrisk.ncomp
    for i in range(na):
        weights.append(relrisk.w[i])
        for j in range(relrisk.ncomp):
            weights[i]+=relrisk.w[na+j]*relrisk.Composites[i+na*j]
        print ('%30s,%15.8e'%(relrisk.names[i],weights[i]))

def oxprintmat(a,name):
    """Generate a file containing a float list in Ox matrix format for list a"""
    name=name+'.mat'
    length=len(a)
    if length<=0:return
    file=open(name,'w')
    file.write('%d 1\n' % length)
    for i in a:file.write('%-.16e\n' % i)
    file.close()

del sys.argv[0] #This will be the string CURVE.py
#sys.argv.append('-f')
#sys.argv.append('ntround.log')
OxPrint=0
DoParity=0
DoSharp=0
Forms=0
logout=0
costfilel='pcosts.log'
for arg in sys.argv:
    if arg == '-ox':OxPrint=1;continue
    if arg == '-f':Forms=1;continue
    if arg == '-p':DoParity=1;continue
    if arg == '-s':DoSharp=1;continue
    if arg.find('-c')==0:costfilel=arg.replace('-c','');print ('Cost file',arg);continue
    if arg.find('-l')==0:logout=arg.replace('-l','');continue
    if Forms==0:print ('Use -f option to get GUI interface')
    print ('-ccostfile to introduce piece-wise costs (no spaces). Set npiece to -1')
    print (arg)
    a=getf.datin()
    a.getBITA5(arg)
    
    #for i in dir(a):print i,getattr(a,i)
    print( version())
    relrisk=Opt()

    relrisk.n=n=a.numAssets
    relrisk.nfac=a.numFactors
    if hasattr(a,'numCompositeAssets'):relrisk.ncomp=ncomp=a.numCompositeAssets
    try:
        if relrisk.nfac == -1:
            try:relrisk.Q=a.Q
            except:relrisk.Q=[0]*(n*(n+1)/2)
            eigval=eigen(relrisk.n-relrisk.ncomp,a.Q)[0]
            print('Eigenvalues of the covariance matrix')
            for i in range(relrisk.n-relrisk.ncomp):
                print ('%4d %20.8e'%(i+1,eigval[i]))
            if OxPrint:oxprintmat(relrisk.Q,'Q')
        elif relrisk.nfac:
            relrisk.FC=a.FC
            eigval=eigen(relrisk.nfac,a.FC)[0]
            print( 'Eigenvalues of the factor covariance matrix')
            for i in range(relrisk.nfac):
                print( '%4d %20.8e'%(i+1,eigval[i]))
            if OxPrint:oxprintmat(relrisk.FC,'FC')
            #fix_covariancem(relrisk.nfac,relrisk.FC)
    except:print( 'No risk model');pass
    ncomp = 0
    try:
        relrisk.ncomp=ncomp=a.numCompositeAssets
        Comp=[]
        if a.numCompositeAssets > 0:
            stockcount=0
            for name in a.assetNames:
                if stockcount>=(relrisk.n-relrisk.ncomp):
                    ccc=getattr(a,name)
                    #exec 'ccc = a.%s' % name
                    for i in range(ncomp):
                        del ccc[-1]
                    Comp += ccc
                stockcount+=1
        relrisk.Composites=Comp
        if OxPrint:oxprintmat(relrisk.Composites,'Composites')
    except:pass
    if OxPrint:
        oxf=open('names','w')
        for name in a.assetNames:oxf.write('%s\n'%name)
        oxf.close()
    if relrisk.nfac!=-1:
        FL=[]
        if relrisk.nfac:
            FC=[]
            for i in a.FACNAMES:
                FFL=getattr(a,i)
                for i in range(ncomp):
                    del FFL[-1]
                FL+=FFL
            try:
                if jython:FL=single2double(n,relrisk.nfac,FL)
            except:print('Using single dim list with jython');pass
            SV=a.specificVariance
        else:SV=[0]*n
        for i in range(ncomp):
            del SV[-1]
        relrisk.SV=SV
        if OxPrint:oxprintmat(relrisk.SV,'SV')
        relrisk.FL=FL
        if OxPrint:oxprintmat(relrisk.FL,'FL')
    relrisk.bench=a.benchmarkPortfolio
    if OxPrint:oxprintmat(relrisk.bench,'benchmark')
    relrisk.alpha=[i*1 for i in a.alphas]
    if OxPrint:oxprintmat(relrisk.alpha,'alpha')
    relrisk.names=a.assetNames
    relrisk.initial=a.initialPortfolio
    if OxPrint:oxprintmat(relrisk.initial,'initial')
    relrisk.buy=a.buyCost
    if OxPrint:oxprintmat(relrisk.buy,'buy')
    relrisk.sell=a.sellCost
    if OxPrint:oxprintmat(relrisk.sell,'sell')
    relrisk.m=m=a.numLinearConstraints
    A=[0]*n*m
    L=a.lowerBoundAssetWeight
    U=a.upperBoundAssetWeight
    for cc in range(m):
        aa=getattr(a,'linearConstraint'+str(cc+1))
        #exec 'aa = a.%s' % 'linearConstraint'+str(cc+1)
        for i in range(n):
            A[cc+m*i] = aa[i]
        L.append(a.lower['linearConstraint'+str(cc+1)])
        U.append(a.upper['linearConstraint'+str(cc+1)])
    try:
        if jython:A=single2double(m,n,A)
    except:print ('Using single dim list in jython');pass
    relrisk.L=L
    if OxPrint:oxprintmat(relrisk.L,'L')
    relrisk.U=U
    if OxPrint:oxprintmat(relrisk.U,'U')
    relrisk.A=A
    if OxPrint:oxprintmat(relrisk.A,'A')

       
    relrisk.gamma=a.returnParameter
    if hasattr(a,'costParameter'):relrisk.kappa=a.costParameter
    if hasattr(a,'value'):relrisk.value=a.value
    if hasattr(a,'shortbasket'):relrisk.shortbasket=a.shortbasket
    relrisk.costs=a.costsOnOff
    relrisk.delta=a.turnoverConstraint
    relrisk.basket=a.maxNumAssetsInOptimisedPortfolio
    relrisk.tradenum=a.maxNumTradesInOptimisedPortfolio
    relrisk.revise=a.reviseOnOff
    relrisk.min_holding=a.minAssetWeight
    relrisk.min_trade=a.minAssetTrade
    relrisk.ls=a.longShortOnOff
    relrisk.full=a.fullyInvested
    relrisk.rmin=a.minShortLongRatio                      
    relrisk.rmax=a.maxShortLongRatio                        
    relrisk.round=a.roundLotsOnOff
    relrisk.npoints=a.numFrontierIncrements
    relrisk.Nlong=-1
    relrisk.Nshort=-1

    try:    
        nabs=relrisk.nabs=a.numGrossWeightConstraints
        A_abs=[0]*n*nabs
        U_abs=[0]*nabs
        L_abs=[0]*nabs
        for cc in range(nabs):
            aa=getattr(a,'grossWeightContraint'+str(cc+1))
            for i in range(n):
                A_abs[cc+nabs*i] = aa[i]
            U_abs[cc]=a.upper['grossWeightContraint'+str(cc+1)]
            L_abs[cc]=a.lower['grossWeightContraint'+str(cc+1)]
        try:
            if jython:A_abs=single2double(nabs,n,A_abs)
        except:print ('Using single dim list in jython for A_abs');pass
        relrisk.A_abs=A_abs
        relrisk.Abs_U=U_abs
        relrisk.Abs_L=L_abs
    except:
        print ('Old trace file has no abs constraint setup')
        relrisk.nabs=0
        relrisk.A_abs=[]
        relrisk.Abs_U=[]
    if not hasattr(a,'isRiskConstrained'):a.isRiskConstrained='false'
    if a.isRiskConstrained == 'false':
        relrisk.riskc=0
    elif a.isRiskConstrained == 'true':
        relrisk.riskc=1
    else:
        raise 'isRiskConstrained is neither false nor true: %s'%a.isRiskConstrained

    if relrisk.riskc:    
        relrisk.maxrisk = a.maxRisk
        relrisk.minrisk = a.minRisk
#    relrisk.downrisk=1
    relrisk.downfactor=2.0/pow(annorm,0.5)
#    relrisk.minrisk=-.0316667
#    relrisk.maxrisk=6.1e-2

    relrisk.min_lot=a.minLot
    if OxPrint:oxprintmat(relrisk.min_lot,'min_lot')
    relrisk.size_lot=a.sizeLot
    if OxPrint:oxprintmat(relrisk.size_lot,'size_lot')


    root=None
    if Forms==1 and a.optimisationTechnique>-1:
        from scrolled import *
        class Info(Frame):
            def __init__(self,root,name,cnf={},**kw):
                """Associate a text entry with a label"""
                for i in kw.keys():
                    cnf[i]=kw[i]
                Frame.__init__(self,root,cnf)
                l=Label(self,bg='#33ee22',text=name,justify=LEFT,anchor=W)
                l.config(width=10,relief=SUNKEN)
                l.pack(side=LEFT)
                ents=Entry(self,bg='#dddd22')
                ents.config(width=6,relief=SUNKEN)
                ents.pack(side=LEFT)
                self.ents=ents
        class StockGraph(Frame):
            def __init__(self,root,relrisk,cnf={},**kw):
                """Plot stock, initial and trade weights"""
                for i in kw.keys():
                    cnf[i]=kw[i]
                Frame.__init__(self,root,cnf)
                self.frame=frame=ScrolledCanvas(root)
                frame.canvas.config(width=700,height=400,bg='#ffff55')
                frameb=Frame(root)
                def trades_data():
                    frame.canvas.delete(ALL)
                    np = relrisk.n
                    x=[float(i) for i in range(np)]
                    y=[relrisk.w[i] - relrisk.initial[i] for i in range(np)]
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    frame.stockplot(fill='red',title='Trades')
                    frame.canvas.postscript(file='graph.ps')
                def cost_front():
                    now=strftime('%a, %d %b %Y %H:%M:%S', localtime())
                    print ('Start at %s'%now)
                    frame.canvas.delete(ALL)
                    for i in scalarnamesI.split():
                        setattr(relrisk,i,int(scalarframes[i].ents.get()))
                    for i in scalarnamesF.split():
                        setattr(relrisk,i,float(scalarframes[i].ents.get()))
                    x=[]
                    y=[]
                    scalr=sqrt(annorm)*100
                    gscal=relrisk.gamma/(1-relrisk.gamma)
                    np=0
                    for i in range(1,20):
                        relrisk.kappa=pow(float(i)/80,4)
                        relrisk.opt()
                        relrisk.margutility()
                        relrisk.props()
                        if relrisk.gamma < 1e-8:
                            x.append(relrisk.risk*scalr)
                        else:
                            x.append((relrisk.risk*relrisk.risk*0.5-gscal*relrisk.rreturn)*annorm*100)
                        y.append(relrisk.tcost*100)
                        np+=1
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    if relrisk.gamma < 1e-8:
                        frame.plotnojoin(fill='red',title='Cost vs risk')
                    else:
                        frame.plotnojoin(fill='red',title='Cost vs risk/return utility')
                    frame.canvas.postscript(file='graph.ps')

                def front_data():
                    now=strftime('%a, %d %b %Y %H:%M:%S', localtime())
                    print( 'Start at %s'%now)
                    frame.canvas.delete(ALL)
                    for i in scalarnamesI.split():
                        setattr(relrisk,i,int(scalarframes[i].ents.get()))
                    for i in scalarnamesF.split():
                        setattr(relrisk,i,float(scalarframes[i].ents.get()))
                    #relrisk.DoByRisks=0
                    if relrisk.costs>-1:
                        """A way to put in piece-wise cost curves, with Mike Servant's format for file, i.e.
                            pgrad; length=3520
                            -9.822733333333332E-4
                            -9.195891666666666E-4
                            -8.822208333333333E-4
                            -8.378966666666667E-4
                        """
                        relrisk.costfunc=None
                        relrisk.costgrad=None
                        relrisk.costhess=None
                        if relrisk.npiece==-1:
                            print( 'Costs in file %s'%costfilel)
                            costfile=open(costfilel)
                            while(1):
                                line=costfile.readline()
                                if len(line)==0:break
                                if line.find('hpiece') >-1 or line.find('pgrad')>-1:
                                    lline=line.strip().split('=')
                                    npiece=int(lline[1])/relrisk.n
                                    pname=line.strip().split(';')[0]
                                    print( 'npiece = %d'%npiece)
                                    relrisk.npiece=npiece
                                    setattr(relrisk,pname,[])
                                else:
                                    getattr(relrisk,pname).append(float(line.strip()))
                            print( relrisk.hpiece)
                            print (relrisk.pgrad)
                    relrisk.front()
                    print( relrisk.frontrisk)
                    print( relrisk.frontrreturn)
                    np = relrisk.npoints
                    scalr=sqrt(annorm)*100
                    scalret=annorm*100
                    x=list(map(lambda t:t*scalr,relrisk.frontrisk))
                    y=list(map(lambda t:t*scalret,relrisk.frontrreturn))
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    frame.plot(fill='red',title='Return vs risk')
                    frame.canvas.postscript(file='graph.ps')
                    put_rounded_on_frontier=int(scalarframes['round'].ents.get())
                    if put_rounded_on_frontier:#compare rounded and unrounded on frontier
                        scalarframes['round'].ents.delete(0,END)
                        scalarframes['round'].ents.insert(END,'1')#rounded
                        for gamhere in [.99,.8,.7,.6,.5,.4,.3,.2,.1,.01,.001]:
                            scalarframes['gamma'].ents.delete(0,END)
                            scalarframes['gamma'].ents.insert(END,str(gamhere))
                            GetValues()
                        scalarframes['round'].ents.delete(0,END)
                        scalarframes['round'].ents.insert(END,'0')#not rounded
                        for gamhere in [.99,.8,.7,.6,.5,.4,.3,.2,.1,.01,.001]:
                            scalarframes['gamma'].ents.delete(0,END)
                            scalarframes['gamma'].ents.insert(END,str(gamhere))
                            GetValues()
                def stocks_data():
                    frame.canvas.delete(ALL)
                    np = relrisk.n
                    x=[float(i) for i in range(np)]
                    y=relrisk.w
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    ret1=retval.get()
                    r1=riskval.get()
                    u=utilval.get()
                    if 0:
                        wfile=open(arg+'w','a')
                        names=relrisk.names
                        wfile.write(ret1+'\n')
                        wfile.write(r1+'\n')
                        wfile.write(u+'\n')
                        wfile.write('Weights\n')
                        for ii in range(len(x)):
                            wfile.write('%20s %20.8e\n'%(names[ii],y[ii]))
                    frame.stockplot(fill='green',title='%s %s %s'%(ret1,r1,u))
                    frame.canvas.postscript(file='graph.ps')
                def initial_data():
                    frame.canvas.delete(ALL)
                    np = relrisk.n
                    x=[float(i) for i in range(np)]
                    y=relrisk.initial
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    frame.stockplot(fill='#dddd33',title='Initial weights')
                    frame.canvas.postscript(file='graph.ps')
                buttoni=Button(frameb,bg='#ffddaa',command=initial_data,text='initial weights')
                buttons=Button(frameb,bg='#ddaaff',command=stocks_data,text='stock weights')
                buttonfg=Button(frameb,bg='#bbaadd',command=front_data,text='frontier')
                buttonfc=Button(frameb,bg='#ddaabb',command=cost_front,text='cost frontier')
                buttont=Button(frameb,bg='#ddffaa',command=trades_data,text='trades')
                frame.pack(expand=1,fill=BOTH)
                frameb.pack(expand=1,fill=X)
                buttons.pack(expand=1,fill=X,side=LEFT)
                buttont.pack(expand=1,fill=X,side=LEFT)
                buttoni.pack(expand=1,fill=X,side=LEFT)
                buttonfg.pack(expand=1,fill=X,side=LEFT)
                buttonfc.pack(expand=1,fill=X,side=LEFT)
        root=Tk()
        root.title('Trace file %s; %s, expires %s, keys %s'%(arg,version(),expire_date(),
                                                                                     component_key()))
        scalarnamesF='gamma kappa delta min_holding min_trade rmin rmax maxrisk minrisk value zetaS zetaF ShortCostScale downfactor'
        scalarnamesI='nabs npoints ncomp nfac npiece nabs m mabs costs basket shortbasket longbasket tradenum tradebuy tradesell revise ls full round riskc DoByRisks downrisk log '
        scalarframes={}
        vals=Frame(root,relief=SUNKEN)
        vals.pack(side=LEFT)
        vals1=Frame(vals,relief=SUNKEN)
        vals2=Frame(vals,relief=SUNKEN)
        vv=Label(vals,text='Scalar values',font='-*-Arial-Bold-R-Bold--*-200-*-*-*-*-*-*')
        vv.pack(side=TOP,fill=X)
        vals2.pack(side=BOTTOM,expand=1,fill=X)
        vals1.pack(side=RIGHT,expand=1,fill=BOTH)
        retmes=Entry(vals2,bg='#ff33ee')
        riskval=Entry(vals2,bg='#33eeff')
        retval=Entry(vals2,bg='#33eeff')
        utilval=Entry(vals2,bg='#33eeff')
        costval=Entry(vals2,bg='#48debf')
        TCOST=None
        def Parity():
            relrisk.stockparity()
            relrisk.props()
            r1=relrisk.risk
            ret1=relrisk.rreturn
            print( 'annus',annorm)
            ret1*=annorm*100
            r1*=sqrt(annorm)*100
            print('Annualised percent Return %20.8e'%ret1)
            print('Annualised percent Risk %20.8e'%r1)
            for i in range(relrisk.n):
                print relrisk.w[i]*relrisk.MCTR[i],(relrisk.w[i]*relrisk.MCTR[i] - relrisk.arisk/relrisk.n)
            if r1>1e-12:print('Annualised Info or Sharp %20.8e'%(ret1/r1))
            try:
                frameg.frame.point(r1,ret1,fill='blue')
                frameg.frame.canvas.postscript(file='graph.ps')
            except:pass
            riskval.delete(0,END)
            riskval.insert(END,'risk\t%20.15e'%r1)
            retval.delete(0,END)
            retval.insert(END,'return\t%20.15e'%ret1)
            utilval.delete(0,END)
            costval.delete(0,END)
            retmes.delete(0,END)
            retmes.insert(END,relrisk.returnmessage+' use parity implied alphas now')
            relrisk.alpha=[relrisk.MCTR[i]*relrisk.arisk for i in range(relrisk.n)]
        def SharpInfo():
            relrisk.sharpinfo()
            relrisk.props()
            r1=relrisk.risk
            ret1=relrisk.rreturn
            if r1>1e-12:print('Raw Ratio %20.5f'%(ret1/r1))
            else:print('Indeterminant ratio')
            print( 'annus',annorm)
            if r1>1e-12:print('Effective gamma %20.8e'%(1./(ret1/r1/r1 + 1.)))
            ret1*=annorm*100
            r1*=sqrt(annorm)*100
            print('Annualised percent Return %20.8e'%ret1)
            print('Annualised percent Risk %20.8e'%r1)
            if r1>1e-12:print('Ratio %20.5f'%(ret1/r1))
            else:print('Indeterminant ratio')
            try:
                frameg.frame.point(r1,ret1,fill='blue')
                frameg.frame.canvas.postscript(file='graph.ps')
            except:pass
            riskval.delete(0,END)
            riskval.insert(END,'risk\t%20.15e'%r1)
            retval.delete(0,END)
            retval.insert(END,'return\t%20.15e'%ret1)
            utilval.delete(0,END)
            costval.delete(0,END)
            retmes.delete(0,END)
            retmes.insert(END,relrisk.returnmessage)
            
        def GetValues():
            #print relrisk.min_lot
            #print relrisk.size_lot
            now=strftime('%a, %d %b %Y %H:%M:%S', localtime())
            print( 'Start at %s'%now)
            for i in scalarnamesI.split():
                setattr(relrisk,i,int(scalarframes[i].ents.get()))
            for i in scalarnamesF.split():
                setattr(relrisk,i,float(scalarframes[i].ents.get()))
            extrascale=0
            if extrascale:
                month2day=(12./252.)
                month2day=12
                rootmonth2day=pow(month2day,.5)
                for i in 'alpha FC SV buy sell'.split():
                    gg=getattr(relrisk,i)
                    setattr(relrisk,i,[k*month2day for k in gg])
                relrisk.minrisk*=rootmonth2day
                relrisk.maxrisk*=rootmonth2day
                print( relrisk.maxrisk,relrisk.minrisk)
            if relrisk.costs>-1:
                """A way to put in piece-wise cost curves, with Mike Servant's format for file, i.e.
                    pgrad; length=3520
                    -9.822733333333332E-4
                    -9.195891666666666E-4
                    -8.822208333333333E-4
                    -8.378966666666667E-4
                """
                relrisk.costfunc=None
                relrisk.costgrad=None
                relrisk.costhess=None
                if relrisk.npiece==-1:
                    print( 'Costs in file %s'%costfilel)
                    costfile=open(costfilel)
                    while(1):
                        line=costfile.readline()
                        if len(line)==0:break
                        if line.find('hpiece') >-1 or line.find('pgrad')>-1:
                            lline=line.strip().split('=')
                            npiece=int(lline[1])/relrisk.n
                            pname=line.strip().split(';')[0]
                            print ('npiece = %d'%npiece)
                            relrisk.npiece=npiece
                            setattr(relrisk,pname,[])
                        else:
                            getattr(relrisk,pname).append(float(line.strip()))
                    print( relrisk.hpiece)
                    print (relrisk.pgrad)
                    if extrascale:
                        for i in 'pgrad'.split():
                            gg=getattr(relrisk,i)
                            setattr(relrisk,i,[k*month2day for k in gg])
                        
            else:
                if relrisk.costs==-2:relrisk.take_out_costs=1
                else:relrisk.take_out_costs=0
                relrisk.costs=0
                costlimit=1e-15
                def util(n,x):
                    ncost=0
                    for i in range(n):
                        w=x[i]-relrisk.initial[i]
                        if w<-costlimit:
                            ncost+=pow(-w,0.5)*relrisk.sell[i]
                        elif w>costlimit:
                            ncost+=pow(w,0.5)*relrisk.buy[i]
                        ncost+=ticket(w,(relrisk.sell[i]+relrisk.buy[i])*.005)
                    return ncost
                def modc(n,x,grad):
                    for i in range(n):
                        w=x[i]-relrisk.initial[i]
                        grad[i]=dticket(w,(relrisk.sell[i]+relrisk.buy[i])*.005)
                        if w<-costlimit:
                            grad[i]+=-0.5*relrisk.sell[i]/pow(-w,0.5)
                        elif w>costlimit:
                            grad[i]+=0.5*relrisk.buy[i]/pow(w,0.5)
                def modq(n,x,grad):
                    print( 'Update modq')
                    nn=n*(n+1)/2
                    for i in range(nn):grad[i]=0
                    for i in range(n):
                        ii=i*(i+3)/2
                        w=x[i]-relrisk.initial[i]
                        grad[ii]=ddticket(w,(relrisk.sell[i]+relrisk.buy[i])*.005)
                        if w<-costlimit:
                            grad[ii]-=0.25*relrisk.sell[i]/pow(-w,1.5)
                        elif w>costlimit:
                            grad[ii]-=0.25*relrisk.buy[i]/pow(w,1.5)
                def modch(n,w,c):
                    print( 'Piece Gradients')
                    npiece=4
                    hp=[-1,-.5,.5,1]*n
                    pg=[2*i for i in hp]
                    ShortCostScale=relrisk.ShortCostScale
                    hpstart=0
                    initial=relrisk.initial
                    for j in range(n):
                        done=0
                        scale=1
                        if w[j]<0:scale=ShortCostScale
                        if initial == []:ww=w[j]
                        else:ww=w[j]-initial[j]
                        if ww<hp[hpstart]:
                            c[j]=pg[hpstart]*scale
                            done=1
                            hpstart+=npiece
                            continue
                        for i in range(1,npiece):
                            if(ww<hp[hpstart+i] and ww>=hp[hpstart+i-1]):
                               if ww>0:c[j]=pg[hpstart+i]*scale
                               elif ww<0:c[j]=pg[hpstart+i-1]*scale
                               else:c[j]=0
                               done=1
                               break
                        if done:
                            hpstart+=npiece                
                            continue
                        c[j]=pg[hpstart+npiece-1]*scale
                        hpstart+=npiece                
                def utilh(n,w):
                    print( 'Piece Utility')
                    npiece=4
                    hp=[-1,-.5,.5,1]*n
                    pg=[2*i for i in hp]
                    ShortCostScale=relrisk.ShortCostScale
                    initial=relrisk.initial
                    hpstart=0
                    total=0
                    nstart=0
                    for j in range(n):
                        nstart=0
                        done=0
                        scale=1
                        if w[j]<0:scale=ShortCostScale
                        for i in range(npiece):#Get the first positive ordinate; we integrate from 0
                            if hp[hpstart+i]>0:nstart=i;break
                        if initial == []:ww=w[j]
                        else:ww=w[j]-initial[j]
                        if ww<=hp[nstart+hpstart] and ww>=0:
                            total+=ww*pg[nstart+hpstart]*scale
                            done=1
                            hpstart+=npiece
                            continue
                        sofar=hp[nstart+hpstart]*pg[nstart+hpstart]*scale
                        if ww>0:
                            for i in range(nstart+1,npiece):
                                if ww<hp[i+hpstart] and ww>=hp[i-1+hpstart]:
                                    total+=sofar+(ww-hp[i-1+hpstart])*pg[i+hpstart]*scale
                                    done=1
                                    break
                                sofar+=(hp[i+hpstart]-hp[i-1+hpstart])*pg[i+hpstart]*scale
                        if done:
                            hpstart+=npiece
                            continue
                        if ww>=0:
                            total+=sofar+(ww-hp[npiece-1+hpstart])*pg[npiece-1+hpstart]*scale
                            done=1
                            hpstart+=npiece
                            continue
                        if not ww<0:raise 'BIG ERROR in util'
                        sofar=0
                        for ii in range(nstart):
                            i=nstart-ii
                            usehpi=hp[hpstart+i]
                            if i == nstart:usehpi=0
                            if ww<usehpi and ww>= hp[i-1+hpstart]:
                                total+=sofar+(ww-usehpi)*pg[i-1+hpstart]*scale
                                done=1
                                break
                            sofar-=(usehpi-hp[i-1+hpstart])*pg[i-1+hpstart]*scale
                        if done:
                            hpstart+=npiece
                            continue
                        total+=sofar+(ww-hp[hpstart])*pg[hpstart]*scale
                        hpstart+=npiece
                    return total
                #relrisk.costfunc=utilh
                #relrisk.costgrad=modch
                relrisk.costfunc=util
                relrisk.costgrad=modc
                relrisk.costhess=modq
                #print 'Uniform cost ',util(relrisk.n,[1.0/relrisk.n]*relrisk.n)
                #ggg=[0]*relrisk.n
                #modc(relrisk.n,[1.0/relrisk.n]*relrisk.n,ggg)
                #print ggg
            #print '============ riskc %d =============='%relrisk.riskc
            relrisk.opt()
            #wprint(relrisk)
            relrisk.props()
            bthresh=1e-5
            if(0 and relrisk.nfac==-1 and relrisk.gamma!=0):
                relrisk.analytic()
                relrisk.OptviaSOCP()
            print( 'Basket %d (long %d short %d)'%(basketcount(relrisk.w)))
            print( 'Trades %d (buy  %d sell  %d)'%(basketcount(relrisk.w,relrisk.initial)))
            print( 'Thresh %-.8e\tBasket %d (long %d short %d)'%((bthresh,)+basketcount(relrisk.w,[],bthresh)))
            print( 'Thresh %-.8e\tTrades %d (buy  %d sell  %d)'%((bthresh,)+basketcount(relrisk.w,relrisk.initial,bthresh)))
            if relrisk.Nlong>-1 or relrisk.Nshort>-1:
                if relrisk.Nshort==-1:relrisk.Nshort=relrisk.n
                if relrisk.Nlong==-1:relrisk.Nlong=relrisk.n
                (Basket,Nlong,Nshort)=basketcount(relrisk.w)
                kL=[i for i in relrisk.L]
                kU=[i for i in relrisk.U]
                Nlongset=max(relrisk.Nlong,Nlong*.5)
                Nshortset=max(relrisk.Nshort,Nshort*.5)
                while Nlong>relrisk.Nlong or Nshort>relrisk.Nshort:
                    kp=0
                    kn=0
                    neworder=GetOrderW(relrisk.w,1,1)
                    for i in [neworder[j] for j in range(relrisk.n)]:
                        set=0
                        if kp<Nlongset and relrisk.w[i]>0:kp+=1;set=1
                        if kn<Nshortset and relrisk.w[i]<0:kn+=1;set=1
                        if set:print( kp,kn,i,relrisk.w[i]);continue
                        if kL[i]<=0 and kU[i]>=0:
                            relrisk.L[i]=0
                            relrisk.U[i]=0
                    relrisk.opt()
                    relrisk.props()
                    (Basket,Nlong,Nshort)=basketcount(relrisk.w)
                    print( 'Basket %d (long %d short %d)'%(Basket,Nlong,Nshort))
                    print( 'Trades %d (buy  %d  sell %d)'%(basketcount(relrisk.w,relrisk.initial)))
                    relrisk.L=[i for i in kL]   
                    relrisk.U=[i for i in kU]   
                    if Nlong>relrisk.Nlong:
                        Nlongset=max(relrisk.Nlong,Nlong*.5)
                    if Nshort>relrisk.Nshort:
                        Nshortset=max(relrisk.Nshort,Nshort*.5)
                                
                                
            r1=relrisk.risk
            ret1=relrisk.rreturn
            print('gamma set',relrisk.gamma,'gamma back',relrisk.ogamma)
            print( 'annus',annorm)
            ret1*=annorm*100
            r1*=sqrt(annorm)*100
            print('Annualised percent Return %20.8e'%ret1)
            print('Annualised percent Risk %20.8e'%r1)
            if r1>1e-12:print('Ratio %20.5f'%(ret1/r1))
            try:
                frameg.frame.point(r1,ret1,fill='blue')
                frameg.frame.canvas.postscript(file='graph.ps')
            except:pass
            riskval.delete(0,END)
            riskval.insert(END,'risk\t%20.15e'%r1)
            retval.delete(0,END)
            retval.insert(END,'return\t%20.15e'%ret1)
            scalarframes['gamma'].ents.delete(0,END)
            scalarframes['gamma'].ents.insert(END,str(relrisk.ogamma))
            if relrisk.ogamma<1:relrisk.gamma=relrisk.ogamma
            relrisk.margutility()
            u=relrisk.utility
            u*=annorm*100
            utilval.delete(0,END)
            utilval.insert(END,'utility\t%20.15e'%u)
            print( 'Annualised percent Utility %-.8e' % u)
            costval.delete(0,END)
            if relrisk.costs or relrisk.costfunc!=None:
                print('Annualised Cost %-.8e' % (relrisk.tcost*annorm))
                costval.insert(END,'cost\t%20.15e'%(relrisk.tcost*annorm))
            if relrisk.costs>1 or relrisk.take_out_costs==1:
                print( '1-cost %-.8e'%(1-relrisk.tcost))
            retmes.delete(0,END)
            retmes.insert(END,relrisk.returnmessage)
            
        optcom=Button(vals2,bg='#ffaadd',command=GetValues,text='Optimise')
        parcom=Button(vals2,bg='#ffaadd',command=Parity,text='Parity')
        infocom=Button(vals2,bg='#ffaadd',command=SharpInfo,text='SharpInfo')
        for i in scalarnamesI.split():
            scalarframes[i]=Info(vals,i,relief=SUNKEN)
            scalarframes[i].ents.insert(END,str(getattr(relrisk,i)))
            scalarframes[i].pack(side=TOP)
        for i in scalarnamesF.split():
            scalarframes[i]=Info(vals1,i,relief=SUNKEN)
            scalarframes[i].ents.insert(END,str(getattr(relrisk,i)))
            scalarframes[i].pack(side=TOP)
        optcom.pack(side=TOP,expand=1,fill=X)
        parcom.pack(side=TOP,expand=1,fill=X)
        infocom.pack(side=TOP,expand=1,fill=X)
        retmes.pack(side=TOP,expand=1,fill=X)
        riskval.pack(side=TOP,expand=1,fill=X)
        retval.pack(side=TOP,expand=1,fill=X)
        utilval.pack(side=TOP,expand=1,fill=X)
        costval.pack(side=TOP,expand=1,fill=X)
        frameg=StockGraph(root,relrisk)
        frameg.pack(side=LEFT)
        finish=Button(root,bg='#eeff33',command=root.destroy,text='Finish')
        finish.pack(side=RIGHT,expand=1,fill=X)
        root.mainloop()
    else:
        now=strftime('%a, %d %b %Y %H:%M:%S', localtime())
        print( 'Start at %s'%now)

        relrisk.npoints=a.numFrontierIncrements
        if a.optimisationTechnique>-1:
            if a.optimisationTechnique==2:
                relrisk.DoByRisks=1
                relrisk.front()
                print(relrisk.frontrisk)
                print(relrisk.frontrreturn)
            elif a.optimisationTechnique==1:
                relrisk.DoByRisks=0
                relrisk.front()
                print(relrisk.frontrisk)
                print(relrisk.frontrreturn)
            elif DoParity:
                relrisk.stockparity()       
                relrisk.props()
                r1=relrisk.risk
                ret1=relrisk.rreturn
                print( 'annus',annorm)
                ret1*=annorm*100
                r1*=sqrt(annorm)*100
                print('Annualised percent Return %20.8e'%ret1)
                print('Annualised percent Risk %20.8e'%r1)
                for i in range(relrisk.n):
                    print relrisk.w[i]*relrisk.MCTR[i],(relrisk.w[i]*relrisk.MCTR[i] - relrisk.arisk/relrisk.n)
                if r1>1e-12:print('Annualised Info or Sharp %20.8e'%(ret1/r1))
            elif DoSharp:
                relrisk.sharpinfo()       
                relrisk.props()
                r1=relrisk.risk
                ret1=relrisk.rreturn
                if r1>1e-12:print('Raw Ratio %20.5f'%(ret1/r1))
                else:print('Indeterminant ratio')
                if r1>1e-12:print('Effective gamma %20.8e'%(1./(ret1/r1/r1 + 1.)))
                print( 'annus',annorm)
                ret1*=annorm*100
                r1*=sqrt(annorm)*100
                print('Annualised percent Return %20.8e'%ret1)
                print('Annualised percent Risk %20.8e'%r1)
                if r1>1e-12:print('Annualised Info or Sharp %20.8e'%(ret1/r1))
            else:
                if relrisk.costs>-1:
                    relrisk.costfunc=None
                    relrisk.costgrad=None
                    relrisk.costhess=None
                else:
                    if relrisk.costs==-2:relrisk.take_out_costs=1
                    else:relrisk.take_out_costs=0
                    relrisk.costs=0
                    costlimit=1e-15
                    def util(n,x):
                        ncost=0
                        for i in range(n):
                            w=x[i]-relrisk.initial[i]
                            if w<-costlimit:
                                ncost+=pow(-w,0.5)*relrisk.sell[i]
                            elif w>costlimit:
                                ncost+=pow(w,0.5)*relrisk.buy[i]
                            ncost+=ticket(w,(relrisk.sell[i]+relrisk.buy[i])*.005)
                        return ncost
                    def modc(n,x,grad):
                        for i in range(n):
                            w=x[i]-relrisk.initial[i]
                            grad[i]=dticket(w,(relrisk.sell[i]+relrisk.buy[i])*.005)
                            if w<-costlimit:
                                grad[i]+=-0.5*relrisk.sell[i]/pow(-w,0.5)
                            elif w>costlimit:
                                grad[i]+=0.5*relrisk.buy[i]/pow(w,0.5)
                    def modq(n,x,grad):
                        print( 'Update modq')
                        nn=n*(n+1)/2
                        for i in range(nn):grad[i]=0
                        for i in range(n):
                            ii=i*(i+3)/2
                            w=x[i]-relrisk.initial[i]
                            grad[ii]=ddticket(w,(relrisk.sell[i]+relrisk.buy[i])*.005)
                            if w<-costlimit:
                                grad[ii]-=0.25*relrisk.sell[i]/pow(-w,1.5)
                            elif w>costlimit:
                                grad[ii]-=0.25*relrisk.buy[i]/pow(w,1.5)
                    def modch(n,w,c):
                        npiece=4
                        hp=[-1,-.5,.5,1]*n
                        pg=[2*i for i in hp]
                        ShortCostScale=relrisk.ShortCostScale
                        initial=relrisk.initial
                        hpstart=0
                        for j in range(n):
                            done=0
                            scale=1
                            if w[j]<0:scale=ShortCostScale
                            if initial == []:ww=w[j]
                            else:ww=w[j]-initial[j]
                            if ww<hp[hpstart]:
                                c[j]=pg[hpstart]*scale
                                done=1
                                hpstart+=npiece
                                continue
                            for i in range(1,npiece):
                                if(ww<hp[hpstart+i] and ww>=hp[hpstart+i-1]):
                                   if ww>0:c[j]=pg[hpstart+i]*scale
                                   elif ww<0:c[j]=pg[hpstart+i-1]*scale
                                   else:c[j]=0
                                   done=1
                                   break
                            if done:
                                hpstart+=npiece                
                                continue
                            c[j]=pg[hpstart+npiece-1]*scale
                            hpstart+=npiece                
                    def utilh(n,w):
                        npiece=4
                        hp=[-1,-.5,.5,1]*n
                        pg=[2*i for i in hp]
                        ShortCostScale=relrisk.ShortCostScale
                        initial=relrisk.initial
                        hpstart=0
                        total=0
                        nstart=0
                        for j in range(n):
                            nstart=0
                            done=0
                            scale=1
                            if w[j]<0:scale=ShortCostScale
                            for i in range(npiece):#Get the first positive ordinate; we integrate from 0
                                if hp[hpstart+i]>0:nstart=i;break
                            if initial == []:ww=w[j]
                            else:ww=w[j]-initial[j]
                            if ww<=hp[nstart+hpstart] and ww>=0:
                                total+=ww*pg[nstart+hpstart]*scale
                                done=1
                                hpstart+=npiece
                                continue
                            sofar=hp[nstart+hpstart]*pg[nstart+hpstart]*scale
                            if ww>0:
                                for i in range(nstart+1,npiece):
                                    if ww<hp[i+hpstart] and ww>=hp[i-1+hpstart]:
                                        total+=sofar+(ww-hp[i-1+hpstart])*pg[i+hpstart]*scale
                                        done=1
                                        break
                                    sofar+=(hp[i+hpstart]-hp[i-1+hpstart])*pg[i+hpstart]*scale
                            if done:
                                hpstart+=npiece
                                continue
                            if ww>=0:
                                total+=sofar+(ww-hp[npiece-1+hpstart])*pg[npiece-1+hpstart]*scale
                                done=1
                                hpstart+=npiece
                                continue
                            if not ww<0:raise 'BIG ERROR in util'
                            sofar=0
                            for ii in range(nstart):
                                i=nstart-ii
                                usehpi=hp[hpstart+i]
                                if i == nstart:usehpi=0
                                if ww<usehpi and ww>= hp[i-1+hpstart]:
                                    total+=sofar+(ww-usehpi)*pg[i-1+hpstart]*scale
                                    done=1
                                    break
                                sofar-=(usehpi-hp[i-1+hpstart])*pg[i-1+hpstart]*scale
                            if done:
                                hpstart+=npiece
                                continue
                            total+=sofar+(ww-hp[hpstart])*pg[hpstart]*scale
                            hpstart+=npiece
                        return total
                    #relrisk.costfunc=utilh
                    #relrisk.costgrad=modch
                    relrisk.costfunc=util
                    relrisk.costgrad=modc
                    relrisk.costhess=modq
                    #print 'Uniform cost ',util(relrisk.n,[1.0/relrisk.n]*relrisk.n)
                    #ggg=[0]*relrisk.n
                    #modc(relrisk.n,[1.0/relrisk.n]*relrisk.n,ggg)
                    #print ggg
                    #print '============ riskc %d =============='%relrisk.riskc
                relrisk.opt()
                
                #wprint(relrisk)
                if(0 and relrisk.nfac==-1 and relrisk.gamma!=0):
                    relrisk.analytic()
                    relrisk.OptviaSOCP()
                if relrisk.ogamma<=1:
                    relrisk.gamma=relrisk.ogamma
                bthresh=1e-5
                print( 'Basket %d (long %d short %d)'%(basketcount(relrisk.w)))
                print( 'Trades %d (buy  %d sell  %d)'%(basketcount(relrisk.w,relrisk.initial)))
                print( 'Thresh %-.8e\tBasket %d (long %d short %d)'%((bthresh,)+basketcount(relrisk.w,[],bthresh)))
                print( 'Thresh %-.8e\tTrades %d (buy  %d sell  %d)'%((bthresh,)+basketcount(relrisk.w,relrisk.initial,bthresh)))
        else:relrisk.w=a.initialPortfolio
        if relrisk.nfac!=-1:relrisk.Q=[]
        relrisk.risks()
        annr=sqrt(annorm)*100
        anna=annorm*100
        print( 'abs risk %-.8e\t%-.8e' % (relrisk.arisk,relrisk.arisk*annr))
        print( 'rel risk %-.8e\t%-.8e' % (relrisk.risk,relrisk.risk*annr))
        relrisk.props()
        #wprint(relrisk)
        r1=relrisk.risk
        ret1=relrisk.rreturn

        relrisk.margutility()
        ute=relrisk.utility
        if 0:
            weig=open('opt_i.csv','w')
            for i in range(relrisk.n):
                weig.write('%30s,%20.10e\n'%(relrisk.names[i],relrisk.w[i]))
        print( 'rel risk %-.8e\t%-.8e' % (r1,r1*annr))
        print ('rel return %-.8e\t%-.8e' % (ret1,ret1*anna))
        print ('abs risk %-.8e\t%-.8e' % (relrisk.arisk,relrisk.arisk*annr))
        print ('abs return %-.8e\t%-.8e' % (relrisk.areturn,relrisk.areturn*anna))
        print ('Utility %-.8e' % ute)
        if relrisk.costs:
            print( 'Cost %-.8e' % relrisk.tcost)
        if relrisk.costs>1 or relrisk.take_out_costs==1:
            print( '1-cost %-.8e'%(1-relrisk.tcost))
        #print relrisk.beta,relrisk.pbeta
        """
        outrisk=[]
        outcost=[]
        for i in [1e-7,1e-6,1e-5,1e-4,1e-3,1e-2,1e-1,2e-1]:
            relrisk.kappa=i
            relrisk.opt()
            relrisk.props()
            outrisk.append(relrisk.risk)
            relrisk.margutility()
            outcost.append(relrisk.tcost)
            print 'kappa %f done'%relrisk.kappa
        print outrisk
        print outcost
        """
        if logout:
            fff=open(logout,'w')
            fff.write(version())
            fff.write('\n')
            fff.write('%20s %20s %20s\n'%('Lower','Constraint','Upper'))
            for i in range(relrisk.m):
                con=0
                for j in range(relrisk.n):
                    con+=relrisk.w[j]*relrisk.A[j*relrisk.m+i]
                fff.write('%20.8e %20.8e %20.8e\n'%(relrisk.L[i+relrisk.n],con,relrisk.U[i+relrisk.n]))
                if relrisk.costs>1 and i == 0:
                    fff.write('Take out costs check %-.8e %-.8e\n'%(relrisk.tcost,1-con))
            fff.write('\n')
            ws=0
            wi=0
            wb=0
            wt=0
            fff.write('%20s %20s %20s %20s %20s %20s %20s %20s %20s %20s\n'%('Name','Initial','Optimised','Benchmark','half Trade','Lower','Upper','MCTR','MCAR','MCRR'))
            for i in range(relrisk.n):
                fff.write('%20s %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e\n'%(relrisk.names[i],relrisk.initial[i],
                                                                    relrisk.w[i],relrisk.bench[i],
                                                                    0.5*abs(relrisk.w[i]-relrisk.initial[i]),
                                                                    relrisk.L[i],relrisk.U[i],relrisk.MCTR[i],relrisk.MCAR[i],relrisk.MCRR[i]))
                ws+=relrisk.w[i]
                wb+=relrisk.bench[i]
                wi+=relrisk.initial[i]
                wt+=abs(relrisk.w[i]-relrisk.initial[i])
            fff.write('%20s %20.8e %20.8e %20.8e %20.8e\n'%('Totals',wi,ws,wb,wt))
            fff.write('\n')
            fff.write('Risk\t\t%20.8e\n'%relrisk.risk)
            fff.write('Return\t\t%20.8e\n'%relrisk.rreturn)
            fff.write('Utility\t\t%20.8e\n'%relrisk.utility)
            fff.write('\n')
            (l,s,g)=longshortgross(relrisk.w)
            fff.write('Long\t\t%20.8e\tShort\t\t%20.8e\n'%(l,s))
            fff.write('Gross\t\t%20.8e\t-Short/Long\t\t%20.8e\n'%(g,-s/l))
        
            
        

