#include "baseoptimise.h"

static void lpprnt(int lp, integer iter, integer jdel, char ldel, integer jadd, char ladd, real alfa, real condt, integer numinf, real suminf, real objlp)
{
	lm_wmsg(
	"\n\n  ITN JDEL  JADD       STEP    COND T NUMINF         SUMINF%s",
	lp?"          LPOBJ":"");
	lm_printf((char*)"%5ld%5ld%c%5ld%c%10.2g%10.2g%7ld%15.6g",
		CL(iter), CL(jdel), ldel, CL(jadd), ladd, alfa, condt, CL(numinf), suminf);
	if (lp) lm_printf((char*)"%15.6g",objlp);
	lm_putc('\n');
}
/*
	copyright	das ltd. october 1992
	lpprt  prints various levels of output for  lpcore
	msg    cumulative result
	---    -----------------
	le   0  no output
	eq   1  nothing now (but full output later)
	eq   5  one terse line of output
	ge  10  same as 5 (but full output later)
	ge  15  nothing more if  iter < istart
		otherwise,  x,	istate	and  kfree
	ge  20  multipliers (printed outside lpprt)
		the array  ax
	ge  30  diagonals of	t
	ge  80  debug output
	eq  99  a,  bl,  bu,	cvec,  x  (called from lpdump)
*/
void Base_Optimise::dlpprt(	int lp, dimen nrowa, dimen Nrowrt, dimen n, dimen nclin, dimen nfree, dimen isdel, dimen nactiv,
		dimen ncolz, dimen iter, dimen jadd, dimen jdel, real alfa, real condt,
		dimen numinf, real suminf, real objlp, short_vec istate, short_vec kfree, matrix a,
		matrix rt, vector x, vector wrk1, vector wrk2)
{

    static char lstate[5] = {' ','L','U','E','T'};

    char ladd, ldel;
    integer inct, k, laddi, ldeli;

    --wrk2;
    --wrk1;
    --x;
    rt -= Nrowrt + 1;
    a -= nrowa+1;
    --kfree;
    --istate;

    if (msg < 5) {
	return;
    }
    ldeli = 0;
    laddi = 0;
    if (jdel > 0) {
	ldeli = isdel;
    }
    if (jadd > 0) {
	laddi = istate[jadd];
    }
    ldel = lstate[ldeli];
    ladd = lstate[laddi];
    if (msg < 15) {
	/*
	------------------------------------------------------------------
	print heading (possibly) and terse line
	------------------------------------------------------------------
	*/
	if (iter == 0) {
	    lpprnt(lp,iter,jdel,ldel,jadd,ladd,alfa,condt,numinf, suminf,objlp);
	    return;
	}
    }
	/*
	---------------------------------------------------------------------
	print terse line,  x,  istate  and  kfree
	---------------------------------------------------------------------
	*/
    itrwri((char*)"LP", iter);
	lpprnt(lp,iter,jdel,ldel,jadd,ladd,alfa,condt,numinf, suminf,objlp);
    lm_mdvwri((char*)"\nLP VARIABLES",n, &x[1]);
    lm_mivwri((char*)"\nSTATUS OF THE LP BOUND   CONSTRAINTS",n, &istate[1]);
    if(nclin>0)
	lm_mivwri((char*)"\nSTATUS OF THE LP GENERAL CONSTRAINTS",nclin,
		&istate[n + 1]);
    if(nfree>0) lm_mivwri((char*)"\nLIST OF FREE LP VARIABLES",nfree, &kfree[1]);
	/*
	---------------------------------------------------------------------
	compute and print  ax.	use  work = ap	to avoid side effects
	---------------------------------------------------------------------
	*/
    if (msg < 20) {
	return;
    }
    if (nclin > 0) {
	for (k = 1; k <=  (integer)nclin; ++k) {
	    wrk2[k] = BITA_ddot(n, &a[k + nrowa], nrowa, &x[1], 1);
	}
	lm_mdvwri((char*)"\nVALUES OF LP GENERAL LINEAR CONSTRAINTS",nclin, &wrk2[1]);
    }
	/*
	---------------------------------------------------------------------
	print the diagonals of	t
	---------------------------------------------------------------------
	*/
    if (msg >= 30) {
	inct = Nrowrt - 1;
	if (nactiv != 0) {
	    dcopy(nactiv,&rt[nactiv+(ncolz+1)*Nrowrt],inct,&wrk1[1], 1);
	    lm_mdvwri((char*)"\nDIAGONALS OF LP WORKING SET FACTOR  T",nactiv, &wrk1[1]);
	}
    }
}
