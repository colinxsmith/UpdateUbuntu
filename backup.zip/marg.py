#! /bin/env python
"""
python/jython script to demonstrate the methods for getting marginal contributions
(and that they give the right risks).
"""
try:
    from java.lang import *
    System.loadLibrary("safejavajy")
    from jarray import *
    from safejavajy import *
    import FOptimise
except:
    from safe import *
from math import sqrt

def dot(a,b,inc=0):
    s=0
    n=len(a)
    for i in range(n):s+=a[i]*b[i+inc]
    return s

opt=FOptimise()

opt.n=11
opt.ncomp=1
opt.nfac=2
opt.SV=[(i+1)*1e-4 for i in range(opt.n-opt.ncomp)]
opt.FL=[1]*(opt.n-opt.ncomp)+[1,-1]*((opt.n-opt.ncomp)/2)
opt.FC=[i*1e-4 for i in [1,.1,1]]

bench=[.1]*(opt.n-opt.ncomp)+[0]*opt.ncomp
w=[1]+[0]*(opt.n-1)
initial=[.1]*(opt.n-opt.ncomp)+[0]*opt.ncomp
buy=[1e-5]*opt.n
sell=[1.1e-5]*opt.n
npiece=2
hpiece=[-1,1]*opt.n
pgrad=[-1.1e-5,1e-5]*opt.n
active=map(lambda i:(w[i]-bench[i]),range(opt.n))
trade=map(lambda i:(w[i]-initial[i]),range(opt.n))
           
try:
    marg=array([0]*opt.n,Double)
    beta=array([0]*opt.n,Double)
    fmarg=array([0]*(opt.n+opt.nfac),Double)
    fx=array([0]*opt.nfac,Double)
    opt.composites=[.1]*(opt.n-opt.ncomp)
    alpha=map(lambda i:(i-(opt.n-1)/2)*1e-3,range(opt.n-1))
    alpha.append(dot(alpha,opt.composites))
    print alpha
    Composite=opt.composites
except:
    marg=[]
    fmarg=[]
    fx=[]
    beta=[]
    opt.Composites=[.1]*(opt.n-opt.ncomp)
    alpha=map(lambda i:(i-(opt.n-1)/2)*1e-3,range(opt.n-1))
    alpha.append(dot(alpha,opt.Composites))
    print alpha
    Composite=opt.Composites

opt.factor_model_process()

try:
    print 'Compressed Risk Matrix',opt.H,opt.H_size()
    Q=opt.H
except:
    print opt.h,opt.H_size()
    Q=opt.h

opt.CompSetup()
opt.beta(bench,beta)
print beta

opt.MC(w,bench,marg)
risk=dot(active,marg)
print 'risk %e'%risk

print marg
opt.FMC(w,bench,fmarg,fx)

print fmarg
nfrisk=dot(active,fmarg,opt.nfac)
print 'non-factor risk %e'%nfrisk
print fx

frisk=dot(fx,fmarg)
print 'factor risk %e'%frisk

print 'Check risk %e'%sqrt(nfrisk*nfrisk+frisk*frisk)

gamma=.1
kappa=.1

try:
    gradutility=array([0]*opt.n,Double)
    utility_per_stock=array([0]*opt.n,Double)
    cost_per_stock=array([0]*opt.n,Double)
    cost=array([0],Double)
    utility=array([0],Double)
except:
    gradutility=[]
    utility_per_stock=[]
    cost_per_stock=[]
    cost=[]
    utility=[]

MarginalUtility(opt.n,opt.nfac,[],w,bench,initial,Q,gamma,kappa,npiece,hpiece,pgrad,buy,sell,alpha,
                cost,utility,gradutility,utility_per_stock,cost_per_stock,opt.ncomp,Composite)
print 'Piece-wise cost test'
print '%20s %20s %20s %20s'%('trade','utility per stock','cost per stock','utility gradient')
tcost=0
tutility=0
for i in range(opt.n):
    print '%20.8e %20.8e %20.8e %20.8e'%(trade[i],utility_per_stock[i],cost_per_stock[i],gradutility[i])
    tcost+=cost_per_stock[i]
    tutility+=utility_per_stock[i]
print '%20s %20.8e %20.8e'%('total',tutility,tcost)
print '%20s %20.8e %20.8e'%('check',utility[0],cost[0])

npiece=0
print 'Linear cost test'
MarginalUtility(opt.n,opt.nfac,[],w,bench,initial,Q,gamma,kappa,npiece,hpiece,pgrad,buy,sell,alpha,
                cost,utility,gradutility,utility_per_stock,cost_per_stock,opt.ncomp,Composite)

print '%20s %20s %20s %20s'%('trade','utility per stock','cost per stock','utility gradient')
tcost=0
tutility=0
for i in range(opt.n):
    print '%20.8e %20.8e %20.8e %20.8e'%(trade[i],utility_per_stock[i],cost_per_stock[i],gradutility[i])
    tcost+=cost_per_stock[i]
    tutility+=utility_per_stock[i]
print '%20s %20.8e %20.8e'%('total',tutility,tcost)
print '%20s %20.8e %20.8e'%('check',utility[0],cost[0])
