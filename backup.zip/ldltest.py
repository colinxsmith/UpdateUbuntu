#!/bin/env python

from Opt import *

"""
symm_inverse_x(size_t n,vector Q,vector x,vector Qm1x)
"""
n=3
MAT=[1,0,2,.2,0,3]
b=[1,2,3]
res=[0]*3
symm_inverse_x(n,MAT,b,res)
print res

A=[]
Ai=[]
Ap=[0]
ij=0
tot=0
for i in range(n):
    for j in range(i+1):
        if MAT[ij]!=0:
            A.append(MAT[ij])
            Ai.append(j)
            tot+=1
        ij+=1
    Ap.append(tot)

print ldl_valid_matrix(n,Ap,Ai)

"""
void ldl_symbolic
(
 int n,		/* A and L are n-by-n, where n >= 0 */
 int* Ap ,		/* input of size n+1, not modified */
 int* Ai ,		/* input of size nz=Ap[n], not modified */
 int* Lp ,		/* output of size n+1, not defined on input */
 int* Parent ,	/* output of size n, not defined on input */
 int* Lnz ,	/* output of size n, not defined on input */
 int* Flag ,	/* workspace of size n, not defn. on input or output */
 int* P ,		/* optional input of size n */
 int* Pinv 	/* optional output of size n (used if P is not NULL) */
 )
"""
Lp=[0]*(n+1)
Parent=[0]*n
Lnz=[0]*n
Flag=[0]*n
ldl_symbolic(n,Ap,Ai,Lp,Parent,Lnz,Flag,[],[])
print Lp
print Parent
print Lnz

"""
int ldl_numeric		/* returns n if successful, k if D (k,k) is zero */
(
 int n,		/* A and L are n-by-n, where n >= 0 */
 int* Ap ,		/* input of size n+1, not modified */
 int* Ai ,		/* input of size nz=Ap[n], not modified */
 double* Ax ,	/* input of size nz=Ap[n], not modified */
 int* Lp ,		/* input of size n+1, not modified */
 int* Parent ,	/* input of size n, not modified */
 int* Lnz ,	/* output of size n, not defn. on input */
 int* Li ,		/* output of size lnz=Lp[n], not defined on input */
 double* Lx ,	/* output of size lnz=Lp[n], not defined on input */
 double* D ,	/* output of size n, not defined on input */
 double* Y ,	/* workspace of size n, not defn. on input or output */
 int* Pattern ,	/* workspace of size n, not defn. on input or output */
 int* Flag ,	/* workspace of size n, not defn. on input or output */
 int* P ,		/* optional input of size n */
 int* Pinv 	/* optional input of size n */
 )
 """
Li=[0]*(Lp[n])
Lx=[0]*(Lp[n])
D=[0]*n
Y=[0]*n
Pattern=[0]*n

if n==ldl_numeric(n,Ap,Ai,A,Lp,Parent,Lnz,Li,Lx,D,Y,Pattern,Flag,[],[]):
    print Li
    print Lx
    print D
    ldl_lsolve(n,b,Lp,Li,Lx)
    ldl_dsolve(n,b,D)
    ldl_ltsolve(n,b,Lp,Li,Lx)
    print b
