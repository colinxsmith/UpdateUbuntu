#include "baseoptimise.h"
static void set_addr(dimen i, dimen l, integer *iloc, void *a, dimen sa, void **ploc)
{
	while(i<=l){
		ploc[i] = ((byte*)a)+iloc[i]*sa;
		i++;
		}
}

/*
	dalloc allocates the addresses of the work arrays for dlpcore,
	dqpcore, dlccore, dnpcore
*/
void Base_Optimise::dalloc(byte nalg, dimen n, dimen nclin, dimen ncnln, dimen nctotl, short_vec iw, vector w, ulong *litotl, ulong *lwtotl)
{
	ulong	ladx, laqp, lrho, lslk, lqtg, lwrk, lcsl1, lmax1, lmax2, lslk1, 
		lztg2, ldlam, lcjdx, lrlam, ldslk, lxbwd, lxfwd, lqpdx, lgrad2, 
		lkfree, lcslam, lsigma, lshare, lenaqp=1000000000, lkactv, lanorm, lqpadx, 
		lg1, lg2, lqptol, liqpst, lnpwrk, lqpwrk, lx1, lx2, lbl, lap, lbu,
		ldx, lrt, lpx, lzy, lcs1, lcs2;
	long	loclp[10];

	switch(nalg){
		case 1:
		case 2:
			/*
			allocate the addresses for  lpcore  and  qpcore
			*/
			lkactv = *litotl + 1;
			lkfree = lkactv + n;
			*litotl = lkfree + n - 1;
			lanorm = *lwtotl + 1;
			lap = lanorm + nclin;
			lpx = lap + nclin;
			lqtg = lpx + n;
			lrlam = lqtg + n;
			lrt = lrlam + n;
			lzy = lrt + nrowrt * ncolrt;
			lwrk = lzy + nq * nq;
			*lwtotl = lwrk + n - 1;
			loclp[0] = lkactv;
			loclp[1] = lkfree;
			loclp[2] = lanorm;
			loclp[3] = lap;
			loclp[4] = lpx;
			loclp[5] = lqtg;
			loclp[6] = lrlam;
			loclp[7] = lrt;
			loclp[8] = lzy;
			loclp[9] = lwrk;
			set_addr(0,1,(integer*)loclp,iw,sizeof(*iw),DAS_Sol_ploc);
			set_addr(2,9,(integer *)loclp,w,sizeof(*w),DAS_Sol_ploc);
			break;
		case 3:
			/*
			allocate the addresses for npcore
			*/
			lkactv = *litotl + 1;
			lkfree = lkactv + n;
			liqpst = lkfree + n;
			*litotl = liqpst + nctotl - 1;
			/*
			variables used not only by  dnpcore,  but also dlpcore and  dqpcore
			*/
			lanorm = *lwtotl + 1;
			lqtg = lanorm + nrowqp;
			lrlam = lqtg + n;
			lrt = lrlam + n;
			lzy = lrt + nrowrt * ncolrt;
			loclp[1] = lkactv;
			loclp[2] = lkfree;
			loclp[3] = lanorm;
			loclp[6] = lqtg;
			loclp[7] = lrlam;
			loclp[8] = lrt;
			loclp[9] = lzy;
			/*
			assign the addresses for the workspace arrays used by  dnpiqp
			*/
			lqpadx = lzy + nq * nq;
			lqpdx = lqpadx + nrowqp;
			lqpwrk = lqpdx + n;
			loclp[4] = lqpadx;
			loclp[5] = lqpdx;
			loclp[10] = lqpwrk;
			/*
			assign the addresses for arrays used in  npcore
			*/
			if(ncnln == 0) lenaqp = 0;
			if(ncnln > 0) lenaqp = nrowqp * n;
			laqp = lqpwrk + n;
			ladx = laqp + lenaqp;
			lbl = ladx + nrowqp;
			lbu = lbl + nctotl;
			ldx = lbu + nctotl;
			lg1 = ldx + n;
			lg2 = lg1 + n;
			lqptol = lg2 + n;
			lx1 = lqptol + nctotl;
			lnpwrk = lx1 + n;
			locnp[0] = liqpst;
			locnp[1] = laqp;
			locnp[2] = ladx;
			locnp[3] = lbl;
			locnp[4] = lbu;
			locnp[5] = ldx;
			locnp[6] = lg1;
			locnp[7] = lg2;
			locnp[8] = lqptol;
			locnp[9] = lx1;
			locnp[10] = lnpwrk;
			lcs1 = lnpwrk + nctotl;
			lcs2 = lcs1 + ncnln;
			lcsl1 = lcs2 + ncnln;
			lcslam = lcsl1 + ncnln;
			lcjdx = lcslam + ncnln;
			ldlam = lcjdx + ncnln;
			ldslk = ldlam + ncnln;
			lrho = ldslk + ncnln;
			lsigma = lrho + ncnln;
			lslk1 = lsigma + ncnln;
			lslk = lslk1 + ncnln;
			locnp[11] = lcs1;
			locnp[12] = lcs2;
			locnp[13] = lcsl1;
			locnp[14] = lcslam;
			locnp[15] = lcjdx;
			locnp[16] = ldlam;
			locnp[17] = ldslk;
			locnp[18] = lrho;
			locnp[19] = lsigma;
			locnp[20] = lslk1;
			locnp[21] = lslk;
			*lwtotl = lslk + ncnln - 1;
			break;
		case 4:
			/*
			allocate the addresses for  lccore
			*/
			lkactv = *litotl + 1;
			lkfree = lkactv + n;
			*litotl = lkfree + n - 1;
			lztg2 = *lwtotl + 1;
			loclc[0] = lztg2;
			/*
			arrays used not only by  dlccore,  but also  dlpcore
			*/
			lanorm = lztg2 + n;
			lap = lanorm + nclin;
			lpx = lap + nclin;
			lqtg = lpx + n;
			lrlam = lqtg + n;
			lrt = lrlam + n;
			lzy = lrt + nrowrt * ncolrt;
			lwrk = lzy + nq * nq;
			loclp[1] = lkactv;
			loclp[2] = lkfree;
			loclp[3] = lanorm;
			loclp[4] = lap;
			loclp[5] = lpx;
			loclp[6] = lqtg;
			loclp[7] = lrlam;
			loclp[8] = lrt;
			loclp[9] = lzy;
			loclp[10] = lwrk;
			lshare = lwrk + n;
			/*
			assign the addresses of the workspace used by  dlcsrch
			this workspace is shared by  dlcappg
			*/
			lx2 = lshare;
			lgrad2 = lx2 + n;
			lmax1 = lgrad2 + n - 1;
			/*
			assign the addresses of the workspace used by  dlcappg
			this workspace is shared by  dlcsrch
			*/
			lxfwd = lshare;
			lxbwd = lxfwd + n;
			lmax2 = lxbwd + n - 1;
			*lwtotl = max(lmax1,lmax2);
			loclc[1] = lx2;
			loclc[2] = lgrad2;
			loclc[3] = lxfwd;
			loclc[4] = lxbwd;
			break;
		}
}
