#!/usr/bin/env python
#Colin 10-1-2006
#Use an active risk constraint and a robust constraint

from Opt import *
def var(x,Q):
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    return pow(var(x,Q),.5)

n=3
m=1
w=[0]*n
A=[1,1,1]
Q=[1,.02,3,.04,.05,6]
alpha=[.02,.01,.03]
dalpha=[1e-4,3e-4,2e-4]
bench=[.5,.3,.2]
full=0
rmin=-1
rmax=-1
L=[0]*n+[1]
U=[1]*n+[1]
val=0
TopRisk=1.402
MaxDalpha=1.48e-4
nabs=0
Aabs=[]
Uabs=[]


SOCPlstest(n,m,w,A,Q,alpha,full,rmin,rmax,L,U,val,TopRisk,dalpha,MaxDalpha,nabs,Aabs,Uabs,bench)
error=pow(sum([w[i]*w[i]*dalpha[i]*dalpha[i] for i in range(n)]),.5)
print w,sum(w),dot(alpha,w),risk([w[i]-bench[i] for i in range(n)],Q),error
