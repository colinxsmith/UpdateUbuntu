#! /bin/env python
#Colin 9-4-2003, class interface to threadsafe optimiser (classes Optimise and FOptimise
#where FOptimise extends Optimise to allow factor model input)
#Here we test the general interface Optimise that allows the Hessian times vector routine
#to be defined in Python and show how to perform a risk constrained optimisation with all
#of the necessary functions defined in Python.
from safe import *
from math import sqrt
"""
Helper functions
"""
def sumlist(a):
    s=0
    for i in a:s+=i
    return s
def dot(a,b):
    s=0
    for i in range(len(a)):s+=a[i]*b[i]
    return s
def utilityhere(n,x,c,Q):
    implied=[0]*n
    testmul(n,1,1,1,Q,x,implied)
    s=dot(c,x) + 0.5*dot(implied,x)
    return s
def listadd(a,b):
    c=[]
    for i in range(len(a)):c.append(a[i]+b[i])
    return c
def listsub(a,b):
    c=[]
    for i in range(len(a)):c.append(a[i]-b[i])
    return c
def scallistadd(gamma,a,c):
    b=[]
    for i in range(len(a)):b.append(a[i]*gamma+c[i])
    return b
def scallistsub(gamma,a,c):
    b=[]
    for i in range(len(a)):b.append(a[i]*gamma-c[i])
    return b
"""
The optimisation problem
"""

#_________________________________________________________________________________________________
def testmul(n,n1,n2,n3,H,x,y):
    """Define the Hessian times vector routine here in Python instead of the optimiser dll"""
    ij = 0
    for i in range(n):
        y[i] = 0
        for j in range(i+1):
            y[i] += H[ij] * x[j]
            if i != j:y[j] += H[ij] * x[i]
            ij+=1
c=[]
def ModifyGrad(n,x,C):
#    print 'ModifyGrad function'
#    print x
#    print c
    for i in range(n):
        for j in range(i+1):
            for k in range(j+1):
                prod=c[i]*c[j]*c[k]
                if j!=k and j!=i and i!=k:#321
                    C[i]+=prod*x[j]*x[k]*2
                    C[j]+=prod*x[i]*x[k]*2
                    C[k]+=prod*x[i]*x[j]*2
                elif i==j and j!=k:#221
                    C[i]+=prod*x[j]*x[k]*2
                    C[k]+=prod*x[i]*x[j]
                elif j==k and i!=k:#211
                    C[i]+=prod*x[j]*x[k]
                    C[j]+=prod*x[i]*x[k]*2
                elif i==k and j==k:#111
                    C[i]+=prod*x[j]*x[k]
def ModifyHessian(n,x,C):
#    print 'ModifyHessian function'
#    print x
#    print c
    ij=0
    for i in range(n):
        jk=0
        for j in range(i+1):
            for k in range(j+1):
                ik=i*(i+1)/2+k
                prod=c[i]*c[j]*c[k]
                if j!=k and j!=i and i!=k:#321
                    C[ij]+=prod*x[k]
                    C[jk]+=prod*x[i]
                    C[ik]+=prod*x[j]
                elif i==j and j!=k:#221
                    C[ij]+=prod*x[k]*2
                    C[ik]+=prod*x[i]*2
                elif j==k and i!=k:#211
                    C[jk]+=prod*x[i]*2
                    C[ij]+=prod*x[j]*2
                elif i==k and j==k:#111
                    C[ij]+=prod*x[i]*6
                jk+=1
            ij+=1
    
def Utility(n,x):
#    print 'Utility function'
#    print x
#    print c
    s=0
    for i in range(n):
        for j in range(i+1):
            for k in range(j+1):
                prod=c[i]*c[j]*c[k]*x[i]*x[j]*x[k]
                if j!=k and j!=i and i!=k:#321
                    s+=prod*6
                elif i==j and j!=k:#221
                    s+=prod*3
                elif j==k and i!=k:#211
                    s+=prod*3
                elif j==k and i==k:#111
                    s+=prod
    return s
                    
opt = Optimise()
n=5
opt.n=n
opt.m=1
opt.A=[1]*n
opt.lower=[0]*n+[1]
opt.upper=[1]*n+[1]
opt.c=c=[-.2,-.1,.1,.2,.3]
opt.H=H=[1,
       -.1,1,
       .1,-.1,1,
       .1,.1,-.1,1,
       .1,.1,.1,-.1,1]
opt.hmul=testmul
opt.delta=1
opt.mask=[1]*(n-1)+[0]
print opt.OptSetup(2,n) #Drop to just 2 variables
#_________________________________________________________________________________________________
"""
Results and checks
"""

x=opt.x
print x,sumlist(x)
print 'Utility there %20.8e' % (opt.utility(n,x,c,H))
del opt #To test the C++ destructor
print 'Utility here  %20.8e' % (utilityhere(n,x,c,H))


"""
A BITA kind of problem to constrain absolute risk
although we are minimising relative risk
"""
opt = Optimise()
print opt.Version
n=5
opt.n=n
opt.m=1
opt.A=[1]*n
opt.lower=[-1]*n+[0]
opt.upper=[1]*n+[0]
alpha=[-.2,-.1,.1,.2,.3]
bench=[.2,.2,.2,.2,.2]

opt.H=H=[1,
       -.1,1,
       .1,-.1,1,
       .1,.1,-.1,1,
       .1,.1,.1,-.1,1]
opt.hmul=testmul
opt.Util=Utility
opt.ModDeriv=ModifyGrad
opt.ModHessian=ModifyHessian
c=[1e-1,2e-1,3e-1,4e-1,5e-1]
opt.npiece=1
opt.hess_choice=2
opt.UseDiagPenalty=0
opt.Full=1

implied=[0]*n

testmul(n,1,1,1,H,bench,implied)
store=[0]*n
store1=[0]*n
def variance(gamma):
    """
    Do a relative variance optimisation for this value of gamma and return the
    the absolute variance
    """
    scale=-gamma/(1-gamma)
    opt.c=scallistsub(scale,alpha,implied)
    opt.OptSetup(n-1,n)
    x=opt.x
    testmul(n,1,1,1,H,x,store)
    return dot(x,store)

def Sharpe(gamma):
    scale=-gamma/(1-gamma)
    opt.c=scallistsub(scale,alpha,implied)
    opt.OptSetup(n-1,n)
    x=opt.x
    store1=listsub(x,bench)
    testmul(n,1,1,1,H,store1,store)
    relrisk=sqrt(dot(store,store1))
    relret=dot(alpha,store1)
    return - relret/relrisk
    
def rfunc(gamma):
    """
    This function will return 0 when the variance is 0.71
    """
    vv=variance(gamma)
    print '@'*40,' ',gamma,' ',vv,' ','@'*40
    return vv-.71

print 'One Dimsional Solver'
g=Solve1D(rfunc,0.1,.999)
if g < 1e10:
    srat=-Sharpe(g)
    print 'gamma %f gives Sharpe ratio %f'%(g,srat)
    print 'gamma %f has variance %f' % (g,variance(g))
else:print '************ Input to Solve1D was not valid ***************'

active=listsub(x,bench)
testmul(n,1,1,1,H,active,store)
activevar=dot(store,active)
print 'Active variance is %f'%activevar

print 'Maximise Sharpe ratio'
g=PathMin(Sharpe,0,.99999,1e-5)
srat=-Sharpe(g)
print 'gamma %f gives Sharpe ratio %f'%(g,srat)
print 'gamma %f has variance %f' % (g,variance(g))

