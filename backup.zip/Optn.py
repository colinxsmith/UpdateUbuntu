#This defines a class-based interface for calling the optimisation and other routines in the safeqp library.
#Extra helper functions are also defined here.
#This has been written so that it should work with python and jython without needing any changes.
from time import clock

try:
    from java.lang import *
    from jarray import *
    from safejava import *
    """
    >>> from Optn import *
    >>> b=Allocate2D(3,2)
    >>> b
    array([array([0.0, 0.0], double), array([0.0, 0.0], double), array([0.0, 0.0], double)], [D)
    >>> b=[[0]*2]*3
    >>> b
    [[0, 0], [0, 0], [0, 0]]
    >>> b=Convert(b)
    >>> b
    array([array([0L, 0L], long), array([0L, 0L], long), array([0L, 0L], long)], [J)
    """    
    jython=1
    jython_set=lambda t:array(t,'d')
    if not sum:#Old version of jython doesn't have sum
        def sum(a):
            back=0
            for i in range(len(a)):
                back+=a[i]
            return back
except:
    try:
        from safee import *
#        if not UnlockBita('BITA_PAS_key','colincolin1'):#the correct one
        if not UnlockBita('BITA_PAS_key','colincolin'):
            #print('Bad licence key')
            raise Exception()
    except:
        #print 'Cannot use PAS dll'
        from safe import *
    jython=0
debug=0
toList=lambda x:[i for i in x]

PYsingle2double=lambda n,m,a:[[a[i*n+j] for i in range(m)] for j in range(n)]
PYsingle2doublet=lambda n,m,a:[[a[i+j*n] for i in range(n)] for j in range(m)]
spike=lambda t:1e-6/pow(t,4)
dspike=lambda t:-1e-6*4/pow(t,5)
ddspike=lambda t:1e-6*20/pow(t,6)

sqr=lambda x:x*x
pythag=lambda x,y:pow(x*x+y*y,0.5)

def dumpv(name,dat,file='weightdump'):
    try:
        dumpvec(len(dat),name,dat,file)
    except:
        dumpvec(1,name,[dat],file)
def makeUM(n):
    """Make unit matrix of size n
    """
    M=[0]*(n*n)
    for i in range(n):
        M[i+i*n]=1
    return M

def addvec(n,c,M,v):
    """Add vector v to column c in square matrix M
    """
    for i in range(n):
        M[i+c*n]=v[i]

def util2quadC(n,gamma,alpha,Q):
    c=[0]*n
    symm_inverse_x(n,Q,alpha,c)
    ll=gamma/(1-gamma)
    c=[-i*ll for i in c]
    largealpha=[0]*n+[1]
    largen=n+1
    nquad=1
    qtype=[0]
    cov=Q+[0]*n+[1]
    centres=c+[0]
    Uq=10
    return (largen,largealphas,nquad,qtype,cov,centres,Uq) 
def change(a):
    try:return int(a)
    except:
        try:return float(a)
        except:return a
def linf(a):
    n=len(a)
    back=-1
    for i in a:
        back=max(abs(i),back)
    return back
def rootQ(n,Q):
    """Use matrix diagonalisation to find square root of
    positive semi-definite symmetric matrix.
    """
    conv=epsget()
    S=[0]*(n*n)
    (eig,eigv)=eigen(n,Q)
    for l in range(n):
        if eig[l]<conv:eig[l]=conv
        eig[l]=pow(eig[l],.5)
        for i in range(n):
            p1=eig[l]*eigv[l*n+i]
            for j in range(i+1):
                p=p1*eigv[l*n+j]
                S[j+n*i]+=p
                if i!=j:S[i+n*j]+=p
    return S
def rootQinverse(n,Q):
    """Use matrix diagonalisation to find inverse square root of
    positive semi-definite symmetric matrix.
    """
    conv=epsget()
    S=[0]*(n*n)
    (eig,eigv)=eigen(n,Q)
    for l in range(n):
        if eig[l]<conv:eig[l]=0
        else:eig[l]=pow(1.0/eig[l],.5)
        for i in range(n):
            p1=eig[l]*eigv[l*n+i]
            for j in range(i+1):
                p=p1*eigv[l*n+j]
                S[j+n*i]+=p
                if i!=j:S[i+n*j]+=p
    return S
def getnames(fl,dic,sep='|'):
    """Read just the first column to get the factor names"""
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        dic[line.split(sep)[0]]=1
def getsym(n,fl,dic,sep='|'):
    """Read symmetric data from file fl"""
    M=[0]*(n*(n+1)/2)
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        data=line.split(sep)
        try:
            i=dic[data[0].strip()]-1
            j=dic[data[1].strip()]-1
            I=max(i,j)
            J=min(i,j)
            M[I*(I+1)/2+J]=float(data[2].strip())
        except:pass
    return M
def getnonsym(nl,ng,fl,dic1,dic2,sep='|'):
    """Read non-symmetric data from file fl"""
    if jython:M=Convert([[0.0]*ng]*nl)#Allocate2D(nl,ng)#does the same
    else:M=[0]*(nl*ng)
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        data=line.split(sep)
        try:
            i=dic1[data[0].strip()]-1
            j=dic2[data[1].strip()]-1
            if jython:M[i][j]=float(data[2].strip())
            else:M[i+j*nl]=float(data[2].strip())
        except:pass
    return M
def setorder(dic,names):
    i=1
    for name in names:
        dic[name]=i
        i+=1
def sign(x):
	if x>0:return 1
	elif x<0:return -1
	else:return 0
def ticketshape(x,p=spike(1)):
    if abs(x)<p:return spike(p)
    else: return spike(x)
def dticketshape(x,p=spike(1)):
    if abs(x)<p:return 0
    else: return dspike(x)
def ddticketshape(x,p=spike(1)):
	if abs(x)<p:return 0
	else: return ddspike(x)
def ticket(x,strength=1e-1):
    return -(ticketshape(x)-ticketshape(0))*strength/ticketshape(0)
def dticket(x,strength=1e-1):
    return -dticketshape(x)*strength/ticketshape(0)
def ddticket(x,strength=1e-1):
	return -ddticketshape(x)*strength/ticketshape(0)

def numline(llist=[],func=float):
    """Converts a string to number if possible
    To get an int list something like

    func=lambda t:int(float(t))
    
    may be best to convert a string float to an int"""
    for i in range(len(llist)):
        try:llist[i]=func(llist[i])
        except:pass
    return llist
def epsget():
    """Return machine accuracy."""
    return  1-3*(4./3-1)
def kag_sum(w,issues=[],five=.05,eps=0):
    if eps==0:eps256=epsget()*256
    else:eps256=eps
    n=len(w)
    back=0
    if issues==[]:
        for i in range(n):
            if w[i]>five+eps256:back+=w[i]
    else:
        nish=len(issues)/n
        for i in range(nish):
            exp=dot(w,issues[i*n:(i+1)*n])
            if exp >five+eps256:back+=exp
    return back
def dot(a,b,s=0):
    """Scalar product of a and b (with shift s on b)."""
    back=0
    n=len(a)
    for i in range(n):back+=a[i]*b[i+s]
    return back
def squaremult(n,M,x):return [dot(x,M[n*i:n*i+n]) for i in range(n)]
def turnover(w,wi,mask=[],start=0,stop=-1):
    """The turnover between w and wi (possibly masked)."""
    n=len(w)
    if stop!=-1:n=stop+start
    s=0
    if mask==[]:
        for i in range(start,n):s+=abs(w[i]-wi[i])
    else:
        for i in range(start,n):s+=abs((w[i]-wi[i])*mask[i-start])
    return s*0.5
def GetOrderW(w,sign=1,abs=0):
    """Returns a list of indices for ordering the elements of w (largest first sign=1, smallest first sign=-1).
        If abs is 1, then ordering is done according to absolute value.
        (This is a helper function which calls the function GetOrder(n,w,returned_order,abs=0,badlist=0) in safe wrapper.)
    """
    n=len(w)
    porder=[0]*n
    if jython:porder=array(porder,Long)
    if sign==1:
        GetOrder(n,w,porder,abs,[])
    else:
        GetOrder(n,[i*sign for i in w],porder,abs,[])
    if(jython):porder=[i for i in porder]
    return porder
def actualthresh(w,initial=[]):
    thresh=1e10
    for i in range(len(w)):
        s=w[i]
        if(initial!=[]):s-=initial[i]
        if abs(s)>1e-8:thresh=min(abs(s),thresh)
    return thresh
def basketcount(w,initial=[],thresh=0):
    """Get the size of the basket (or number of trades if initial is not [])."""
    b=0
    longamount=0
    shortamount=0
    zamount=0
    if(thresh==0):thresh=epsget()
    for i in range(len(w)):
        s=0
        if initial != []:s=initial[i]
        tt=w[i]-s
        if abs(tt) > thresh:
            b+=1
            if tt>thresh:longamount+=1
            elif tt<-thresh:shortamount+=1
    return (b,longamount,shortamount)
def Parab(delta,U,prt=0):
    """Fit a parabola a*x2+bx+c to the data in delta and U and output the stationary point and its value"""
    (F1,F2,F3) = tuple(U)
    (d1,d2,d3) = tuple(delta)
    a = (F1*(d2-d3)+F3*(d1-d2)+F2*(d3-d1))/(d1-d3)/(d2-d3)/(d1-d2)
    b = (F1-F3)/(d1-d3)-a*(d1+d3)
    c=F3-d3*b-d3*d3*a
    xmin=-0.5*b/a
    fmin=c-0.25*b*b/a
    if prt:print('a = %f b = %f c = %f'%(a,b,c))
    return(xmin,fmin)
def Pmin(n,x,f,eps=0.1,conv=1e-9,prt=0):
    """
        Minimise f(n,x) by fitting parabolas to each of the independent directions.
        (Simple-minded approach, only really works for parabolas!)
    """
    fmin=f(n,x)
    if prt:print(x,fmin)
    f1=1e10
    while abs((f1-fmin)/fmin) > conv:
        f1=fmin
        x1=[k for k in x]
        for i in range(n):
            delt=[-eps,0,eps]
            U=[f(n,x1) for x1[i] in delt]
            (xmin,Umin)=Parab(delt,U,prt)
            x[i]=xmin
        fmin=f(n,x)
        if prt:print(x,fmin,(f1-fmin)/fmin)
    return fmin
def longshortgross(w):
    """Get the total long, short and gross weights for weights in w."""
    p=0
    m=0
    g=0
    for i in w:
        if i>0:p+=i;g+=i
        else:m+=i;g-=i
    if p!=0:print('Short/Long',-m/p)
    return (p,m,g)
def eigen(n,MM):
    """
    MM can be either a lower triangle or a square matrix. M is
    generated from MM.
    n is the dimension of the problem and M is a square symmetric matrix.
    eigen returns a tuple (eigval,eigvec)
    the order of the eigenvectors in
    eigenvector i is eigvec[j+i*n]

    
    Uses routine eigendecomp in safe optimiser
    eigendecomp(dimen n, matrix S, vector eigval, dimen itmax);
    """
    if len(MM)==(n*n):
        M=MM
    else:
        M=[0]*(n*n)
        ij=0
        for i in range(n):
            for j in range(i+1):
                M[i+j*n]=MM[ij]
                if i != j:
                    M[j+i*n]=MM[ij]
                ij+=1
    if jython:
        S=array(M,'d')
        eigval=array([0]*n,'d')
    else:
        S=list(map(lambda t:t,M))
        eigval=[]
    itmax=3000
    r=eigendecomp(n,S,eigval,itmax)
    if r != 0:raise 'Eigenvalues were not found properly'
    if jython:
        S=[i for i in S]
        eigval=[i for i in eigval]
    return (eigval,S)
def eigvalprint(e):
    n=len(e)
    print('Eigenvalues')
    for i in range(n):
        print('%4d %20.8e'%(i+1,e[i]))
def eigvecprint(n,e):
    print('Eigenvectors (as columns)')
    for j in range(n):
        out=''
        for i in range(n):
            out+='%20.8e '%(e[i*n+j])
        print(out)
def covprint(n,c):
    print('Covariances')
    ij=0
    for i in range(n):
        out=''
        for j in range(i+1):
            out+='%20.8e '%c[ij]
            ij+=1
        print(out)
def makeapt(n,nfac,COV):
    """
    Make a principal component model from a covariance matrix which can
    be given either as a lower triangle or a square matrix. n is the number of
    stocks and nfac (must be <= n) is the number of principal components
    required. Principal components are ordered so that the stongest is first.
    The stockvariance list returned contains the stock variances. These
    are NOT equivalent to the specific variances in a factor model. The first
    n elements of Q are the stock residual variances, these are equivalent
    to the specific variances in a factor model.
    """
    (eigval,eigvec)=eigen(n,COV)

    if len(COV)==(n*n):stockvariance=[COV[i+n*i] for i in range(n)]
    else:stockvariance=[COV[i*(i+3)/2] for i in range(n)]

    if jython:Q=array([0]*((nfac+1)*n),'d')
    else:Q=[]

    FL=[0]*(n*nfac)

    for i in range(nfac):
        for j in range(n):
            FL[j+n*i]=eigvec[j+n*i]

    apt_model_process(n,nfac,FL,eigval,stockvariance,Q)
    if jython:Q=[i for i in Q]

    return (FL,eigval,stockvariance,Q)
def printeig(n,eigval,eigvec):
    """
    n is the order of the matrix
    eigval is the vector of size n of eigenvalues
    eigvec contains the n eigenvectors end to end
    """
    
    print('______________________________')
    for i in range(n):
        print('Eigenvalue %d %12.5f\nEigenvector %d' % (i+1,eigval[i],i+1))
        for j in range(n):
            print('%12.5f' % eigvec[j+i*n])
        print('______________________________')
def decompFC(nl,ng,Y,G,S,FC):
    """Split the factor covariance matrix (FC) into pure global (SYGYS) and pure local (SFS) parts
    (Here we use genmult and getFSF which are written in c++)"""
    nn=nl*(nl+1)/2
    if jython:
        YS=Allocate2D(nl,ng)
    else:
        YS=[0]*(nl*ng)
    genmult(nl,ng,Y,S,YS)
    if jython:
        SYGYS=array([0]*nn,'d')
    else:
        SYGYS=[0]*nn
    getFSF(nl,ng,G,YS,SYGYS)
    if jython:SYGYS=[i for i in SYGYS]
    SFS=[FC[i]-SYGYS[i] for i in range(nn)]
    return(SYGYS,SFS)
class RobustGen:
    def __init__(self):
        for i in 'm full val nabs signtest nq ncomp'.split():
            setattr(self,i,0)
        for i in 'w alpha A L U Labs Uabs Aabs qtype cov Uq centres Comps'.split():
            setattr(self,i,[])
        for i in 'rmin rmax'.split():
            setattr(self,i,-1)
    def Opt(self):
        RobustOptDump(self.n,self.m,self.w,self.alpha,self.A,self.L,
                        self.U,self.full,self.rmin,self.rmax,self.val,
                        self.nabs,self.Aabs,self.Labs,self.Uabs,self.signtest,
                        self.nq,self.qtype,self.cov,
                        self.Uq,self.centres,self.ncomp,self.Comps,1,"Robdump")
        back=RobustOpt(self.n,self.m,self.w,self.alpha,self.A,self.L,
                        self.U,self.full,self.rmin,self.rmax,self.val,
                        self.nabs,self.Aabs,self.Labs,self.Uabs,self.signtest,
                        self.nq,self.qtype,self.cov,
                        self.Uq,self.centres,self.ncomp,self.Comps)
        print(SOCPlstestMessage(back))
    def Report(self):
        U=[0]*self.nq
        areturn=[0]
        QuadCVals(self.n,self.w,self.alpha,areturn,self.nq,self.qtype,self.cov,self.Uq,
                  self.centres,U,self.ncomp,self.Comps)
        print('Return',areturn[0])
        for i in range(self.nq):
            print('Value of quadratic constraint %f (Max %f)'%(U[i],self.Uq[i]))
class SOCP:
	def __init__(self):
		for i in 'tau kappa'.split():
			setattr(self,i,[0])
		for i in 'c A b x y s ncone'.split():
			setattr(self,i,[])
		for i in 'n m log signtest'.split():
			setattr(self,i,0)
		eps=100*pow(epsget(),.5)
		self.maxit=100
		self.beta=1e-06
		self.delta=0.5
		self.ccomp=eps
		self.cgap=eps
		self.changeratio=4
		self.rhoconv=1e-06
		self.logfile=''
		self.SOCPdump='ser1'
	def opt(self):
		t1=clock()
		if SOCPinfeasHomogt(self.n,self.m,self.ncone,self.c,self.A,self.b,self.x,self.y,self.s,
			self.tau,self.kappa,self.maxit,self.beta,self.delta,
			self.ccomp,self.cgap,self.signtest,self.changeratio,
			self.rhoconv,self.log,self.logfile,self.SOCPdump):
			print('SOCP failed '*4)
		else:
			if 0:
				startfile=open('startg','w')
				startfile.write('n\n')
				startfile.write('%d\n'%self.n)
				startfile.write('m\n')
				startfile.write('%d\n'%self.m)
				startfile.write('ncone\n')
				for i in self.ncone:
					startfile.write('%d '%i)
				startfile.write('\nx\n')
				for i in self.x:
					startfile.write('%20.12e '%i)
				startfile.write('\ns\n')
				for i in self.s:
					startfile.write('%20.12e '%i)
				startfile.write('\ny\n')
				for i in self.y:
					startfile.write('%20.12e '%i)
				startfile.write('\ntau\n')
				startfile.write('%20.12e\n'%self.tau[0])
				startfile.write('kappa\n')
				startfile.write('%20.12e\n'%self.kappa[0])
				startfile.close()
			if self.tau[0]<1e-4*self.kappa[0]:
				print('INFEASIBLE '*5)
				if dot(self.b,self.y)>0:print('c dot y is %20.12e: primal is infeasible'%(dot(self.b,self.y)))
				if dot(self.c,self.x)<0:print('b dot x is %20.12e: dual   is infeasible'%(dot(self.c,self.x)))
			else:
				print('Worked',self.tau[0],self.kappa[0])
				self.s=[i/self.tau[0] for i in self.s]
				self.y=[i/self.tau[0] for i in self.y]
				self.x=[i/self.tau[0] for i in self.x]
		print('Time in SOCP %20.8e'%(clock()-t1))
	def rebound(self,DA):
		for i in range(DA.n):
			if DA.initial[i]>0 and self.y[i]>=DA.initial[i]:DA.L[i]=max(DA.initial[i],DA.L[i])
			elif DA.initial[i]>0 and self.y[i]<DA.initial[i] and self.y[i]>=0:DA.L[i]=max(DA.L[i],0);DA.U[i]=min(DA.initial[i],DA.U[i])
			elif DA.initial[i]<0 and self.y[i]<=DA.initial[i]:DA.U[i]=min(DA.initial[i],DA.U[i])
			elif DA.initial[i]<0 and self.y[i]>DA.initial[i] and self.y[i]<=0:DA.U[i]=min(DA.U[i],0);DA.L[i]=max(DA.initial[i],DA.L[i])
			elif self.y[i]>0:DA.L[i]=max(0,DA.L[i])
			else:DA.U[i]=min(0,DA.U[i])
			if DA.L[i]==DA.U[i]:#this is a temporary fixup, we need to remove equal bounds properly
				luold=DA.L[i]
				if DA.L[i]==0 and DA.initial[i]>=0:DA.U[i]=1e-8
				elif DA.L[i]==0 and DA.initial[i]<0:DA.L[i]=-1e-8
				elif DA.L[i]==DA.initial[i] and DA.initial[i]>=0:DA.U[i]+=1e-8
				elif DA.L[i]==DA.initial[i] and DA.initial[i]<0:DA.L[i]-=1e-8
				print('old %20.8e new (%20.8e,%20.8e)'%(luold,DA.L[i],DA.U[i]))
	def reboundP(self,DA):
		for i in range(DA.n):
			if DA.initial[i]>0 and self.x[i]>=DA.initial[i]:DA.L[i]=max(DA.initial[i],DA.L[i])
			elif DA.initial[i]>0 and self.x[i]<DA.initial[i] and self.x[i]>=0:DA.L[i]=max(0,DA.L[i]);DA.U[i]=min(DA.initial[i],DA.U[i])
			elif DA.initial[i]<0 and self.x[i]<=DA.initial[i]:DA.U[i]=min(DA.initial[i],DA.U[i])
			elif DA.initial[i]<0 and self.x[i]>DA.initial[i] and self.x[i]<=0:DA.U[i]=min(0,DA.U[i]);DA.L[i]=max(DA.initial[i],DA.L[i])
			elif self.x[i]>0:DA.L[i]=max(0,DA.L[i])
			else:DA.U[i]=min(0,DA.U[i])
			if DA.L[i]==DA.U[i]:#this is a temporary fixup, we need to remove equal bounds properly
				luold=DA.L[i]
				if DA.L[i]==0 and DA.initial[i]>=0:DA.U[i]=1e-8
				elif DA.L[i]==0 and DA.initial[i]<0:DA.L[i]=-1e-8
				elif DA.L[i]==DA.initial[i] and DA.initial[i]>=0:DA.U[i]+=1e-8
				elif DA.L[i]==DA.initial[i] and DA.initial[i]<0:DA.L[i]-=1e-8
				print('old %20.8e new (%20.8e,%20.8e)'%(luold,DA.L[i],DA.U[i]))
	def optsetupP(self,DA,toprisk,meanstd,meanstdlambda):
		order=[-1]*(DA.n)
		fixed=FixedAtEnd(DA.n,DA.L,DA.U,order)
		if fixed:
			print('Need to reorder')
		Q=self.Factor2Cov(DA.n,DA.nfac,DA.FC,DA.FL,DA.SV)
		(RQ,RQm1)=self.RootQ(DA.n,Q)
		alpha=[i for i in DA.alpha]
		alphatr=[0]*DA.n
		for i in range(DA.n):
			if DA.costs:
				if DA.L[i]>=DA.initial[i]:alpha[i]-=DA.buy[i]
				elif DA.U[i]<=DA.initial[i]:alpha[i]+=DA.sell[i]

		lsi=[]
		revi=[]
		for i in range(DA.n):
			if DA.L[i]<DA.initial[i] and DA.U[i]>DA.initial[i]:
				if DA.costs:
					alpha[i]-=(DA.buy[i]-DA.sell[i])*.5
				revi.append(i)
		if toprisk>0 or meanstd:dmxtmulv(DA.n,DA.n,RQm1,alpha,alphatr)
		else:alphatr=[i for i in alpha]
		revextra=len(revi)
		for i in range(DA.n):
			if DA.L[i]<0 and DA.U[i]>0:
				lsi.append(i)
		lsextra=len(lsi)
		print('revextra',revextra)
		print('lsextra',lsextra)
		if meanstd:print('meanstdlambda',meanstdlambda)
		if toprisk>0:print('toprisk',toprisk)
		mequal=0
		riskcon_i1=-1
		riskcon_i2=-1
		for i in range(DA.m):
			if DA.U[DA.n+i]-DA.L[DA.n+i]<1e-8:mequal+=1
		print( 'number of equality constrained constraints',mequal)
		self.ncone=[DA.n+1]+[2]*meanstd+[2]*(DA.m-mequal+DA.n+lsextra+revextra)
		self.n=len(self.ncone)
		nn=sum(self.ncone)
		self.c=[-i for i in alphatr]
		self.c+=[0]
		if meanstd:self.c+=[0,meanstdlambda]
		self.c+=[0,0]*(DA.m-mequal+DA.n+lsextra+revextra)
		assert(len(self.c)==nn)
		self.A=[]
		self.b=[]
		if toprisk>0:
			nextr=[0]*nn
			nextr[DA.n]=1
			if meanstd:nextr[DA.n+1]=1
			riskcon_i1=len(self.b)
			self.b+=[toprisk]
			self.A+=nextr
		if meanstd:
			nextr=[0]*nn
			nextr[DA.n]=-1
			nextr[DA.n+2]=1
			riskcon_i2=len(self.b)
			self.b+=[0]
			self.A+=nextr
		print( 'finished risk part')
		if(DA.m):#bounds on linear constraints
			dmx_transpose(DA.m,DA.n,DA.A,DA.A)
			im=0
			for i in range(DA.m):
				nextA=[0]*DA.n
				benchA=dot(DA.A[i*DA.n:(i+1)*DA.n],DA.benchmark)
				if toprisk>0 or meanstd:dmxtmulv(DA.n,DA.n,RQm1,DA.A[i*DA.n:(i+1)*DA.n],nextA)
				else:nextA=[k for k in DA.A[i*DA.n:(i+1)*DA.n]]
				nextr=nextA+[0]*(1+meanstd*2)+[0,0]*(DA.m-mequal+DA.n+lsextra+revextra)
				if DA.U[DA.n+i]-DA.L[DA.n+i]>=1e-8:
					nextr[DA.n+1+meanstd*2+2*im]=-1
					self.b+=[(DA.L[DA.n+i]+DA.U[DA.n+i])*.5-benchA]
					self.A+=nextr
					nextr=[0]*nn
					nextr[DA.n+1+meanstd*2+2*im+1]=1
					self.A+=nextr
					self.b+=[(DA.U[DA.n+i]-DA.L[DA.n+i])*.5]
					im+=1
				else:
					self.b+=[(DA.L[DA.n+i]+DA.U[DA.n+i])*.5-benchA]
					self.A+=nextr
			dmx_transpose(DA.n,DA.m,DA.A,DA.A)
		print( 'finished linear constraints')

		if toprisk>0 or meanstd:dmx_transpose(DA.n,DA.n,RQm1,RQm1)
		for i in range(DA.n):#bounds on stocks
			if toprisk>0 or meanstd:nextr=RQm1[i*DA.n:(i+1)*DA.n]+[0]*(1+meanstd*2)+[0,0]*(DA.m-mequal+DA.n+lsextra+revextra)
			else:
				nextr=[0]*nn
				nextr[i]=1
			nextr[DA.n+1+meanstd*2+(DA.m-mequal)*2+2*i]=-1
			self.b+=[(DA.L[i]+DA.U[i])*.5-DA.benchmark[i]]
			self.A+=nextr
			nextr=[0]*nn
			nextr[DA.n+1+meanstd*2+(DA.m-mequal)*2+2*i+1]=1
			self.A+=nextr
			self.b+=[(DA.U[i]-DA.L[i])*.5]
		print( 'finished asset constraints')
		if lsextra:
			for i in range(lsextra):#link assets to the values in 2d cones
				ni=lsi[i]
				if toprisk>0 or meanstd:nextr=RQm1[ni*DA.n:(ni+1)*DA.n]+[0]*(1+meanstd*2)+[0,0]*(DA.m-mequal+DA.n+lsextra+revextra)
				else:
					nextr=[0]*nn
					nextr[ni]=1
				nextr[DA.n+1+meanstd*2+(DA.n+DA.m-mequal)*2+2*i]=-1
				self.b+=[-DA.benchmark[ni]]
				self.A+=nextr
		if toprisk>0 or meanstd:dmx_transpose(DA.n,DA.n,RQm1,RQm1)
		if DA.ls:#put constraints for absolute values on the upper variables in the 2d cones
			nextAA=[0]*DA.n
			nextA=[0]*DA.n
			for i in range(DA.n):#link in the aseets which don't need to be split
				if DA.L[i]>=0:nextAA[i]=1
				elif DA.U[i]<=0:nextAA[i]=-1
			if toprisk>0 or meanstd:dmxtmulv(DA.n,DA.n,RQm1,nextAA,nextA)
			else:nextA=[k for k in nextAA]
			nextr=nextA+[0]*(1+meanstd*2)+[0,0]*(DA.m-mequal+DA.n+lsextra+revextra)
			benchex=dot(DA.benchmark,nextAA)
			for i in range(lsextra):
				nextr[DA.n+1+meanstd*2+(DA.n+DA.m-mequal)*2+2*i+1]=1
			self.b+=[2-benchex]#gross upper bound
			self.A+=nextr
		print( 'finished ls extras',lsextra)
		if toprisk>0 or meanstd:dmx_transpose(DA.n,DA.n,RQm1,RQm1)
		if revextra:
			for i in range(revextra):#link assets to the values in 2d cones
				ni=revi[i]
				if toprisk>0 or meanstd:nextr=RQm1[ni*DA.n:(ni+1)*DA.n]+[0]*(1+meanstd*2)+[0,0]*(DA.m-mequal+DA.n+lsextra+revextra)
				else:
					nextr=[0]*nn
					nextr[ni]=1
				nextr[DA.n+1+meanstd*2+(DA.n+DA.m-mequal)*2+2*lsextra+2*i]=-1
				self.b+=[DA.initial[ni]-DA.benchmark[ni]]
				self.A+=nextr
				self.c[DA.n+1+meanstd*2+2*(DA.m-mequal+DA.n+lsextra)+2*i+1]=0
				if DA.costs:
					self.c[DA.n+1+meanstd*2+2*(DA.m-mequal+DA.n+lsextra)+2*i+1]+=(DA.buy[ni]+DA.sell[ni])*.5
		if toprisk>0 or meanstd:dmx_transpose(DA.n,DA.n,RQm1,RQm1)
		if DA.delta>0:#put constraints for trade values on the upper variables in the 2d cones
			nextAA=[0]*DA.n
			nextA=[0]*DA.n
			for i in range(DA.n):#link in the aseets which don't need to be split
				if DA.L[i]>=DA.initial[i]:nextAA[i]=1
				elif DA.U[i]<=DA.initial[i]:nextAA[i]=-1
			delt=0.5*(dot(nextAA,DA.initial)-dot(nextAA,DA.benchmark))
			if toprisk>0 or meanstd:dmxtmulv(DA.n,DA.n,RQm1,nextAA,nextA)
			else:nextA=[k for k in nextAA]
			nextr=nextA+[0]*(1+meanstd*2)+[0,0]*(DA.m-mequal+DA.n+lsextra+revextra)
			for i in range(revextra):
				nextr[DA.n+1+meanstd*2+(DA.n+DA.m-mequal+lsextra)*2+2*i+1]=1
			self.b+=[2*(DA.delta+delt)]#turnover upper bound
			self.A+=nextr
		print( 'finished rev extras',revextra)

		self.n=len(self.ncone)
		self.m=len(self.b)
		self.y=[0]*self.m
		self.x=[0]*nn
		self.s=[0]*nn
		self.rhoconv=1e-7
		self.ccomp=1e-2
		self.cgap=1e-2

		print( 'nn %d m %d'%(nn,self.m))
		self.log=1
		self.opt()
		w=[0]*DA.n
		if toprisk>0 or meanstd:
			dmxmulv(DA.n,DA.n,RQm1,self.x[:DA.n],w)
			for i in range(DA.n):self.x[i]=w[i]
		else:w=[i for i in self.x[:DA.n]]
		w=[w[i]+DA.benchmark[i] for i in range(DA.n)]
		print( '%20s %20s %20s %20s'%('weight','initial','lower','upper'))
		for i in range(DA.n):
			print( '%20.8e %20.8e %20.8e %20.8e'%(w[i],DA.initial[i],DA.L[i],DA.U[i]))

		print( '%20s '%('Budget'))
		print( '%20.8e '%(sum([w[i] for i in range(DA.n)])) )
		print( '%20s '%('Gross'))
		print( '%20.8e '%(sum([abs(w[i]) for i in range(DA.n)])) )
		print( 'x[n] %20.8e'%self.x[DA.n])
		mu1=0
		mu2=0
		if toprisk>0:
			rr=self.x[DA.n]
			print( 'Langrange multiplier from top risk? %20.8e (implied gamma %20.8e)'%(self.y[riskcon_i1],1./(1+abs(self.y[riskcon_i1])/rr)))
			mu1=abs(self.y[riskcon_i1])
		if meanstd:
			rr=self.x[DA.n+2]
			print( 'risk from risk penalty %20.8e'%(rr))
			print( 'risk penalty (%20.8e,%20.8e)'%(self.x[DA.n+1],self.x[DA.n+2]))
			print( 'Langrange multiplier? %20.8e (implied gamma %20.8e)'%(self.y[riskcon_i2],1./(1+abs(self.y[riskcon_i2])/rr)))
			mu1=abs(self.y[riskcon_i2])
		Op=Opt()
		for i in 'n nfac SV FC FL alpha'.split():
			setattr(Op,i,getattr(DA,i))
		Op.bench=DA.benchmark
		Op.w=w[:Op.n]
		Op.props()
		Op.initial=DA.initial
		Op.buy=DA.buy
		Op.sell=DA.sell
		lagrange=max(mu1,mu2)
		Op.gamma=1./(1+lagrange/Op.risk)
		self.gamma=Op.gamma
		print( 'Lagrange multiplier %20.8e gives gamma=%20.8e'%(lagrange,Op.gamma))

		Op.kappa=DA.kappa
		Op.margutility()
		print( '%20.8e (tentative utility)'%Op.utility)
		print( '%20s '%('Absolute Risk'))
		print( '%20.8e '%Op.arisk)
		print( '%20s '%('Absolute Return'))
		print( '%20.8e '%(Op.areturn))
		print( '%20s '%('Relative Risk'))
		print( '%20.8e '%Op.risk)
		print( '%20s '%('Relative Return'))
		print( '%20.8e '%(Op.rreturn))
		cost=0
		turnover=0
		longb=0
		shortb=0
		for i in range(DA.n):
			if w[i]>=DA.initial[i]:
				cost+=(w[i]-DA.initial[i])*DA.buy[i]
				turnover+=(w[i]-DA.initial[i])
			elif w[i]<=DA.initial[i]:
				cost-=(w[i]-DA.initial[i])*DA.sell[i]
				turnover-=(w[i]-DA.initial[i])
			if w[i]>2e-8:longb+=1
			elif w[i]<-2e-8:shortb+=1
		turnover*=.5
		print( '%20s '%('cost'))
		print( '%20.8e %20.8e (from margutility)'%(cost,Op.tcost))
		print( '%20s '%('Absolute profit'))
		print( '%20.8e '%(Op.areturn-cost))
		print( '%20s '%('Relative profit'))
		print( '%20.8e '%(Op.rreturn-cost))
		print( '%20s '%('turnover'))
		print( '%20.8e '%turnover)
		print( 'long %d short %d basket %d'%(longb,shortb,longb+shortb))
		print( longshortgross(Op.w))
					
	def optsetup(self,DA,toprisk,meanstd,meanstdlambda,toparisk=-1):
		order=[-1]*(DA.n)
		fixed=FixedAtEnd(DA.n,DA.L,DA.U,order)
		if fixed:
			print( 'Need to reorder')
			
		Q=self.Factor2Cov(DA.n,DA.nfac,DA.FC,DA.FL,DA.SV)
		(RQ,RQm1)=self.RootQ(DA.n,Q)
		del RQm1
		benchtr=[0]*DA.n
		dmxtmulv(DA.n,DA.n,RQ,DA.benchmark,benchtr)
		lsi=[]
		revi=[]
		for i in range(DA.n):
			if DA.L[i]<DA.initial[i] and DA.U[i]>DA.initial[i]:
				revi.append(i)
		revextra=len(revi)
		for i in range(DA.n):
			if DA.L[i]<0 and DA.U[i]>0:
				lsi.append(i)
		lsextra=len(lsi)
		print( 'revextra',revextra)
		print( 'lsextra',lsextra)
		if meanstd:print( 'meanstdlambda',meanstdlambda)
		self.m=DA.n+lsextra+revextra+meanstd
		self.b=[i for i in DA.alpha]+[0]*lsextra+[0]*revextra+[-meanstdlambda]*meanstd
		self.c=[]
		self.A=[]
		A=[0]*self.m
		self.n=0
		self.ncone=[]
		riskcon_i1=-1
		riskcon_i2=-1
		riskcon_i3=-1
		for i in range(DA.n):#weight constraints
			if DA.L[i]==DA.U[i]:print( 'equal bounds %d'%i);continue
			A[i]=1
			self.c+=[(DA.L[i]+DA.U[i])*.5]
			self.A+=A
			A[i]=0
			self.c+=[(DA.U[i]-DA.L[i])*.5]
			self.A+=A
			self.ncone+=[2]
			self.n+=1
		if lsextra:
			for j in range(lsextra):#want |self.y[lsi[i]]| - self.y[DA.n+i] = 0 (the best we can do is < 0)
				i=lsi[j]
				A[i]=1
				self.A+=A
				self.c+=[0]
				A[i]=0
				A[j+DA.n]=-1
				self.A+=A
				A[j+DA.n]=0
				self.c+=[0]
				self.ncone+=[2]
				self.n+=1
		if DA.ls:
			print( 'set up gross value constraint')
			A=[0]*DA.n+[1]*lsextra+[0]*revextra+[0]*meanstd#Gross value constraint
			for i in range(DA.n):
				if DA.L[i]>=0:A[i]=1
				elif DA.U[i]<=0:A[i]=-1
			self.A+=A
			self.c+=[2]
			self.A+=[0]*self.m
			self.c+=[0]
			self.ncone+=[2]
			self.n+=1
		for i in range(DA.n):
			if DA.costs:
				if DA.L[i]>=DA.initial[i]:self.b[i]-=DA.buy[i]
				elif DA.U[i]<=DA.initial[i]:self.b[i]+=DA.sell[i]
		if revextra:
			A=[0]*self.m
			for j in range(revextra):#want |self.y[revi[i]]-initial[revi[i]]| - self.y[DA.n+lsextra+i] = 0 (the best we can do is < 0)
				i=revi[j]
				if DA.costs:
					self.b[j+DA.n+lsextra]-=(DA.buy[i]+DA.sell[i])*.5
					self.b[i]-=(DA.buy[i]-DA.sell[i])*.5
				A[i]=1
				self.A+=A
				self.c+=[DA.initial[i]]
				A[i]=0
				A[j+DA.n+lsextra]=-1
				self.A+=A
				A[j+DA.n+lsextra]=0
				self.c+=[0]
				self.ncone+=[2]
				self.n+=1
		if DA.delta>0:
			A=[0]*(DA.n+lsextra)+[1]*revextra+[0]*meanstd#turnover constraint
			for i in range(DA.n):
				if DA.L[i]>=DA.initial[i]:A[i]=1
				elif DA.U[i]<=DA.initial[i]:A[i]=-1
			delt=0.5*dot(DA.initial,A[:DA.n])
			print( 'Have turnover constraint; top %f'%(DA.delta+delt))
			self.A+=A
			self.c+=[DA.delta+2*delt]
			self.A+=[0]*self.m
			self.c+=[DA.delta]
			self.ncone+=[2]
			self.n+=1
		if toprisk>0:
			A=[0]*self.m
			for i in range(DA.n):#risk constraint
				self.A+=RQ[i*DA.n:(i+1)*DA.n]+[0]*lsextra+[0]*revextra+[0]*meanstd
				self.c+=[benchtr[i]]
			self.A+=A
			self.c+=[toprisk]
			riskcon_i1=sum(self.ncone)+DA.n
			self.ncone+=[DA.n+1]
			self.n+=1
		if toparisk>0:
			A=[0]*self.m
			for i in range(DA.n):#absolute risk constraint
				self.A+=RQ[i*DA.n:(i+1)*DA.n]+[0]*lsextra+[0]*revextra+[0]*meanstd
				self.c+=[0]
			self.A+=A
			self.c+=[toparisk]
			riskcon_i3=sum(self.ncone)+DA.n
			self.ncone+=[DA.n+1]
			self.n+=1
		if meanstd:
			A=[0]*self.m
			A[DA.n+lsextra+revextra]=-1
			for i in range(DA.n):
				self.A+=RQ[i*DA.n:(i+1)*DA.n]+[0]*lsextra+[0]*revextra+[0]*meanstd
				self.c+=[benchtr[i]]
			self.A+=A
			self.c+=[0]
			riskcon_i2=sum(self.ncone)+DA.n
			self.ncone+=[DA.n+1]
			self.n+=1
		dmx_transpose(DA.m,DA.n,DA.A,DA.A)
		A=[0]*self.m
		for i in range(DA.m):#linear constraints
			self.c+=[(DA.L[i+DA.n]+DA.U[i+DA.n])*.5]
			self.A+=DA.A[i*DA.n:(i+1)*DA.n]+[0]*(revextra+lsextra)+[0]*meanstd
			self.c+=[(DA.U[i+DA.n]-DA.L[i+DA.n])*.5]
			self.A+=A
			self.ncone+=[2]
			self.n+=1
		dmx_transpose(DA.n,DA.m,DA.A,DA.A)
		nn=len(self.c)
		dmx_transpose(self.m,nn,self.A,self.A)
		self.log=1

		self.x=[0]*nn
		self.s=[0]*nn

		if 0:
			self.beta=1e-06
			self.delta=0.5
			self.ccomp=10
			self.cgap=1e-1
			self.changeratio=4
			self.rhoconv=1e-02
		j=0
		for i in range(self.n):
			j+=self.ncone[i]
			self.s[j-1]=1.
			self.x[j-1]=1.
	#	self.beta=1e-6
	#	self.delta=1e-3
		self.y=[0.]*self.m
		self.tau=[1.]
		self.kappa=[1.]
		self.rhoconv=1e-7
		self.ccomp=1e-2
		self.cgap=1e-2
		print( 'nn %d m %d'%(nn,self.m))

		self.opt()

		print( '%20s %20s %20s %20s'%('weight','initial','lower','upper'))
		for i in range(DA.n):
			print( '%20.8e %20.8e %20.8e %20.8e'%(self.y[i],DA.initial[i],DA.L[i],DA.U[i]))

		print( '%20s '%('Budget'))
		print( '%20.8e '%(sum([self.y[i] for i in range(DA.n)])) )
		print( '%20s '%('Gross'))
		print( '%20.8e '%(sum([abs(self.y[i]) for i in range(DA.n)])) )

		mu1=0
		mu2=0
		mu3=0
		if toprisk>0:
			print( 'Langrangian multiplier for risk constraint? %20.8e'%self.x[riskcon_i1])
			if abs(self.x[riskcon_i1])>1e-7:print( 'gives gamma %20.8e'%(1./(1+abs(self.x[riskcon_i1])/toprisk)))
			startC=riskcon_i1-DA.n
			print( 'cone norm %20.8e'%(self.x[riskcon_i1]*self.x[riskcon_i1]-dot(self.x[startC:startC+DA.n],self.x[startC:startC+DA.n])))
			mu1=abs(self.x[riskcon_i1])
		if toparisk>0:
			print( 'Langrangian multiplier for arisk constraint %20.8e'%self.x[riskcon_i3])
			if abs(self.x[riskcon_i3])>1e-7:print( 'gives gamma %20.8e'%(1./(1+abs(self.x[riskcon_i3])/toparisk)))
			startC=riskcon_i3-DA.n
			print( 'cone norm %20.8e'%(self.x[riskcon_i3]*self.x[riskcon_i3]-dot(self.x[startC:startC+DA.n],self.x[startC:startC+DA.n])))
			mu3=abs(self.x[riskcon_i3])
		if meanstd:
			print( 'Langrangian multiplier for risk lambda? %20.8e (should be %20.8e)'%(self.x[riskcon_i2],meanstdlambda))
			startC=riskcon_i2-DA.n
			print( 'cone norm %20.8e'%(self.x[riskcon_i2]*self.x[riskcon_i2]-dot(self.x[startC:startC+DA.n],self.x[startC:startC+DA.n])))
			mu2=abs(self.x[riskcon_i2])

		lagrange=max(mu1,mu2)
		Op=Opt()
		for i in 'n nfac SV FC FL alpha'.split():
			setattr(Op,i,getattr(DA,i))
		Op.bench=DA.benchmark
		Op.w=self.y[:Op.n]
		Op.props()
		Op.initial=DA.initial
		Op.buy=DA.buy
		Op.sell=DA.sell
		Op.gamma=1./(1+lagrange/Op.risk)
		self.gamma=Op.gamma
		print( 'Lagrange multiplier %20.8e gives gamma=%20.8e'%(lagrange,Op.gamma))
		Op.kappa=DA.kappa
		Op.margutility()
		print( '%20.8e (tentative utility)'%Op.utility)
		print( '%20s '%('Benchmark Risk'))
		print( '%20.8e '%Op.brisk)
		print( '%20s '%('Absolute Risk'))
		print( '%20.8e '%Op.arisk)
		print( '%20s '%('Relative Risk'))
		print( '%20.8e '%Op.risk)
		if meanstd:print( 'risk penalty %20.8e (b is %20.8e)'%(self.y[DA.n+lsextra+revextra],self.b[DA.n+lsextra+revextra]))
		print( '%20s '%('Absolute Return'))
		print( '%20.8e '%(Op.areturn))
		print( '%20s '%('Relative Return'))
		print( '%20.8e '%(Op.rreturn))
		cost=0
		turnover=0
		longb=0
		shortb=0
		for i in range(DA.n):
			if self.y[i]>=DA.initial[i]:
				if DA.costs:
					cost+=(self.y[i]-DA.initial[i])*DA.buy[i]
				turnover+=(self.y[i]-DA.initial[i])
			elif self.y[i]<=DA.initial[i]:
				if DA.costs:
					cost-=(self.y[i]-DA.initial[i])*DA.sell[i]
				turnover-=(self.y[i]-DA.initial[i])
			if self.y[i]>2e-8:longb+=1
			elif self.y[i]<-2e-8:shortb+=1
		turnover*=.5
		print( '%20s '%('cost'))
		print( '%20.8e %20.8e (from margutility)'%(cost,Op.tcost))
		print( '%20s '%('Absolute profit'))
		print( '%20.8e '%(Op.areturn-cost))
		print( '%20s '%('Relative profit'))
		print( '%20.8e '%(Op.rreturn-cost))
		print( '%20s '%('turnover'))
		print( '%20.8e '%turnover)
		print( 'long %d short %d basket %d'%(longb,shortb,longb+shortb))
		if lsextra:
			badmod=0
			for i in range(lsextra):
				badmod+=abs(self.y[lsi[i]])-self.y[DA.n+i]
			print( '(Error in extra absolute optimisation variables %20.8e)'%badmod)
		if revextra:
			badrev=0
			for i in range(revextra):
				badrev+=abs(self.y[revi[i]]-DA.initial[revi[i]])-self.y[DA.n+lsextra+i]
			print( '(Error in extra trade optimisation variables %20.8e)'%badrev)
		for i in 'arisk risk rreturn'.split():
			setattr(self,i,getattr(Op,i))
		print( longshortgross(Op.w))

	def RootQ(self,n,Q):
		RQ=[0]*(n*n)
		RQm1=[0]*(n*n)
		RootQ(n,Q,RQ,RQm1)
		return (RQ,RQm1)
	def Factor2Cov(self,n,nfac,FC,FL,SV):
		Q=[0]*(n*(n+1)/2)
		Factor2Cov(n,nfac,FC,FL,SV,Q)
		return Q
	def popt(self,DA,maxrisk,meanstd,meanstdl,maxarisk=-1):
		"""Use SOCPportfolio to set up and perform the SOCP optimisation"""
		lambda1=[0]
		lambda2=[0]
		lambda3=[0]
		optvalue=[0]
		w=[]
		nsum=1
		nsumU=1
		min_trade=[]
		if DA.min_trade > 0:min_trade=[DA.min_trade]*DA.n
		back=SOCPportfolio(DA.n,DA.m,w,DA.L,DA.U,DA.A,DA.alpha,DA.benchmark,DA.initial,DA.buy,DA.sell,DA.costs,DA.delta,DA.psum,DA.psumL,DA.nsum,DA.nsumU,DA.rmax,DA.rmin,DA.mabs,DA.A_abs,DA.L_abs,DA.U_abs,DA.FC,DA.nfac,DA.FL,DA.SV,maxrisk,maxarisk,meanstd,meanstdl,lambda1,lambda2,lambda3,optvalue,'robinp',1,'',min_trade)
		Op=Opt()
		for i in 'n nfac SV FC FL alpha'.split():
			setattr(Op,i,getattr(DA,i))
		Op.bench=DA.benchmark
		Op.w=w
		Op.props()
		Op.initial=DA.initial
		Op.buy=DA.buy
		Op.sell=DA.sell
		ll=0
		Op.gamma=1
		if maxrisk>0 and meanstd:ll=max(lambda1[0],lambda3[0])
		elif meanstd:ll=lambda3[0]
		elif maxrisk>0:ll=lambda1[0]
		if ll:Op.gamma=1./(1+ll/Op.risk)
		self.gamma=Op.gamma
		Op.kappa=-1
		self.kappa=Op.kappa
		Op.margutility()
		print( '%20.8e (tentative utility)'%Op.utility)
		print( '%20s '%('Benchmark Risk'))
		print( '%20.8e '%Op.brisk)
		print( '%20s '%('Absolute Risk'))
		print( '%20.8e '%Op.arisk)
		print( '%20s '%('Relative Risk'))
		print( '%20.8e '%Op.risk)
		print( '%20s '%('Absolute Return'))
		print( '%20.8e '%(Op.areturn))
		print( '%20s '%('Relative Return'))
		print( '%20.8e '%(Op.rreturn))
		print( '%20s '%('cost'))
		print( '%20.8e '%(Op.tcost))
		print( '%20s '%('Absolute profit'))
		print( '%20.8e '%(Op.areturn-Op.tcost))
		print( '%20s '%('Relative profit'))
		print( '%20.8e '%(Op.rreturn-Op.tcost))
		turnover=0
		longb=0
		shortb=0
		for i in range(DA.n):
			if w[i]>=DA.initial[i]:
				turnover+=(w[i]-DA.initial[i])
			elif w[i]<=DA.initial[i]:
				turnover-=(w[i]-DA.initial[i])
			if w[i]>2e-8:longb+=1
			elif w[i]<-2e-8:shortb+=1
		turnover*=.5
		print( '%20s '%('turnover'))
		print( '%20.8e '%turnover)
		print( 'long %d short %d basket %d'%(longb,shortb,longb+shortb))
		for i in 'arisk risk rreturn'.split():
			setattr(self,i,getattr(Op,i))
		self.w=w
		if maxrisk>0:print( 'Langrange multiplier for rel. risk constraint %20.8e (gamma %20.8e)'%(lambda1[0],(1./(1+lambda1[0]/Op.risk))))
		if maxarisk>0:print( 'Langrange multiplier for abs. risk constraint %20.8e (gamma %20.8e)'%(lambda2[0],(1./(1+lambda2[0]/Op.arisk))))
		if meanstd:
			print( 'Langrange multiplier for rel. risk penalty %20.8e (gamma %20.8e)'%(lambda3[0],(1./(1+lambda3[0]/Op.risk))))
			print( 'risk from meanstd term        %f'%optvalue[0])
		if maxrisk>0 and meanstd:
			lam=lambda1[0]+lambda3[0]
			print( 'Total Langrange multiplier for rel. risk term %20.8e (gamma %20.8e)'%(lam,(1./(1+lam/Op.risk))))
		print( longshortgross(w))
class Opt:
    def __init__(self):
        self.entropy=0
        self.n=0
        self.nfac=0
        self.names=[]
        self.FC=[]
        self.FL=[]
        self.SV=[]
        self.m=0
        self.bench=[]
        self.alpha=[]
        self.A=[]
        self.L=[]
        self.U=[]
        self.gamma=0
        self.kappa=.5
        self.costs=0
        self.initial=[]
        self.delta=2
        self.buy=[]
        self.sell=[]
        self.mask=[]
        self.basket=-1
        self.tradenum=-1
        self.revise=0
        self.min_holding=-1
        self.min_trade=-1
        self.ls=0
        self.full=1
        self.rmin=-1
        self.rmax=-1
        self.round=0
        self.min_lot=[]
        self.size_lot=[]
        self.shake=[]
        self.ncomp=0
        self.Composites=[]
        self.value=1
        self.valuel=0
        self.npiece=0
        self.hpiece=[]
        self.pgrad=[]
        self.nabs=0
        self.A_abs=[]
        self.mabs=0
        self.I_A=[]
        self.Abs_U=[]
        self.Abs_L=[]
        self.Q=[]
        self.riskc=0
        self.shake=[]
        self.w=[]
        self.costgrad=None
        self.costfunc=None
        self.costhess=None
        self.SV=[]
        self.FC=[]
        self.FL=[]
        self.npoints=0
        self.frontrisk=[]
        self.frontarisk=[]
        self.frontareturn=[]
        self.frontrreturn=[]
        self.risk=[]
        self.arisk=[]
        self.areturn=[]
        self.rreturn=[]
        self.minrisk=-1
        self.maxrisk=-1
        self.take_out_costs=0
        self.log=1
        self.logfile=""
        self.downrisk=0
        self.downfactor=3
        self.DoByRisks=0
        self.longbasket=-1
        self.shortbasket=-1
        self.tradebuy=-1
        self.tradesell=-1
        self.zetaS=1
        self.zetaF=1
        self.ShortCostScale=1
        self.shortalphacost=[]
        self.never_slow=1
        self.mem_kbytes=[0]
        self.soft_m=0
        self.soft_l=[]
        self.soft_L=[]
        self.soft_U=[]
        self.soft_b=[]
        self.soft_A=[]
        self.qbuy=[]
        self.qsell=[]
        self.five=-1
        self.ten=-1
        self.forty=-1
        self.issues=[]
    def CreateDataFile(self,n,nfac,names,w,m,A,
                                    L,U,alpha,bench,Q,
                                    gamma,initial,delta,buy,
                                    sell,kappa,basket,tradenum,
                                    revise,costs,min_holding,
                                    min_trade,ls,full,rmin,
                                    rmax,round,min_lot,size_lot,
                                    shake,ncomp,Composites,value,
                                    npiece,hpiece,pgrad,nabs,A_abs,
                                    mabs,I_A,Abs_U,FC,FL,SV,
                                    minrisk,maxrisk,ogamma,mask,log,logfile,
                                    downrisk,downfactor,longbasket,shortbasket,
                                    tradebuy,tradesell,zetaS,zetaF,ShortCostScale):
        if hasattr(self,'datafile'):
            outfile=open(self.datafile,'w')
            attribs='n,nfac,names,m,A,L,U,alpha,bench,Q,gamma,initial,delta,buy,sell,kappa,basket,tradenum,revise,costs,min_holding,min_trade,ls,full,rmin,rmax,round,min_lot,size_lot,ncomp,Composites,value,npiece,hpiece,pgrad,nabs,A_abs,mabs,I_A,Abs_U,FC,FL,SV,minrisk,maxrisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale'
            for i in attribs.split(','):
                try:
                    exec ('l=len(%s)'%i)
                    outfile.write(i+'\n')
                    out=''
                    try:
                        exec ('m=len(%s[0])'%i)
                        for j in range(m):
                            for k in range(l):out+=str(eval(i)[k][j])+' '
                    except:
                        for j in range(l):
                            out+=str(eval(i)[j])+' '
                    out+='\n'
                    outfile.write(out)
                except:#Not a list
                    outfile.write(i+'\n')
                    outfile.write(str(eval(i))+'\n')
            outfile.close()
    def ReadDataFile(self):
        if hasattr(self,'datafile'):
            infile=open(self.datafile)
            while 1:
                line=infile.readline()
                if not len(line):break
                line=line.strip().split()
                if len(line)==1:
                    name=line[0]
                    print( name)
                    line=infile.readline()
                    if not len(line):break
                    data=line.strip().split()
                    if len(data)==1:setattr(self,name,change(data[0]))
                    else:setattr(self,name,[change(i) for i in data])
            if getattr(self,'logfile')==[]:setattr(self,'logfile','')
    def process(self):
        """Get the compressed risk array from risk model data."""
        if self.nfac==-1:raise 'must have 0 or more factors'
        if jython:
            if getattr(self,'Q') == []:
                    Q=array([0]*((self.n-self.ncomp)*(self.nfac+1)),'d')
            else:
                if len(self.Q) != (self.n-self.ncomp)*(self.nfac+1):raise 'member Q is too small'
                Q=array(self.Q,'d')
        else:
            Q=self.Q
        FL=self.FL
        try:
            if jython:FL=single2double(self.nfac,self.n,FL)
        except:print( 'FL not converted to [][]');pass
        factor_model_process(self.n,self.nfac,FL,self.FC,self.SV,Q)
        setattr(self,'Q',list(map(lambda t:t,Q)))
    def props(self):
        """Get the marginal risks and expected risks and returns and also factor exposures."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print( '%4d\t%20s'%(c+1,i),self.__dict__[i])
                c+=1
        FMCAR=[]
        FMCTR=[]
        FMCRR=[]
        FMCBR=[]
        FMCSR=[]
        FX=[]
        AFX=[]
        RFX=[]
        BFX=[]
        SFX=[]
        if getattr(self,'alpha')==[]:
            setattr(self,'alpha',[0]*(self.n))
        if jython:
            arisk=array([0],'d')
            risk=array([0],'d')
            Rrisk=array([0],'d')
            brisk=array([0],'d')
            pbeta=array([0],'d')
            rreturn=array([0],'d')
            areturn=array([0],'d')
            Rreturn=array([0],'d')
            breturn=array([0],'d')
            srisk=array([0],'d')
            MCAR=array([0]*self.n,'d')
            MCTR=array([0]*self.n,'d')
            MCRR=array([0]*self.n,'d')
            MCBR=array([0]*self.n,'d')
            beta=array([0]*self.n,'d')
            if self.nfac>-1:
                FMCAR=array([0]*(self.n+self.nfac),'d')
                FMCTR=array([0]*(self.n+self.nfac),'d')
                FMCRR=array([0]*(self.n+self.nfac),'d')
                FMCBR=array([0]*(self.n+self.nfac),'d')
                FMCSR=array([0]*(self.n+self.nfac),'d')
                FX=array([0]*self.nfac,'d')
                AFX=array([0]*self.nfac,'d')
                BFX=array([0]*self.nfac,'d')
                SFX=array([0]*self.nfac,'d')
                RFX=array([0]*self.nfac,'d')
        else:
            arisk=[]
            risk=[]
            Rrisk=[]
            brisk=[]
            pbeta=[]
            rreturn=[]
            areturn=[]
            Rreturn=[]
            breturn=[]
            srisk=[]
            MCAR=[]
            MCTR=[]
            MCRR=[]
            MCBR=[]
            beta=[]
        FL=self.FL
        if self.Q==[]:
            if jython:
                Q=array([0]*(self.n*(self.nfac+1)),'d')
                try:
                    if jython:FL=single2double(self.nfac,self.n,FL)
                except:print( 'FL not converted to [][]');pass
                factor_model_process(self.n,self.nfac,FL,self.FC,self.SV,Q)
                setattr(self,'Q',Q)
            else:factor_model_process(self.n,self.nfac,self.FL,self.FC,self.SV,self.Q)
        PropertiesCA(self.n,self.nfac,self.names,self.w,self.bench,self.alpha,rreturn,
                     areturn,Rreturn,breturn,self.Q,
                     risk,arisk,Rrisk,brisk,srisk,pbeta,MCAR,MCTR,MCRR,MCBR,FMCRR,
                     FMCTR,FMCAR,FMCBR,FMCSR,beta,FX,RFX,AFX,BFX,SFX,FL,self.FC,self.SV,
                     self.ncomp,self.Composites)
        for i in ['arisk','risk','Rrisk','brisk','pbeta','areturn',
                  'rreturn','Rreturn','breturn','srisk']:setattr(self,i,list(map(lambda t:t,eval(i)))[0])
        for i in ['MCAR','MCTR','MCRR','MCBR','beta','FMCAR',
                  'FMCTR','FMCRR','FMCSR','FMCBR','FX','AFX','SFX','RFX','BFX']:setattr(self,i,list(map(lambda t:t,eval(i))))
    def simplepiece_ext(self,costgrad,costfunc):
        """Set up variables for an optimisation with budget constraint and all long with
        piecewise costs define externally"""
        if(self.n==0): raise 'Number of variables has not been set'
        self.m=1
        self.L=[0]*(self.n)+[1]
        self.U=[1]*(self.n+1)
        self.A=[1]*(self.n*self.m)
        if jython:self.A=single2double(self.m,self.n,self.A)
        self.costfunc=costfunc
        self.costgrad=costgrad
        self.npiece=0
        self.hpiece=[]
        self.pgrad=[]
    def simplepiece_int(self,npiece,hpiece,pgrad):
        """Set up variables for an optimisation with budget constraint and all long with
        piecewise costs define internally"""
        if(self.n==0): raise 'Number of variables has not been set'
        self.m=1
        self.L=[0]*(self.n)+[1]
        self.U=[1]*(self.n+1)
        self.A=[1]*(self.n)
        self.A=[1]*(self.n*self.m)
        if jython:self.A=single2double(self.m,self.n,self.A)
        self.costs=1
        self.npiece=npiece
        self.hpiece=hpiece
        self.pgrad=pgrad
        self.costfunc=None
        self.costgrad=None
    def simpleset(self):
        """Set up variables for an optimisation with budget constraint and all long"""
        if(self.n==0): raise 'Number of variables has not been set'
        self.m=1
        self.L=[0]*(self.n)+[1]
        self.U=[1]*(self.n+1)
        self.A=[1]*(self.n)
        self.A=[1]*(self.n*self.m)
        if jython:self.A=single2double(self.m,self.n,self.A)
    def simplehedge(self):
        """Set up long/short/balanced optimisation"""
        if(self.n==0): raise 'Number of variables has not been set'
        self.ls=1
        self.full=1
        self.m=1
        self.L=[-1]*self.n+[0]
        self.U=[1]*self.n+[0]
        self.A=[1]*(self.n)
        self.A=[1]*(self.n*self.m)
        if jython:self.A=single2double(self.m,self.n,self.A)
    def sharpinfo(self):
        """Find portfolio with max sharp ratio (or information ratio)"""
        for i in range(self.n):
            try:
                self.names[i]=str(self.names[i])
            except:pass
        w=[]
        alpha=self.alpha
        L=self.L
        U=self.U
        A=self.A
        benchmark=self.bench
        initial=self.initial
        buy=[]
        sell=[]
        costs=0
        n=self.n
        m=self.m
        nfac=self.nfac
        delta=-1
        if self.delta>0 and self.delta<1000:
            delta=self.delta
        if self.nfac==-1:
            SV=[]
            FC=self.Q
            FL=[]
        else:
            SV=self.SV
            FC=self.FC
            FL=self.FL
        meanstd=2 #Use this to enable sharp/info
        back=SOCPportfolio(n,m,w,L,U,A,alpha,benchmark,initial,buy,sell,costs,delta,-1,-1,1,1,-1,-1,0,[],[],[],FC,nfac,FL,SV,-1,-1,meanstd)
        self.w=w
        if back >-1:setattr(self,'returnmessage',SOCPlstestMessage(back))
        else:setattr(self,'returnmessage','Optimiser is not licensed!')
        return back
    def stockparity(self):
        """Find the portfolio which equal risk contribution for each stock"""
        for i in range(self.n):
            try:
                self.names[i]=str(self.names[i])
            except:pass
        w=[1.0/self.n]*self.n
        alpha=[0]*self.n
        nsect=self.n
        if self.nfac==-1:
            SV=[]
            FC=self.Q
            FL=[]
        else:
            SV=self.SV
            FC=self.FC
            FL=self.FL
        conc=[-1]
        sectors=[]
        DFGS=0
        DiffGrad=0
        print self.nfac
        back=RiskParitySolve2(self.n,nsect,self.nfac,w,alpha,sectors,SV,FC,FL,conc,DFGS,DiffGrad,2)
        self.w=w
        if back >-1:setattr(self,'returnmessage',Return_Message(back))
        else:setattr(self,'returnmessage','Optimiser is not licensed!')
        return back
    def getmodel(self,model,stocknames):
        self.nfac=nfac=int(get_nfac(model))
        if(nfac==0):raise 'Problem with file %s, there are no factors'%model
        nstocks=get_nstocks(model)
        self.n=n=len(stocknames)
        FL=[]
        SV=[]
        if jython:
            if n:
                FL=Allocate2D(n,nfac)
                SV=array([0]*n,'d')
            FC=array([0]*(nfac*(nfac+1)/2),'d')
            fnames=array(['1'*200]*nfac,String)
            mnames=array(['1'*100]*nstocks,String)
        else:
            if n:
                FL=[0]*(n*nfac)
                SV=[0]*n
            FC=[0]*(int(nfac*(nfac+1)/2))
            fnames=['0'*200]*nfac
            mnames=['1'*100]*nstocks
        get_stocknames(mnames,model)
        get_factornames(fnames,model)
        if n:
            #print( n,nfac,stocknames,FL,SV,FC,model
            getdata(n,nfac,stocknames,FL,SV,FC,model)
        names=stocknames
        for i in ['FC','FL','SV','names','fnames','mnames']:setattr(self,i,list(map(lambda t:t,eval(i))))

    def SOCPopt(self):
        """Very basic set up for Second Order Cone Optimisation"""
        w=[]
        if jython:
            w=Convert([0,0]*self.n)
        log=self.log
        SOCPopt(self.n,self.m,self.md,self.c,self.A,self.b,w,1e-2,10,100,1,0,log)
        for i in ['w']:setattr(self,i,map(lambda t:t,eval(i)))
        
    def SOCPquad(self):
        """Use SOCP to do quadratic programming (full covariance Q)
        We do this by solving the SOCP
        min t
        such that
        Li<=xi<=Ui
        L(n+i)<=[Ax]i=U(n+i)
        ||-gamma/(1-gamma)*alpha.x + 0.5 x*Q*x|| <= scalefac*t
        We can write the || || as a square using R*R=Q
        """
        scalefac=1
        rQ=[]
        rQm1=[]
        if jython:
            rQ=Convert([0.0]*(self.n*self.n))
            rQm1=Convert([0.0]*(self.n*self.n))
        RootProcessQ(self.n,self.Q,rQ,rQm1)
        print( len(rQ))
        print( len(rQm1))
        #for i in range(self.n):#To check that we get the inverse matrix
        #    for j in range(i+1):
        #        print( dot(rQ[i*self.n:(i+1)*self.n],rQm1[j*self.n:(j+1)*self.n])
        n=self.n+1
        m=self.n+self.m+1
        md=[2]*(self.n+self.m)+[n+1]
        c=[0]*self.n+[1]
        A=[]
        for i in range(self.n):
            s=[0]*n
            s[i]=1
            A+=s
            A+=[0]*n
        for i in range(self.m):
            s=[0]*n
            for j in range(self.n):s[j]=self.A[j*self.m+i]
            A+=s
            A+=[0]*n
        cc=-self.gamma/(1-self.gamma)
        implied=[0.0]*n
        if jython:implied=Convert(implied)
        if self.bench!=[]:Sym_mult(self.n,self.Q,self.bench,implied)
        avec=[cc*self.alpha[i]-implied[i] for i in range(self.n)]
        cvec=[0]*n
        for i in range(self.n):cvec[i]=dot(avec,rQm1[i*self.n:(i+1)*self.n])
        for i in range(self.n):
            A+=toList(rQ[i*self.n:(i+1)*self.n])
            A+=[0]
        A+=[0]*n
        A+=[0]*self.n
        A+=[scalefac]
        print( len(A),(n*sum(md)))
        b=[]
        for i in range(self.n+self.m):
            b.append(-(self.L[i]+self.U[i])*.5)
            b.append((self.U[i]-self.L[i])*.5)
        b+=cvec+[0]
        """
        ## Using feasible method ##############################################
        wf=[]
        if jython:wf=jython_set([0]*n)
        SOCPopt(n,m,md,c,A,b,wf,1e-2,10,1000,1,0,self.log)
        print( "t is %20.12e; Constant %20.12e"%(scalefac*wf[n-1],(-0.5*dot(cvec,cvec)))
        print( 'BITA Utility upper limit\t%20.12e'%(0.5*(scalefac*scalefac*wf[n-1]*wf[n-1]-dot(cvec,cvec)))
        X=[0]*(self.n)
        wf=wf[:(n-1)]
        for i in range(self.n):X[i]=dot(wf,rQ[i*self.n:(i+1)*self.n])
        print( 'BITA Utility\t\t\t%20.12e'%(dot(X,X)*.5+dot(X,cvec))
        #######################################################################
        """
        ## Using infeasible method ##############################################
        nx=sum(md)
        x=[0]*nx
        s=[0]*nx
        w=[0]*n
        tau=[0]
        kappa=[0]
        if jython:
            for i in ['x','s','w','tau','kappa','A']:
                exec ('%s=jython_set(%s)'%(i,i))
        dmx_transpose(n,nx,A,A)
        if SOCPinfeasHomogt(m,n,md,b,A,c,x,w,s,tau,kappa,100,1e-8,.5,1e-9,1e-9):print( 'SOCP failed '*10)
        if tau[0]<kappa[0]:
            print( 'INFEASIBLE '*5)
            if dot(c,w)>0:print( 'c dot y %20.12e primal is infeasible'%(dot(c,w)))
            if dot(b,x)<0:print( 'b dot x is %20.12e dual is infeasible (our problem)'%(dot(b,x)))
        else:
            w=[-i/tau[0] for i in w]
            print( "t is %20.12e; Constant %20.12e"%(scalefac*w[n-1],(-0.5*dot(cvec,cvec))))
            print( 'BITA Utility upper limit\t%20.12e'%(0.5*(scalefac*scalefac*w[n-1]*w[n-1]-dot(cvec,cvec))))
            X=[0]*(self.n)
            w=w[:(n-1)]
            for i in range(self.n):X[i]=dot(w,rQ[i*self.n:(i+1)*self.n])
            print( 'BITA Utility\t\t\t%20.12e'%(dot(X,X)*.5+dot(X,cvec)))
            for i in ['w']:setattr(self,i,list(map(lambda t:t,eval(i))))
        #######################################################################

    def opt(self):
        """Optimise, if self.nfac>-1 and self.FC, self.SV and self.FL are all not empty,
            then self.Q is returned as compressed risk array."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print( '%4d\t%20s'%(c+1,i),self.__dict__[i])
                c+=1
        A=self.A
        A_abs=self.A_abs
        FL=self.FL
        try:
            if jython:A=single2double(self.m,self.n,A)
        except:print( 'A not converted to [][]');pass
        try:
            if jython:A_abs=single2double(self.nabs,self.n,A_abs)
        except:print( 'A_abs not converted to [][]');pass
        try:
            if jython:FL=single2double(self.nfac,self.n,FL)
        except:print( 'FL not converted to [][]');pass
        if jython:
            w=array([0]*self.n,'d')          #Need java objects for returned variables
            shake=array([-1]*self.n,'i')
            ogamma=array([(self.gamma)],'d')
            if getattr(self,'Q') == []:
                if getattr(self,'nfac')>-1:
                    Q=array([0]*((self.n-self.ncomp)*(self.nfac+1)),'d')
            else:
                Q=array(self.Q,'d')
        else:
            w=[]
            shake=[]
            Q=self.Q
            ogamma=[(self.gamma)]
        for i in range(self.n):
            try:
                self.names[i]=str(self.names[i])
            except:pass
        t1=clock()
        if self.costfunc == None or self.costgrad == None:
            if 0:
                """This is for testing the csdp optimiser"""
                import SDPgen
                w=[0]*(self.n)
                if self.maxrisk>0:RR=sqr(self.maxrisk)
                else:RR=0
                cov=[0]*(self.n*(self.n+1)/2)
                if self.nfac>-1:Factor2Cov(self.n,self.nfac,self.FC,self.FL,self.SV,cov)
                else:cov=Q
                ret= SDPgen.Opt(self.n,self.m,w,self.L,self.U,self.alpha,self.bench,self.gamma,self.A,cov,self.basket,RR)
            else:
                useV=0
                try:
                    print self.min_holding
                    if len(self.min_holding)>0:
                        if len(self.min_holding)==1:
                            if self.min_holding[0]==-1:
                                useV=0
                                self.min_holding=-1
                            else:
                                useV=1
                                self.min_holding=[self.min_holding[0]]*self.n
                        else:
                            useV=1
                    else:
                        useV=1
                except:pass
                try:
                    print self.min_trade
                    if len(self.min_trade)>0:
                        if len(self.min_trade)==1:
                            if self.min_trade[0]==-1:
                                useV=0
                                self.min_trade=-1
                            else:
                                useV=1
                                self.min_trade=[self.min_trade[0]]*self.n
                        else:
                            useV=1
                    else:
                        useV=1
                except:pass
                if useV:
                    if len(self.min_holding)==1:
                        self.min_holding=[self.min_holding[0]]*self.n
                        print self.min_holding
                    if len(self.min_trade)==1:
                        self.min_trade=[self.min_trade[0]]*self.n
                        print self.min_trade
                    ret = Optimise_internalCVPAFblSaMSoftQV(self.n,self.nfac,self.names,w,self.m,A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.gamma,self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.FC,FL,self.SV,
                                        self.minrisk,self.maxrisk,ogamma,self.mask,self.log,self.logfile,
                                        self.downrisk,self.downfactor,self.longbasket,self.shortbasket,
                                        self.tradebuy,self.tradesell,self.zetaS,self.zetaF,self.ShortCostScale,self.valuel,self.Abs_L,self.shortalphacost,
                                        self.never_slow,self.mem_kbytes,self.soft_m,self.soft_l,self.soft_b,self.soft_L,self.soft_U,self.soft_A,self.qbuy,self.qsell,self.five,self.ten,self.forty,self.issues)
                else:
                    ret = Optimise_internalCVPAFblSaMSoftQ(self.n,self.nfac,self.names,w,self.m,A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.gamma,self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.FC,FL,self.SV,
                                        self.minrisk,self.maxrisk,ogamma,self.mask,self.log,self.logfile,
                                        self.downrisk,self.downfactor,self.longbasket,self.shortbasket,
                                        self.tradebuy,self.tradesell,self.zetaS,self.zetaF,self.ShortCostScale,self.valuel,self.Abs_L,self.shortalphacost,
                                        self.never_slow,self.mem_kbytes,self.soft_m,self.soft_l,self.soft_b,self.soft_L,self.soft_U,self.soft_A,self.qbuy,self.qsell,self.five,self.ten,self.forty,self.issues)
        else:
            if not self.entropy:
                if self.min_holding!=-1:
                    min_holding=[self.min_holding]*self.n
                else:
                    min_holding=[]
                if self.min_trade==-1:
                    min_trade=[self.min_trade]*self.n
                else:
                    min_trade=[]
                ret = Optimise_internalCVPAextcostslSaMSoft(self.n,self.nfac,self.names,w,self.m,A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.gamma,self.initial,self.delta,self.kappa,
                                        self.basket,self.tradenum,
                                        self.revise,min_holding,
                                        min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.nabs,A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.FC,FL,self.SV,
                                        self.costfunc,self.costgrad,self.costhess,self.minrisk,self.maxrisk,ogamma,
                                        self.take_out_costs,self.mask,self.log,self.logfile,1,self.downrisk,self.downfactor,
                                        self.longbasket,self.shortbasket,
                                        self.tradebuy,self.tradesell,self.zetaS,self.zetaF,self.ShortCostScale,self.valuel,self.Abs_L,self.shortalphacost,
                                        self.never_slow,self.mem_kbytes,self.soft_m,self.soft_l,self.soft_b,self.soft_L,self.soft_U,self.soft_A,self.five,self.ten,self.forty,self.issues)
            else:
                if self.entropy==2:
                    if self.min_holding!=-1:
                        min_holding=[self.min_holding]*self.n
                    else:
                        min_holding=[]
                    if self.min_trade!=-1:
                        min_trade=[self.min_trade]*self.n
                    else:
                        min_trade=[]
                    ret = Optimise_Entropy(self.n,self.nfac,self.names,w,self.m,A,
                                            self.L,self.U,self.alpha,self.bench,Q,
                                            self.gamma,self.kappa,self.initial,self.delta,
                                            self.basket,self.tradenum,
                                            self.revise,min_holding,
                                            min_trade,self.ls,self.full,self.rmin,
                                            self.rmax,self.round,self.min_lot,self.size_lot,
                                            shake,self.ncomp,self.Composites,self.value,
                                            self.nabs,A_abs,
                                            self.mabs,self.I_A,self.Abs_U,self.FC,FL,self.SV,
                                            self.minrisk,self.maxrisk,ogamma,
                                            self.mask,self.log,self.logfile,
                                            self.longbasket,self.shortbasket,
                                            self.tradebuy,self.tradesell,self.valuel,self.Abs_L)
                elif self.entropy==1:
                    if self.min_holding!=-1 and self.min_holding!=[]:
                        min_holding=[self.min_holding]*self.n
                    else:
                        min_holding=[]
                    if self.min_trade!=-1 and self.min_trade!=[]:
                        min_trade=[self.min_trade]*self.n
                    else:
                        min_trade=[]
                    me_entropy='entropy_gamma MVlambda MVUmin MVUmax'
                    if hasattr(self,'entropy_gamma'):self.kappa=self.entropy_gamma
                    if hasattr(self,'MVlambda'):self.gamma=self.MVlambda
                    if hasattr(self,'MVUmin'):self.minrisk=self.MVUmin
                    if hasattr(self,'MVUmax'):self.maxrisk=self.MVUmax
                    #print self.n,self.nfac,self.names,w,self.m,A,self.L,self.U,self.alpha,self.bench,Q,self.gamma,self.kappa,self.initial,self.delta,self.basket,self.tradenum,self.revise,min_holding,min_trade,self.ls,self.full,self.rmin,self.rmax,self.round,self.min_lot,self.size_lot,shake,self.ncomp,self.Composites,self.value,self.nabs,A_abs,self.mabs,self.I_A,self.Abs_U,self.FC,FL,self.SV,self.minrisk,self.maxrisk,ogamma,self.mask,self.log,self.logfile,self.longbasket,self.shortbasket,self.tradebuy,self.tradesell,self.valuel,self.Abs_L
                    ret = Optimise_EntropyU(self.n,self.nfac,self.names,w,self.m,A,
                                            self.L,self.U,self.alpha,self.bench,Q,
                                            self.gamma,self.kappa,self.initial,self.delta,
                                            self.basket,self.tradenum,
                                            self.revise,min_holding,
                                            min_trade,self.ls,self.full,self.rmin,
                                            self.rmax,self.round,self.min_lot,self.size_lot,
                                            shake,self.ncomp,self.Composites,self.value,
                                            self.nabs,A_abs,
                                            self.mabs,self.I_A,self.Abs_U,self.FC,FL,self.SV,
                                            self.minrisk,self.maxrisk,ogamma,
                                            self.mask,self.log,self.logfile,
                                            self.longbasket,self.shortbasket,
                                            self.tradebuy,self.tradesell,self.valuel,self.Abs_L)
        #eigval=eigen(self.nfac,self.FC)[0]
        #print( 'Eigenvalues of the factor covariance matrix'
        #for i in range(self.nfac):
        #    print( '%4d %20.8e'%(i+1,eigval[i])
        t2=clock()
        print( 'Optimisation needed %d secs'%(t2-t1))
        if self.never_slow:print( 'Memory needed %d'%self.mem_kbytes[0])
        if ret>1:print( '@*'*10,' ',ret,' ','*@'*10);print( Return_Message(ret))
        if getattr(self,'Q')==[]:setattr(self,'Q',map(lambda t:t,Q))
        for i in ['w','shake']:setattr(self,i,list(map(lambda t:t,eval(i))))
        for i in ['ogamma']:setattr(self,i,list(map(lambda t:t,eval(i)))[0])
        if ret >-1:setattr(self,'returnmessage',Return_Message(ret))
        else:setattr(self,'returnmessage','Optimiser is not licensed!')
        return ret
    def risks(self):
        """Get risks and betas."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print( '%4d\t%20s'%(c+1,i),self.__dict__[i])
                c+=1
        if jython:
            arisk=array([0],'d')
            risk=array([0],'d')
            Rrisk=array([0],'d')
            brisk=array([0],'d')
            pbeta=array([0],'d')
        else:
            arisk=[]
            risk=[]
            Rrisk=[]
            brisk=[]
            pbeta=[]
        if self.Q==[]:
            if jython:
                Q=array([0]*(self.n*(self.nfac+1)),'d')
                FL=self.FL
                try:
                    if jython:FL=single2double(self.nfac,self.n,FL)
                except:print( 'FL not converted to [][]');pass
                factor_model_process(self.n,self.nfac,FL,self.FC,self.SV,Q)
                setattr(self,'Q',[i for i in Q])
            else:factor_model_process(self.n,self.nfac,self.FL,self.FC,self.SV,self.Q)
        Get_RisksC(self.n,self.nfac,self.Q,self.w,self.bench,arisk,risk,Rrisk,brisk,pbeta,self.ncomp,self.Composites)
        for i in ['arisk','risk','Rrisk','brisk','pbeta']:setattr(self,i,list(map(lambda t:t,eval(i)))[0])
    def margutility(self):
        """Method for getting marginal utility, cost per stock, cost and utility. More needs to be done when
            using external term in the utility function."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print( '%4d\t%20s'%(c+1,i),self.__dict__[i])
                c+=1
        if jython:
            tcost=array([0],'d')
            utility=array([0],'d')
            gradutility=array([0]*self.n,'d')
            utility_per_stock=array([0]*self.n,'d')
            cost_per_stock=array([0]*self.n,'d')
        else:
            tcost=[]
            utility=[]
            gradutility=[]
            utility_per_stock=[]
            cost_per_stock=[]
        kappa=self.kappa
        if self.costs==3:
            kappa=0
        if self.costfunc == None or self.costgrad == None:
            MarginalUtilitybSaQ(self.n,self.nfac,self.names,self.w,
                            self.bench,self.initial,
                            self.Q,self.gamma,kappa,
                            self.npiece,self.hpiece,self.pgrad,
                            self.buy,self.sell,
                            self.alpha,tcost,utility,gradutility,utility_per_stock,cost_per_stock,
                            self.ncomp,self.Composites,self.ShortCostScale,self.shortalphacost,self.qbuy,self.qsell)
        else:
            if self.kappa<0:self.kappa=self.gamma
            utility_per_stock=[]
            cost_per_stock=[]
            if not self.entropy:
                MarginalUtility_ext(self.n,self.nfac,self.names,self.w,
                                self.bench,self.initial,
                                self.Q,self.gamma,kappa,
                                self.alpha,tcost,utility,gradutility,
                                self.ncomp,self.Composites,self.ShortCostScale,self.costfunc,self.costgrad,self.shortalphacost)
            else:
                if self.entropy==2:
                    EntropyUtility(self.n,self.nfac,self.names,self.w,
                                    self.bench,self.initial,
                                    self.Q,self.gamma,kappa,
                                    self.alpha,tcost,utility,gradutility,
                                    self.ncomp,self.Composites)
                elif self.entropy==1:
                    gamma=1./(1+self.MVlambda)
                    EntropyUtility(self.n,self.nfac,self.names,self.w,
                                    self.bench,self.initial,
                                    self.Q,gamma,self.entropy_gamma,
                                    self.alpha,tcost,utility,gradutility,
                                    self.ncomp,self.Composites)
        for i in ['utility']:setattr(self,i,list(map(lambda t:t,eval(i)))[0])
        for i in ['gradutility','utility_per_stock']:setattr(self,i,list(map(lambda t:t,eval(i))))
        if self.costs==3:
            if self.costfunc == None or self.costgrad == None:
                MarginalUtilitybSa(self.n,self.nfac,self.names,self.w,
                                self.bench,self.initial,
                                self.Q,self.gamma,self.kappa,
                                self.npiece,self.hpiece,self.pgrad,
                                self.buy,self.sell,
                                self.alpha,tcost,utility,gradutility,utility_per_stock,cost_per_stock,
                                self.ncomp,self.Composites,self.ShortCostScale,self.shortalphacost)
            else:
                utility_per_stock=[]
                cost_per_stock=[]
                MarginalUtility_ext(self.n,self.nfac,self.names,self.w,
                                self.bench,self.initial,
                                self.Q,self.gamma,kappa,
                                self.alpha,tcost,utility,gradutility,
                                self.ncomp,self.Composites,self.ShortCostScale,self.costfunc,self.costgrad,self.shortalphacost)
        for i in ['tcost']:setattr(self,i,list(map(lambda t:t,eval(i)))[0])
        for i in ['cost_per_stock']:setattr(self,i,list(map(lambda t:t,eval(i))))

    def front(self):
        """The method for getting frontier points."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print( '%4d\t%20s'%(c+1,i),self.__dict__[i])
                c+=1
        if jython:
            w=array([0]*(self.n*self.npoints),'d')          #Need java objects for returned variables
            shake=array([-1]*self.n,'i')
            frontrisk=array([0]*self.npoints,'d')
            frontarisk=array([0]*self.npoints,'d')
            frontrreturn=array([0]*self.npoints,'d')
            frontareturn=array([0]*self.npoints,'d')
            if getattr(self,'Q') == []:
                if getattr(self,'nfac')>-1:
                    Q=array([0]*((self.n-self.ncomp)*(self.nfac+1)),'d')
            else:
                Q=array(self.Q,'d')
        else:
            w=[]
            shake=[]
            frontrisk=[]
            frontarisk=[]
            frontrreturn=[]
            frontareturn=[]
            Q=self.Q
        if self.costfunc == None or self.costgrad == None:
            ret = FrontierCVPAF(self.npoints,frontrisk,frontarisk,frontrreturn,frontareturn,self.n,
                                self.nfac,self.names,w,self.m,self.A,
                                self.L,self.U,self.alpha,self.bench,Q,
                                self.initial,self.delta,self.buy,
                                self.sell,self.kappa,self.basket,self.tradenum,
                                self.revise,self.costs,self.min_holding,
                                self.min_trade,self.ls,self.full,self.rmin,
                                self.rmax,self.round,self.min_lot,self.size_lot,
                                shake,self.ncomp,self.Composites,self.value,
                                self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,self.mask,self.DoByRisks)
        else:
            ret = FrontierCVPAextcostsl(self.npoints,frontrisk,frontarisk,frontrreturn,frontareturn,
                                self.n,self.nfac,self.names,w,self.m,self.A,
                                self.L,self.U,self.alpha,self.bench,Q,
                                self.initial,self.delta,self.kappa,
                                self.basket,self.tradenum,
                                self.revise,self.min_holding,
                                self.min_trade,self.ls,self.full,self.rmin,
                                self.rmax,self.round,self.min_lot,self.size_lot,
                                shake,self.ncomp,self.Composites,self.value,
                                self.nabs,self.A_abs,
                                self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                self.costfunc,self.costgrad,self.costhess,self.take_out_costs,self.mask,1,
                                self.DoByRisks,self.longbasket,self.shortbasket,self.tradebuy,self.tradesell,
                                self.ShortCostScale,self.valuel,self.Abs_L)
        if ret>1:print( '@*'*10,' ',ret,' ','*@'*10)
        if getattr(self,'Q')==[]:
            setattr(self,'Q',list(map(lambda t:t,Q)))
        for i in ['w','shake','frontrisk','frontarisk','frontrreturn',
                  'frontareturn']:setattr(self,i,list(map(lambda t:t,eval(i))))
    def analytic(self):
        KKT=[i*(1-self.gamma)/self.gamma for i in self.Q]
        KKT+=[1]*self.n+[0]
        rhs=[i for i in self.alpha]
        rhs+=[1]
        w=[0.]*(self.n+1)
        if jython:
            w=jython_set(w)
        symm_inverse_x(self.n+1,KKT,rhs,w)
        print( 'Analytic solution for sum of weights = 1 as only linear constraint')
        for i in range(self.n):
            print( '%20s %20.8e'%(self.names[i],w[i]))
    def OptviaSOCP(self):
        Rob=RobustGen()
        c=[0]*self.n
        symm_inverse_x(self.n,self.Q,self.alpha,c)
        ll=self.gamma/(1-self.gamma)
        c=[i*ll for i in c]
        Rob.n=self.n+1
        Rob.m=self.m
        Rob.alpha=[0]*self.n+[10]
        Rob.A=self.A+[0]*self.m
        Rob.L=[0]*self.n+[0]+self.L[self.n:]
        Rob.U=[1]*self.n+[1e5]+self.U[self.n:]
        Rob.full=self.full
        Rob.rmin=self.rmin
        Rob.rmax=self.rmax
        Rob.val=self.value
        Rob.nabs=self.nabs
        Rob.Aabs=self.A_abs
        Rob.Labs=self.Abs_L
        Rob.Uabs=self.Abs_U
        Rob.nq=1
        Rob.qtype=[0]
        Rob.cov=[i for i in self.Q]+[0]*self.n+[10]
        Rob.Uq=[100000]
        Rob.centres=c+[0]
        Rob.ncomp=self.ncomp
        Rob.Comps=self.Composites
        Rob.Opt()
        print( sum(Rob.w[:self.n]),Rob.w)
        print( Rob.w[self.n],pow(Rob.w[self.n]*Rob.w[self.n]*Rob.cov[-1],.5))
        Rob.Report()
        print( 'Robust solution for sum of weights = 1 as only linear constraint')
        for i in range(self.n):
            print( '%20s %20.8e'%(self.names[i],Rob.w[i]))
        y=[0]*self.n
        diff=[Rob.w[i]-Rob.centres[i] for i in range(self.n)]
        Sym_mult(self.n,self.Q,diff,y)
        print( 'quad',pow(dot(y,diff),.5))
        



