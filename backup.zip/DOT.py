#!/bin/env python
#Colin 13-1-2005
#Semi-definite optimisation interior point algorithm
from safe import DOT,combineS,symm_inverse_x,vec2symm,symmsymm,Sinv_X,A1MA2,square2symm,gensymm,eigendecomp,square2sqsymm,Sinv_M,AdotSiAX,AdotSi,SiAX,Sisymm
"""
from safe import covariance1
from random import random

a=[None]*4
for i in range(4):
    a[i]=[random() for j in range(100)]
w=[1]*100

cov=[]
for i in range(4):
    for j in range(i+1):
        cov.append(covariance1(a[i],a[j],w,100))

print cov                   
"""
def epsget():
    """Return machine accuracy."""
    a=1.3333333333333333333333333333333333333
    b=a-1.
    return 1-(b+b+b)
def step(n,X,dX,name=''):
    XidX=[0]*(n*n)
    Sinv_X(n,X,dX,XidX)
    square2sqsymm(n,XidX)
#    printsqr(n,XidX,'finding: '+name)
    eigval=[]
    r=eigendecomp(n,XidX,eigval,100)
    if r != 0:raise 'Eigenvalues were not found properly'
    return -1.0/eigval[-1]

def printsqr(n,s,name=''):
    print name
    for i in range(n):
        out=''
        for j in range(n):
            out+='%10.5f  '%s[i+j*n]
        print out
def diagset(x):
    n=len(x)+1
    aa=[0]*(n*(n+1)/2)
    for i in range(n-1):
        aa[i*(i+1)/2+i]=x[i]
    return aa
def bigA(x,end=1):
    n=len(x)
    A=[0]*((n+2)*(n+1)/2)
    ij=0
    for i in range(n):
        for j in range(i+1):
            A[ij]=x[i]*x[j]
            ij+=1
    if end:
        for i in range(n):
            A[ij]=x[i]
            ij+=1
    return A
def doublecov(n,a):
    n2=n+n
    la=len(a)
    aa=[0]*(n2*(n2+1)/2)
    ij=0
    for i in range(n2):
        for j in range(i+1):
            if i < n:
                aa[ij]=a[ij]
            else:
                ii=i-n
                if j >= n:
                    jj=j-n
                    aa[ij]=a[ii*(ii+1)/2+jj]
            ij+=1
    return aa

n=4
cov=[0.082413214985258054, 0.0085237134681903914, 0.089070270882033536, 0.0052971882656530911, -0.010020600571815669, 0.079791663443914862, 0.016249612103159561, -0.012009661280024869, -0.0056633461502720861, 0.092481531373906162]
C=[0]*((n+1)*(n+2)/2)
combineS(n,cov,[0]*n,C)
print C
a=[1,1,1,1]
m=2
A=[None]*m
A[0]=[0]*((n+1)*(n+2)/2)
A[1]=[0]*((n+1)*(n+2)/2)
#A[2]=[0]*((n+1)*(n+2)/2)
A[1][-1]=1
#A[2][1]=1
b=[2,1]

combineS(n,A[0],a,A[0])
#A[0]=bigA(a)
for i in A:print i

X=diagset([1,1,1,1])
S=diagset([1,1,1,1])
X[-1]=1
S[-1]=1
L=[0]*m
mu=0

dL=[i for i in L]
dX=[i for i in X]
dS=[i for i in S]

bigiter=0
top=100
conv=pow(epsget(),.5)
#MU=[1]*((n+1)*(n+2)/2)
#SiMU=[0]*((n+1)*(n+1))
while 1:
    print 'Iteration %d'%bigiter
    print 'X',X
    print 'S',S
    print 'L',L
    print 'Variables',X[(n*(n+1)/2):(n*(n+1)/2)+n]
    XdtS=DOT(n+1,X,S)
    prim=DOT(n+1,C,X)
    dual=sum([b[i]*L[i] for i in range(m)])
    print 'X dot S',XdtS
    print 'Primal ',prim
    print 'Dual   ',dual

    r_p=[(b[i]-DOT(n+1,A[i],X)) for i in range(m)]
    print 'r_p',r_p

    r_d=[C[i]-S[i] for i in range(len(C))]
    for i in range(m):
        for j in range(len(C)):
            r_d[j]-=L[i]*A[i][j]
    print 'r_d',r_d
    normd=sum([abs(r_d[i]) for i in range(len(r_d))])/len(r_d)
    normp=sum([abs(r_p[i]) for i in range(len(r_p))])/len(r_p)
    primdual=abs(prim-dual)/prim
    print 'normd',normd
    print 'normp',normp
    print 'primdual',primdual
    if bigiter>top:break
    if normd<conv and normp<conv and XdtS<conv:
        print '='*20+' Converged '+'='*20
        break
    mu=0
#    Sinv_X(n+1,S,MU,SiMU)
#    square2symm(n+1,SiMU)
    for meth in range(2):
        print meth,' mu is ',mu
        AA=[]
        bb=[i for i in r_p]
        for i in range(m):
            for j in range(i+1):
                AA.append(AdotSiAX(n+1,A[i],S,A[j],X))
            bb[i]+=AdotSiAX(n+1,A[i],S,r_d,X)+DOT(n+1,A[i],X)
            if mu > 0:
                bb[i]-=mu*AdotSi(n+1,A[i],S)
#                bb[i]-=mu*DOT(n+1,A[i],SiMU)
        print 'AA',AA
        print 'bb',bb
        symm_inverse_x(m,AA,bb,dL)
        print 'dL',dL
        for i in range(len(C)):
            dS[i]=r_d[i]
            for j in range(m):
                dS[i]-=A[j][i]*dL[j]
        print 'dS',dS
        interim=[0]*((n+1)*(n+1))
        SiAX(n+1,S,dS,X,interim)
        for i in range(len(X)):
            dX[i]=-interim[i]-X[i]
        if mu > 0:
            Sisymm(n+1,S,interim)
            for i in range(len(X)):
                dX[i]+=mu*interim[i]
#                dX[i]+=mu*SiMU[i]
        print 'dX',dX
        stepx=step(n+1,X,dX,'step x')
        steps=step(n+1,S,dS,'step s')
        print 'max stepx: %-.8e\tmax steps: %-.8e'%(stepx,steps)
        stepx=min(.99,stepx*.95)
        steps=min(.99,steps*.95)
        for i in range(len(S)):
            S[i]+=steps*dS[i]
            X[i]+=stepx*dX[i]
        for i in range(m):
            L[i]+=dL[i]
        if meth==0:
            muratio=DOT(n+1,X,S)/XdtS
            print 'muratio',muratio
            mu=XdtS/(n+1)*min(.9,max(.1,muratio))
            for i in range(len(S)):
                S[i]-=steps*dS[i]
                X[i]-=stepx*dX[i]
            for i in range(m):
                L[i]-=dL[i]

    bigiter+=1

x=X[(n*(n+1)/2):(n*(n+1)/2)+n]
print 'Variables from the linear part',x
xx=[pow(X[i*(i+3)/2],.5) for i in range(n)]
print 'Variables from root(diagonal) ',xx

XX=bigA(x)
XX[-1]=1
print 'X consistency test',[X[i]-XX[i] for i in range(len(X))]

XX=bigA(xx)
XX[-1]=1
print 'XX consistency test',[X[i]-XX[i] for i in range(len(X))]
