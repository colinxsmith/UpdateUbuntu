#include "ldefns.h"
void itrwri(char *name, integer iter)
{
    lm_wmsg("\n\n\n\n=================\n%s ITERATION%6ld\n=================(char*)",
	name,CL(iter));
}
