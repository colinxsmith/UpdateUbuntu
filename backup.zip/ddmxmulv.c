#include "ldefns.h"
#ifdef _OPENMP
#include<omp.h>
#endif
/*     x := diag( d )*x */
#define OMPSWITCH 2000
void ddmxmulv(dimen n, vector d, increment incd, vector x, increment incx)
{
	if(n){
		if(incd == 0 && incx != 0) BITA_dscal(n, d[0], x, incx );
		else	while(n--){
				*x *= *d;
				x += incx;
				d += incd;
				}
		}
}
/*
	multiply a vector by a diagonal matrix stored as a vector
	i.e. 	y = D x
*/
void ddmxmul(dimen n, vector D, vector x, vector y)
{
	while(n--) *y++ = *D++ * *x++;
}
/*
	multiply the transpose of an n by m matrix on an n-vector to give an m-vector
	i.e. y = A'*x
	NB	A is assumed stored in column order
*/
void dmxtmulv(dimen n, dimen m, matrix A, vector x, vector y)
{
/*
	for(i=0;i<m;i++)
	{
		y[i]=0;
		for(j=0;j<n;++j)
		{
			y[i]+=A[j+i*n]*x[j];
		}
	}

	for(i=0;i<m;i++)
	{
		y[i]=0;
	}
	for(j=0;j<n;++j)
	{
		for(i=0;i<m;i++)
		{
			y[i]+=A[j+i*n]*x[j];
		}
	}
*/	

	if(n<OMPSWITCH)
	{
		size_t j;
		dzerovec(m,y);
		for(j=0;j<n;++j)BITA_daxpy(m,x[j],A+j,n,y,1);
	}
	else
	{
		long i;
//		printf("OMP part\n");
		if(n>3000)
		{
#pragma omp parallel for private(i) schedule(dynamic)
			for(i=0;i<m;i++) y[i] = ddotvec(n,x,A+i*n);
		}
		else
		{
			for(i=0;i<m;i++) y[i] = ddotvec(n,x,A+i*n);
		}
	}



	
	
//	dimen i;
//	for(i=0;i<m;i++, A+=n) *y++ = ddotvec(n,x,A);
//	BITA_dgemv("T",n,m,1,A,n,x,1,0,y,1);
}
void dmxtmultv(dimen n, dimen m, matrix A, vector x, vector y)
{
//This doesn't make sense really but ....
//	dimen i;
//	for(i=0;i<m;i++) *y++ = BITA_ddot(n,x,1,A++,m);
	BITA_dgemv("N",m,n,1,A,m,x,1,0,y,1);
}
/*
	multiply a n by m matrix on an m-vector to give an n-vector
	i.e. y = A*x
	NB	A is assumed stored in column order
*/
void dmxmulv(dimen n, dimen m, matrix A, vector x, vector y)
{
/*
	for(i=0;i<n;i++)
	{
		y[i]=0;
		for(j=0;j<m;++j)
		{
			y[i]+=A[j*n+i]*x[j];
		}
	}
same as 
	dzerovec(n,y);
	for(j=0;j<m;++j)
	{
		for(i=0;i<n;i++)
		{
			y[i]+=A[j*n+i]*x[j];
		}
	}
same as*/
	if(n<OMPSWITCH)
	{
		size_t j;
		dzerovec(n,y);
		for(j=0;j<m;++j)daxpyvec(n,x[j],A+j*n,y);
	}
	else
	{
		long i;
		//		printf("OMP part\n");
		if(m>3000)
		{
#pragma omp parallel for private(i) schedule(dynamic)
			for(i=0;i<n;i++) y[i] = BITA_ddot(m,x,1,A+i,n);
		}
		else
		{
			for(i=0;i<n;i++) y[i] = BITA_ddot(m,x,1,A+i,n);
		}
	}

//	dzerovec(n,y);
//	BITA_dgemv("N",n,m,1,A,n,x,1,0,y,1);
//	dimen i;
//	for(i=0;i<n;i++) *y++ = BITA_ddot(m,x,1,A++,n);
}
