#include "baseoptimise.h"
#define FMT_SB \
"\n//DELCON//  SIMPLE BOUND DELETED.\n//DELCON//  NACTIV NCOLZ NFREE IFREED JDEL UNITQ\n//DELCON//%8ld%6ld%6ld%7ld%5ld%6ld"
#define FMT_GC \
"\n//DELCON//  GENERAL CONSTRAINT DELETED.\n//DELCON//  NACTIV NCOLZ NFREE  KDEL  JDEL UNITQ\n//DELCON//%8ld%6ld%6ld%6ld%6ld%6ld"
/*
	ddelcon updates the factorization of the matrix of
	constraints in the working set,  A(free)*(Z Y) = (0 T)
	if there are no general constraints in the working set and the
	matrix  Q = (Z Y)  is the identity, Q will not be touched
*/
void Base_Optimise::ddelcon(int modfyg, int orthog, int unitq, dimen jdel, dimen kdel, dimen nactiv, dimen ncolz, dimen nfree, dimen n, dimen Nq, dimen nrowa, dimen Nrowrt, short_vec kactiv, short_vec kfree, matrix a, vector qtg, matrix rt, matrix zy)
{
	dimen	i, j, k, l, ldiag;
	dimen	nfree1, nactp1, nactv1, ka;
	real	store;
	real	cs, sn;
	integer ibegin, ifreed;
	integer nfreei, nactpi, istore;


	zy -= Nq + 1;
	rt -= Nrowrt + 1;
	--qtg;
	a -= nrowa + 1;
	--kfree;
	--kactiv;

	if (jdel <= n){
		/*A SIMPLE BOUND IS BEING DELETED FROM THE WORKING SET. */
		ifreed = kdel - nactiv;
		if (msg >= 80)
			lm_wmsg(FMT_SB, CL(nactiv), CL(ncolz), CL(nfree), CL(ifreed),
				CL(jdel), CL(unitq));
		nactv1 = nactiv;
		nfree1 = nfree + 1;
		ibegin = 1;
		kfree[nfree1] = jdel;

		/*
		ADD THE GRADIENT CORRESPONDING TO THE NEWLY-FREED VARIABLE TO THE 
		END OF  Q(FREE)(T)G(FREE).  THIS IS DONE BY INTERCHANGING THE
		APPROPRIATE ELEMENTS OF  QTG  AND  KACTIV
		*/
		if(modfyg && ifreed!=1){
			nfreei = nfree + ifreed;
			nactp1 = nactiv + 1;
			nactpi = nactiv + ifreed;
			store = qtg[nfree1];
			qtg[nfree1] = qtg[nfreei];
			qtg[nfreei] = store;
			istore = kactiv[nactp1];
			kactiv[nactp1] = kactiv[nactpi];
			kactiv[nactpi] = istore;
			}

		/*COPY THE INCOMING COLUMN OF A INTO THE END OF  T. */
		if(!unitq){
			for(ka = 1; ka <= nactiv; ++ka) {
				i = kactiv[ka];
				rt[ka + nfree1 * Nrowrt] = a[i + jdel * nrowa];
				}
			/*EXPAND  Q  BY ADDING A UNIT ROW AND COLUMN. */
			dzero(nfree, &zy[nfree1 + Nq],Nq);
			dzerovec(nfree, &zy[nfree1 * Nq + 1]);
			zy[nfree1 + nfree1 * Nq] = 1;
			}
		}
	else	{
		/*A GENERAL CONSTRAINT IS BEING DELETED FROM THE WORKING SET*/
		if (msg >= 80)
			lm_wmsg(FMT_GC, CL(nactiv),CL(ncolz),CL(nfree),CL(kdel),
				CL(jdel),CL(unitq));
		nactv1 = nactiv - 1;
		nfree1 = nfree;
		ibegin = kdel;
		/*DELETE A ROW OF  T  AND MOVE THE ONES BELOW IT UP. */
		for (i = kdel; i <= nactv1; ++i) {
			j = i + 1;
			kactiv[i] = kactiv[j];
			ldiag = nfree - i;
			dcopy(j, rt+j+ldiag*Nrowrt,Nrowrt,rt+i+ldiag*Nrowrt,Nrowrt);
			}
		}

	/*
	ELIMINATE THE SUPER-DIAGONAL ELEMENTS OF  T
	USING A BACKWARD SWEEP OF 2*2 TRANFORMATIONS
	*/
	if (ibegin <= (integer) nactv1){
		k = nfree1 - ibegin;
		l = nactv1 - ibegin;
		for (i = ibegin; i <= nactv1; ++i){
			delmgen(orthog,rt+i + (k+1)*Nrowrt, rt + i + k*Nrowrt, &cs, &sn);
			if(l > 0) delm(orthog, l, rt+i+1+(k+1)*Nrowrt,1,rt+i+1+k*Nrowrt,1,cs,sn);
			if(nactv1>0) delm(orthog, nfree1,zy+(k+1)*Nq+1,1,zy+k*Nq+1,1,cs,sn);
			if(modfyg) delm(orthog,1,qtg+k+1,1,qtg+k,1,cs,sn);
			--k;
			--l;
			}
		}

	/*COMPRESS THE ELEMENTS OF  KACTIV  CORRESPONDING TO FIXED VARIABLES*/
	i = n - nfree1;
	if(i != 0){
		j = nactv1 + 1;
		for (k = 1; k <= i; ++k) {
			kactiv[j] = kactiv[j + 1];
			++j;
			}
		}
	/*ESTIMATE THE CONDITION NUMBER OF  T. */
	if(nactv1 > 0)
		dxminmax(nactv1, &rt[nactv1 + (ncolz + 2) * Nrowrt], Nrowrt - 1, &dtmax, &dtmin);
}
