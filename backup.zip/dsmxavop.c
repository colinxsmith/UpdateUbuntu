#include "ldefns.h"
/*
	add a vector outer product to a symmetric matrix stored compactly by row
*/

void	dsmxavop( dimen n, sym_matrix S, vector v )
{
	dimen	i, j;

	for(i=0;i<n;i++) {for(j=0; j<=i; j++ ) *S++ += v[i]*v[j];}
}
