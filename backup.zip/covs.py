#!/bin/env python
#Colin Smith March 2005
from Opt import *
missing=1e45
square=lambda t:t*t
cube=lambda t:t*t*t
n=1000      #Number of 'time' points
w=[1.0]*n   #weights

#Set up four series; 1, x, x*x, x*x*x on domain [0,1)
#Since the first one is constant we must get a positive semi-definite covariance matrix
nseries=4
xx=[None]*nseries
xx[0]=map(lambda t:float(1),range(n))
xx[1]=map(lambda t:float(t)/n,range(n))
xx[2]=map(lambda t:square(float(t)/n),range(n))
xx[3]=map(lambda t:cube(float(t)/n),range(n))

#Find covariance matrix....
cov=[]
for i in range(nseries):
    for j in range(i+1):
        cov.append(covariance1(xx[i],xx[j],w,n))
covprint(nseries,cov)

#...  and its eigenvalues and eigenvectors
(eig,eigv)=eigen(nseries,cov)
eigvalprint(eig)
eigvecprint(nseries,eigv)

#Mark some data as missing and repeat
#xx[1][45]=missing  #just making this one missing results in a semi-definite matrix
xx[2][44]=missing   #just making this one missing results in an indefinite matrix
#xx[3][45]=missing
cov=[]

for i in range(nseries):
    for j in range(i+1):
        cov.append(covariance1(xx[i],xx[j],w,n))

covprint(nseries,cov)
(eig,eigv)=eigen(nseries,cov)
eigvalprint(eig)
eigvecprint(nseries,eigv)

#Fix the covariances and find new eigenvalues and eigenvectors
if jython:cov=array(cov,Double)
fix_covariancem(nseries,cov)
if jython:cov=map(lambda t:t,cov)
covprint(nseries,cov)
(eig,eigv)=eigen(nseries,cov)
eigvalprint(eig)
eigvecprint(nseries,eigv)

