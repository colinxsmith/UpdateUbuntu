#include "optimise.h"
#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#endif
#ifdef _OPENMP
#include<omp.h>
#endif
#define OPT_METH_SWITCH 10000
#define softbound 1e2
#define softebound .25  //Stefano said U=.2 but getting .25 was OK. So error of .05 in .2 = .25 can be allowed
#define revert_to_zero 1
#define ls_small 1e-7 //better than 0 I think
#define round_eps lm_eps8
extern void violation_test(Optimise*Opt,char*mess=0,size_t Nvab=0);
//#define TOPPER //New arrangement in compressed risk array
extern double check_digit(double digit);
extern "C" short QPbySeqLP(size_t n,size_t m,vector w,vector c,vector A,
							  vector L,vector U,vector Q,pHmul Qwmul,void *Hinfo=0,
							  double lpeps=1e-7,double toobig=lm_max,double qpeps=1e-5,short homog=1);
extern "C" short QPopt(size_t n,size_t m,vector w,vector c,vector A,
							  vector L,vector U,vector Q,pHmul Qwmul,void *Hinfo=0,
							  double eps=1e-8,double toobig=lm_max,short homog=0);
extern "C" void QPbySeqHmul(dimen n,dimen n1,dimen n2,dimen n3,vector Q,vector x,
							vector Qx,void* info)
{
	((Base_Optimise*) info)->qphess(n,n1,n2,n3,Q,x,Qx);
}
extern "C" short Droptwo(void*info,dimen basket,dimen trades,bool SOCP=false,bool onlyfast=false,bool revway=false);

extern int check_key(char* filename,unsigned char*);
linearcostpasser::linearcostpasser()
{
	qbuy=0;//The quadratic buy costs if needed
	qsell=0;//The quadratic sell costs if needed
}
#define bask_fact 30
#ifdef PAS
bool Optimise::bitago=false;
extern "C" int DLLEXPORT UnlockBita(char* filename,char*password)
{
	int k=check_key(filename,(unsigned char*)password);
	Optimise::bitago=(k>0?true:false);
	return k;
}
#endif
void Kag_check(size_t n,vector w,double five,double ten,double forty,double&totalg5,bool&tencheck,vector amod,double eps)
{
	totalg5=0;
	tencheck=true;
	size_t modcount=0,modmax=n-(size_t)((1.0-forty)/five +.5);
	while(n--)
	{
		if(amod)*amod = 0;
		if(*w > five+eps)
		{
			totalg5 += *w;
			if(amod&&modcount<modmax){*amod = 1;modcount++;}
		}
		if(amod)amod++;
		if(ten+eps<*w)tencheck=false;
		w++;
	}
}
void Kag_check(size_t n,size_t nish,vector w,vector issues,double five,double ten,double forty,double&totalg5,bool&tencheck,vector amod,double eps)
{
	totalg5=0;
	tencheck=true;
	size_t i;
	double exp;
	size_t modcount=0,modmax=nish-(size_t)((1.0-forty)/five +.5);
	if(amod)dzerovec(n,amod);
	for(i=0;i<nish;++i)
	{
		exp=ddotvec(n,w,issues+i*n);
		if(exp > five+eps)
		{
			totalg5 += exp;
			if(amod&&modcount<modmax){daxpyvec(n,1,issues+i*n,amod);modcount++;}
		}
		if(ten+eps<exp)tencheck=false;
	}
}
double AccumulateU(void*info)		//For Optimise class only
{
	OptParamAccum*OP=(OptParamAccum*)info;
	Optimise*opt=(Optimise*)OP->MoreInfo;
	return opt->utility_base(opt->n,opt->x,opt->c,opt->H);
}
inline void AccumulateG(void *info)	//For Optimise class only
{
	OptParamAccum*OP=(OptParamAccum*)info;
	Optimise*opt=(Optimise*)OP->MoreInfo;
	if(opt->H&&!opt->lp)
	{
		opt->qphess_base(opt->n,1,1,1,opt->H,opt->x,OP->grad);
		daddvec(opt->n,OP->grad,opt->c,OP->grad);
	}
	else dcopyvec(opt->n,opt->c,OP->grad);
    
    if(opt->ModCObjectInfo && opt->ModDeriv)
    {
    	vector cc=&(*opt->buysell)[0];
        opt->ResetInitial(0);
        opt->ModDeriv(opt->n,opt->x,cc,opt->ModCObjectInfo);
        opt->ResetInitial();
        daxpyvec(opt->n,opt->scale_utility_external_terms,cc,OP->grad);
    }
}
short AccumulateOpt(void*info)//For Optimise:: only
{
	OptParamAccum*OP=(OptParamAccum*)info;
	Optimise*opt=(Optimise*)OP->MoreInfo;
		if(opt->n==OP->basket&&opt->n==OP->trades&&!opt->threshvector&&!opt->threshvector&&opt->threshscalart<0&&opt->threshscalar<0)
			opt->OptSetup(opt->n);//Do this when there is no dropping or rounding
		else
			opt->OptSetup(OP->basket,OP->trades);
		return opt->back;
}
short OptParamAccum::KagOpt()
{
	//Initial things which change here
	size_t mm=*bm;
	vector AA=*bA;
	vector L=*bL;
	vector U=*bU;
	//_________________________________
	if(lower==L&&upper==U&&A==AA)
	{
		OptFunc(this);
		if(five>0&&ten>0&&forty>0)
		{
			if(!nish)Kag_check(*bn,*bx,five,ten,forty,totalg5,tencheck,0,constraint_eps);
			else Kag_check(*bn,nish,*bx,issues,five,ten,forty,totalg5,tencheck,0,constraint_eps);
		}
	}
	else
	{
		size_t i;
		if(dokagcheck)
		{
			if(!nish)Kag_check(*bn,*bx,five,ten,forty,totalg5,tencheck,A+mm* *bn,constraint_eps);
			else Kag_check(*bn,nish,*bx,issues,five,ten,forty,totalg5,tencheck,A+(mm+nish)* *bn,constraint_eps);
			if(!nish)
			{
				for(i=0;i<*bn;++i)
				{
					if(A[mm* *bn+i]==1) upper[i]=dmin(ten,U[i]);
					else upper[i]=dmin(five,U[i]);
					if(lower[i]>upper[i])//Hope we don't get here
					{
						upper[i]=lower[i]+lm_eps8;
						if(upper[i]>five)
							A[mm* *bn+i]=1;
					}
				}
			}
			else
			{
				for(i=0;i<nish;++i)
				{
					if(ddotvec(*bn,A+(mm+nish)* *bn,issues+i* *bn)>0)
						upper[*bn+mm+i]=ten;
					else
						upper[*bn+mm+i]=five;
				}
			}
		}
		dmx_transpose(*bn,m,A,A);
		*bL=lower;
		*bU=upper;
		*bm=m;
		*bA=A;
		OptFunc(this);
		if(*bback==infease_error)dsetvec(*bn,1.0/ *bn,*bx);
		if(!nish)Kag_check(*bn,*bx,five,ten,forty,totalg5,tencheck,0,constraint_eps);
		else Kag_check(*bn,nish,*bx,issues,five,ten,forty,totalg5,tencheck,0,constraint_eps);
		*bm=mm;
		*bA=AA;
		*bL=L;
		*bU=U;
		dmx_transpose(m,*bn,A,A);
	}
	return *bback;
}
OptParamAccum::OptParamAccum(void*info)
{
	MoreInfo=info;
	lower=0;
	upper=0;
	A=0;
	grad=0;
	m=-1;
	dokagcheck=true;
	bestU=lm_max;
	basket=-1;
	trades=-1;
	nish=0;
	issues=0;
	pissues=new std::valarray<double>;
	issues_def=0;
}
OptParamAccum::~OptParamAccum()
{
	delete pissues;
}
OptPassAccum::OptPassAccum()
{
	L1=0;
	U1=0;
	A1=0;
	constraint_eps=lm_eps256;
	infease_error=6;
	Optname=0;
	Utilname=0;
	GUtilname=0;
}
OptPassAccum::~OptPassAccum()
{
	if(L1)delete[]L1;
	if(U1)delete[]U1;
	if(A1)delete[]A1;
}
void OptParamAccum::SetExtras(int way)
{
	switch (way)
	{
	case 1://For Optimise class
		{
			Optimise* opt=(Optimise*)MoreInfo;
			bn=&(opt->n);
			bm=&(opt->m);
			bback=&(opt->back);
			bL=&(opt->lower);
			bU=&(opt->upper);
			bA=&(opt->A);
			bx=&(opt->x);
			issues_def=opt->issues;//issues_def[i] is the issue code for stock i
			OptFunc=opt->KagOpt;
			UtilityFunc=opt->KagUtil;
			GradFunc=opt->KagGrad;
			five=opt->five;
			ten=opt->ten;
			forty=opt->forty;
			lower=opt->lower;
			upper=opt->upper;
			A=opt->A;
			infease_error=6;
			constraint_eps=lm_eps256;
		}
		break;
	case 2:	//For SOCPportfolio
		{
			ExtraR* opt=(ExtraR*)MoreInfo;
			issues_def=opt->issues;//issues_def[i] is the issue code for stock i
			OptFunc=opt->KagOpt;
			UtilityFunc=opt->KagUtil;
			GradFunc=opt->KagGrad;
			five=opt->five;
			ten=opt->ten;
			forty=opt->forty;
			lower=opt->lower;
			upper=opt->upper;
			A=opt->A;
			infease_error=2;
			constraint_eps=lm_rooteps;
			bn=&(opt->n);
			bm=&(opt->m);
			bback=&(opt->back);
			bL=&(opt->lower);
			bU=&(opt->upper);
			bA=&(opt->A);
			bx=&(opt->x);
		}
		break;
	case 3:	//For OptPassAccum; the Opt, Util and GUtil function pointers are set by the user (maybe via a scripting language API)
		{
			OptPassAccum* opt=(OptPassAccum*)MoreInfo;
			issues_def=opt->issues;//issues_def[i] is the issue code for stock i
			OptFunc=opt->Opt;
			UtilityFunc=opt->Util;
			GradFunc=opt->GUtil;
			five=opt->five;
			ten=opt->ten;
			forty=opt->forty;
			lower=opt->L;
			upper=opt->U;
			A=opt->A;
			infease_error=opt->infease_error;
			constraint_eps=opt->constraint_eps;
			bn=&(opt->n);
			bm=&(opt->m);
			bback=&(opt->back);
			bL=&(opt->L);
			bU=&(opt->U);
			bA=&(opt->A);
			bx=&(opt->w);
			opt->L1=new double [*bn+*bm];
			opt->U1=new double [*bn+*bm];
			opt->A1=new double [*bn* *bm];
			//Lastly we copy the original values of the things we change when doing the Accumulation Optimisation (m,L,U and A)
			opt->m1=*bm;
			dcopyvec(*bn+*bm,opt->L,opt->L1);
			dcopyvec(*bn+*bm,opt->U,opt->U1);
			dcopyvec(*bn* *bm,opt->A,opt->A1);
			//The values are copied back if necessary in the final cleanup by the user (most likely in the wrapper)
		}
		break;
	default:
		std::cerr << "No extras have been set" << std::endl;
	}
	if(issues_def)
	{
		size_t m0=*bn,m1=0,i,j;
		for(i=0;i<*bn;++i)
		{
			if(issues_def[i]<m0)m0=issues_def[i];
			if(issues_def[i]>m1)m1=issues_def[i];
		}
		nish=m1-m0+1;
		pissues->resize(nish* *bn);
		issues=&(*pissues)[0];
		for(i=0;i<nish;++i)
		{
			for(j=0;j<*bn;++j)
			{
				issues[j]=(double)(((i+m0)==issues_def[j]));
			}
			issues+=*bn;
		}
		issues=&(*pissues)[0];//Here it's tempting to reset issues to 0 if nish == n; the user shouldn't be sending issuers each of which issue only one stock!
	}
}
void OptParamAccum::UpdateSolution(vector X,size_t&UUstable)
{
	double UU=UtilityFunc(this);
	if(UU<bestU)
	{
		bestU=UU;UUstable=0;dcopyvec(n,X,x);
	}
	else
		UUstable++;
}
short Accumulation5_10_40(void*info,dimen basket,dimen trades,int way)
{
	OptParamAccum OP(info);
	OP.SetExtras(way);
	if(!info)return -2;
	OP.basket=basket;
	OP.trades=trades;

	short back=OP.KagOpt();
	if(back==OP.infease_error) return back;
	if(OP.five<0||OP.ten<0||OP.forty<0)return back;

	if(OP.totalg5<=OP.forty+lm_eps8 && OP.tencheck)return back;
	size_t n=*(OP.bn);
	//Initial things which change here
	size_t m=*(OP.bm);
	vector A=*(OP.bA);
	vector L=*(OP.bL);
	vector U=*(OP.bU);
	//_________________________________
	size_t m1=m+OP.nish+1,i;
	std::valarray<double> newL(n+m1),newU(n+m1),newA(n*m1),newx(n),grad(n);
	dcopyvec(n+m,L,&newL[0]);newL[n+OP.nish+m]=0;
	dcopyvec(n+m,U,&newU[0]);newU[n+OP.nish+m]=OP.forty;
	dmx_transpose(m,n,A,&newA[0]);
	dcopyvec(OP.nish*n,OP.issues,&newA[n*m]);
	dsetvec(OP.nish,0,&newL[n+m]);
	dsetvec(OP.nish,OP.ten,&newU[n+m]);
	OP.lower=&newL[0];
	OP.upper=&newU[0];
	OP.A=&newA[0];
	OP.grad=&grad[0];
	OP.n=n;
	OP.m=m1;
	OP.x=&newx[0];
	if(!OP.nish)
	{
		for(i=0;i<n;++i)
		{
			if(OP.ten<=U[i]&&OP.ten>=L[i])
				OP.upper[i]=OP.ten;
		}
	}
	if(OP.nish)Kag_check(*(OP.bn),OP.nish,*(OP.bx),OP.issues,OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*(m+OP.nish),OP.constraint_eps);
	else Kag_check(*(OP.bn),*(OP.bx),OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*m,OP.constraint_eps);
	OP.dokagcheck=false;
	back=OP.KagOpt();
	if(back==OP.infease_error) return back;
	if(OP.totalg5<=OP.forty+lm_eps8&&OP.tencheck)return back;

	OP.dokagcheck=true;
	double kagt;
	size_t UUstable=0,count=0,iswitch,switchc=0,topswitch=((OP.nish==0)?*(OP.bn):OP.nish);
	bool changed=false;
	std::valarray<size_t>gorder(n);
	std::valarray<double>expissues;
	if(OP.nish)
		expissues.resize(OP.nish);
	size_t j,zj,zj1;
	back=OP.KagOpt();
	while(count++<100)
	{
		if(back!=OP.infease_error) 
		{
			if(OP.totalg5<=OP.forty+OP.constraint_eps)
				OP.UpdateSolution(*(OP.bx),UUstable);
			else
				UUstable++;
		}
		else
			UUstable++;
		if(UUstable==0)switchc=0;
		back=OP.KagOpt();
		if(back!=OP.infease_error) 
		{
			if(OP.totalg5<=OP.forty+OP.constraint_eps)
				OP.UpdateSolution(*(OP.bx),UUstable);
			else
				UUstable++;
		}
		else
			UUstable++;
		if(UUstable==0)switchc=0;
		if(UUstable>3)break;
		if(back==OP.infease_error&&count>3)break;
		kagt=OP.totalg5;
		changed=false;
		if(back!=OP.infease_error&&kagt<=OP.forty+OP.constraint_eps)
		{
			OP.GradFunc(&OP);
			if(!OP.nish)
			{
				getordereig(n,OP.grad,&gorder[0],0);
			}
			else
			{
				for(j=0;j<OP.nish;++j)
					expissues[j]=ddotvec(OP.n,OP.issues+j*OP.n,OP.grad);
				getordereig(OP.nish,&expissues[0],&gorder[0],0);
				for(j=0;j<OP.nish;++j)
					expissues[j]=ddotvec(OP.n,OP.issues+j*OP.n,*(OP.bx));
			}
		}
		iswitch=switchc++;
		while(back!=OP.infease_error&&kagt<=OP.forty+OP.constraint_eps&&iswitch<topswitch)
		{
			if(!OP.nish)
			{
				if(fabs((*(OP.bx))[gorder[iswitch]] - OP.five)<=OP.constraint_eps)
				{
					OP.upper[gorder[iswitch]]=dmin(OP.ten,(*(OP.bU))[gorder[iswitch]]);
					kagt+=OP.five;
					changed=true;
				}
			}
			else
			{
				if(fabs(expissues[gorder[iswitch]] - OP.five)<=OP.constraint_eps)
				{
					OP.upper[*(OP.bn)+m+gorder[iswitch]]=dmin(OP.ten,(*(OP.bU))[gorder[iswitch]]);
					kagt+=OP.five;
					changed=true;
				}
			}
			iswitch++;
		}
		if(changed)
		{
			count++;
			OP.dokagcheck=false;
			back=OP.KagOpt();
			OP.dokagcheck=true;
		}
	}
	dcopyvec(n,OP.x,*(OP.bx));
	if(OP.nish)Kag_check(*(OP.bn),OP.nish,*(OP.bx),OP.issues,OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*(m+OP.nish),OP.constraint_eps);
	else Kag_check(*(OP.bn),*(OP.bx),OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*m,OP.constraint_eps);
	OP.GradFunc(&OP);
	getordereig(n,OP.grad,&gorder[0],0);
	bool reopt=false;
	double UUswap=OP.UtilityFunc(&OP),BestSwap=OP.bestU;
	do
	{
		if(back==OP.infease_error)break;
		if(UUswap<BestSwap)
		{
			BestSwap=UUswap;reopt=true;
			OP.GradFunc(&OP);
			getordereig(n,OP.grad,&gorder[0],0);
			if(OP.nish)Kag_check(*(OP.bn),OP.nish,*(OP.bx),OP.issues,OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*(m+OP.nish),OP.constraint_eps);
			else Kag_check(*(OP.bn),*(OP.bx),OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*m,OP.constraint_eps);
		}
		for(j=0;j<n;++j)
		{
			zj=gorder[j];
			if((*(OP.bx))[zj]>dmax((*(OP.bL))[zj],0.0)+lm_eps8)break;
		}
		for(zj1=zj;j<n;++j)
		{
			zj1=gorder[j];
			if((*(OP.bx))[zj1]<=dmax((*(OP.bL))[zj1],0.0)+lm_eps8)break;
		}
		std::swap((*(OP.bx))[zj],(*(OP.bx))[zj1]);
		UUswap=OP.UtilityFunc(&OP);
		if(UUswap>=BestSwap)
			std::swap((*(OP.bx))[zj],(*(OP.bx))[zj1]);
	}
	while(UUswap<BestSwap&&back!=OP.infease_error);
	UUswap=OP.UtilityFunc(&OP);

	do
	{
		if(back==OP.infease_error)break;
		if(UUswap<BestSwap)
		{
			BestSwap=UUswap;reopt=true;
			OP.GradFunc(&OP);
			getordereig(n,OP.grad,&gorder[0],0);
			if(OP.nish)Kag_check(*(OP.bn),OP.nish,*(OP.bx),OP.issues,OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*(m+OP.nish),OP.constraint_eps);
			else Kag_check(*(OP.bn),*(OP.bx),OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*m,OP.constraint_eps);
		}
		for(j=0;j<n;++j)
		{
			zj=gorder[j];
			if((*(OP.bx))[zj]>=OP.ten-lm_eps8)break;
		}
		for(j=0,zj1=zj;j<n;++j)
		{
			zj1=gorder[n-j-1];
			if((*(OP.bx))[zj1]>=OP.five-lm_eps8&&(*(OP.bx))[zj1]<OP.ten-lm_eps8)break;
		}
		std::swap((*(OP.bx))[zj],(*(OP.bx))[zj1]);
		UUswap=OP.UtilityFunc(&OP);
		if(UUswap>=BestSwap)
			std::swap((*(OP.bx))[zj],(*(OP.bx))[zj1]);
	}
	while(UUswap<BestSwap&&back!=OP.infease_error);
	UUswap=OP.UtilityFunc(&OP);

	do
	{
		if(back==OP.infease_error)break;
		if(UUswap<BestSwap)
		{
			BestSwap=UUswap;reopt=true;
			OP.GradFunc(&OP);
			getordereig(n,OP.grad,&gorder[0],0);
			if(OP.nish)Kag_check(*(OP.bn),OP.nish,*(OP.bx),OP.issues,OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*(m+OP.nish),OP.constraint_eps);
			else Kag_check(*(OP.bn),*(OP.bx),OP.five,OP.ten,OP.forty,OP.totalg5,OP.tencheck,OP.A+n*m,OP.constraint_eps);
		}
		for(j=0;j<n;++j)
		{
			zj=gorder[n-j-1];
			if((*(OP.bx))[zj]<dmin(OP.ten,(*(OP.bU))[zj]-lm_eps8))break;
		}
		for(zj1=zj;j<n;++j)
		{
			zj1=gorder[n-j-1];
			if((*(OP.bx))[zj1]>=dmin(OP.ten,(*(OP.bU))[zj1]-lm_eps8))break;
		}
		std::swap((*(OP.bx))[zj],(*(OP.bx))[zj1]);
		UUswap=OP.UtilityFunc(&OP);
		if(UUswap>=BestSwap)
			std::swap((*(OP.bx))[zj],(*(OP.bx))[zj1]);
	}
	while(UUswap<BestSwap&&back!=OP.infease_error);
	UUswap=OP.UtilityFunc(&OP);

	if(UUswap<OP.bestU&&back!=OP.infease_error)
	{
		back=OP.KagOpt();
		if(back!=OP.infease_error && OP.totalg5<=OP.forty+OP.constraint_eps)
			OP.UpdateSolution(*(OP.bx),UUstable);
	}
	if(back!=OP.infease_error)dcopyvec(n,OP.x,*(OP.bx));
	return back;
}
void lineprint(FILE* I,const char* name,size_t n,vector data)
{
	fprintf(I,"%s\n",name);
	for(size_t i=0;data&&i<n;++i)
		fprintf(I,"%-.17e ",data[i]);
	fprintf(I,"\n");
}
void lineprint(FILE* I, const char* name, size_t n, vector data, size_t limit)
{
	bool last = false;
	fprintf(I, "%s\n", name);
	for (size_t i = 0; data&&i < n; ++i) {
		fprintf(I, "%-.17e ", data[i]);
		last = false;
		if (i%limit == limit - 1) {
			fprintf(I, "\n");
			last = true;
		}
	}
	if(!last)fprintf(I, "\n");
}
void lineprint(FILE* I,const char* name,size_t n,int* data)
{
	fprintf(I,"%s\n",name);
	for(size_t i=0;data&&i<n;++i)
		fprintf(I,"%d ",data[i]);
	fprintf(I,"\n");
}
void lineprint(FILE* I,const char* name,size_t n,dimen* data)
{
	fprintf(I,"%s\n",name);
	for(size_t i=0;data&&i<n;++i)
		fprintf(I,"%d ",data[i]);
	fprintf(I,"\n");
}
void lineprint(FILE* I,const char* name,size_t n,char** data)
{
	fprintf(I,"%s\n",name);
	for(size_t i=0;data&&i<n;++i)
		fprintf(I,"%s ",data[i]);
	fprintf(I,"\n");
}
short BaskInnerOpt(void*info)
{
	OptParamRound*OP=(OptParamRound*)info;
	Optimise*Opt=(Optimise*)OP->MoreInfo;
	if(OP->basket==Opt->n&&OP->trades==Opt->n)Opt->AccumOpt(Opt->n);
	else Opt->AccumOpt(OP->basket,OP->trades);
	if(Opt->back == 0)
	{
		size_t i;
		double lsum,ssum;
		for(i=0,lsum=0,ssum=0;i<Opt->n;++i)
		{
			if(fabs(Opt->x[i]-Opt->lower[i])<1e-7)
				Opt->x[i]=Opt->lower[i];
			else if(fabs(Opt->x[i]-Opt->upper[i])<1e-7)
				Opt->x[i]=Opt->upper[i];
			if(Opt->x[i]>0)lsum+=Opt->x[i];
			else ssum+=Opt->x[i];
		}
/*
		FILE*OOO=fopen("opt_constraints","a");
		fprintf(OOO,"Longsum %f\n Shortsum %f\n",lsum,ssum);
		lineprint(OOO,"L",Opt->n+Opt->m,Opt->lower);
		lineprint(OOO,"U",Opt->n+Opt->m,Opt->upper);
		fflush(OOO);
		fclose(OOO);
*/
	}
	OP->back=Opt->back;
	return Opt->back;
}
double BaskUtility(void*info)
{
	OptParamRound*OP=(OptParamRound*)info;
	Optimise*OO=(Optimise*)OP->MoreInfo;
	double U=0;
	if(OO->TimeOptData)
	{
		if(OO->TimeOptData->OptType==GainLossType)
		{
			GainLossVar* GainLossData=(GainLossVar*)(OO->TimeOptData);
			GainLossData->GainCLoss(OP->x,GainLossData->losslambda+1,0,0);
			U=GainLossData->losslambda*GainLossData->Loss;
		}
		else if(OO->TimeOptData->OptType==CVarType)
		{
			MVCvar* CVData=(MVCvar*)(OO->TimeOptData);
			U=CVData->cvar_averse*CVData->CVar(OP->x);
		}
		else if(OO->TimeOptData->OptType==SemiVarType)
		{
			double tt,mm=ddotvec(OO->n,OO->TimeOptData->meanDATA,OP->x);
			if(OO->TimeOptData->benchmark)
				mm-=ddotvec(OO->n,OO->TimeOptData->meanDATA,OO->TimeOptData->benchmark);
			for(size_t i = 0;i<OO->TimeOptData->tlen;++i)
			{
				tt=BITA_ddot(OO->n,OO->TimeOptData->DATA+i,OO->TimeOptData->tlen,OP->x,1)-mm;
				if(OO->TimeOptData->benchmark)
				{
					tt-=BITA_ddot(OO->n,OO->TimeOptData->DATA+i,OO->TimeOptData->tlen,OO->TimeOptData->benchmark,1);
				}
				if(tt<-lm_eps)
					U+=tt*tt;
			}
			U*=.5;
			U/=((double)(OO->TimeOptData->tlen));
		}
	}
	U+=OO->utility_base(OP->n,OP->x,OO->c,OO->H);
	return U;
}
inline void BaskGrad(void *info)
{
	OptParamRound*OP=(OptParamRound*)info;
	Optimise*Opt=(Optimise*)OP->MoreInfo;
	Opt->qphess_base(Opt->n,1,1,1,Opt->H,OP->x,OP->grad);
	daddvec(Opt->n,OP->grad,Opt->c,OP->grad);
	if(Opt->TimeOptData)
	{
		if(Opt->TimeOptData->OptType==GainLossType)
		{
			GainLossVar* GainLossData=(GainLossVar*)(Opt->TimeOptData);
			std::valarray<double>gg(Opt->n);
			GainLossData->GainCLoss(OP->x,GainLossData->losslambda+1,&gg[0],0);//grad G-CL
			dsubvec(Opt->n,OP->grad,&gg[0],OP->grad);
			GainLossData->GainCLoss(OP->x,0,&gg[0],0);								//grad G
			daddvec(Opt->n,OP->grad,&gg[0],OP->grad);
		}
		else if(Opt->TimeOptData->OptType==CVarType)
		{
			MVCvar* CVData=(MVCvar*)(Opt->TimeOptData);
			std::valarray<double>gg(Opt->n);
			CVData->DCVar(OP->x,&gg[0]);
			daxpyvec(Opt->n,CVData->cvar_averse,&gg[0],OP->grad);
		}
		else if(Opt->TimeOptData->OptType==SemiVarType)
		{
			std::valarray<double>gg(Opt->n);gg=0;
			double tt,mm=ddotvec(Opt->n,Opt->TimeOptData->meanDATA,OP->x);
			if(Opt->TimeOptData->benchmark)
				mm-=ddotvec(Opt->n,Opt->TimeOptData->meanDATA,Opt->TimeOptData->benchmark);
			for(size_t i = 0;i<Opt->TimeOptData->tlen;++i)
			{
				tt=BITA_ddot(Opt->n,Opt->TimeOptData->DATA+i,Opt->TimeOptData->tlen,OP->x,1)-mm;
				if(Opt->TimeOptData->benchmark)
				{
					tt-=BITA_ddot(Opt->n,Opt->TimeOptData->DATA+i,Opt->TimeOptData->tlen,Opt->TimeOptData->benchmark,1);
				}
				if(tt<-lm_eps)
				{
					BITA_daxpy(Opt->n,tt,Opt->TimeOptData->DATA+i,Opt->TimeOptData->tlen,&gg[0],1);
					daxpyvec(Opt->n,-tt,Opt->TimeOptData->meanDATA,&gg[0]);
				}
			}
			daxpyvec(Opt->n,1./((double)(Opt->TimeOptData->tlen)),&gg[0],OP->grad);
		}
	}
	if(Opt->ModCObjectInfo && Opt->ModDeriv)
	{
    	vector cc=&(*Opt->buysell)[0];
		std::valarray<double>fixforGL;
		if(!cc)
		{
			//Must be GainLoss
			fixforGL.resize(Opt->n);fixforGL=0;
			cc=&fixforGL[0];
		}
        Opt->ResetInitial(0);
        Opt->ModDeriv(Opt->n,OP->x,cc,Opt->ModCObjectInfo);
        Opt->ResetInitial();
        daxpyvec(Opt->n,Opt->scale_utility_external_terms,cc,OP->grad);
    }
}

int	_dsmxmpd_check(dimen n, sym_matrix F, ldl_matrix L, short_vec P, sym_matrix S,
				   short msglvl,void*pter )

{	
	FOptimise* opter=(FOptimise*)pter;
	dsmxmpd_info_rec	info;
	int was_fixed = 0;
	vector		w = new double[n];
	size_t nn=(n*(n+1))>>1;
	std::valarray<double> Fcopy(nn);
	dcopyvec(nn,F,&Fcopy[0]);
	dsmxmpd( n, &Fcopy[0], L, w, P, &info );
	if(S&&L!=F)
	{
		opter->AddLog("dmsxmpd finished  1b=%u 2b=%u #c=%u MaxC=%lg ||err||=%lg\n",
		info.oneb, info.twob, info.ncor, info.maxc, denrm2vec(nn, F, S));
	}
	else
	{
		opter->AddLog("dmsxmpd finished 1b=%u 2b=%u #c=%u MaxC=%lg\n",
		info.oneb, info.twob, info.ncor, info.maxc );
	}
	opter->AddLog("  min/max Abs = %lg/%lg min/max = %lg/%lg\n", info.minA, info.maxA, info.minE, info.maxE );
	delete[] w;
	return (info.ncor!=0 || was_fixed);
}

//#define TZVI_DUMP //Make a dump of inputs for Optimise_internalCVPA

inline bool testonenonneg(double x1,double x2,double x3=0)
{
	double tol=10*lm_eps;
	if(fabs(x3)>tol) return 1;
	if(fabs(x1*x2)>tol) return 1;
	if(fabs(x3*x2)>tol) return 1;
	if(fabs(x1*x3)>tol) return 1;
	return 0;
}
inline bool longshorttest(size_t n,vector x,class Optimise* info)
{
	double l=0,s=0;
	while(n--)
	{
		if(*x > 0) 
			l+=*x;
		else 
			s-=*x;
		x++;
	}
	if(info->Full && !info->gross)
	{
		info->AddLog("Long value should be %-.8e\n",info->LSValue);
		info->AddLog("long %-.8e, short %-.8e\n",l,s);
		if(fabs(info->LSValue-l)>lm_rooteps)
			return 1;
	}
	else if(info->gross==2)
	{
		info->AddLog("Gross value should be %-.8e\n",info->LSValue);
		info->AddLog("long %-.8e, short -%-.8e, gross %-.8e\n",l,s,l+s);
		if(fabs(info->LSValue-l-s)>lm_rooteps)
			return 1;
	}
	else if(info->gross==1)
	{
		info->AddLog("Gross value should be above%-.8e\n",info->LSValue_Low);
		info->AddLog("long %-.8e, short -%-.8e, gross %-.8e\n",l,s,l+s);
		if((l+s-info->LSValue_Low)<-lm_rooteps)
			return 1;
	}
	return 0;
}

char*Return_Messages[]=
{
			"Optimal Solution Found",
			"Weak local minimum found, the solution is not unique",
			"Solution appears to be unbounded",
			"Local minimum found, active set may not be correct",
			"QP phase may be cycling, possibly redundant/dependant constraints",
			"QP phase reached limit iterations, change ITMAX and/or constraints",
			"LP phase couldn't find a feasible point, check the constraints",
			"LP phase may be cycling, possibly redundant/dependant constraints",
			"LP phase reached limit iterations, change ITMAX and/or constraints",
			"An input parameter was invalid",
			"Invalid Simple Bounds",
			"Super quadratic loop did not converge",
			"Cannot make the risk lie in the desired range",
			"Cost+risky asset value is not total value",
			"Risk cannot be met to satisfy the downside constraint",
			"Not enough memory for optimisation",
			"The Interior Point Method failed",
			"Omega probability not correct",
			"Risk Parity calculation failed, covariance matrix may be unstable",
			"Cannot make the mean variance utility lie in the desired range",
			"Cannot make ETL lie in the desired range"
};

Optimise::Optimise()
{
	ShortCostScale=1;
	lp_really=0;
	leave_out_trivial=0;
	lsinitial=0;
	longbasket=-1;
	shortbasket=-1;
	tradebuy=-1;
	tradesell=-1;
	drop_to_this_both=0;
	fixed_zerot=0;
	fixed_zero=0;
	have_ls = 0;
	have_rev = 0;
	UseDiagPenalty=1;
	badcountlimit=10;
	fileset = 0;
	ncomp = 0;
	Composites=0;
	drop_to_this=0;
	initial=0;
	delta=-1;
	work=0;
	neworder=0;
	inverse=0;
	lspenalty=0;
	newA=0;
	newC=0;
	newL=0;
	newU=0;
	newX=0;
	mask=0;
	shortalphacost=0;
	lab=0;
	hess_choice=1;
	Full=0;
	LSValue = 1;
	LSValue_Low = 0;
	dropfac=0.5;
	threshfac=0.1;//was 0.9
	equalbounds=lm_10minus14;
	SLRATmax=-1;
	SLRATmin=-1;
	gross=0;
	mabs=0;
	absoluteA=0;
	clocker(1);
	threshvector=0;
	threshscalar=-1;
	threshvectort=0;
	threshscalart=-1;
	take_out_costs=0;
	NaturalTurnover=-1;
	issues=0;
	five=-1;
	ten=-1;
	forty=-1;


//	printf("Optimise::Optimise()\n");
	vx = new std::valarray<double>;
	yc = new std::valarray<double>;
	CompQ = new std::valarray<double>;
	vneworder = new std::valarray<size_t>;
	effectiveorder=new std::valarray<size_t>;
	vinverse = new std::valarray<size_t>;
	vdroporder = new std::valarray<size_t>;
	vdinverse = new std::valarray<size_t>;
	vcomporder = new std::valarray<size_t>;
	vcinverse = new std::valarray<size_t>;
	fixed_implied = new std::valarray<double>;
	dropbad = new std::valarray<unsigned char>;
	buysell = new std::valarray<double>;
	SSS1 = new std::valarray<double>;
	SSS2 = new std::valarray<double>;
	SSS3 = new std::valarray<size_t>;
	SSS4 = new std::valarray<double>;
	KagOpt=AccumulateOpt;
	KagUtil=AccumulateU;
	KagGrad=AccumulateG;
}
Optimise::~Optimise()
{
	nowTime=clocker();
	lm_wmsg("Optimise::~Optimise() elapsed time since reset: %20.5f mins",nowTime/60);
	delete yc;
	delete CompQ;
	delete vx;
	delete vneworder;
	delete effectiveorder;
	delete vinverse;
	delete vdroporder;
	delete vdinverse;
	delete vcomporder;
	delete vcinverse;
	delete fixed_implied;
	delete dropbad;
	delete buysell;
	delete SSS1;
	delete SSS2;
	delete SSS3;
	delete SSS4;
}
real Optimise::shortcost(dimen n,vector w)
{
	vector a=shortalphacost;
	real back=0;
	size_t n_here=n;
	if(TimeOptData&&TimeOptData->usethis)n_here-=TimeOptData->nextra;
	if(a)
	{
		while(n_here--)
		{
			if(*w<0)
				back-=*w* *a;
			a++;w++;
		}
	}
	return back;
}
void Optimise::ResetInitial(unsigned char forward)
{
//We define this as a virtual method so that it can be called from utility_base
	size_t n_here=n;
	if(TimeOptData&&TimeOptData->usethis)n_here-=TimeOptData->nextra;
	if(!this->initial) return;
	vector initialh=this->initial;
	if(TimeOptData)
		initialh=TimeOptData->initialst;
	if(!forward)
	{
		if(optimiseorder)Reorder_gen(n_here,optimiseorder+n_here,initialh,1);
	}
	else
	{
		if(optimiseorder)Reorder_gen(n_here,optimiseorder,initialh,1);
	}
}
void Optimise::qphess(dimen nvab,dimen n1,dimen n2,dimen n3,vector Q,vector w,vector y)
{
	if(hess_choice==1)
	{
		qphess_base(nvab,n1,n2,n3,Q,w,y);
	}
	else if(hess_choice==2 || hess_choice==4)
	{
		size_t i,j;
		for(i = 0,j=0;i < nbefore;++i)
		{
			work[i] = w[i];
			if(lab[j] == i)
			{
				work[i] += w[nbefore+j++];
			}
		}

		qphess_base(nbefore,1,1,1,Q,work,y);

		for(i = 0,j=0;i < nbefore;++i)
		{
			if(lab[j] == i)
			{
				y[nbefore + j] = y[i] - lspenalty[i] * w[i];
				y[i] -= lspenalty[i] * w[nbefore + j];
				if(higher_reset)
				{
					(*ExtraQx)[nbefore + j] = (*ExtraQx)[i] - lspenalty[i] * w[i];
					(*ExtraQx)[i] -= lspenalty[i] * w[nbefore + j];
				}
				j++;
			}
		}
		if(hess_choice==4)
		{
			dzerovec(nvab-nbefore-lsi,y+nbefore+lsi);
			if(higher_reset)
			{
				dzerovec(nvab-nbefore-lsi,&(*ExtraQx)[nbefore+lsi]);
			}
		}
	}
	else if(hess_choice==3)
	{
		size_t i,j=0;
		for(i = 0;i < nbefore;++i)
		{
			work[i] = w[i];
			if(lab&&lab[j] == i)
			{
				work[i] += w[nbefore+j++];
			}
		}
		qphess_base(nbefore,1,1,1,Q,work,y);
		if(lab)
		{
			j = 0;
			for(i = 0;i < nbefore;++i)
			{
				if(lab[j] == i)
				{
//					y[nbefore + j++] = y[i];
					y[nbefore + j] = y[i] - lspenalty[i] * w[i];
					y[i] -= lspenalty[i] * w[nbefore + j];
					if(higher_reset)
					{
						(*ExtraQx)[nbefore + j] = (*ExtraQx)[i] - lspenalty[i] * w[i];
						(*ExtraQx)[i] -= lspenalty[i] * w[nbefore + j];
					}
					j++;
				}
			}
		}
	}
	else if(hess_choice == 5)
	{
		size_t i,jm=0,jr=0,zeroinit_here=0;
		for(i = 0;i < nbefore;++i)
		{
			work[i]=w[i];//long buy
			if(lab && lab[jm]==i && jm < lsi && labrev && labrev[jr]==i && jr < revi)
			{
				if(initial[i]<0)
					work[i]+=w[nbefore+jm-zeroinit_here];//short buy
				else if(initial[i]>0)
					work[i]+=w[nbefore+jm-zeroinit_here];//long sell
				else
					zeroinit_here++;
				jm++;
				work[i]+=w[nbefore+lsi-zeroinit+jr++];//short sell
			}
			else if(lab && lab[jm]==i && jm < lsi)
			{
				work[i]+=w[nbefore+jm++-zeroinit_here];
			}
			else if(labrev && labrev[jr]==i && jr < revi)
			{
				work[i]+=w[nbefore+lsi-zeroinit+jr++];
			}
		}
		qphess_base(nbefore,1,1,1,Q,work,y);
		jm = 0;
//______________________________________________________________________
		for(i = 0,jm=0,jr=0,zeroinit_here=0;i < nbefore;++i)
		{
			if(lab[jm] == i && jm < lsi && labrev[jr] == i && jr < revi)
			{
				y[nbefore + lsi-zeroinit+jr] = y[i];
				if(higher_reset)
					(*ExtraQx)[nbefore + lsi-zeroinit+jr] = (*ExtraQx)[i];
				if(initial[i]<0)
				{
					y[nbefore + jm-zeroinit_here] = y[i] - lspenalty[i] * w[i];
					y[nbefore + lsi-zeroinit+jr] = y[i] - lspenalty[i] * w[i];
					
					//y[nbefore + lsi-zeroinit+jr] -=lspenalty[i] * w[nbefore + jm-zeroinit_here];
					//y[nbefore + jm-zeroinit_here] -= lspenalty[i] * w[nbefore + lsi-zeroinit+jr];
					
					y[i] -= lspenalty[i] * w[nbefore + jm-zeroinit_here];
					y[i] -= lspenalty[i] * w[nbefore + lsi-zeroinit+jr];
					if(higher_reset)
					{
						(*ExtraQx)[nbefore + jm-zeroinit_here] = (*ExtraQx)[i] - lspenalty[i] * w[i];
						(*ExtraQx)[nbefore + lsi-zeroinit+jr] = (*ExtraQx)[i] - lspenalty[i] * w[i];
						
						//(*ExtraQx)[nbefore + lsi-zeroinit+jr] -=lspenalty[i] * w[nbefore + jm-zeroinit_here];
						//(*ExtraQx)[nbefore + jm-zeroinit_here] -= lspenalty[i] * w[nbefore + lsi-zeroinit+jr];
						
						(*ExtraQx)[i] -= lspenalty[i] * w[nbefore + jm-zeroinit_here];
						(*ExtraQx)[i] -= lspenalty[i] * w[nbefore + lsi-zeroinit+jr];
					}
				}
				else if(initial[i]>0)
				{
					//y[nbefore + jm-zeroinit_here] = y[i] - lspenalty[i] * w[i];
					y[nbefore + lsi-zeroinit+jr] = y[i] - lspenalty[i] * w[i];
					
					y[nbefore + lsi-zeroinit+jr] -=lspenalty[i] * w[nbefore + jm-zeroinit_here];
					y[nbefore + jm-zeroinit_here] = y[i]- lspenalty[i] * w[nbefore + lsi-zeroinit+jr];
					
					//y[i] -= lspenalty[i] * w[nbefore + jm-zeroinit_here];
					y[i] -= lspenalty[i] * w[nbefore + lsi-zeroinit+jr];
					if(higher_reset)
					{
						//(*ExtraQx)[nbefore + jm-zeroinit_here] = (*ExtraQx)[i] - lspenalty[i] * w[i];
						(*ExtraQx)[nbefore + lsi-zeroinit+jr] = (*ExtraQx)[i] - lspenalty[i] * w[i];
						
						(*ExtraQx)[nbefore + lsi-zeroinit+jr] -=lspenalty[i] * w[nbefore + jm-zeroinit_here];
						(*ExtraQx)[nbefore + jm-zeroinit_here] = (*ExtraQx)[i]-lspenalty[i] * w[nbefore + lsi-zeroinit+jr];
						
						//(*ExtraQx)[i] -= lspenalty[i] * w[nbefore + jm-zeroinit_here];
						(*ExtraQx)[i] -= lspenalty[i] * w[nbefore + lsi-zeroinit+jr];
					}
				}
				else
				{
					zeroinit_here++;
					y[nbefore + lsi-zeroinit+jr] -= lspenalty[i] * w[i];
					y[i]-=lspenalty[i]*w[nbefore + lsi-zeroinit+jr];
					if(higher_reset)
					{
						(*ExtraQx)[nbefore + lsi-zeroinit+jr] -= lspenalty[i] * w[i];
						(*ExtraQx)[i]-=lspenalty[i]*w[nbefore + lsi-zeroinit+jr];
					}
				}
				jr++;jm++;
			}
			else if(lab[jm] == i && jm < lsi)
			{
				y[nbefore + jm-zeroinit_here] = y[i] - lspenalty[i] * w[i];
				y[i] -= lspenalty[i] * w[nbefore + jm -zeroinit_here];
				if(higher_reset)
				{
					(*ExtraQx)[nbefore + jm-zeroinit_here] = (*ExtraQx)[i] - lspenalty[i] * w[i];
					(*ExtraQx)[i] -= lspenalty[i] * w[nbefore + jm -zeroinit_here];
				}
				jm++;
			}
			else if(labrev[jr] == i && jr < revi)
			{
				y[nbefore + lsi-zeroinit+jr] = y[i] ;//- lspenalty[i] * w[i];
				//y[i] -= lspenalty[i] * w[nbefore + lsi-zeroinit + jr];
				if(higher_reset)
				{
					(*ExtraQx)[nbefore + lsi-zeroinit+jr] = (*ExtraQx)[i] ;//- lspenalty[i] * w[i];
					//(*ExtraQx)[i] -= lspenalty[i] * w[nbefore + lsi-zeroinit + jr];
				}
				jr++;
			}
		}
	}
}
void Optimise::qphess_base(dimen nvab,dimen n1,dimen n2,dimen n3,vector Q,vector w,vector y)
{
	size_t t=0;
	if(TimeOptData&&TimeOptData->opt)
	{
		t=TimeOptData->tlen;
		if(TimeOptData->OptType==CVarType)
			t++;
		dzerovec(t,y+nvab-t);
		if(TimeOptData->OptType==SemiVarType)
		{
			dcopyvec(t,w+nvab-t,y+nvab-t);
			dscalvec(t,1./(TimeOptData->tlen),y+nvab-t);
		}
	}
	if(!Q)
	{
		dzerovec(nvab-t,y);
	}
	else
	{
		if(!ncomp)
			hmul(nvab-t,n1,n2,n3,Q,w,y,HmulObjectInfo);
		else
		{
			size_t i;
			hmul(nvab-t-ncomp,n1,n2,n3,Q,w,y,HmulObjectInfo);
			dsmxmulv(ncomp-t,&(*CompQ)[0],w+nvab-ncomp,y+nvab-ncomp);
			for(i=0;i<ncomp;++i)
				y[nvab-t-ncomp+i]+=ddotvec(nvab-t-ncomp,&(*yc)[i*(n-t-ncomp)],w);
			for(i=0;i<ncomp;++i)
				daxpyvec(nvab-t-ncomp,w[nvab-t-ncomp+i],&(*yc)[i*(n-t-ncomp)],y);
		}
	}
/*	if(TimeOptData&&TimeOptData->opt&&TimeOptData->OptType==SemiVarType)
	{
		size_t i;
		for(i=0;i<t;++i)
		{
			BITA_daxpy(nvab-t,.25*(w[nvab-t+i]+BITA_ddot(nvab-t,TimeOptData->DATA+i,t,w,1)) /(t-1),TimeOptData->DATA+i,t,y,1);
		}
	}*/
	if(ModHessian && use_higher_H)//Won't be correct for Gain/Loss new method
	{
		std::valarray<double>yy(nvab);
		if(higher_reset)
		{
			dzerovec(n*(n+1)/2,H_from_higher_terms);
			std::valarray<double>XXX(n);
			dcopyvec(nvab,w,&XXX[0]);
			dcopyvec(n-nvab,x+nvab,&XXX[nvab]);
			if(hess_choice==3 || hess_choice==5)
			{
				daddvec(n,&XXX[0],initial,&XXX[0]);
			}
			ResetInitial(0);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&XXX[0],1);
			ModHessian(n,&XXX[0],H_from_higher_terms,ModQObjectInfo);
			ResetInitial();
			dscalvec(n*(n+1)/2,scale_utility_external_terms,H_from_higher_terms);
			if(optimiseorder)Reorder_sym(n,optimiseorder,H_from_higher_terms);
		}
		dsmxmulv(nvab,H_from_higher_terms,w,&yy[0]);
		if(higher_reset)
			dcopyvec(nvab,&yy[0],&(*ExtraQx)[0]);
		daddvec(nvab,y,&yy[0],y);
	}
	if(use_soft_in_hessmult&&soft_m)//Won't be correct for Gain/Loss new method
	{
		size_t i;
		double ss;
		for(i=0;i<soft_m;++i)
		{
			ss=BITA_ddot(nvab,soft_A+i,soft_m,w,1);
			if(ss!=0)
			{
				ss*=soft_l[i];
				BITA_daxpy(nvab,ss,soft_A+i,soft_m,y,1);
			}
		}
	}
}
short Optimise::GOpt(dimen nvab,dimen m,vector x,vector A,vector lower,vector upper,vector c)
{
	size_t badcount = 0;
	upperusednow=upper;
	lowerusednow=lower;
	for(size_t is=0;is<nvab;++is)
	{
		if(x[is]<lower[is])
		{
			x[is]=(lower[is]+upper[is])*.5;
		}
		else if(x[is]>upper[is])
		{
			x[is]=(lower[is]+upper[is])*.5;
		}
	}
	if(hess_choice == 1)
	{
		if(!have_rev && !have_ls)
		{
			short back;
			if(TimeOptData&&TimeOptData->OptType == CVarType)
			{
				size_t i= nvab-TimeOptData->nextra;
				lower[i] = -upper[i];
			}

			switch(this->useInteriorPoint)
			{
			case 0:
				if(nvab<OPT_METH_SWITCH)
					back=Opt(nvab,m,x,A,lower,upper,c);
				else
					back=OptInterior(nvab,m,x,A,lower,upper,c);
				break;
			case 1:
				back=OptInterior(nvab,m,x,A,lower,upper,c);
				break;
			case 2:
				back=QPbySeqLP(nvab,m,x,c,A,lower,upper,H,QPbySeqHmul,this);
				break;
			case 3:
				back=QPopt(nvab,m,x,c,A,lower,upper,H,QPbySeqHmul,this);
							break;
			}
			if(TimeOptData&&TimeOptData->OptType == CVarType)
			{
				size_t i= nvab-TimeOptData->nextra;
				lower[i] = 0;
			}
			if(back==5 && lp_really) back=0;
			return back;
		}
		else
		{
			AddLog("CHOICE 1\n");
			size_t MM=m+have_ls+(SLRATmax>0)+(SLRATmin>0)+mabs+(have_rev&&delta>-lm_eps),k,i;
			std::valarray<double> space4(nvab*MM+2*(nvab+MM));
			vector newA=&(space4)[0];
			vector newL=newA+nvab*MM;
			vector newU=newL+nvab+MM;
			vector newconls=newA+nvab*m;
			vector newconrev=newA+nvab*(m+have_ls+mabs+(SLRATmax>0)+(SLRATmin>0));
			std::valarray<double>newC;
			if(shortalphacost)
			{
				newC.resize(n);
				dcopyvec(n,c,&newC[0]);
			}


			size_t lsratn;
			for(i=0;i<nvab;++i)
			{
				lsratn=1;
				newL[i] = lower[i];
				newU[i] = upper[i];
				if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
				{
					newL[i] = -upper[i];
					newU[i] = upper[i];
					newC[i] = c[i];
				}
				for(k = 0;k < m;++k)
				{
					newA[i+k*nvab] = A[k+i*m];
					if(take_out_costs && k == 0 && !have_ls)
					{
						if(lower[i]>initial[i])
							newA[i+k*nvab] += (*buysell)[i]/scale_utility_external_terms;
						else 
							newA[i+k*nvab] += (*buysell)[n+i]/scale_utility_external_terms;
					}
				}
				if(have_ls)
				{
					if(lower[i]>=0)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							newconls[i]=1;
							if(take_out_costs)
								newconls[i]+=1.0/scale_utility_external_terms*((lower[i]>initial[i])?(*buysell)[i]:(*buysell)[n+i]);
							if(SLRATmin>0)
								newconls[i+nvab*lsratn++]=-SLRATmin;
							if(SLRATmax>0)
								newconls[i+nvab*lsratn++]=-SLRATmax;
							for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*nvab]=absoluteA[i*mabs+k];}
						}
					}
					else if(upper[i]<=0)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							newconls[i]=(gross?-1:0);
							if(take_out_costs&&gross)
								newconls[i]+=1.0/scale_utility_external_terms*((lower[i]>initial[i])?(*buysell)[i]:(*buysell)[n+i]);
							if(SLRATmin>0)
								newconls[i+nvab*lsratn++]=-1;
							if(SLRATmax>0)
								newconls[i+nvab*lsratn++]=-1;
							for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*nvab]=-absoluteA[i*mabs+k];}
							if(shortalphacost)
							{
								newC[i]+=shortalphacost[i];
							}
						}
					}
					else
					{
						std::exception();
					}
				}
				if(have_rev && delta>-lm_eps)
				{
					if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
					{

					}
					else
					{

						if(lower[i]>=initial[i])
						{
							newconrev[i]=(mask?mask[i]:1);
						}
						else if(upper[i]<=initial[i])
						{
							newconrev[i]=(mask?-mask[i]:-1);
						}
						else
						{
							std::exception();
						}
					}
				}
			}
			for(k = 0;k < m;++k)
			{
				newL[nvab+k] = lower[nvab+k];
				newU[nvab+k] = upper[nvab+k];
				if(take_out_costs && k == 0 && !have_ls)
				{
					double vvv=0;
					for(i=0;i<nvab;++i)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(lower[i]>initial[i])
								vvv+=initial[i]*(*buysell)[i]/scale_utility_external_terms;
							else
								vvv+=initial[i]*(*buysell)[i+n]/scale_utility_external_terms;
						}
					}
					newL[nvab+k]+=vvv;
					newU[nvab+k]+=vvv;
				}

			}
	//________________________________________________COVER LONG SUM IN (0,LSValue)
			if(have_ls)
			{
				lsratn=0;
				newL[nvab+m] = (gross?LSValue_Low:(Full ?LSValue:LSValue_Low));
				newU[nvab+m] = LSValue;
				if(take_out_costs)
				{
					double vvv=0;
					for(i=0;i<nvab;++i)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if((lower[i]>0)||gross)
							{
								if(lower[i]>initial[i])
									vvv+=initial[i]*(*buysell)[i];
								else
									vvv+=initial[i]*(*buysell)[i+n];
							}
						}
					}
					newL[nvab+m]+=vvv/scale_utility_external_terms;
					newU[nvab+m]+=vvv/scale_utility_external_terms;
				}
				if(SLRATmin>0)
				{
					newL[nvab+m+1+lsratn] = 0;
					newU[nvab+m+1+lsratn++] = 1000;
				}
				if(SLRATmax>0)
				{
					newL[nvab+m+1+lsratn] = -1000;
					newU[nvab+m+1+lsratn++] = 0;
				}
				for(i=0;i < (n-nvab);++i)
				{
					lsratn=0;
					if(x[i+nvab] > 0)
					{
						newL[nvab+m] -= x[i+nvab];
						newU[nvab+m] -= x[i+nvab];
					}
					else if(gross&&(x[i+nvab]<0))
					{
						newL[nvab+m] += x[i+nvab];
						newU[nvab+m] += x[i+nvab];
					}
					if(SLRATmin>0)
					{
						if(x[i+nvab] > 0)
						{
							newL[nvab+m+1+lsratn] += SLRATmin*x[i+nvab];
						}
						else if(x[i+nvab] < 0)
						{
							newL[nvab+m+1+lsratn] += x[i+nvab];
						}
						lsratn++;
					}
					if(SLRATmax>0)
					{
						if(x[i+nvab] > 0)
						{
							newU[nvab+m+1+lsratn] += SLRATmax*x[i+nvab];
						}
						else if(x[i+nvab] < 0)
						{
							newU[nvab+m+1+lsratn] += x[i+nvab];
						}
						lsratn++;
					}
				}
				if(newU[nvab+m] < newL[nvab+m])
				{
					back=6;
					AddLog("Impossible gross or cover bounds\n");
				}
				if(gross==2)
					newL[nvab+m]=newU[nvab+m];
			}
	//________________________________________________Absolute
			for(k=0;have_ls&&(k<mabs);++k)
			{
				newL[nvab+m+1+k+(SLRATmin>0)+(SLRATmax>0)] = lowerA[k];
				newU[nvab+m+1+k+(SLRATmin>0)+(SLRATmax>0)] = upperA[k];
				for(i=0;i < (n-nvab);++i)
				{
					if(x[i+nvab] > 0)
					{
						newL[nvab+m+1+k+(SLRATmin>0)+(SLRATmax>0)] -= absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
						newU[nvab+m+1+k+(SLRATmin>0)+(SLRATmax>0)] -= absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
					}
					else if(x[i+nvab] < 0)
					{
						newL[nvab+m+1+k+(SLRATmin>0)+(SLRATmax>0)] += absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
						newU[nvab+m+1+k+(SLRATmin>0)+(SLRATmax>0)] += absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
					}
				}
			}
	//________________________________________________turnover
			if(have_rev && (this->delta>-lm_eps))
			{
				real tt;
				newL[nvab+m+1+mabs+(SLRATmin>0)+(SLRATmax>0)] = (tt=ddotvec(nvab,newconrev,initial));
				newU[nvab+m+1+mabs+(SLRATmin>0)+(SLRATmax>0)] = this->delta*2+tt;
				real forced=0,inner;
				for(i=0;i < (n-nvab);++i)
				{
					if((inner = fabs((x[i+nvab]-initial[i+nvab])*(mask?mask[i+nvab]:1))) > 0)
					{
						newU[nvab+m+1+mabs+(SLRATmin>0)+(SLRATmax>0)] -= inner;
						forced += inner;
					}
				}
				//lm_wmsg("Forced turnover is %f (%lu,%lu)",forced*.5,n,nvab);
				if(newU[nvab+m+1+mabs+(SLRATmin>0)+(SLRATmax>0)] < newL[nvab+m+1+mabs+(SLRATmin>0)+(SLRATmax>0)])
				{
					back=6;
					AddLog("Impossible turnover\n");
				}
			}
	//________________________________________________
			dmx_transpose(nvab,MM,newA,newA);
			switch(this->useInteriorPoint)
			{
			case 0:
				if(nvab<OPT_METH_SWITCH)back=Opt(nvab,MM,x,newA,newL,newU,c);
				else back=OptInterior(nvab,MM,x,newA,newL,newU,(shortalphacost?&newC[0]:c));
							break;
			case 1:
				back=OptInterior(nvab,MM,x,newA,newL,newU,(shortalphacost?&newC[0]:c));
							break;
			case 2:
				back=QPbySeqLP(nvab,MM,x,(shortalphacost?&newC[0]:c),newA,newL,newU,H,QPbySeqHmul,this);
							break;
			case 3:
				back=QPopt(nvab,MM,x,(shortalphacost?&newC[0]:c),newA,newL,newU,H,QPbySeqHmul,this);
							break;
			}
			this->releaseSSS();
			if(back==5 && lp_really) back=0;
			return back;
		}
	}
	else if(hess_choice == 2)
	{
		AddLog("CHOICE 2\n");
		nbefore=nvab;
		do
		{
			size_t i = 0,j = 0,k,NN=nvab,MM=m+1+mabs+(have_rev&&delta>-lm_eps)+(SLRATmin>0)+(SLRATmax>0);
			if(badcount==0)
			{
				lsi=0;
				for(i=0;i<nvab;++i){if(lower[i] < 0 && upper[i] > 0) {NN++;lsi++;}}
				AddLog("%d extra variables for ls\n",lsi);
			}
			else{lsi=0;AddLog("No extra variables this time\n");}
			SSS1->resize(nbefore);
			SSS2->resize(nbefore);
			SSS3->resize(lsi+1);
			*SSS3=(size_t) -1;
			SSS4->resize(NN*MM+2*NN+2*(NN+MM));

			work = &(*SSS1)[0];
			lspenalty=&(*SSS2)[0];
			if(!UseDiagPenalty)
			{
				large_eigen=leigen(nvab);
				dsetvec(nvab,large_eigen,lspenalty);
			}
			else
			{
				lspenaltyvec(nvab,lspenalty);
			//	dscalvec(nvab,100,lspenalty);
			}
			//dzerovec(nvab,lspenalty);
			newX=&(*SSS4)[0];
			newC=newX+NN;
			newL=newC+NN;
			newU=newL+NN+MM;
			newA=newU+NN+MM;
			lab = (SSS3->size()>0?&(*SSS3)[0]:0);//In gcc &(x)[0] is not 0 when x.size() is 0!!
			vector newcon=newA+m*NN;
			vector newconrev=newA+(m+1+mabs+(SLRATmin>0)+(SLRATmax>0))*NN;
			size_t lsratn;
			double oldobj=lm_max;
			if(badcount == 0)
			{
				for(i = 0;i < nvab;++i)
				{
					lsratn=1;
					if(lower[i] <= 0 && upper[i] <= 0)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							newcon[i]=(gross?-1:0);
							if(SLRATmin>0)
							{
								newcon[i+NN*lsratn++] = -1;
							}
							if(SLRATmax>0)
							{
								newcon[i+NN*lsratn++] = -1;
							}
							for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
							if(have_rev && (this->delta>-lm_eps))
							{
								if(lower[i] >= initial[i])
									newconrev[i]=(mask?mask[i]:1);
								else if(upper[i] <= initial[i])
									newconrev[i]=(mask?-mask[i]:-1);
								else
									throw std::exception();
							}
						}
						newL[i] = lower[i];
						newU[i] = upper[i];
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
						newC[i] = c[i];
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(shortalphacost)
							{
								newC[i]+=shortalphacost[i];
							}
						}
						newX[i] = dmax(lower[i],dmin(upper[i],-ls_small));//x[i];
						for(k = 0;k < m;++k)
							newA[i+k*NN] = A[k+i*m];
					}
					else if(lower[i] >= 0 && upper[i] >= 0)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{
							
						}
						else
						{
							newcon[i]=1;
							if(SLRATmin>0)
							{
								newcon[i+NN*lsratn++] = -SLRATmin;
							}
							if(SLRATmax>0)
							{
								newcon[i+NN*lsratn++] = -SLRATmax;
							}
							for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
							if(have_rev && (this->delta>-lm_eps))
							{
								if(lower[i] >= initial[i])
									newconrev[i]=(mask?mask[i]:1);
								else if(upper[i] <= initial[i])
									newconrev[i]=(mask?-mask[i]:-1);
								else
									throw std::exception();
							}
						}
						newL[i] = lower[i];
						newU[i] = upper[i];
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
						newC[i] = c[i];
						newX[i] = dmax(lower[i],dmin(upper[i],ls_small));//x[i];
						for(k = 0;k < m;++k)
							newA[i+k*NN] = A[k+i*m];
					}
					else
					{
						for(k = 0;k < m;++k)
						{
							newA[i + k*NN] = newA[nvab+j + k*NN] = A[k+i*m];
						}
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						if(have_rev && (this->delta>-lm_eps))
						{
							if(lower[i] >= initial[i])
								newconrev[i]=(mask?mask[i]:1);
							else if(upper[i] <= initial[i])
								newconrev[i]=(mask?-mask[i]:-1);
							else
								throw std::exception();
							newconrev[nvab+j]=newconrev[i];
						}
						newcon[nvab+j] = (gross?-1:0);
						newL[nvab+j] = lower[i];
						newU[nvab+j] = 0;
						newC[nvab+j] = c[i];
						if(shortalphacost)
						{
								newC[nvab+j]+=shortalphacost[i];
						}
						newX[nvab+j] = dmax(lower[i],-ls_small);//dmin(x[i],0);

						if(SLRATmin>0)
						{
							newcon[nvab+j+NN*lsratn] = -1;
							newcon[i+NN*lsratn++] = -SLRATmin;
						}
						if(SLRATmax>0)
						{
							newcon[nvab+j+NN*lsratn] = -1;
							newcon[i+NN*lsratn++] = -SLRATmax;
						}
						for(k=0;k<mabs;++k){newcon[nvab+j+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}

						lab[j++] = i;
						newcon[i] = 1;
						for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
						newL[i] = 0;
						newU[i] = upper[i];
						newC[i] = c[i];
						newX[i] = dmin(upper[i],ls_small);//max(x[i],0);
					}
				}
			}
			else
			{
				NN=nvab;
				newC=newX+NN;
				newL=newC+NN;
				newU=newL+NN+MM;
				newA=newU+NN+MM;
				newcon=newA+m*NN;
				newconrev=newA+(m+1+mabs+(SLRATmin>0)+(SLRATmax>0))*NN;
				*SSS3=(size_t)-1;
				AddLog("Reopt using the signs of the previous result\n");
				for(i = 0;i < nvab;++i)
				{
					lsratn=1;
					if(x[i] <= 0)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							newcon[i]=(gross?-1:0);
							if(SLRATmin>0)
							{
								newcon[i+NN*lsratn++] = -1;
							}
							if(SLRATmax>0)
							{
								newcon[i+NN*lsratn++] = -1;
							}
							for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
						}
						newL[i] = lower[i];
						newU[i] = dmin(0,upper[i]);
						newC[i] = c[i];
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(shortalphacost)
							{
								newC[i]+=shortalphacost[i];
							}
						}
						newX[i] = x[i];
						for(k = 0;k < m;++k)
							newA[i+k*NN] = A[k+i*m];
					}
					else if(x[i] >= 0)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							newcon[i]=1;
							if(SLRATmin>0)
							{
								newcon[i+NN*lsratn++] = -SLRATmin;
							}
							if(SLRATmax>0)
							{
								newcon[i+NN*lsratn++] = -SLRATmax;
							}
							for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
						}
						newL[i] = dmax(0,lower[i]);
						newU[i] = upper[i];
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
						newC[i] = c[i];
						newX[i] = x[i];
						for(k = 0;k < m;++k)
							newA[i+k*NN] = A[k+i*m];
					}
					if(have_rev && (this->delta>-lm_eps))
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(lower[i] >= initial[i])
								newconrev[i]=(mask?mask[i]:1);
							else if(upper[i] <= initial[i])
								newconrev[i]=(mask?-mask[i]:-1);
							else
								throw std::exception();
						}
					}
				}
			}
			for(k = 0;k < m;++k)
			{
				newL[NN+k] = lower[nvab+k];
				newU[NN+k] = upper[nvab+k];
			}
	//________________________________________________COVER LONG SUM IN (0,LSValue)
			newL[NN+m] = (gross?LSValue_Low:(Full ?LSValue:LSValue_Low));
			newU[NN+m] = LSValue;
			lsratn=0;
			if(SLRATmin>0)
			{
				newL[NN+m+1+lsratn] = 0;
				newU[NN+m+1+lsratn++] = 1000;
			}
			if(SLRATmax>0)
			{
				newL[NN+m+1+lsratn] = -1000;
				newU[NN+m+1+lsratn++] = 0;
			}
			for(i=0;i < (n-nvab);++i)
			{
				lsratn=0;
				if(x[i+nvab] > 0)
				{
					newL[NN+m] -= x[i+nvab];
					newU[NN+m] -= x[i+nvab];
				}
				else if(gross&&(x[i+nvab]<0))
				{
					newL[NN+m] += x[i+nvab];
					newU[NN+m] += x[i+nvab];
				}
				if(SLRATmin>0)
				{
					if(x[i+nvab] > 0)
					{
						newL[NN+m+1+lsratn] += SLRATmin*x[i+nvab];
					}
					else if(x[i+nvab] < 0)
					{
						newL[NN+m+1+lsratn] += x[i+nvab];
					}
					lsratn++;
				}
				if(SLRATmax>0)
				{
					if(x[i+nvab] > 0)
					{
						newU[NN+m+1+lsratn] += SLRATmax*x[i+nvab];
					}
					else if(x[i+nvab] < 0)
					{
						newU[NN+m+1+lsratn] += x[i+nvab];
					}
					lsratn++;
				}
			}
			if(newU[NN+m] < newL[NN+m])
			{
				back=6;
				AddLog("Impossible gross or cover bounds\n");
			}
			if(gross==2)
				newL[NN+m]=newU[NN+m];
	//________________________________________________Absolute
			for(k=0;k<mabs;++k)
			{
				newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] = lowerA[k];
				newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] = upperA[k];
				for(i=0;i < (n-nvab);++i)
				{
					if(x[i+nvab] > 0)
					{
						newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] -= absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
						newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] -= absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
					}
					else if(x[i+nvab] < 0)
					{
						newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] += absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
						newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] += absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
					}
				}
			}
	//________________________________________________turnover
			if(have_rev && (this->delta>-lm_eps))
			{
				real tt;
				newL[NN+m+mabs+1+(SLRATmin>0)+(SLRATmax>0)] = (tt=ddotvec(nvab,newconrev,initial));
				newU[NN+m+mabs+1+(SLRATmin>0)+(SLRATmax>0)] = this->delta*2+tt;
				real forced=0,inner;
				for(i=0;i < (n-nvab);++i)
				{
					if((inner=fabs((x[i+nvab]-initial[i+nvab])*(mask?mask[i+nvab]:1))) > 0)
					{
						newU[NN+m+mabs+1+(SLRATmin>0)+(SLRATmax>0)] -= inner;
						forced += inner;
					}
				}
				//lm_wmsg("Forced turnover is %f (%lu,%lu)",forced*.5,n,nvab);
				if(newU[NN+mabs+m+1+(SLRATmin>0)+(SLRATmax>0)] < newL[nvab+mabs+m+1+(SLRATmin>0)+(SLRATmax>0)])
				{
					back=30;
					AddLog("Impossible turnover\n");
					break;
				}
			}
	//________________________________________________
			dmx_transpose(NN,MM,newA,newA);
			do
			{
				double correction=0,gsum=0,total;
				bool trivial=0;
#ifdef USETRIV
				if(leave_out_trivial)
				{
					bool bad=0;
					double tt=0;
					for(i=0;i<MM;++i)
					{
						if(!(tt >= newL[NN+i] && newU[NN+i]>= tt))
							bad=1;
					}
					for(i=0;i<NN;++i)
					{
						if(!(tt >= newL[i] && newU[i]>= tt))
							bad=1;
					}
					trivial=!bad;
				}
#endif
				if(trivial)
				{
					dzerovec(NN,newX);back=0;
				}
				else
				{
					switch(this->useInteriorPoint)
					{
					case 0:
						if(NN<OPT_METH_SWITCH)back=Opt(NN,MM,newX,newA,newL,newU,newC);
						else back=OptInterior(NN,MM,newX,newA,newL,newU,newC);
							break;
					case 1:
						back=OptInterior(NN,MM,newX,newA,newL,newU,newC);
							break;
					case 2:
						back=QPbySeqLP(NN,MM,newX,newC,newA,newL,newU,H,QPbySeqHmul,this);
							break;
					case 3:
						back=QPopt(NN,MM,newX,newC,newA,newL,newU,H,QPbySeqHmul,this);
							break;
					}
					if(back==6)
					{
						for(i=0;i<NN;i++)
						{
							if(newX[i]<newL[i])
								newX[i]=newL[i];
							else if(newX[i]>newU[i])
								newX[i]=newU[i];
						}
					}
				}
				if(NN==nvab)
					dcopyvec(nvab,newX,x);
				else
				{
					j = 0;
					for(i = 0,total=0;i < nvab;++i)
					{
						x[i] = newX[i];
						if(lab[j] == i)
						{
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{							
								gsum+=x[i]-newX[nvab+j];
								total=x[i] + newX[nvab+j];
								correction+=dmin(x[i]-total,total-newX[nvab+j]);
								x[i] += newX[nvab+j++];
							}
						}
						else
						{
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{
								gsum+=fabs(x[i]);
								total+=x[i];
							}
						}
					}
				}
				AddLog("Try: %2d, back: %2d, objective: %-.8e, Gross: %-.8e, correction: %-.8e\n",badcount,back,this->objective,gsum,correction);
				if(back < 2 &&fabs(correction)>10*lm_eps)
				{
					back=20;if(nvab>1000)break;
					//if(fabs(correction)< 3e-2*gsum){break;}
				}
				else if(back == 16&&fabs(correction)>10*lm_eps)
				{
					back=20;break;
					if(fabs(correction)< 3e-2*gsum){break;}
				}
				if(fabs(oldobj-this->objective)<lm_rooteps&&badcount<badcountlimit)
				{
					AddLog("Objective is stable\n");
					break;
				}
				oldobj=this->objective;
				if(back == 20) {*SSS2 *= 2.0;AddLog("###############################################\n# Changing LS penalty to %-.5f #\n###############################################\n",(*SSS2)[0]);}
			}
			while(back == 20 && badcount++ < badcountlimit);
		}	
		while(back==20 && badcount++<badcountlimit+2);
		if(back == 20) {back=6;}
		else if(back == 30) {back=6;}
		releaseSSS();
		if(back==5 && lp_really) back=0;
		return back;
	}
	else if(hess_choice == 3)
	{
		size_t n_here=nvab,nnn=n;
		if(TimeOptData&&TimeOptData->usethis)
		{
			n_here-=TimeOptData->nextra;
			nnn-=TimeOptData->nextra;
		}
		AddLog("CHOICE 3\n");
		if(!have_ls&&!ModDeriv)
		{
			hess_choice = 1;
			back=GOpt(nvab,m,x,A,lower,upper,c);
			if(back==5 && lp_really) back=0;
			hess_choice = 3;
			double actual_delta=turnover();
			if(back < 2) NaturalTurnover=actual_delta;
			if(back >= 2 || (!ModDeriv && ((this->delta<-lm_eps) || (actual_delta <= this->delta))))
			{
				if(back < 2)
					AddLog("Natural delta satisfies turnover constraint\n");
				return back;
			}
			else
			{
				size_t jj;double delta_get=this->delta*.95;
				for(jj=0;jj<nvab;++jj)
				{
					x[jj] = ((actual_delta-delta_get)*initial[jj] + delta_get*x[jj])/actual_delta;
				}
				AddLog("Set up guess with turnover %-.8e\n",this->turnover());
			}
		}
		dsubvec(nvab,x,initial,x);
		if(ModDeriv && !have_ls)//This gets the gradients around initial
		{
			buysell->resize(nnn*2);
			std::valarray<double>ww(nnn);

			ww=1e-5;
			daddvec(n_here,&ww[0],initial,&ww[0]);
			if(optimiseorder)Reorder_gen(nnn,optimiseorder+nnn,&ww[0],1);
			*buysell=0;
			ResetInitial(0);//TTO DO    need something for TimeOptData!
			ModDeriv(n_here,&ww[0],&(*buysell)[0],ModCObjectInfo);
			ResetInitial();
			if(optimiseorder)Reorder_gen(nnn,optimiseorder,&(*buysell)[0],1);

			ww=-1e-5;
			if(optimiseorder)Reorder_gen(nnn,optimiseorder+nnn,&ww[0],1);
			daddvec(n_here,&ww[0],initial,&ww[0]);
			ResetInitial(0);
			ModDeriv(n_here,&ww[0],&(*buysell)[nnn],ModCObjectInfo);
			ResetInitial();
			if(optimiseorder)Reorder_gen(nnn,optimiseorder,&(*buysell)[nnn],1);
			*buysell*=scale_utility_external_terms;
		}
		nbefore=nvab;
		size_t i = 0,j = 0,k,NN=nvab,MM=m+(delta>-lm_eps)+(have_ls)+mabs+(SLRATmin>0)+(SLRATmax>0);
		dsubvec(nvab,lower,initial,lower);
		dsubvec(nvab,upper,initial,upper);
		for(i=0;i<nvab;++i)
		{
#ifdef __SYSNT__
			_ASSERT(lower[i]<=upper[i]);
#endif
			if(lower[i] < 0 && upper[i] > 0) {NN++;}
		}
		AddLog("Need %lu extra variables for bs\n",NN-nvab);
		AddLog("%d variables for this optimisation\n",NN);
		size_t NNkeep=NN;
		real ttt;
		back=0;
		vector implied;

		SSS1->resize(nbefore);
		work = &(*SSS1)[0];
		SSS3->resize(NN-nvab+1);
		*SSS3=(size_t) -1;
		SSS2->resize(nvab+NN*MM+2*NN+2*(NN+MM)+nvab);

		implied=&(*SSS2)[0];
		lspenalty=implied+nvab;
		if(!UseDiagPenalty)
		{
			large_eigen=leigen(nvab);
			dsetvec(nvab,large_eigen,lspenalty);
		}
		else
			lspenaltyvec(nvab,lspenalty);
		//dzerovec(nvab,lspenalty);

		lab = (SSS3->size()>0?&(*SSS3)[0]:0);//In gcc &(x)[0] is not 0 when x.size() is 0!!
		newX=lspenalty+nvab;
		newC=newX+NN;
		newL=newC+NN;
		newU=newL+NN+MM;
		newA=newU+NN+MM;
		vector newcon=newA+m*NN;
		vector newconls=newcon+(delta>-lm_eps)*NN;
//______________________________________________________________
		qphess_base(nvab,1,1,1,H,initial,implied);
		daddvec(nvab,c,implied,c);
		size_t lsratn;
		for(i=0;i<m;++i)
		{
			ttt=BITA_ddot(nvab,A+i,m,initial,1);
			lower[nvab+i]-=ttt;
			upper[nvab+i]-=ttt;
		}
//______________________________________________________________
		bool used_undoubled=0;//I added this to make risk constraining work when we get weak local minima
		do
		{
			if(!badcount || used_undoubled)
			{
				NN=NNkeep;
				j=0;
				*SSS3=(size_t)-1;
				newC=newX+NN;
				newL=newC+NN;
				newU=newL+NN+MM;
				newA=newU+NN+MM;
				newcon=newA+m*NN;
				newconls=newcon+(delta>-lm_eps)*NN;
				dzerovec(NN*MM,newA);
				for(i = 0;i < nvab;++i)
				{
					lsratn=1;
					if(lower[i] <= 0 && upper[i] <= 0)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{

							if(delta>-lm_eps){newcon[i]=(mask?-mask[i]:-1);}
							if(have_ls)
							{
								double takeoff=0;
								if(take_out_costs)
									takeoff=(*buysell)[nnn+i]/scale_utility_external_terms;
								newconls[i] = ((initial[i]+lower[i])>=0?1+takeoff:(gross?-1+takeoff:0));
								if(SLRATmin>0){newconls[i+NN*lsratn++] = ((initial[i]+lower[i])>=0?-SLRATmin:-1);}
								if(SLRATmax>0){newconls[i+NN*lsratn++] = ((initial[i]+lower[i])>=0?-SLRATmax:-1);}
							}
							if(mabs&&(initial[i]+lower[i]>=0)){for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}}
							else if(mabs){for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}}
						}
						newL[i] = lower[i];
						newU[i] = upper[i];
						newC[i] = c[i];
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
						if(have_ls&&shortalphacost)
						{
							//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{
								if(initial[i]+upper[i]<=0)
									newC[i]+=shortalphacost[i];
							}
						}
						newX[i] = dmax(lower[i],dmin(upper[i],-ls_small));//x[i];
						for(k = 0;k < m;++k)
						{
							newA[i+k*NN] = A[k+i*m];
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{			
								if(take_out_costs && k == 0 && !have_ls)
									newA[i]+=(*buysell)[nnn+i]/scale_utility_external_terms;
							}
						}
					}
					else if(lower[i] >= 0 && upper[i] >= 0)
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(delta>-lm_eps){newcon[i]=(mask?mask[i]:1);}
							if(have_ls)
							{
								double takeoff=0;
								if(take_out_costs)
									takeoff=(*buysell)[i]/scale_utility_external_terms;
								newconls[i] = ((initial[i]+lower[i])>=0?1+takeoff:(gross?-1+takeoff:0));
								if(SLRATmin>0){newconls[i+NN*lsratn++] = ((initial[i]+lower[i])>=0?-SLRATmin:-1);}
								if(SLRATmax>0){newconls[i+NN*lsratn++] = ((initial[i]+lower[i])>=0?-SLRATmax:-1);}
							}
							if(mabs&&(initial[i]+lower[i]>=0)){for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}}
							else if(mabs){for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}}
						}
						newL[i] = lower[i];
						newU[i] = upper[i];
						newC[i] = c[i];
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(have_ls&&shortalphacost)
							{
								//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
								if(initial[i]+upper[i]<=0)
									newC[i]+=shortalphacost[i];
							}
						}
						newX[i] = dmax(lower[i],dmin(upper[i],ls_small));//x[i];
						for(k = 0;k < m;++k)
						{
							newA[i+k*NN] = A[k+i*m];
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{

								if(take_out_costs && k == 0 && !have_ls)
									newA[i]+=(*buysell)[i]/scale_utility_external_terms;
							}
						}
					}
					else
					{
						for(k = 0;k < m;++k)
						{
							newA[i + k*NN] = newA[nvab+j + k*NN] = A[k+i*m];
							if(take_out_costs && k == 0 && !have_ls)
							{
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newA[i+k*NN]+=(*buysell)[i]/scale_utility_external_terms;
									newA[nvab+j+k*NN]+=(*buysell)[i+nnn]/scale_utility_external_terms;
								}
							}
						}
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(delta>-lm_eps)
							{
								newcon[i] = (mask?mask[i]:1);
								newcon[nvab+j] = (mask?-mask[i]:-1);
							}
							if(have_ls)
							{
								newconls[i] = ((initial[i]+lower[i])>=0?1:(gross?-1:0));
								newconls[nvab+j] = newconls[i];
								if(take_out_costs)
								{
									newconls[i]+=1.0/scale_utility_external_terms*((initial[i]+lower[i])>=0?(*buysell)[i]:(gross?(*buysell)[i]:0));
									newconls[nvab+j]+=1.0/scale_utility_external_terms*(initial[i]+lower[i])>=0?(*buysell)[i+nnn]:(gross?(*buysell)[i+nnn]:0);
								}
								if(SLRATmin>0){newconls[nvab+j+NN*lsratn]=newconls[i+NN*lsratn] = ((initial[i]+lower[i])>=0?-SLRATmin:-1);lsratn++;}
								if(SLRATmax>0){newconls[nvab+j+NN*lsratn]=newconls[i+NN*lsratn] = ((initial[i]+lower[i])>=0?-SLRATmax:-1);lsratn++;}
							}
							if(mabs&&(initial[i]+lower[i]>=0)){for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}}
							else if(mabs){for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}}
							if(mabs&&(initial[i]+lower[i]>=0)){for(k=0;k<mabs;++k){newconls[nvab+j+(k+lsratn)*NN]=absoluteA[i*mabs+k];}}
							else if(mabs){for(k=0;k<mabs;++k){newconls[nvab+j+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}}
						}
						newL[nvab+j] = lower[i];
						newU[nvab+j] = 0;
						newC[nvab+j] = c[i];
						if(have_ls&&shortalphacost)
						{
							//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{
								if(initial[i]+upper[i]<=0)
									newC[nvab+j]+=shortalphacost[i];
							}
						}
						newX[nvab+j] = dmax(lower[i],-ls_small);//dmin(x[i],0);


						lab[j++] = i;
						newL[i] = 0;
						newU[i] = upper[i];
						newC[i] = c[i];
						newX[i] = dmin(upper[i],ls_small);//max(x[i],0);
					}
				}
			}
			else if(lower[i]>upper[i])
			{
				AddLog("Bound error for asset %d %f > %f\n",i,lower[i],upper[i]);
			}
			else
			{
				NN=nvab;
				newC=newX+NN;
				newL=newC+NN;
				newU=newL+NN+MM;
				newA=newU+NN+MM;
				newcon=newA+m*NN;
				newconls=newcon+(delta>-lm_eps)*NN;
				*SSS3=(size_t)-1;
				*SSS2=0;
				AddLog("Reopt using the signs of the previous result\n");
				for(i = 0;i < nvab;++i)
				{
					lsratn=1;
					if(x[i]<0)//Sell
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(delta>-lm_eps){(newcon[i]=mask?-mask[i]:-1);}
						}
						newL[i] = lower[i];
						newU[i] = dmin(0,upper[i]);
						newC[i] = c[i];
						newX[i] = x[i];
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
						for(k = 0;k < m;++k)
						{
							newA[i+k*NN] = A[k+i*m];
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{
								if(take_out_costs && k == 0 && !have_ls)
									newA[i]+=(*buysell)[nnn+i]/scale_utility_external_terms;
							}
						}
					}
					else if(x[i]>=0)//Buy
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(delta>-lm_eps){newcon[i]=(mask?mask[i]:1);}
						}
						newL[i] = dmax(0,lower[i]);
						newU[i] = upper[i];
						newC[i] = c[i];
						newX[i] = x[i];
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
						for(k = 0;k < m;++k)
						{
							newA[i+k*NN] = A[k+i*m];
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{
								if(take_out_costs && k == 0 && !have_ls)
									newA[i]+=(*buysell)[i]/scale_utility_external_terms;
							}
						}
					}
					if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
					{
				//		newconls[i] =0;
					}
					else
					{
						if(have_ls)
						{
							double takeoff=0;
							if(take_out_costs)
								takeoff=(*buysell)[i]/scale_utility_external_terms;
							newconls[i] = ((initial[i]+x[i])>0?1+takeoff:(gross?-1+takeoff:0));
							if(SLRATmin>0){newconls[i+NN*lsratn++] = ((initial[i]+x[i])>0?-SLRATmin:-1);}
							if(SLRATmax>0){newconls[i+NN*lsratn++] = ((initial[i]+x[i])>0?-SLRATmax:-1);}
							if(shortalphacost)
							{
								if(initial[i]+x[i]<=0)
									newC[i]+=shortalphacost[i];
							}
						}
						if(mabs&&(initial[i]+x[i]>0)){for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}}
						else if(mabs){for(k=0;k<mabs;++k){newconls[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}}
					}
				}
			}
			for(k = 0;k < m;++k)
			{
				newL[NN+k] = lower[nvab+k];
				newU[NN+k] = upper[nvab+k];
			}
	//________________________________________________turnover
//			_ASSERT(j==(NN-nvab));
			size_t last_con=0;
			if(delta>-lm_eps)
			{
				last_con++;
				newL[NN+m] = 0;
				newU[NN+m] = delta*2;
				double inner;
				for(i=0;i < (n-nvab);++i)
				{
					if((inner=(fabs((x[i+nvab]-initial[i+nvab])*(mask?mask[i+nvab]:1)))) > 0)
					{
						newU[NN+m] -= inner;
					}
				}
				if(newU[NN+m] < 0)
				{
					back=6;
					AddLog("Impossible turnover\n");
				}
			}
		//________________________________________________COVER LONG SUM IN (0,LSValue)
			if(have_ls)
			{
				lsratn=1;
				newL[NN+m+last_con] = (gross?LSValue_Low:(Full ?LSValue:LSValue_Low));
				newU[NN+m+last_con] = LSValue;
				newL[NN+m+last_con] -= (ttt=ddotvec(n_here,newconls,initial));
				newU[NN+m+last_con] -= ttt;
				if(SLRATmin>0)
				{
					newL[NN+m+last_con+lsratn] = -(ttt=ddotvec(n_here,newconls+lsratn*NN,initial));
					newU[NN+m+last_con+lsratn++] = 1000-ttt;
				}
				if(SLRATmax>0)
				{
					newU[NN+m+last_con+lsratn] = -(ttt=ddotvec(n_here,newconls+lsratn*NN,initial));
					newL[NN+m+last_con+lsratn++] = -1000-ttt;
				}
				for(i=0;i < (n-nvab);++i)
				{
					lsratn=1;
					if(x[i+nvab] > 0)
					{
						newL[NN+m+last_con] -= x[i+nvab];
						newU[NN+m+last_con] -= x[i+nvab];
					}
					else if(gross&&(x[i+nvab] < 0))
					{
						newL[NN+m+last_con] += x[i+nvab];
						newU[NN+m+last_con] += x[i+nvab];
					}
					if(SLRATmin>0)
					{
						if(x[i+nvab] > 0)
						{
							newL[NN+m+last_con+lsratn] += SLRATmin*x[i+nvab];
						}
						else if(x[i+nvab] < 0)
						{
							newL[NN+m+last_con+lsratn] += x[i+nvab];
						}
						lsratn++;
					}
					if(SLRATmax>0)
					{
						if(x[i+nvab] > 0)
						{
							newU[NN+m+last_con+lsratn] += SLRATmax*x[i+nvab];
						}
						else if(x[i+nvab] < 0)
						{
							newU[NN+m+last_con+lsratn] += x[i+nvab];
						}
						lsratn++;
					}
				}
				if(newU[NN+m+last_con] < newL[NN+m+last_con])
				{
					back=6;
					AddLog("Impossible gross or cover bounds\n");
				}
				if(gross==2)
					newL[NN+m+last_con]=newU[NN+m+last_con];
		//________________________________________________Absolute
				for(k=0;k<mabs;++k)
				{
					newL[NN+m+last_con+1+k+(SLRATmax>0)+(SLRATmin>0)] = lowerA[k];
					newU[NN+m+last_con+1+k+(SLRATmax>0)+(SLRATmin>0)] = upperA[k];
					newL[NN+m+last_con+1+k+(SLRATmax>0)+(SLRATmin>0)] -= (ttt=ddotvec(n_here,newconls+(k+lsratn)*NN,initial));
					newU[NN+m+last_con+1+k+(SLRATmax>0)+(SLRATmin>0)] -= ttt;
					for(i=0;i < (n-nvab);++i)
					{
						if(x[i+nvab] > 0)
						{
							newL[NN+m+last_con+1+k+(SLRATmax>0)+(SLRATmin>0)] -= (ttt=absoluteA[(i+nvab)*mabs+k]*x[i+nvab]);
							newU[NN+m+last_con+1+k+(SLRATmax>0)+(SLRATmin>0)] -= ttt;
						}
						if(x[i+nvab] < 0)
						{
							newL[NN+m+last_con+1+k+(SLRATmax>0)+(SLRATmin>0)] -= (ttt=-absoluteA[(i+nvab)*mabs+k]*x[i+nvab]);
							newU[NN+m+last_con+1+k+(SLRATmax>0)+(SLRATmin>0)] -= ttt;
						}
					}
				}
			}
		//________________________________________________
			dmx_transpose(NN,MM,newA,newA);
//			ttt=BITA_ddot(NN,newA+m+(delta>-lm_eps),MM,initial,1);
			double oldobj=0;
			this->objective=lm_max;
			do
			{
				double correction=0,gsum=0,total=0;
				if(back!=6)
				{
					oldobj=this->objective;
/*					for(i=0;i<NN;++i)
					{
						std::cout<<newX[i]<<" ";
						std::cout<<newC[i]<<" ";
						std::cout<<newL[i]<<" ";
						std::cout<<newU[i]<<" ";
						for(j=0;j<MM;++j)
						{
							std::cout<<newA[i*MM+j]<<" ";
						}
						std::cout<<std::endl;
					}
					for(i=0;i<MM;++i)
					{
						std::cout<<newL[i+NN]<<" ";
						std::cout<<newU[i+NN]<<" ";
						std::cout<<std::endl;
					}*/
/*					for(i=0;i<NN+MM;++i)
					{
						if(newL[i]>newU[i])
						{
							if(i<NN)
							{
								printf("Stocks %d %f %f\n",i,newL[i],newU[i]);
							}
							else
							{
								printf("Constraints %d %f %f\n",i-NN,newL[i],newU[i]);
							}
						}
					}*/
					switch(this->useInteriorPoint)
					{
					case 0:
						if(NN<OPT_METH_SWITCH)back=Opt(NN,MM,newX,newA,newL,newU,newC);
						else back=OptInterior(NN,MM,newX,newA,newL,newU,newC);
							break;
					case 1:
						back=OptInterior(NN,MM,newX,newA,newL,newU,newC);
							break;
					case 2:
						back=QPbySeqLP(NN,MM,newX,newC,newA,newL,newU,H,QPbySeqHmul,this);
							break;
					case 3:
						back=QPopt(NN,MM,newX,newC,newA,newL,newU,H,QPbySeqHmul,this);
							break;
					}
					if(back==6)
					{
						for(i=0;i<NN;i++)
						{
							if(newX[i]<newL[i])
								newX[i]=newL[i];
							else if(newX[i]>newU[i])
								newX[i]=newU[i];
						}
					}
/*					for(i=0;i<NN;++i)
					{
						std::cout<<newX[i]<<" ";
						std::cout<<newC[i]<<" ";
						std::cout<<newL[i]<<" ";
						std::cout<<newU[i]<<" ";
						for(j=0;j<MM;++j)
						{
							std::cout<<newA[i*MM+j]<<" ";
						}
						std::cout<<std::endl;
					}
					for(i=0;i<MM;++i)
					{
						std::cout<<newL[i+NN]<<" ";
						std::cout<<newU[i+NN]<<" ";
						std::cout<<std::endl;
					}*/
				}
				if(NN==nvab)
				{
					dcopyvec(nvab,newX,x);
/*					ttt=BITA_ddot(nvab,newA+m+(delta>-lm_eps),MM,x,1);
					ttt+=BITA_ddot(nvab,newA+m+(delta>-lm_eps),MM,initial,1);
					double psum=0;
					for(i=0;i<nvab;++i)
					{	
						if(x[i]+initial[i]>0)
						{
							if(i>=nvab-TimeOptData->nextra)
							{
								_ASSERT(newA[m+(delta>-lm_eps)+MM*i]==0);
							}
							else
							{
								_ASSERT(newA[m+(delta>-lm_eps)+MM*i]==1);
								psum+=x[i]+initial[i];
							}
						}
					}
					_ASSERT(psum==ttt);*/
				}
				else
				{
					j = 0;
					for(i = 0;i < nvab;++i)
					{
						x[i] = newX[i];
						if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
						{

						}
						else
						{
							if(lab[j] == i)
							{
								gsum+=x[i]-newX[nvab+j];
								total=x[i] + newX[nvab+j];
								correction+=dmin(x[i]-total,total-newX[nvab+j]);
								x[i] += newX[nvab+j++];
							}
							else
							{
								gsum+=fabs(x[i]);
								total+=x[i];
							}
						}
					}
				}
				if(NN==nvab)
				{
					AddLog("Try: %2d, back: %2d, objective: %-.8e, \n",badcount,back,this->objective);
//					used_undoubled=1;
//					if(back==1 && badcount>2) used_undoubled=0;
					break;
				}
				else
				{
					AddLog("Try: %2d, back: %2d, objective: %-.8e, Gross turnover: %-.8e, correction: %-.8e\n",badcount,back,this->objective,gsum,correction);
//					used_undoubled=0;
				}
				if(back==1||(back<2&&fabs(correction)>10*lm_eps))
				{
					back=20;
					AddLog("BREAKING\n");break;
					if(fabs(correction) < 3e-2*gsum){break;}
					AddLog("NO BREAKING\n");
				}
				else if(back==1||(back==16&&fabs(correction)>10*lm_eps))
				{
					back=20;
					AddLog("BREAKING\n");break;
					if(fabs(correction) < 3e-2*gsum){break;}
					AddLog("NO BREAKING\n");
				}
				if(fabs(oldobj-this->objective)<lm_rooteps&&badcount<badcountlimit)
				{
					AddLog("Objective is stable\n");
					break;
				}
				if(back==20){dscalvec(nvab,2.0,lspenalty);}
			}
			while(back==20);
		}	while((back==20 /*|| used_undoubled*/) && badcount++<badcountlimit);
//______________________________________________________________
		daddvec(nvab,lower,initial,lower);
		daddvec(nvab,upper,initial,upper);
		daddvec(nvab,x,initial,x);
		dsubvec(nvab,c,implied,c);
		AddLog("turnover %-.8e\n",this->turnover());
		for(i=0;i<m;++i)
		{
			ttt=BITA_ddot(nvab,A+i,m,initial,1);
			lower[nvab+i]+=ttt;
			upper[nvab+i]+=ttt;
		}
//______________________________________________________________
		if(back == 20) {back=6;}
		releaseSSS();
		if(back==5 && lp_really) back=0;
		return back;
	}
	else if(hess_choice == 4)
	{
		AddLog("CHOICE 4\n");
		if(!ModDeriv)
		{
			hess_choice = 2;
			back=this->GOpt(nvab,m,x,A,lower,upper,c);
			if(back==5 && lp_really) back=0;
			hess_choice = 4;
			double actual_delta=turnover();
			if(back < 2) NaturalTurnover=actual_delta;
			if(back >= 2 || (actual_delta <= this->delta||this->delta<-lm_eps))
			{
				if(back < 2)
					AddLog("Natural delta satisfies turnover constraint\n");
				return back;
			}
			else
			{
				size_t jj;double delta_get=this->delta*.95;
				for(jj=0;jj<nvab;++jj)
				{
					x[jj] = ((actual_delta-delta_get)*initial[jj] + delta_get*x[jj])/actual_delta;
				}
				//lm_wmsg("Set up guess with turnover %f",this->turnover());
			}
		}

		if(ModDeriv)//This gets the gradients around initial
		{
			buysell->resize(n*2);
			std::valarray<double>ww(n);

			ww=1e-5;
			daddvec(n,&ww[0],initial,&ww[0]);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&ww[0],1);
			*buysell=0;
			ResetInitial(0);
			ModDeriv(n,&ww[0],&(*buysell)[0],ModCObjectInfo);
			ResetInitial();
			if(optimiseorder)Reorder_gen(n,optimiseorder,&(*buysell)[0],1);

			ww=-1e-5;
			daddvec(n,&ww[0],initial,&ww[0]);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&ww[0],1);
			ResetInitial(0);
			ModDeriv(n,&ww[0],&(*buysell)[n],ModCObjectInfo);
			ResetInitial();
			if(optimiseorder)Reorder_gen(n,optimiseorder,&(*buysell)[n],1);
			*buysell*=scale_utility_external_terms;
		}
		double oldobjective;
		this->objective=-lm_max;
		do
		{
			size_t i = 0,j = 0,k,NN=2*nvab,MM=m+1+(delta>-lm_eps)+nvab+mabs+(SLRATmin>0)+(SLRATmax>0);
			nbefore=nvab;
			if(badcount == 0)
			{
				lsi=0,revi=0;
				for(i=0;i<nvab;++i)
				{
					if(lower[i] < 0 && upper[i] > 0) 
					{
						NN++;lsi++;
					}
					if(lower[i] < initial[i] && upper[i] > initial[i]) 
					{
						NN++;revi++;
					}
				}
				AddLog("%d extra variables for ls\n",lsi);
				AddLog("%d extra variables for bs\n",revi);
				AddLog("%ld extra variables for matching ls and bs\n",nvab);
				AddLog("%d variables in this optimisation\n",NN);
				if(lsi == 0 && revi== 0)
				{
					have_ls=1;
					have_rev=1;
					hess_choice=1;
					back = this->GOpt(nvab,m,x,A,lower,upper,c);
					have_ls=0;
					have_rev=0;
					hess_choice=4;
					break;
				}
				else if(lsi == 0)
				{
					have_ls=1;
					hess_choice=3;
					back = this->GOpt(nvab,m,x,A,lower,upper,c);
					have_ls=0;
					hess_choice=4;
					break;
				}
				else if(revi == 0)
				{
					have_rev=1;
					hess_choice=2;
					back = this->GOpt(nvab,m,x,A,lower,upper,c);
					have_rev=0;
					hess_choice=4;
					break;
				}
			}
			else
			{
				revi=0;
				lsi=0;
			}
			SSS1->resize(nbefore);
			SSS2->resize(nbefore);
			SSS3->resize(revi+lsi+2);
			*SSS3=(size_t) -1;
			SSS4->resize(nvab+NN*MM+2*NN+2*(NN+MM)+mabs*nvab);

			work = &(*SSS1)[0];
			lspenalty=&(*SSS2)[0];
			if(!UseDiagPenalty)
			{
				large_eigen=leigen(nvab);
				dsetvec(nvab,large_eigen,lspenalty);
			}
			else
				lspenaltyvec(nvab,lspenalty);
			//dzerovec(nvab,lspenalty);
			vector implied=&(*SSS4)[0];
			qphess_base(nvab,1,1,1,H,initial,implied);
			newX=implied+nvab;
			newC=newX+NN;
			newL=newC+NN;
			newU=newL+NN+MM;
			newA=newU+NN+MM;
			lab = (SSS3->size()>0?&(*SSS3)[0]:0);//In gcc &(x)[0] is not 0 when x.size() is 0!!
			labrev=lab+lsi+1;
			vector newcon=newA+m*NN;
			vector newcon1=newcon+NN*(mabs+1+(SLRATmin>0)+(SLRATmax>0));
			vector newcond=newcon1+(NN+mabs)*nvab;
			j=0;
			dzerovec((NN+mabs)*nvab,newcon1);
			size_t jm=0,j1=0,lsratn;
			if(badcount == 0)
			{
				for(i = 0;i < nvab;++i)
				{
					lsratn=1;
					if(lower[i] < 0 && upper[i] > 0)
					{
						newcon[i]=1;
						if(SLRATmin>0)
						{
							newcon[i+NN*lsratn]=-SLRATmin;
							newcon[nvab+j+NN*lsratn++]=-1;
						}
						if(SLRATmax>0)
						{
							newcon[i+NN*lsratn]=-SLRATmax;
							newcon[nvab+j+NN*lsratn++]=-1;
						}
						for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
						newcon1[i+jm*NN]=1;
						if(delta>-lm_eps)
							newcond[i]=0;
						newL[i] = 0;
						newU[i] = upper[i];
						newC[i] = c[i];
						newX[i] = dmax(0,x[i]);
						for(k = 0;k < m;++k)
							newA[i+k*NN] = A[k+i*m];

						lab[j] = i;
						newcon[nvab+j] = (gross?-1:0);
						for(k=0;k<mabs;++k){newcon[nvab+j+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
						newcon1[nvab+j+NN*jm]=1;
						if(delta>-lm_eps)
							newcond[nvab+j]=0;
						newL[nvab+j] = lower[i];
						newU[nvab+j] = 0;
						newC[nvab+j] = c[i];
						if(shortalphacost)
							newC[nvab+j]+=shortalphacost[i];
						newX[nvab+j] = dmin(0,x[i]);
						for(k = 0;k < m;++k)
							newA[nvab+j+k*NN] = A[k+i*m];
						j++;
					}
					else
					{
						if(lower[i] >= 0)
							newcon[i]=1;
						else
							newcon[i]=(gross?-1:0);
						if(SLRATmin>0)
						{
							newcon[i+NN*lsratn++]=((lower[i] >= 0)?-SLRATmin:-1);
						}
						if(SLRATmax>0)
						{
							newcon[i+NN*lsratn++]=((lower[i] >= 0)?-SLRATmax:-1);
						}
						if(lower[i]>=0){for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}}
						else if(mabs){for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}}

						newcon1[i+jm*NN]=1;
						if(delta>-lm_eps)
							newcond[i]=0;
						newL[i] = lower[i];
						newU[i] = upper[i];
						newC[i] = c[i];
						if(shortalphacost&&upper[i]<=0)
							newC[nvab+j]+=shortalphacost[i];

						newX[i] = x[i];
						for(k = 0;k < m;++k)
							newA[i+k*NN] = A[k+i*m];
					}

					lsratn=1;
					if(lower[i] < initial[i] && upper[i] > initial[i])
					{
						newcon[nvab+lsi+i] = 0;
						if(take_out_costs)
							newcon[nvab+lsi+i]+=(*buysell)[i]/scale_utility_external_terms;
						if(SLRATmin>0)
						{
							newcon[nvab+lsi+i+lsratn*NN] = 0;
							newcon[2*nvab+lsi+j1+lsratn++*NN] = 0;
						}
						if(SLRATmax>0)
						{
							newcon[nvab+lsi+i+lsratn*NN] = 0;
							newcon[2*nvab+lsi+j1+lsratn++*NN] = 0;
						}
						for(k=0;k<mabs;++k){newcon[nvab+lsi+i+(k+lsratn)*NN]=0;}
						newcon1[nvab+lsi+i+jm*NN]=-1;
						if(delta>-lm_eps)
							newcond[nvab+lsi+i]=(mask?mask[i]:1);
						newL[nvab+lsi+i] = 0;
						newU[nvab+lsi+i] = upper[i]-initial[i];
						newC[nvab+lsi+i] = 0;
						newX[nvab+lsi+i] = dmax(0,x[i]-initial[i]);
						for(k = 0;k < m;++k)
							newA[nvab+lsi+i+k*NN] = 0;

						labrev[j1] = i;
						newcon[2*nvab+lsi+j1] = 0;
						if(take_out_costs)
							newcon[2*nvab+lsi+j1]+=(*buysell)[n+i]/scale_utility_external_terms;
						for(k=0;k<mabs;++k){newcon[2*nvab+lsi+j1+(k+lsratn)*NN]=0;}
						newcon1[2*nvab+lsi+j1+jm*NN]=-1;
						if(delta>-lm_eps)
							newcond[2*nvab+lsi+j1]=(mask?-mask[i]:-1);
						newL[2*nvab+lsi+j1] = lower[i]-initial[i];
						newU[2*nvab+lsi+j1] = 0;
						newC[2*nvab+lsi+j1] = 0;
						newX[2*nvab+lsi+j1] = dmin(0,x[i]-initial[i]);
						for(k = 0;k < m;++k)
							newA[2*nvab+lsi+j1+k*NN] = 0;
						j1++;
					}
					else
					{
						newcon[nvab+lsi+i] = 0;
						if(SLRATmin>0)
						{
							newcon[nvab+lsi+i+NN*lsratn++]=0;
						}
						if(SLRATmax>0)
						{
							newcon[nvab+lsi+i+NN*lsratn++]=0;
						}
						for(k=0;k<mabs;++k){newcon[nvab+lsi+i+(k+lsratn)*NN]=0;}
						newcon1[nvab+lsi+i+jm*NN]=-1;
						if(delta>-lm_eps || take_out_costs)
						{
							if(lower[i] >= initial[i])
							{
								if(delta>-lm_eps)
									newcond[nvab+lsi+i]=(mask?mask[i]:1);
								if(take_out_costs)
									newcon[nvab+lsi+i]+=(*buysell)[i]/scale_utility_external_terms;
							}
							else if(upper[i] <= initial[i])
							{
								if(delta>-lm_eps)
									newcond[nvab+lsi+i]=(mask?-mask[i]:-1);
								if(take_out_costs)
									newcon[nvab+lsi+i]+=(*buysell)[i+n]/scale_utility_external_terms;
							}
							else
								throw std::exception();
						}
						newL[nvab+lsi+i] = lower[i]-initial[i];
						newU[nvab+lsi+i] = upper[i]-initial[i];
						newC[nvab+lsi+i] = 0;
						newX[nvab+lsi+i] = x[i]-initial[i];
						for(k = 0;k < m;++k)
							newA[nvab+lsi+i+k*NN] = 0;
					}
					newL[NN+m+1+jm+(SLRATmin>0)+(SLRATmax>0)+mabs]=initial[i]-lm_eps;
					newU[NN+m+1+jm++ +(SLRATmin>0)+(SLRATmax>0)+mabs]=initial[i]+lm_eps;
				}	
			}
			else
			{
				AddLog("Reopt using the signs of the previous result\n");
				std::valarray<double>newC;
				if(shortalphacost)
				{
					newC.resize(n);
					dcopyvec(n,c,&newC[0]);
				}
				have_ls=1;
				have_rev=1;
				hess_choice=3;
				dcopyvec(m+nvab,lower,newL);
				dcopyvec(m+nvab,upper,newU);
				for(i=0;i<nvab;++i)
				{
					if(lower[i] <= 0 && upper[i] >= 0)
					{
						if(x[i] >= 0)
						{
							newL[i] = dmax(0,lower[i]);
							newU[i] = upper[i];
						}
						else if(x[i] <= 0)
						{
							newL[i] = lower[i];
							newU[i] = dmin(0,upper[i]);
							newC[i]+=shortalphacost[i];
						}
					}
				}
				/*for(i=0;i<nvab;++i)
				{
					if(newL[i] <= initial[i] && newU[i] >= initial[i])
					{
						if(x[i] >= initial[i])
						{
							newL[i] = initial[i];
						}
						else if(x[i] <= initial[i])
						{
							newU[i] = initial[i];
						}
					}
				}*/
				back = this->GOpt(nvab,m,x,A,newL,newU,(shortalphacost?&newC[0]:c));
				have_ls=0;
				have_rev=0;
				hess_choice=4;
				break;
			}
			for(k = 0;k < m;++k)
			{
				newL[NN+k] = lower[nvab+k];
				newU[NN+k] = upper[nvab+k];
			}
	//________________________________________________COVER LONG SUM IN (0,LSValue)
			newL[NN+m] = (gross?LSValue_Low:(Full ?LSValue:LSValue_Low));
			newU[NN+m] = LSValue;
			lsratn=0;
			if(SLRATmin>0)
			{
				newL[NN+m+1+lsratn] = 0;
				newU[NN+m+1+lsratn++] = 1000;
			}
			if(SLRATmax>0)
			{
				newL[NN+m+1+lsratn] = -1000;
				newU[NN+m+1+lsratn++] = 0;
			}
			for(i=0;i < (n-nvab);++i)
			{
				lsratn=0;
				if(x[i+nvab] > 0)
				{
					newL[NN+m] -= x[i+nvab];
					newU[NN+m] -= x[i+nvab];
				}
				if(gross&&x[i+nvab] < 0)
				{
					newL[NN+m] += x[i+nvab];
					newU[NN+m] += x[i+nvab];
				}
				if(SLRATmin>0)
				{
					if(x[i+nvab] > 0)
					{
						newL[NN+m+1+lsratn] += SLRATmin*x[i+nvab];
					}
					else if(x[i+nvab] < 0)
					{
						newL[NN+m+1+lsratn] += x[i+nvab];
					}
					lsratn++;
				}
				if(SLRATmax>0)
				{
					if(x[i+nvab] > 0)
					{
						newU[NN+m+1+lsratn] += SLRATmax*x[i+nvab];
					}
					else if(x[i+nvab] < 0)
					{
						newU[NN+m+1+lsratn] += x[i+nvab];
					}
					lsratn++;
				}
			}
			if(newU[NN+m] < newL[NN+m])
			{
				back=6;
				AddLog("Impossible gross or cover bounds\n");
			}
			if(gross==2)
				newL[NN+m]=newU[NN+m];
	//________________________________________________Absolute
			for(k=0;k<mabs;++k)
			{
				newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] = lowerA[k];
				newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] = upperA[k];
				for(i=0;i < (n-nvab);++i)
				{
					if(x[i+nvab] > 0)
					{
						newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] -= absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
						newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] -= absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
					}
					else if(x[i+nvab] < 0)
					{
						newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] += absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
						newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] += absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
					}
				}
			}
	//________________________________________________turnover
			if(delta>-lm_eps)
			{
				newL[NN+m+1+mabs+nvab+(SLRATmin>0)+(SLRATmax>0)] = 0;
				newU[NN+m+1+mabs+nvab+(SLRATmin>0)+(SLRATmax>0)] = delta*2;
				real forced=0,inner;
				for(i=0;i < (n-nvab);++i)
				{
					if((inner=(fabs((x[i+nvab]-initial[i+nvab])*(mask?mask[i+nvab]:1)))) > 0)
					{
						newU[NN+m+1+mabs+nvab+(SLRATmin>0)+(SLRATmax>0)] -= inner;
						forced += inner;
					}
				}
				//lm_wmsg("Forced turnover is %f (%lu,%lu)",forced*.5,n,nvab);
				if(newU[NN+m+1+mabs+nvab+(SLRATmin>0)+(SLRATmax>0)] < 0)
				{
					back=20;
					AddLog("Impossible turnover\n");
				}
			}
	//________________________________________________
			dmx_transpose(NN,MM,newA,newA);
			do
			{
				double correction=0,total,gsum=0;
				oldobjective=this->objective;
				switch(this->useInteriorPoint)
				{
				case 0:
					if(NN<OPT_METH_SWITCH)back=Opt(NN,MM,newX,newA,newL,newU,newC);
					else back=OptInterior(NN,MM,newX,newA,newL,newU,newC);
							break;
				case 1:
					back=OptInterior(NN,MM,newX,newA,newL,newU,newC);
							break;
				case 2:
					back=QPbySeqLP(NN,MM,newX,newC,newA,newL,newU,H,QPbySeqHmul,this);
							break;
				case 3:
					back=QPopt(NN,MM,newX,newC,newA,newL,newU,H,QPbySeqHmul,this);
							break;
				}
					if(back==6)
					{
						for(i=0;i<NN;i++)
						{
							if(newX[i]<newL[i])
								newX[i]=newL[i];
							else if(newX[i]>newU[i])
								newX[i]=newU[i];
						}
					}
				if(NN==nvab)
					dcopyvec(nvab,newX,x);
				else
				{
					for(i=0,j=0;i<nvab;++i)
					{
						x[i]=newX[i];
						if(lab&&lab[j]==i && j < lsi)
						{
							gsum+=x[i]-newX[nvab+j];
							total=x[i]+newX[nvab+j];
							correction+=dmin(x[i]-total,total-newX[nvab+j]);
							x[i]+=newX[nvab+j++];
						}
						else
						{
							gsum+=fabs(x[i]);
							total+=x[i];
						}
					}
				}
				AddLog("Try: %2d, back: %2d, objective: %-.8e, Gross: %-.8e, correction: %-.8e\n",badcount,back,this->objective,gsum,correction);
				if(longshorttest(n,x,this))	back=6;
				if(back < 2&&fabs(correction)>10*lm_eps)
				{
					back=20;break;
					if(fabs(correction)< 3e-2*gsum){break;}
				}
				else if(back == 16 && fabs(correction)>10*lm_eps)
				{
					back=20;break;
					if(fabs(correction)< 3e-2*gsum){break;}
				}
				if(fabs(this->objective-oldobjective) < lm_rooteps && badcount < badcountlimit)
				{
					AddLog("Objective is stable\n");
					break;
				}
				if(back == 20) {*SSS2 *= 2.0;AddLog("###############################################\n# Changing LS penalty to %-.5f #\n###############################################\n",(*SSS2)[0]);}
			}
			while(back==20 && badcount++ < badcountlimit);
		}
		while(back==20 && badcount++ < badcountlimit+2);
		if(back == 20) {back=6;}
		releaseSSS();
		if(back==5 && lp_really) back=0;
		return back;
	}
	else if(hess_choice == 5)
	{
		size_t n_here=nvab,nnn=n;
		if(TimeOptData&&TimeOptData->usethis)
		{
			n_here-=TimeOptData->nextra;
			nnn-=TimeOptData->nextra;
		}
		AddLog("CHOICE 5\n");
		std::valarray<double> ls_initial;
		std::valarray<double> ls_implied;
		if(!ModDeriv)
		{
			hess_choice = 2;
			back=this->GOpt(nvab,m,x,A,lower,upper,c);
			if(back==5 && lp_really) back=0;
			hess_choice = 5;
			double actual_delta=turnover();
			if(back < 2) NaturalTurnover=actual_delta;
			if(back >= 2 || (actual_delta <= this->delta||this->delta<-lm_eps))
			{
				if(back < 2)
					AddLog("Natural delta satisfies turnover constraint\n");
				return back;
			}
			else
			{
				size_t jj;
			/*	double delta_get=this->delta*.95;
				for(jj=0;jj<nvab;++jj)
				{
					x[jj] = ((actual_delta-delta_get)*initial[jj] + delta_get*x[jj])/actual_delta;
				}*/
				dzerovec(nvab,x);
				for(jj=0;jj<nvab;++jj)
				{
					if(x[jj]<lower[jj] || x[jj] > upper[jj])
						x[jj]=(lower[jj]+upper[jj])*.5;
				}
				//lm_wmsg("Set up guess with turnover %f",this->turnover());
			}
		}

		if(ModDeriv)//This gets the gradients around initial
		{
			buysell->resize(nnn*4);
			std::valarray<double>ww(nnn);

			ww=1e-5;
			daddvec(n_here,&ww[0],initial,&ww[0]);
			if(optimiseorder)Reorder_gen(nnn,optimiseorder+nnn,&ww[0],1);
			*buysell=0;
			ResetInitial(0);
			ModDeriv(n_here,&ww[0],&(*buysell)[0],ModCObjectInfo);
			ResetInitial();
			if(optimiseorder)Reorder_gen(nnn,optimiseorder,&(*buysell)[0],1);

			ww=-1e-5;
			daddvec(n_here,&ww[0],initial,&ww[0]);
			if(optimiseorder)Reorder_gen(nnn,optimiseorder+nnn,&ww[0],1);
			ResetInitial(0);
			ModDeriv(n_here,&ww[0],&(*buysell)[nnn],ModCObjectInfo);
			ResetInitial();
			if(optimiseorder)Reorder_gen(nnn,optimiseorder,&(*buysell)[nnn],1);

			//Get cost gradients around the zero weight
			ww=1e-5;
			if(optimiseorder)Reorder_gen(nnn,optimiseorder+nnn,&ww[0],1);
			ResetInitial(0);
			ModDeriv(n_here,&ww[0],&(*buysell)[2*nnn],ModCObjectInfo);
			ResetInitial();
			if(optimiseorder)Reorder_gen(nnn,optimiseorder,&(*buysell)[2*nnn],1);

			ww=-1e-5;
			if(optimiseorder)Reorder_gen(nnn,optimiseorder+nnn,&ww[0],1);
			ResetInitial(0);
			ModDeriv(n_here,&ww[0],&(*buysell)[3*nnn],ModCObjectInfo);
			ResetInitial();
			if(optimiseorder)Reorder_gen(nnn,optimiseorder,&(*buysell)[3*nnn],1);
			*buysell*=scale_utility_external_terms;
		}
		double oldobjective,minobjective=lm_max;
		double scale=1;
		this->objective=-1e10;
		size_t i = 0,j = 0,k,NN=nvab,MM=m+1+(delta>-lm_eps)+mabs+(SLRATmin>0)+(SLRATmax>0);
		nbefore=nvab;
		do
		{
			if(badcount == 0)
			{
				revi=0;
				lsi=0;
				lsrevi=0;
				zeroinit=0;
				for(i=0;i<nvab;++i)
				{
					if(lower[i] < 0 && upper[i] > 0 && lower[i] < initial[i] 
						&& upper[i] > initial[i])
					{
						lsrevi++;lsi++;revi++;
						if(!(initial[i]>0||initial[i]<0))
							zeroinit++;
					}
					else if(lower[i] < 0 && upper[i] > 0)
					{
						lsi++;
					}
					else if(lower[i] < initial[i] && upper[i] > initial[i])
					{
						revi++;
					}
				}
				AddLog("Extra variables for ls and bs    %d\n",lsrevi);
				AddLog("Extra variables for ls           %d\n",lsi);
				AddLog("Extra variables for bs           %d\n",revi);
				AddLog("Fewer variables for zero initial %d\n",zeroinit);
				//NN+=(lsi-lsrevi)+2*lsrevi+(revi-lsrevi)-zeroinit;
				NN+=lsi+revi-zeroinit;
#if 1
				if(lsi == 0 && revi== 0)
				{
					have_ls=1;
					have_rev=1;
					hess_choice=1;
					back = this->GOpt(nvab,m,x,A,lower,upper,c);
					have_ls=0;
					have_rev=0;
					hess_choice=5;
					break;
				}
				else if(lsi == 0)
				{
					have_ls=1;
					hess_choice=3;
					back = this->GOpt(nvab,m,x,A,lower,upper,c);
					have_ls=0;
					hess_choice=5;
					break;
				}
				else if(revi == 0)
				{
					have_rev=1;
					hess_choice=2;
					back = this->GOpt(nvab,m,x,A,lower,upper,c);
					have_rev=0;
					hess_choice=5;
					break;
				}
#endif
			}
			else
			{
				revi=0;
				lsi=0;
			}
			SSS1->resize(nbefore);
			SSS2->resize(nbefore);
			SSS3->resize(revi+lsi+2);
			*SSS3=(size_t) -1;
			SSS4->resize(nvab+NN*MM+2*NN+2*(NN+MM));//implied,A,X,C,L,U
			*SSS4=123456;
			work = &(*SSS1)[0];
			lspenalty=&(*SSS2)[0];
			if(!UseDiagPenalty)
			{
				large_eigen=leigen(nvab);
				dsetvec(nvab,large_eigen,lspenalty);
			}
			else
			{
				lspenaltyvec(nvab,lspenalty);
				//dscalvec(nvab,100,lspenalty);//UBS demo
			}
			//dzerovec(nvab,lspenalty);
			vector implied=&(*SSS4)[0];
			qphess_base(nvab,1,1,1,H,initial,implied);
			newX=implied+nvab;
			newC=newX+NN;
			newL=newC+NN;
			newU=newL+NN+MM;
			newA=newU+NN+MM;
			lab = (SSS3->size()>0?&(*SSS3)[0]:0);//In gcc &(x)[0] is not 0 when x.size() is 0!!
			labrev=lab+lsi+1;
			vector newcon=newA+m*NN;
			vector newcond=newcon+NN*(mabs+1+(SLRATmin>0)+(SLRATmax>0));
//			dzerovec(NN*MM,newA);
			j=0;
			size_t jm,jr,zeroinit_here,lsratn,bad_range;
			bool lsused=0;
			if(lsi)
			{
 				ls_initial.resize(nvab+lsi);lsinitial=&ls_initial[0];
 				ls_implied.resize(nvab+lsi);
 				ls_initial=0;
 				ls_implied=0;
				for(i=0,jm=0;i<nvab;++i)
				{
					if(lower[i]<0 && upper[i]>0)
					{
						if(initial[i]>0)
						{
							ls_initial[i]=initial[i];
						}
						else if(initial[i]<0) 
						{
							ls_initial[nvab+jm]=initial[i];
						}
						jm++;
					}
				}
			}
			do
			{
				if(lsi)
				{
 					for(i=0,jm=0;i<nvab;++i)
					{
						if(lower[i]<0 && upper[i]>0)
						{
							ls_implied[nvab+jm]=implied[i];
							ls_implied[i]=implied[i];
							ls_implied[i]-=lspenalty[i]*ls_initial[nvab+jm];
							ls_implied[nvab+jm]-=lspenalty[i]*ls_initial[i];
							jm++;
						}
						else
							ls_implied[i]=implied[i];
					}
				}
				else
					lsinitial=0;
				if(!badcount || back==30)
				{
					for(i = 0,jm=0,jr=0,zeroinit_here=0;i < nvab;++i)
					{
						lsratn=1;
						if(lower[i] < 0 && upper[i] > 0 &&
							lower[i] < initial[i] && upper[i] > initial[i])
						{
							if(initial[i]<0)//(long initial is 0 short initial is initial[i])
							{
								//long buy 
								newL[i] = -ls_initial[i];
								newU[i] = upper[i]-ls_initial[i];
								newC[i] = c[i]+ls_implied[i];
								if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
								{
									newL[i] = -upper[i];
									newU[i] = upper[i];
									newC[i] = c[i];
								}
								for(k = 0;k < m;++k){newA[i+k*NN] = A[k+i*m];}
								newX[i] = dmax(ls_small,x[i]-initial[i]);
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newcon[i] = 1;
									if(take_out_costs)
										newcon[i]+=(*buysell)[i]/scale_utility_external_terms;
									if(SLRATmin>0)
									{
										newcon[i+NN*lsratn]=-SLRATmin;
										newcon[nvab+jm-zeroinit_here+NN*lsratn]=-1;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-1;
									}
									if(SLRATmax>0)
									{
										newcon[i+NN*lsratn]=-SLRATmax;
										newcon[nvab+jm-zeroinit_here+NN*lsratn]=-1;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-1;
									}
									for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
									if(delta > -lm_eps)
										newcond[i] = (mask?mask[i]:1);
								}
								//short buy
								newL[nvab+jm-zeroinit_here] = 0;
								newU[nvab+jm-zeroinit_here] = -ls_initial[nvab+jm];
								newC[nvab+jm-zeroinit_here] = c[i]+ls_implied[nvab+jm];
								if(shortalphacost)
								{
									//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
									if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
									{

									}
									else
									{
										newC[nvab+jm-zeroinit_here]+=shortalphacost[i];
									}
								}
								for(k = 0;k < m;++k){newA[nvab+jm-zeroinit_here+k*NN] = A[k+i*m];}
								newX[nvab+jm-zeroinit_here] = dmax(ls_small,x[i]-initial[i]);
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newcon[nvab+jm-zeroinit_here] = (gross?-1:0);
									if(take_out_costs)
										newcon[nvab+jm-zeroinit_here]+=(gross?(*buysell)[i]/scale_utility_external_terms:0);
									for(k=0;k<mabs;++k){newcon[nvab+jm-zeroinit_here+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
									if(delta > -lm_eps)
										newcond[nvab+jm-zeroinit_here] = (mask?mask[i]:1);
								}
								//short sell
								newU[nvab+lsi-zeroinit+jr] = 0;
								newL[nvab+lsi+jr-zeroinit] = lower[i]-ls_initial[nvab+jm];
								newC[nvab+lsi+jr-zeroinit] = c[i]+ls_implied[nvab+jm];
								for(k = 0;k < m;++k){newA[nvab+lsi-zeroinit+jr+k*NN] = A[k+i*m];}
								newX[nvab+lsi-zeroinit+jr] = dmin(-ls_small,x[i]-initial[i]);
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newcon[nvab+lsi-zeroinit+jr] = (gross?-1:0);
									if(take_out_costs)
										newcon[nvab+lsi-zeroinit+jr]+=(gross?(*buysell)[nnn+i]/scale_utility_external_terms:0);
									for(k=0;k<mabs;++k){newcon[nvab+lsi-zeroinit+jr+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
									if(delta > -lm_eps)
										newcond[nvab+lsi-zeroinit+jr] = (mask?-mask[i]:-1);
								}
							}
							else if(initial[i]>0)//(long initial is initial[i] short initial is 0)
							{
								//long buy
								newL[i] = 0;
								newU[i] = upper[i]-ls_initial[i];
								newC[i] = c[i]+ls_implied[i];
								if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
								{
									newL[i] = -upper[i];
									newU[i] = upper[i];
									newC[i] = c[i];
								}
								for(k = 0;k < m;++k){newA[i+k*NN] = A[k+i*m];}
								newX[i] = dmax(ls_small,x[i]-initial[i]);
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{

									newcon[i] = 1;
									if(take_out_costs)
										newcon[i]+=(*buysell)[i]/scale_utility_external_terms;
									if(SLRATmin>0)
									{
										newcon[i+NN*lsratn]=-SLRATmin;
										newcon[nvab+jm-zeroinit_here+NN*lsratn]=-SLRATmin;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-1;
									}
									if(SLRATmax>0)
									{
										newcon[i+NN*lsratn]=-SLRATmax;
										newcon[nvab+jm-zeroinit_here+NN*lsratn]=-SLRATmax;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-1;
									}
									for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
									if(delta > -lm_eps)
										newcond[i] = (mask?mask[i]:1);
								}
								//long sell
								newU[nvab+jm-zeroinit_here] = 0;
								newL[nvab+jm-zeroinit_here] = -ls_initial[i];
								newC[nvab+jm-zeroinit_here] = c[i]+ls_implied[i];
								for(k = 0;k < m;++k){newA[nvab+jm-zeroinit_here+k*NN] = A[k+i*m];}
								newX[nvab+jm-zeroinit_here] = dmin(-ls_small,x[i]-initial[i]);
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{

									newcon[nvab+jm-zeroinit_here] = 1;
									if(take_out_costs)
										newcon[nvab+jm-zeroinit_here]+=(*buysell)[nnn+i]/scale_utility_external_terms;
									for(k=0;k<mabs;++k){newcon[nvab+jm-zeroinit_here+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
									if(delta > -lm_eps)
										newcond[nvab+jm-zeroinit_here] = (mask?-mask[i]:-1);
								}
								//short sell
								newU[nvab+lsi-zeroinit+jr] = -ls_initial[nvab+jm];
								newL[nvab+lsi+jr-zeroinit] = lower[i]-ls_initial[nvab+jm];
								newC[nvab+lsi+jr-zeroinit] = c[i]+ls_implied[nvab+jm];
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									if(shortalphacost)
									{
										//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
										newC[nvab+lsi+jr-zeroinit]+=shortalphacost[i];
									}
								}
								for(k = 0;k < m;++k){newA[nvab+lsi-zeroinit+jr+k*NN] = A[k+i*m];}
								newX[nvab+lsi-zeroinit+jr] = dmin(-ls_small,x[i]-initial[i]);
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newcon[nvab+lsi-zeroinit+jr] = (gross?-1:0);
									if(take_out_costs)
										newcon[nvab+lsi-zeroinit+jr]+=(gross?(*buysell)[nnn+i]/scale_utility_external_terms:0);
									for(k=0;k<mabs;++k){newcon[nvab+lsi-zeroinit+jr+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
									if(delta > -lm_eps)
										newcond[nvab+lsi-zeroinit+jr] = (mask?-mask[i]:-1);

								}
							}
							else
							{
								zeroinit_here++;
								//long buy
								newL[i] = 0;
								newU[i] = upper[i];
								newC[i] = c[i]+ls_implied[i];
								if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
								{
									newL[i] = -upper[i];
									newU[i] = upper[i];
									newC[i] = c[i];
								}
								for(k = 0;k < m;++k){newA[i+k*NN] = A[k+i*m];}
								newX[i] = dmax(100*lm_eps,x[i]);
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{

									newcon[i] = 1;
									if(take_out_costs)
										newcon[i]+=(*buysell)[i]/scale_utility_external_terms;
									if(SLRATmin>0)
									{
										newcon[i+NN*lsratn]=-SLRATmin;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-1;
									}
									if(SLRATmax>0)
									{
										newcon[i+NN*lsratn]=-SLRATmax;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-1;
									}
									for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
									if(delta > -lm_eps)
										newcond[i] = (mask?mask[i]:1);
								}
								//short sell
								newU[nvab+lsi-zeroinit+jr] = 0;
								newL[nvab+lsi+jr-zeroinit] = lower[i];
								newC[nvab+lsi+jr-zeroinit] = c[i]+ls_implied[nvab+jm];
								if(shortalphacost)
								{
									//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
									if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
									{

									}
									else
									{
										newC[nvab+lsi+jr-zeroinit]+=shortalphacost[i];
									}
								}
								for(k = 0;k < m;++k){newA[nvab+lsi-zeroinit+jr+k*NN] = A[k+i*m];}
								newX[nvab+lsi-zeroinit+jr] = dmin(-100*lm_eps,x[i]);
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newcon[nvab+lsi-zeroinit+jr] = (gross?-1:0);
									for(k=0;k<mabs;++k){newcon[nvab+lsi-zeroinit+jr+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
									if(delta > -lm_eps)
										newcond[nvab+lsi-zeroinit+jr] = (mask?-mask[i]:-1);
								}
							}
							labrev[jr++]=i;lab[jm++]=i;
						}
						else if(lower[i] < 0 && upper[i] > 0)
						{
							newL[i] = -ls_initial[i];
							newU[i] = upper[i] - ls_initial[i];
							newC[i] = c[i] + ls_implied[i];
							if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
							{
								newL[i] = -upper[i];
								newU[i] = upper[i];
								newC[i] = c[i];
							}
							newX[i] = dmax(newL[i],x[i]-initial[i]);
							for(k = 0;k < m;++k)
							{
								newA[nvab+jm-zeroinit_here+k*NN] = newA[i+k*NN] = A[k+i*m];
							}
							if(SLRATmin>0)
							{
								newcon[i+NN*lsratn]=-SLRATmin;
								newcon[nvab+jm-zeroinit_here+NN*lsratn++]=-1;
							}
							if(SLRATmax>0)
							{
								newcon[i+NN*lsratn]=-SLRATmax;
								newcon[nvab+jm-zeroinit_here+NN*lsratn++]=-1;
							}
							newcon[i] = 1;
							for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
							newcon[nvab+jm-zeroinit_here] = (gross?-1:0);
							for(k=0;k<mabs;++k){newcon[nvab+jm-zeroinit+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
							if(delta > -lm_eps || take_out_costs)
							{
								if(initial[i] <= lower[i])
								{
									if(delta > -lm_eps)
									{
										newcond[nvab+jm-zeroinit_here]=newcond[i]=1;
									}
									if(take_out_costs)
									{
										newcon[i]+=(*buysell)[i]/scale_utility_external_terms;
										newcon[nvab+jm-zeroinit_here]+=(gross?(*buysell)[i]/scale_utility_external_terms:0);
									}
								}
								else if(initial[i] >= upper[i])
								{
									if(delta > -lm_eps)
										newcond[nvab+jm-zeroinit_here]=newcond[i]=-1;
									if(take_out_costs)
									{
										newcon[i]+=(*buysell)[nnn+i]/scale_utility_external_terms;
										newcon[nvab+jm-zeroinit_here]+=(gross?(*buysell)[nnn+i]/scale_utility_external_terms:0);
									}
								}
								else
									std::exception();
							}
							newL[nvab+jm-zeroinit_here] = lower[i] -ls_initial[nvab+jm];
							newU[nvab+jm-zeroinit_here] = -ls_initial[nvab+jm];
							newC[nvab+jm-zeroinit_here] = c[i] + ls_implied[nvab+jm];
							if(shortalphacost)
							{
						//	AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
									newC[nvab+jm-zeroinit_here]+=shortalphacost[i];
							}
							newX[nvab+jm-zeroinit_here] = dmin(newU[nvab+jm-zeroinit_here],x[i]-initial[i]);
							lab[jm++]=i;
						}
						else if(lower[i] < initial[i] && upper[i] > initial[i])
						{
							newU[i] = upper[i]-initial[i];
							newL[i] = 0;
							newC[i] = c[i]+implied[i];
							if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
							{
								newL[i] = -upper[i];
								newU[i] = upper[i];
								newC[i] = c[i];
							}
							newX[i] = dmax(100*lm_eps,x[i]-initial[i]);
							for(k = 0;k < m;++k)
							{
								newA[i+k*NN] =newA[nvab+lsi-zeroinit+jr+k*NN] = A[k+i*m];
							}
							if(lower[i]>=0)
							{
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newcon[i]=1;
									if(SLRATmin>0)
									{
										newcon[i+NN*lsratn]=-SLRATmin;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-SLRATmin;
									}
									if(SLRATmax>0)
									{
										newcon[i+NN*lsratn]=-SLRATmax;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-SLRATmax;
									}
									newcon[nvab+lsi-zeroinit+jr]=1;
									if(take_out_costs)
									{
										newcon[i]+=(*buysell)[i]/scale_utility_external_terms;
										newcon[nvab+lsi-zeroinit+jr]+=(*buysell)[nnn+i]/scale_utility_external_terms;
									}
									for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
									for(k=0;k<mabs;++k){newcon[nvab+lsi-zeroinit+jr+(k+lsratn)*NN]=absoluteA[i*mabs+k];}
								}
							}
							else if(upper[i] <= 0)
							{
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{

									if(shortalphacost)
									{
										//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
										newC[i]+=shortalphacost[i];
									}
									newcon[i]=(gross?-1:0);
									if(SLRATmin>0)
									{
										newcon[i+NN*lsratn]=-1;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-1;
									}
									if(SLRATmax>0)
									{
										newcon[i+NN*lsratn]=-1;
										newcon[nvab+lsi-zeroinit+jr+NN*lsratn++]=-1;
									}
									newcon[nvab+lsi-zeroinit+jr]=(gross?-1:0);
									for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
									for(k=0;k<mabs;++k){newcon[nvab+lsi-zeroinit+jr+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}
									if(take_out_costs)
									{
										newcon[i]+=(gross?(*buysell)[i]/scale_utility_external_terms:0);
										newcon[nvab+lsi-zeroinit+jr]+=(gross?(*buysell)[nnn+i]/scale_utility_external_terms:0);
									}
									if(shortalphacost)
									{
										//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
										newC[i]+=shortalphacost[i];
									}
								}
							}
							else
								std::exception();
							if(delta > -lm_eps)
							{
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newcond[i] = (mask?mask[i]:1);
									newcond[nvab+lsi-zeroinit+jr] = (mask?-mask[i]:-1);
								}
							}
							newL[nvab+lsi-zeroinit+jr] = lower[i]-initial[i];
							newU[nvab+lsi-zeroinit+jr] = 0;
							newC[nvab+lsi-zeroinit+jr] = c[i]+implied[i];
							newX[nvab+lsi-zeroinit+jr] = dmin(-100*lm_eps,x[i]-initial[i]);
							labrev[jr++]=i;
						}
						else
						{
							newL[i]=lower[i]-initial[i];
							newU[i]=upper[i]-initial[i];
							newC[i]=c[i]+implied[i];
							if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
							{
								newL[i] = -upper[i];
								newU[i] = upper[i];
								newC[i] = c[i];
							}
							newX[i]=x[i]-initial[i];
							for(k = 0;k < m;++k)
								newA[i+k*NN] = A[k+i*m];
							if(lower[i] >= 0)
							{
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									newcon[i]=1;
									if(take_out_costs)
									{
										if(lower[i]>initial[i])
											newcon[i]+=(*buysell)[i]/scale_utility_external_terms;
										else
											newcon[i]+=(*buysell)[nnn+i]/scale_utility_external_terms;
									}
									if(SLRATmin>0)
									{
										newcon[i+NN*lsratn++]=-SLRATmin;
									}
									if(SLRATmax>0)
									{
										newcon[i+NN*lsratn++]=-SLRATmax;
									}
								}
							}
							else if(upper[i] <=0)
							{
								if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
								{

								}
								else
								{
									if(shortalphacost)
									{
										//		AddLog("%d l %f u %f\n",__LINE__,initial[i]+lower[i],initial[i]+upper[i]);
										newC[i]+=shortalphacost[i];
									}
									newcon[i]=(gross?-1:0);
									if(SLRATmin>0)
									{
										newcon[i+NN*lsratn++]=-1;
									}
									if(SLRATmax>0)
									{
										newcon[i+NN*lsratn++]=-1;
									}
									if(take_out_costs)
									{
										if(lower[i]>initial[i])
											newcon[i]+=(gross?(*buysell)[i]/scale_utility_external_terms:0);
										else
											newcon[i]+=(gross?(*buysell)[nnn+i]/scale_utility_external_terms:0);
									}
								}
							}
							else
								std::exception();
							if(TimeOptData&&TimeOptData->opt&&i>=nvab-TimeOptData->nextra)
							{

							}
							else
							{
								if(mabs&&(lower[i] >= 0)){for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=absoluteA[i*mabs+k];}}
								else if(mabs){for(k=0;k<mabs;++k){newcon[i+(k+lsratn)*NN]=-absoluteA[i*mabs+k];}}
								if(delta>-lm_eps)
								{
									if(initial[i] <= lower[i])
									{
										newcond[i]=(mask?mask[i]:1);
									}
									else if(initial[i] >= upper[i])
									{
										newcond[i]=(mask?-mask[i]:-1);
									}
									else
									{
										std::exception();
									}
								}
							}
						}
					}
					//					if(ddotvec(NN,newX,newX)<10*lm_eps)//Avoid zero guess
//					{
//						newX[0]=.5*(newL[0]+newU[0]);
//					}
				}
				else
				{
					AddLog("Reopt using the signs of the previous result\n");
					have_ls=1;
					have_rev=1;
					hess_choice=3;
					dcopyvec(m+nvab,lower,newL);
					dcopyvec(m+nvab,upper,newU);
					std::valarray<double>grad(nvab);
//					std::valarray<size_t>oo(nvab);
					qphess_base(nvab,1,1,1,H,x,&grad[0]);
					daddvec(nvab,&grad[0],c,&grad[0]);
					daddvec(nvab,&grad[0],implied,&grad[0]);
//					getordereig(nvab,&grad[0],&oo[0],0);
/*
	If we get that x[i] is 0 then how do we set the signs?
	The gradients of the utility indicate what a steepest descent step would do,
	so we can use these. It's not always foolproof though.

  In Bryan Smith's UBS problem, there are many zeros in the initial portfolio and the 
  upper and lower bounds for these stock are +- delta; i.e. they are trying to decide 
  whether to include this stock.
  If the optimised results still have zero for these stocks it means that the signs were 
  chosen wrongly, and it may be worth doing another optimisation with changed signs. (The
  tryagain bit below)			9th February 2007
  */

					for(i=0;i<nvab;++i)
					{
						if(x[i] > 0)
						{
							newL[i] = dmax(0,lower[i]);
							newU[i] = upper[i];
						}
						else if(x[i] < 0)
						{
							newL[i] = lower[i];
							newU[i] = dmin(0,upper[i]);
						}
						else if(lower[i]<0 && upper[i]>0)
						{
							if(grad[i]<0)
							{
								newL[i] = dmax(0,lower[i]);
								newU[i] = upper[i];
							}
							else
							{
								newL[i] = lower[i];
								newU[i] = dmin(0,upper[i]);
							}
						}
						if(TimeOptData&&TimeOptData->OptType == CVarType && i == nvab-TimeOptData->nextra)
						{
							newL[i] = -upper[i];
							newU[i] = upper[i];
							newC[i] = c[i];
						}
					}
					std::valarray<double>nnL(nvab+m),nnU(nvab+m);
					dcopyvec(nvab+m,newL,&nnL[0]);
					dcopyvec(nvab+m,newU,&nnU[0]);
					back = this->GOpt(nvab,m,x,A,&nnL[0],&nnU[0],c);
					bool tryagain=true;//Change back to true when bug is fixed FIXED 4-6-2014
					double Unow;
					short backnow=back;
					size_t tcount=0,tcount_top=(nvab>100?2:nvab/2);
					while(tryagain&&tcount<tcount_top)
					{
						tryagain=false;
						for(i=0;i<nvab;++i)
						{
							if(x[i]<lower[i])
								x[i]=lower[i];
							else if(x[i]>upper[i])
								x[i]=upper[i];
							if(initial[i]==0)
							{
								if(fabs(x[i])<1e-12)
								{
									if(nnL[i]==0)
									{
										nnL[i]=lower[i];
										nnU[i]=0;
										tryagain=true;
									}
									else if(nnU[i]==0)
									{
										nnL[i]=0;
										nnU[i]=upper[i];
										tryagain=true;
									}
								}
							}
						}
						Unow=this->utility_base(n,x,c,H)+this->shortcost(n,x);
						if(tryagain)
						{
							std::valarray<double>xkeep(nvab);
							dcopyvec(nvab,x,&xkeep[0]);
							AddLog("U now %20.15e\n",Unow);
							AddLog("Change signs again\n");
							back = this->GOpt(nvab,m,x,A,&nnL[0],&nnU[0],c);
							double Unew=this->utility_base(n,x,c,H)+this->shortcost(n,x);
							if(Unow<Unew||back==9)
							{
								AddLog("Keep previous result\n");
								dcopyvec(nvab,&xkeep[0],x);
								tryagain=false;
								back=backnow;
							}
							else
								Unow=Unew;
							backnow=back;
						}
						tcount++;
					}
					have_ls=0;
					have_rev=0;
					hess_choice=5;
					AddLog("U now %20.15e\n",Unow);
					break;
				}
				real tt;
				for(k = 0;k < m;++k)
				{
					tt = BITA_ddot(nvab,A+k,m,initial,1);
					newL[NN+k] = lower[nvab+k]-tt;
					newU[NN+k] = upper[nvab+k]-tt;
				}
		//________________________________________________COVER LONG SUM IN (0,LSValue)
				for(i=0,tt=0;i<nvab;++i){tt+=(initial[i]>0?initial[i]:(gross?-initial[i]:0));}
				newL[NN+m] = (gross?LSValue_Low:(Full ?LSValue:LSValue_Low)) - tt;
				newU[NN+m] = LSValue - tt;
				lsratn=0;
				if(SLRATmin>0)
				{
					tt=0;
					for(i=0;i<nvab;++i){tt+=(initial[i]>0?-initial[i]*SLRATmin:-initial[i]);}
					newL[NN+m+1+lsratn] = -tt;
					newU[NN+m+1+lsratn++] = 1000;
				}
				if(SLRATmax>0)
				{
					tt=0;
					for(i=0;i<nvab;++i){tt+=(initial[i]>0?-initial[i]*SLRATmax:-initial[i]);}
					newL[NN+m+1+lsratn] = -1000;
					newU[NN+m+1+lsratn++] = -tt;
				}
				for(i=0;i < (n-nvab);++i)
				{
					lsratn=0;
					if(x[i+nvab] > 0)
					{
						newL[NN+m] -= x[i+nvab];
						newU[NN+m] -= x[i+nvab];
					}
					else if(gross&&x[i+nvab] < 0)
					{
						newL[NN+m] += x[i+nvab];
						newU[NN+m] += x[i+nvab];
					}
					if(SLRATmin>0)
					{
						if(x[i+nvab] > 0)
						{
							newL[NN+m+1+lsratn] += SLRATmin*x[i+nvab];
						}
						else if(x[i+nvab] < 0)
						{
							newL[NN+m+1+lsratn] += x[i+nvab];
						}
						lsratn++;
					}
					if(SLRATmax>0)
					{
						if(x[i+nvab] > 0)
						{
							newU[NN+m+1+lsratn] += SLRATmax*x[i+nvab];
						}
						else if(x[i+nvab] < 0)
						{
							newU[NN+m+1+lsratn] += x[i+nvab];
						}
						lsratn++;
					}
				}
				if(newU[NN+m] < newL[NN+m])
				{
					back=6;
					AddLog("Impossible gross or cover bounds\n");
				}
				if(gross==2)
					newL[NN+m]=newU[NN+m];
		//________________________________________________Absolute
				for(k=0;k<mabs;++k)
				{
					tt=0;
					for(i=0;i<nvab;++i){tt+=fabs(absoluteA[i*mabs+k]*initial[i]);}
					newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] = lowerA[k]-tt;
					newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] = upperA[k]-tt;
					for(i=0;i < (n-nvab);++i)
					{
						if(x[i+nvab] > 0)
						{
							newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] -= absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
							newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] -= absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
						}
						else
						{
							newL[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] += absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
							newU[NN+m+1+k+(SLRATmin>0)+(SLRATmax>0)] += absoluteA[(i+nvab)*mabs+k]*x[i+nvab];
						}
					}
				}
		//________________________________________________turnover
				if(delta>-lm_eps)
				{
					newL[NN+m+1+mabs+(SLRATmin>0)+(SLRATmax>0)] = 0;
					newU[NN+m+1+mabs+(SLRATmin>0)+(SLRATmax>0)] = delta*2;
					real forced=0,inner;
					for(i=0;i < (n-nvab);++i)
					{
						if((inner = fabs((x[i+nvab]-initial[i+nvab])*(mask?mask[i+nvab]:1))) > 0)
						{
							newU[NN+m+1+mabs+(SLRATmin>0)+(SLRATmax>0)] -= inner;
							forced += inner;
						}
					}
					//lm_wmsg("Forced turnover is %f (%lu,%lu)",forced*.5,n,nvab);
					if(newU[NN+m+1+nvab+mabs+(SLRATmin>0)+(SLRATmax>0)] < 0)
					{
						back=20;
						AddLog("Impossible turnover\n");
					}
				}
		//________________________________________________
				dmx_transpose(NN,MM,newA,newA);
//				do
				{
					bad_range=0;
					oldobjective=this->objective;
/*					printf("Before\n");
					for(i=0;i<NN+MM;++i)
					{
						if(i<NN)
						{
							if(newX[i]<newL[i]-lm_eps||newX[i]>newU[i]+lm_eps)
							{
								newX[i]=.5*(newL[i]+newU[i]);
								printf("S  %d X%f L%f U%f\n",i,newX[i],newL[i],newU[i]);
							}
						}
						else
						{
							double cons=BITA_ddot(NN,newA+i-NN,MM,newX,1);
							if(cons<newL[i]-lm_eps||cons>newU[i]+lm_eps)
							{
								printf("C  %d X%f L%f U%f\n",i-MM,cons,newL[i],newU[i]);
							}
							}
				}*/
					int bback=0;
					try
					{
						switch(this->useInteriorPoint)
						{
						case 0:
							if(nvab<OPT_METH_SWITCH)back=Opt(NN,MM,newX,newA,newL,newU,newC);
							else back=OptInterior(NN,MM,newX,newA,newL,newU,newC);
							break;
						case 1:
							back=OptInterior(NN,MM,newX,newA,newL,newU,newC);
							break;
						case 2:
							back=QPbySeqLP(NN,MM,newX,newC,newA,newL,newU,H,QPbySeqHmul,this);
							break;
						case 3:
							back=QPopt(NN,MM,newX,newC,newA,newL,newU,H,QPbySeqHmul,this);
							break;
						}
						/*					printf("After\n");
						for(i=0;i<NN+MM;++i)
						{
						if(i<NN)
						{
							if(newX[i]<newL[i]-lm_eps||newX[i]>newU[i]+lm_eps)
							{
								printf("S  %d X%f L%f U%f\n",i,newX[i],newL[i],newU[i]);
							}
						}
						else
						{
							double cons=BITA_ddot(NN,newA+i-NN,MM,newX,1);
							if(cons<newL[i]-lm_eps||cons>newU[i]+lm_eps)
							{
								printf("C  %d X%f L%f U%f\n",i-MM,cons,newL[i],newU[i]);
							}
						}
					}*/
					if(back==6)
					{
						for(i=0;i<NN;i++)
						{
							if(newX[i]<newL[i])
								newX[i]=newL[i];
							else if(newX[i]>newU[i])
								newX[i]=newU[i];
						}
					}
/*						for(i=0;i<MM;++i)
						{
							AddLog("%-.8e  %-.8e  %-.8e\n",newL[i+NN],BITA_ddot(NN,newA+i,MM,newX,1),newU[i+NN]);
						}*/
					}
					catch( ... )
					{
						back=15;bback=15;
						AddLog("Memory Problem\n");
					}
					if(NN==nvab)
						dcopyvec(nvab,newX,x);
					else
					{
						for(i=0,jm=0,jr=0,zeroinit_here=0;i<nvab;++i)
						{
							x[i]=newX[i]+initial[i];
							if(lab&&lab[jm]==i && jm < lsi && labrev&&labrev[jr]==i && jr < revi)
							{
								double xp,xm,xpm;
								xp = newX[i];
								xm = newX[nvab+lsi-zeroinit+jr];
								if(initial[i]<0)
								{
									xpm=newX[nvab+jm-zeroinit_here];
									x[i]+=newX[nvab+jm-zeroinit_here];
									if(back<2&&testonenonneg(xp,xm,xpm))
										back=20;
								}
								else if(initial[i]>0)
								{
									xpm=newX[nvab+jm-zeroinit_here];
									x[i]+=newX[nvab+jm-zeroinit_here];
									if(back<2&&testonenonneg(xp,xm,xpm))
										back=20;
								}
								else
								{
									if(back<2&&testonenonneg(xp,xm))
										back=20;
									zeroinit_here++;
								}
								jm++;
								x[i]+=newX[nvab+lsi-zeroinit+jr++];
							}
							else if(labrev&&labrev[jr]==i && jr < revi)
							{
								if(back<2&&testonenonneg(newX[i],newX[nvab+lsi-zeroinit+jr]))
									back=20;
								x[i]+=newX[nvab+lsi-zeroinit+jr++];
								
							}
							else if(lab&&lab[jm]==i && jm < lsi)
							{
								if(back<2&&testonenonneg(newX[i],newX[nvab+jm-zeroinit_here]))
									back=20;
								x[i]+=newX[nvab+jm++-zeroinit_here];
							}
						}
					}
					if(back==6)
					{
						for(i=0;i<nvab;++i)
						{
							if(x[i]<lower[i])
								x[i]=lower[i];
							else if(x[i]>upper[i])
								x[i]=upper[i];
						}
					}
					if(0)//This slows everything done and doesn't usually help much
					{
						for(i=0,jm=0,bad_range=0;i<nvab;++i)
						{
							if(lab[jm]==i)
							{
								if(!((x[i]>=0 && initial[i]>=0) || (x[i]<=0 && initial[i]<=0)))
								{
									std::swap(ls_initial[i],ls_initial[jm+nvab]);bad_range++;
									AddLog("switch %d %d %f %f\n",i,jm+nvab,ls_initial[i],ls_initial[jm+nvab]);
								}
								jm++;
							}
						}
					}
					AddLog("Try: %2d, back: %2d, bad entries in pseudo-initial portfolio: %3d, obj=%-.8e\n",badcount,back,bad_range,this->objective);
					if(back==11)back=0;
					AddLog("U now %20.15e\n",this->utility_base(n,x,c,H)+this->shortcost(n,x));
					if(longshorttest(n,x,this)||nvab<50)	back=6;
					if(bback==15){back=15;break;}
					if(back>1)//back==20 || bad_range)
					{
						back=20;break;//Breaking here sets up CHOICE=3 with the signs of this solution. Forget about using swapped initials at the moment and changing lspenalty
					}
					if(bad_range&&(back<2||back==20))
					{
						back=30;lsused=1;
					}
					else if(bad_range)
						back=30;
					else if(lsused)
						back=30;
					if(back<2 && lsused)
					{
						back=20;break;
					}
					if((bad_range==0||badcount==badcountlimit)&&back==6)
					{
						back=20;break;
					}
					if(back>=20&&fabs((this->objective-oldobjective)/this->objective) < lm_rooteps && badcount < badcountlimit)
					{
						if(back==30)back=20;
						AddLog("Objective is stable\n");
						break;
					}
					if(back>=20&&fabs((this->objective-minobjective)/this->objective) < lm_rooteps && badcount < badcountlimit)
					{
						if(back==30)back=20;
						AddLog("Stop at min objective\n");
						break;
					}
					if(back == 20&&!bad_range) {scale *= 2.0;AddLog("###############################################\n# Changing LS penalty scale  to %-.5f #\n###############################################\n",scale);}
					if(back == 20&&!bad_range)
					{
						dscalvec(nvab,2.0,lspenalty);
						AddLog("long and short together\n");
						back=30;
					}
				}
//				while(back==20 && badcount++ < badcountlimit);
				if(badcount > 3&&bad_range)
					minobjective=dmin(minobjective,this->objective);
			}
			while(back==30 && badcount++ < badcountlimit);
			if(back==30)back=20;
		}
		while(back==20 && badcount++ < badcountlimit+2);
		if(back == 20) {back=6;} 
		releaseSSS();
		if(back==5 && lp_really) back=0;
		return back;
	}
	else
		return -12345;
}
void	Optimise::releaseSSS()
{
	SSS1->resize(0);
	SSS2->resize(0);
	SSS3->resize(0);
	SSS4->resize(0);
}
double Optimise::turnover()
{
	double t=0;
	size_t nnn=n;
	if(TimeOptData)
		nnn-=TimeOptData->nextra;
	vector w1=x,w2=initial;
	if(mask)
	{
		vector m1=mask;
		while(nnn--)
			t+=fabs(((*w1++)-(*w2++))*(*m1++));
	}
	else
	{
		while(nnn--)
			t+=fabs((*w1++)-(*w2++));
	}
	return t*.5;
}
size_t Optimise::H_size()
{
	return(n*(n+1)/2);
}
size_t FOptimise::H_size()
{	
	size_t size = vQ->size();
	if(!size)
		size=n*(n+1)/2;
	return(size);
}
FOptimise::FOptimise()
{
//	printf("FOptimise::FOptimise()\n");
	FL=0;
	FC=0;
	SV=0;
	vQ = new std::valarray<double>;
#ifdef USE_STOREX
	storex = new std::valarray<double>;
#endif
}
FOptimise::~FOptimise()
{
	lm_wmsg("FOptimise::~FOptimise()");
	delete vQ;
#ifdef USE_STOREX
	delete storex;
#endif
}
void FOptimise::qphess_base(dimen nvab,dimen n1,dimen n2,dimen n3,vector Q,vector w,vector y)
{
	size_t t=0;
	if(TimeOptData&&TimeOptData->opt)
	{
		t=TimeOptData->tlen;
		if(TimeOptData->OptType==CVarType)
			t++;
		dzerovec(t,y+nvab-t);
		if(TimeOptData->OptType==SemiVarType)
		{
			dcopyvec(t,w+nvab-t,y+nvab-t);
			dscalvec(t,1./(TimeOptData->tlen),y+nvab-t);
		}
	}
	if(!ncomp)
		facmul(nvab-t,Q,w,y);
	else
	{
		size_t i;
		facmul(nvab-t-ncomp,Q,w,y);
		dsmxmulv(ncomp-t,&(*CompQ)[0],w+nvab-t-ncomp,y+nvab-t-ncomp);
		for(i=0;i<ncomp;++i)
			y[nvab-t-ncomp+i]+=ddotvec(nvab-t-ncomp,&(*yc)[i*(n-t-ncomp)],w);
		for(i=0;i<ncomp;++i)
			daxpyvec(nvab-t-ncomp,w[nvab-t-ncomp+i],&(*yc)[i*(n-t-ncomp)],y);
	}
/*	if(TimeOptData&&TimeOptData->opt&&TimeOptData->OptType==SemiVarType)
	{
		size_t i;
		for(i=0;i<t;++i)
		{
			BITA_daxpy(nvab-t,.25*(w[nvab-t+i]+BITA_ddot(nvab-t,TimeOptData->DATA+i,t,w,1)) /(t-1),TimeOptData->DATA+i,t,y,1);
		}
	}*/
	if(ModHessian && use_higher_H)//Won't be correct for Gain/Loss new way
	{
		std::valarray<double>yy(nvab);
		if(higher_reset)
		{
			dzerovec(n*(n+1)/2,H_from_higher_terms);
			std::valarray<double>XXX(n);
			dcopyvec(nvab,w,&XXX[0]);
			dcopyvec(n-nvab,x+nvab,&XXX[nvab]);
			if(hess_choice==3 || hess_choice==5)
			{
				daddvec(n,&XXX[0],initial,&XXX[0]);
			}
			ResetInitial(0);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&XXX[0],1);
			ModHessian(n,&XXX[0],H_from_higher_terms,ModQObjectInfo);
			ResetInitial();
			dscalvec(n*(n+1)/2,scale_utility_external_terms,H_from_higher_terms);
			if(optimiseorder)Reorder_sym(n,optimiseorder,H_from_higher_terms);
		}
		dsmxmulv(nvab,H_from_higher_terms,w,&yy[0]);
		if(higher_reset)
			dcopyvec(nvab,&yy[0],&(*ExtraQx)[0]);
		daddvec(nvab,y,&yy[0],y);
	}
	if(use_soft_in_hessmult&&soft_m)
	{
		size_t i;
		double ss;
		for(i=0;i<soft_m;++i)
		{
			ss=BITA_ddot(nvab,soft_A+i,soft_m,w,1);
			if(ss!=0)
			{
				ss*=soft_l[i];
				BITA_daxpy(nvab,ss,soft_A+i,soft_m,y,1);
			}
		}
	}
}
void	Optimise::CompSetup()
{
//_________________________________________________________________________________
//This isn't really a sensible place for this, but it must not happen in FOptimise,
//as we only allow the general Hessian multiplication routine for Optimise and not
//FOptimise.
	if(!hmul) hmul=(pHmul)HMUL;
//_________________________________________________________________________________
	if(ncomp)
	{
		yc->resize(ncomp*(n-ncomp));
		CompQ->resize(ncomp*(ncomp+1)/2);
		size_t ij=0;
		for(size_t i=0;i<ncomp;++i)
		{
			hmul(n-ncomp,1,1,1,H,Composites+(n-ncomp)*i,&(*yc)[i*(n-ncomp)],HmulObjectInfo);
			for(size_t j=0;j<=i;++j)
			{
				(*CompQ)[ij++]=ddotvec(n-ncomp,&(*yc)[i*(n-ncomp)],Composites+(n-ncomp)*j);
			}
		}
	}
}
void	FOptimise::CompSetup()
{
	size_t nvab=n-ncomp;
#ifdef USE_STOREX
	if(storex->size()<nvab)storex->resize(nvab);
#endif
	if(ncomp)
	{
		yc->resize(ncomp*(nvab));
		CompQ->resize(ncomp*(ncomp+1)/2);
		size_t ij=0;
		for(size_t i=0;i<ncomp;++i)
		{
			facmul(nvab,H,Composites+(nvab)*i,&(*yc)[i*(nvab)]);
			for(size_t j=0;j<=i;++j)
			{
				(*CompQ)[ij++]=ddotvec(nvab,&(*yc)[i*(nvab)],Composites+(nvab)*j);
			}
		}
	}
}
void Optimise::beta(vector bench,vector beta)
{
	if(ImportantCheck()) return;
	if(yc->size() == 0 && CompQ->size() == 0)
		CompSetup();
	use_soft_in_hessmult=false;
	qphess_base(n,1,1,1,H,bench,beta);
	use_soft_in_hessmult=true;
	double bvar=ddotvec(n,bench,beta);
	if(bvar>lm_eps) dscalvec(n,1.0/bvar,beta);
	else dzerovec(n,beta);
}
real	Optimise::risk(vector w,vector bench)
{
	if(ImportantCheck()) return 0;
	if(yc->size() == 0 && CompQ->size() == 0)
		CompSetup();
	std::valarray<double>implied(n),rel(n);
	if(bench)
		dsubvec(n,w,bench,&rel[0]);
	else
		dcopyvec(n,w,&rel[0]);
	use_soft_in_hessmult=false;
	qphess_base(n,1,1,1,H,&rel[0],&implied[0]);
	use_soft_in_hessmult=true;
	real v=ddotvec(n,&rel[0],&implied[0]);
	if(v > lm_eps)
		return sqrt(v);
	else
		return 0;
}

void	Optimise::MC(vector w,vector bench,vector MARG)
{
	if(!MARG) return;
	if(ImportantCheck()) return;
	if(yc->size() == 0 && CompQ->size() == 0)
		CompSetup();
	std::valarray<double>rel(n);
	if(bench)	{dsubvec(n,w,bench,&rel[0]);}
	else	{dcopyvec(n,w,&rel[0]);}
	use_soft_in_hessmult=false;
	qphess_base(n,1,1,1,H,&rel[0],MARG);
	use_soft_in_hessmult=true;
	real v=ddotvec(n,&rel[0],MARG);
	if(v > lm_eps)	{dscalvec(n,1/sqrt(v),MARG);}
	else	{dzerovec(n,MARG);}
}
bool Optimise::ImportantCheck()
{
	if(!lp && !H)
	{
		std::cout << "No risk model array" << std::endl;
		back=9;
		return 1;
	}
	return 0;
}
char* Optimise::OptSetup(dimen nvab,dimen nvabt)
{
	double testcon;
	int checkback=0;

/*	if((nvab==(dimen)-1 || nvab >= n) && (!threshvector && threshscalar<=lm_eps))
	{
		threshvector=threshvectort;
		threshscalar=threshscalart;
		char* retmess=OptSetup(nvabt);
		return retmess;
	}
	if((nvabt==(dimen)-1 || nvabt >= n) && (!threshvectort && threshscalart<=lm_eps))
	{
		char* retmess=OptSetup(nvab);
		return retmess;
	}*/
	size_t	i,Nvab=n;

	if(ImportantCheck())
		return Return_Messages[back];
	if(ModHessian)
	{
		extraH->resize(n*(n+1)/2);
		H_from_higher_terms=&(*extraH)[0];
	}
	fixed_bounds=0;
	fixed_zero=0;
	fixed_zerot=0;
	long sofar;

	if(fileset)
	{
		lm_set_files(0,stdout);
		lm_set_files(1,stderr);
		fileset = 0;
	}
//________________________________________________________________________________________
	CompSetup();
//________________________________________________________________________________________
	for(i = 0;i < n-ncomp;++i)
	{
		if(fabs(lower[i] - upper[i]) < equalbounds)	
		{
			fixed_bounds++;
			if(fabs(lower[i]) < equalbounds)
				fixed_zero++;
			if(fabs(lower[i]-(drop_to_this?drop_to_this[i]:0)) < equalbounds)
				fixed_zerot++;
		}
	}

//________________________________________________________________________________________

	Nvab -= fixed_bounds;
	if(Nvab==0)
	{
		AddLog("Stop an attempt to optimise with no variables\n");
		lower[n-ncomp-1]-=lm_rooteps*.5;
		upper[n-ncomp-1]+=lm_rooteps*.5;
		Nvab+=1;
		fixed_bounds-=1;
	}
	if(dropbad->size()!=n)
	{
		dropbad->resize(n);
		(*dropbad) = 0;
	}

	if(vx->size()!=n){vx->resize(n);*vx=0;}
	x = &(*vx)[0];

	if(vx->size()<n)
	{
		AddLog("n=%ld. Could not allocate %ld bytes\n",n,(n)*sizeof(double));
		fflush(stdout);
		throw MemProb("Memory problem for x in Optimise::Opt()",(n)*sizeof(double),n);
	}
	else
	{
		if(initial && ModDeriv &&!ModHessian)
		{
			if(TimeOptData) *vx=1.0/n;
			else			dcopyvec(n,initial,x);
		}
		else if(!ModHessian/*&&ddotvec(n,x,x)<10*lm_eps*/)
			*vx = 1.0/n;    //This is our initial guess
		else if(ModHessian&&firstw)
		{
			if(ddotvec(n,firstw,firstw)>1e-5)//This is our initial guess
				dcopyvec(n,firstw,x);
			else
				*vx = 1.0/n;    
		}
	}

//	if(hess_choice == 2 || hess_choice == 5)
//		dzerovec(nvab,x);
	for(i=0;i<n;++i)
	{
		x[i]=dmax(x[i],lower[i]);
		x[i]=dmin(x[i],upper[i]);
	}

//________________________________________________________________________________________
	vneworder->resize(n-ncomp);
	effectiveorder->resize(2*n);
	for(i=0;i<n;++i){(*effectiveorder)[i]=i;}
	neworder = &(*vneworder)[0];
	vinverse->resize(n-ncomp);
	inverse = &(*vinverse)[0];
	vcomporder->resize(n);
	vcinverse->resize(n);
	for(i=0;i<n-ncomp;++i) {inverse[i]=neworder[i]=i;}

	if(fixed_bounds)
	{violation_test(this,"Start fixed bounds");
		sofar = n-1-ncomp;
		for(i = 0;sofar>=(long)i;++i)
		{
			while(sofar>=0&&fabs(lower[neworder[sofar]] - upper[neworder[sofar]]) < equalbounds){sofar--;}
			if(sofar > (long)i && fabs(lower[neworder[i]] - upper[neworder[i]]) < equalbounds)
			{
				std::swap(neworder[i],neworder[sofar]);
			}
		}
		for(i=0;i<n-ncomp;++i) {inverse[neworder[i]]=i;}
		Reorder_gen(n-ncomp,neworder,upper,1);
		Reorder_gen(n-ncomp,neworder,initial,1);
		Reorder_gen(n-ncomp,neworder,&(*effectiveorder)[0],1);
		Reorder_gen(n-ncomp,neworder,lower,1);
		Reorder_gen(n-ncomp,neworder,c,1);
		Reorder_gen(n-ncomp,neworder,shortalphacost,1);
		Reorder_gen(n-ncomp,neworder,A,m);
		Reorder_gen(n-ncomp,neworder,soft_A,soft_m);
		Reorder_gen(n-ncomp,neworder,absoluteA,mabs);
		TransformH();
		Reorder_gen(n-ncomp,neworder,&(*dropbad)[0],1);
		//order is moving, fixed, comp; moving and comp can change

		if(ncomp)
		{
			for(i=0;i<ncomp;++i)
			{
				Reorder_gen(n-ncomp,neworder,Composites+i*(n-ncomp),1);//I don't think we need this
				Reorder_gen(n-ncomp,neworder,&(*yc)[i*(n-ncomp)],1);
			}
			size_t j=(ncomp+n-Nvab)/2;
			for(i=0;i<n;++i){(*vcomporder)[i]=i;}
			for(i=0;i<j;++i)
			{
				std::swap((*vcomporder)[i+Nvab-ncomp],(*vcomporder)[n-i-1]);
			}
			for(i=0;i<ncomp/2;++i)//The composite order has been reversed so we change it back
			{
				std::swap((*vcomporder)[i+Nvab-ncomp],(*vcomporder)[Nvab-i-1]);
			}
/*			for(i=0;i<(n-Nvab)/2;++i)//The fixed order has been reversed too so we change it back
			{
				std::swap((*vcomporder)[i+Nvab],(*vcomporder)[n-i-1]);
			}*/
			for(i=0;i<n;++i){(*vcinverse)[(*vcomporder)[i]]=i;}
			Reorder_gen(n,&(*vcomporder)[0],&(*dropbad)[0],1);
			Reorder_gen(n,&(*vcomporder)[0],&(*effectiveorder)[0],1);
			Reorder_gen(n,&(*vcomporder)[0],upper,1);
			Reorder_gen(n,&(*vcomporder)[0],initial,1);
			Reorder_gen(n,&(*vcomporder)[0],lower,1);
			Reorder_gen(n,&(*vcomporder)[0],shortalphacost,1);
			Reorder_gen(n,&(*vcomporder)[0],c,1);
			Reorder_gen(n,&(*vcomporder)[0],A,m);// moving, comp, fixed
			Reorder_gen(n,&(*vcomporder)[0],soft_A,soft_m);
			Reorder_gen(n,&(*vcomporder)[0],absoluteA,mabs);
		}

		dcopyvec(fixed_bounds,lower+Nvab,x+Nvab);
		for(i=0;i<m;++i)//We have to check that fixed stocks don't violate linear constraints
		{
			if(BITA_ddot(Nvab,A+i,m,A+i,m) <lm_eps)//This is zero if only the fixed stocks are in the constraint
			{
				testcon=BITA_ddot(n-Nvab,A+i+Nvab*m,m,x+Nvab,1);
				if(testcon<lower[n+i] || testcon>upper[n+i])
					checkback=6;
			}
		}
		bound_reorganise(1,n,Nvab,m,lower);
		bound_reorganise(1,n,Nvab,m,upper);
		for(i = Nvab-ncomp;i < n-ncomp;++i)
		{
			daxpyvec(m,-x[i+ncomp],A + (i+ncomp) * m,lower + Nvab);
			daxpyvec(m,-x[i+ncomp],A + (i+ncomp) * m,upper + Nvab);
		}
//________________________________________________________________________________________
		fixed_implied->resize(2*n);
		dzerovec(Nvab,&(*fixed_implied)[0]);
		dcopyvec(fixed_bounds,x+Nvab,&(*fixed_implied)[Nvab]);
		if(ncomp)
		{
			Reorder_gen(n,&(*vcinverse)[0],&(*fixed_implied)[0],1);
		}
		qphess_base(n,1,1,1,H,&(*fixed_implied)[0],&(*fixed_implied)[n]);
		if(ncomp)
		{
			Reorder_gen(n,&(*vcomporder)[0],&(*fixed_implied)[0],1);
			Reorder_gen(n,&(*vcomporder)[0],&(*fixed_implied)[n],1);
		}
		daddvec(n,c,&(*fixed_implied)[n],c);
		violation_test(this,"End fixed_bounds after transforming",Nvab);
	}
//________________________________________________________________________________________
	optimiseorder=&(*effectiveorder)[0];
	for(i=0;i<n;++i){optimiseorder[optimiseorder[i]+n]=i;}
	if(soft_m)
	{
		size_t j;
		double ss;
		for(j=0;j<soft_m;++j)
		{
			ss=soft_b[j]*soft_l[j];
			if(ss)
			{
				BITA_daxpy(n,-ss,soft_A+j,soft_m,c,1);
			}
		}
	}
	if(TimeOptData)
	{
		TimeOptSetC(Nvab,lower,upper,A,c,initial);
		lower=TimeOptData->L;
		upper=TimeOptData->U;
		A=TimeOptData->A;
		c=TimeOptData->c;
		if(initial)
		{
			initial=TimeOptData->initial;
		}
		if(TimeOptData->OptType==GainLossType||TimeOptData->OptType==SemiVarType)
		{
			n+=TimeOptData->tlen;
			Nvab+=TimeOptData->tlen;
		}
		else if(TimeOptData->OptType==CVarType)
		{
			n+=TimeOptData->tlen+1;
			Nvab+=TimeOptData->tlen+1;
			m+=((MVCvar*)TimeOptData)->cvarConstraintdata;
		}
		m+=TimeOptData->tlen;
		x=TimeOptData->x;
	}
	if(checkback==0)back = GOpt(Nvab,m,x,A,lower,upper,c);
	else back=checkback;
	if(TimeOptData)
	{
		size_t t;double tx;
		if(false&&TimeOptData->OptType==SemiVarType)
		{
			AddLog("Time variables for Semi Variance\n");
			AddLog("%4s %20s %20s\n"," ","Neg Variable","Time transformed w");
			for(t=0;t<TimeOptData->tlen;++t)
			{
				tx=BITA_ddot(Nvab-TimeOptData->tlen,TimeOptData->DATA+t,TimeOptData->tlen,x,1)-ddotvec(Nvab-TimeOptData->tlen,TimeOptData->meanDATA,x)-((TimeOptData->benchmark)?BITA_ddot(Nvab-TimeOptData->tlen,TimeOptData->DATA+t,TimeOptData->tlen,TimeOptData->benchmark,1)-ddotvec(Nvab-TimeOptData->tlen,TimeOptData->meanDATA,TimeOptData->benchmark):0);
				tx+=BITA_ddot(n-Nvab,TimeOptData->DATA+t+TimeOptData->tlen*(Nvab-TimeOptData->tlen),TimeOptData->tlen,x+Nvab,1)-ddotvec(n-Nvab,TimeOptData->meanDATA+(Nvab-TimeOptData->tlen),x+Nvab)-((TimeOptData->benchmark)?BITA_ddot(n-Nvab,TimeOptData->DATA+t+(Nvab-TimeOptData->tlen)*TimeOptData->tlen,TimeOptData->tlen,TimeOptData->benchmark+(Nvab-TimeOptData->tlen),1)-ddotvec(n-Nvab,TimeOptData->meanDATA+(Nvab-TimeOptData->tlen),TimeOptData->benchmark+(Nvab-TimeOptData->tlen)):0);
				AddLog("%4d %20.8e %20.8e\n",t+1,x[Nvab-TimeOptData->tlen+t],tx);
			}
		}
		if(TimeOptData->OptType==GainLossType|| TimeOptData->OptType==SemiVarType)
		{
			Nvab-=TimeOptData->tlen;
			n-=TimeOptData->tlen;
			dcopyvec(n-Nvab,x+Nvab+TimeOptData->tlen,x+Nvab);
		}
		else if(TimeOptData->OptType==CVarType)
		{
			Nvab-=TimeOptData->tlen+1;
			this->AddLog("VAR variable value is %20.8e\n",x[Nvab]);
			n-=TimeOptData->tlen+1;
			dcopyvec(n-Nvab,x+Nvab+TimeOptData->tlen+1,x+Nvab);
			m-=((MVCvar*)TimeOptData)->cvarConstraintdata;
		}
		TimeOptData->usethis=false;
		m-=TimeOptData->tlen;
		lower=TimeOptData->Lst;
		upper=TimeOptData->Ust;
		A=TimeOptData->Ast;
		c=TimeOptData->cst;
		if(initial)
			initial=TimeOptData->initialst;
		dcopyvec(n,x,&(*vx)[0]);
		x=&(*vx)[0];
		TimeOptData->opt=false;
		Reorder_gen(n,optimiseorder+n,TimeOptData->DATA,TimeOptData->tlen);
		Reorder_gen(n,optimiseorder+n,TimeOptData->meanDATA,1);
	}

	if(soft_m)
	{
		size_t j;
		double ss;
		for(j=0;j<soft_m;++j)
		{
			ss=soft_b[j]*soft_l[j];
			if(ss)
			{
				BITA_daxpy(n,ss,soft_A+j,soft_m,c,1);
			}
		}
	}
	if(back == -1) return (char*)"Licence is not valid";
//________________________________________________________________________________________
	if(fixed_bounds)
	{
		violation_test(this,"After optimising",Nvab);
		dsubvec(n,c,&(*fixed_implied)[n],c);
		for(i = Nvab-ncomp;i < n-ncomp;++i)
		{
			daxpyvec(m,x[i+ncomp],A + (i +ncomp)* m,lower + Nvab);
			daxpyvec(m,x[i+ncomp],A + (i +ncomp)* m,upper + Nvab);
		}
		bound_reorganise(0,n,Nvab,m,lower);
		bound_reorganise(0,n,Nvab,m,upper);
		if(ncomp)
		{
			Reorder_gen(n,&(*vcinverse)[0],&(*dropbad)[0],1);
			Reorder_gen(n,&(*vcinverse)[0],upper,1);
			Reorder_gen(n,&(*vcinverse)[0],initial,1);
			Reorder_gen(n,&(*vcinverse)[0],lower,1);
			Reorder_gen(n,&(*vcinverse)[0],c,1);
			Reorder_gen(n,&(*vcinverse)[0],shortalphacost,1);
			Reorder_gen(n,&(*vcinverse)[0],&(*effectiveorder)[0],1);
			Reorder_gen(n,&(*vcinverse)[0],A,m);
			Reorder_gen(n,&(*vcinverse)[0],soft_A,soft_m);
			Reorder_gen(n,&(*vcinverse)[0],absoluteA,mabs);
			Reorder_gen(n,&(*vcinverse)[0],x,1);
			for(i=0;i<ncomp;++i)
			{
				Reorder_gen(n-ncomp,inverse,Composites+i*(n-ncomp),1);//I don't think we need this
				Reorder_gen(n-ncomp,inverse,&(*yc)[i*(n-ncomp)],1);
			}
		}
		Reorder_gen(n-ncomp,inverse,&(*dropbad)[0],1);
		Reorder_gen(n-ncomp,inverse,upper,1);
		Reorder_gen(n-ncomp,inverse,initial,1);
		Reorder_gen(n-ncomp,inverse,lower,1);
		Reorder_gen(n-ncomp,inverse,c,1);
		Reorder_gen(n-ncomp,inverse,shortalphacost,1);
		Reorder_gen(n-ncomp,inverse,&(*effectiveorder)[0],1);
		Reorder_gen(n-ncomp,inverse,A,m);
		Reorder_gen(n-ncomp,inverse,soft_A,soft_m);
		Reorder_gen(n-ncomp,inverse,absoluteA,mabs);
		Reorder_gen(n-ncomp,inverse,x,1);
		TransformH(0,1);
		violation_test(this,"After Optimising and after fixedx transformation");
	}
	optimiseorder=0;

		//________________________________________________________________________________________
	if(back <= 1 && (nvab!=n || nvabt!=n || tradebuy!=-1 || tradesell!=-1 || longbasket!=-1 || shortbasket!=-1))
	{
		OptParamRound OpSend;OpSend.back=back;OpSend.TimeOptData=TimeOptData;
		OpSend.m=m;
		OpSend.n=n;
		OpSend.lower=lower;
		OpSend.upper=upper;
		OpSend.x=x;
		OpSend.grad=0;//This is set in Droptwo
		OpSend.OptFunc=BaskInnerOpt;
		OpSend.UtilityFunc=BaskUtility;
		OpSend.GradFunc=BaskGrad;
		OpSend.mabs=mabs;
		OpSend.lp=lp;
		OpSend.longbasket=longbasket;
		OpSend.shortbasket=shortbasket;
		OpSend.tradebuy=tradebuy;
		OpSend.tradesell=tradesell;
		OpSend.initial=initial;
		OpSend.equalbounds=equalbounds;
		OpSend.dropfac=dropfac;
		OpSend.MoreInfo=this;
		OpSend.c=c;
		OpSend.logprint=this->logprint;
		OpSend.basket=n;
		OpSend.trades=n;
		std::valarray<double>interim(n),first(n);
		double u1,u;
		dcopyvec(n,x,&first[0]);
		short back1=back=Droptwo(&OpSend,nvab,nvabt);
		dcopyvec(n,x,&interim[0]);
		u1=utility_base(n,x,c,H);
		AddLog("Utility 1 %20.8e\n",u1);
		if(back1<2&&(nvab<n&&(long)nvab>=0)&&(nvabt<n&&(long)nvabt>=0))
		{
			dcopyvec(n,&first[0],x);back=0;
			if(Droptwo(&OpSend,nvab,-1)<=1)
			{
				back=Droptwo(&OpSend,nvab,nvabt);
				u=utility_base(n,x,c,H);
				AddLog("Utility 2 %20.8e\n",u);
				if(u>u1||back>1)
				{
					dcopyvec(n,&interim[0],x);
					back=back1;
				}
				else
				{
					back1=back;//David Jessop's quick solution is best
					u1=u;
					dcopyvec(n,x,&interim[0]);
				}
			}
			dcopyvec(n,&first[0],x);back=0;
			if(Droptwo(&OpSend,-1,nvabt)<=1)
			{
				back=Droptwo(&OpSend,nvab,nvabt);
				u=utility_base(n,x,c,H);
				AddLog("Utility 3 %20.8e\n",u);
				if(u>u1||back>1)
				{
					dcopyvec(n,&interim[0],x);
					back=back1;
				}
				else u1=u;
			}
			else
			{
				dcopyvec(n,&interim[0],x);
				back=back1;
			}
		}
		AddLog("Utility Final %20.8e\n",u1);
		OpSend.logprint=0;
	}
	return Return_Messages[back];
}
char* Optimise::AccumOpt(dimen nvab,dimen ntrades)
{
	return Return_Message(Accumulation5_10_40(this,nvab,ntrades,1));
}
char* Optimise::AccumOpt(dimen nvab)
{
	return Return_Message(Accumulation5_10_40(this,nvab,this->n,1));
}
char* Optimise::OptSetup(dimen nvab)
{
	double testcon;
	int checkback=0;
	if(ImportantCheck())
		return Return_Messages[back];
	if(ModHessian)
	{
		extraH->resize(n*(n+1)/2);
		H_from_higher_terms=&(*extraH)[0];
	}
	fixed_bounds=0;
	fixed_zero=0;
	if(nvab==(dimen)-1 || nvab > n)
		nvab=n;
	size_t	i,Nvab=n;
	long sofar;

	if(fileset)
	{
		lm_set_files(0,stdout);
		lm_set_files(1,stderr);
		fileset = 0;
	}
//________________________________________________________________________________________
	CompSetup();
//________________________________________________________________________________________
	for(i = 0;i < n-ncomp;++i)
	{
		if(fabs(lower[i] - upper[i]) < equalbounds)	
		{
			fixed_bounds++;
			if(fabs(lower[i]-(drop_to_this?drop_to_this[i]:0)) < equalbounds)
				fixed_zero++;
		}
	}

//________________________________________________________________________________________

	Nvab -= fixed_bounds;
	if(Nvab==0)
	{
		AddLog("Stop an attempt to optimise with no variables\n");
		lower[n-ncomp-1]-=lm_rooteps*.5;
		upper[n-ncomp-1]+=lm_rooteps*.5;
		Nvab+=1;
		fixed_bounds-=1;
	}

	if(dropbad->size()!=n)
	{
		dropbad->resize(n);
		(*dropbad) = 0;
	}

	if(vx->size()!=n){vx->resize(n);*vx=0;}
	x = &(*vx)[0];

	if(vx->size()<n)
	{
		AddLog("n=%ld. Could not allocate %ld bytes\n",n,(n)*sizeof(double));
		fflush(stdout);
		throw MemProb("Memory problem for x in Optimise::Opt()",(n)*sizeof(double),n);
	}
	else
	{
		if((*vx)[0]==0)
			*vx = 1.0/n;	//This is our initial guess
		if(initial && ModDeriv &&!ModHessian)
		{
			if(TimeOptData) *vx=1.0/n;
			else			dcopyvec(n,initial,x);
		}
		else if(!ModHessian&&ddotvec(n,x,x)<10*lm_eps)
			*vx = 1.0/n;    //This is our initial guess
		else if(ModHessian&&firstw)
		{
			if(ddotvec(n,firstw,firstw)>1e-5)//This is our initial guess
				dcopyvec(n,firstw,x);
			else
				*vx = 1.0/n;    
		}
	}
	for(i=0;i<n;++i)
	{
		x[i]=dmax(x[i],lower[i]);
		x[i]=dmin(x[i],upper[i]);
	}



//________________________________________________________________________________________
	vneworder->resize(n-ncomp);
	effectiveorder->resize(2*n);
	for(i=0;i<n;++i){(*effectiveorder)[i]=i;}
	neworder = &(*vneworder)[0];
	vinverse->resize(n-ncomp);
	inverse = &(*vinverse)[0];
	vcomporder->resize(n);
	vcinverse->resize(n);
	for(i=0;i<n-ncomp;++i) {inverse[i]=neworder[i]=i;}

	if(fixed_bounds)
	{
		sofar = n-1-ncomp;
		for(i = 0;sofar>=(long)i;++i)
		{
			while(sofar>=0&&fabs(lower[neworder[sofar]] - upper[neworder[sofar]]) < equalbounds){sofar--;}
			if(sofar > (long)i && fabs(lower[neworder[i]] - upper[neworder[i]]) < equalbounds)
			{
				std::swap(neworder[i],neworder[sofar]);
			}
		}
		for(i=0;i<n-ncomp;++i) {inverse[neworder[i]]=i;}
		Reorder_gen(n-ncomp,neworder,upper,1);
		Reorder_gen(n-ncomp,neworder,initial,1);
		Reorder_gen(n-ncomp,neworder,&(*effectiveorder)[0],1);
		Reorder_gen(n-ncomp,neworder,lower,1);
		Reorder_gen(n-ncomp,neworder,c,1);
		Reorder_gen(n-ncomp,neworder,x,1);
		Reorder_gen(n-ncomp,neworder,shortalphacost,1);
		Reorder_gen(n-ncomp,neworder,A,m);
		Reorder_gen(n-ncomp,neworder,soft_A,soft_m);
		Reorder_gen(n-ncomp,neworder,absoluteA,mabs);
		TransformH();
		Reorder_gen(n-ncomp,neworder,&(*dropbad)[0],1);
		//order is moving, fixed, comp; moving and comp can change

		if(ncomp)
		{
			for(i=0;i<ncomp;++i)
			{
				Reorder_gen(n-ncomp,neworder,Composites+i*(n-ncomp),1);//I don't think we need this
				Reorder_gen(n-ncomp,neworder,&(*yc)[i*(n-ncomp)],1);
			}
			size_t j=(ncomp+n-Nvab)/2;
			for(i=0;i<n;++i){(*vcomporder)[i]=i;}
			for(i=0;i<j;++i)
			{
				std::swap((*vcomporder)[i+Nvab-ncomp],(*vcomporder)[n-i-1]);
			}
			for(i=0;i<ncomp/2;++i)//The composite order has been reversed so we change it back
			{
				std::swap((*vcomporder)[i+Nvab-ncomp],(*vcomporder)[Nvab-i-1]);
			}
/*			for(i=0;i<(n-Nvab)/2;++i)//The fixed order has been reversed too so we change it back
			{
				std::swap((*vcomporder)[i+Nvab],(*vcomporder)[n-i-1]);
			}*/
			for(i=0;i<n;++i){(*vcinverse)[(*vcomporder)[i]]=i;}
			Reorder_gen(n,&(*vcomporder)[0],&(*dropbad)[0],1);
			Reorder_gen(n,&(*vcomporder)[0],&(*effectiveorder)[0],1);
			Reorder_gen(n,&(*vcomporder)[0],upper,1);
			Reorder_gen(n,&(*vcomporder)[0],initial,1);
			Reorder_gen(n,&(*vcomporder)[0],lower,1);
			Reorder_gen(n,&(*vcomporder)[0],c,1);
			Reorder_gen(n,&(*vcomporder)[0],shortalphacost,1);
			Reorder_gen(n,&(*vcomporder)[0],A,m);// moving, comp, fixed
			Reorder_gen(n,&(*vcomporder)[0],soft_A,soft_m);// moving, comp, fixed
			Reorder_gen(n,&(*vcomporder)[0],absoluteA,mabs);
		}

		dcopyvec(fixed_bounds,lower+Nvab,x+Nvab);
		for(i=0;i<m;++i)//We have to check that fixed stocks don't violate linear constraints
		{
			if(BITA_ddot(Nvab,A+i,m,A+i,m) <lm_eps)//This is zero if only the fixed stocks are in the constraint
			{
				testcon=BITA_ddot(n-Nvab,A+i+Nvab*m,m,x+Nvab,1);
				if(testcon<lower[n+i] || testcon>upper[n+i])
					checkback=6;
			}
		}
		bound_reorganise(1,n,Nvab,m,lower);
		bound_reorganise(1,n,Nvab,m,upper);
		for(i = Nvab-ncomp;i < n-ncomp;++i)
		{
			daxpyvec(m,-x[i+ncomp],A + i * m,lower + Nvab);
			daxpyvec(m,-x[i+ncomp],A + i * m,upper + Nvab);
		}
//________________________________________________________________________________________
		fixed_implied->resize(2*n);
		dzerovec(Nvab,&(*fixed_implied)[0]);
		dcopyvec(fixed_bounds,x+Nvab,&(*fixed_implied)[Nvab]);
		if(ncomp)
		{
			Reorder_gen(n,&(*vcinverse)[0],&(*fixed_implied)[0],1);
		}
		qphess_base(n,1,1,1,H,&(*fixed_implied)[0],&(*fixed_implied)[n]);
		if(ncomp)
		{
			Reorder_gen(n,&(*vcomporder)[0],&(*fixed_implied)[0],1);
			Reorder_gen(n,&(*vcomporder)[0],&(*fixed_implied)[n],1);
		}
		daddvec(n,c,&(*fixed_implied)[n],c);
	}
//________________________________________________________________________________________
	optimiseorder=&(*effectiveorder)[0];
	for(i=0;i<n;++i){optimiseorder[optimiseorder[i]+n]=i;}
	if(soft_m)
	{
		size_t j;
		double ss;
		for(j=0;j<soft_m;++j)
		{
			ss=soft_b[j]*soft_l[j];
			if(ss)
			{
				BITA_daxpy(n,-ss,soft_A+j,soft_m,c,1);
			}
		}
	}
	if(TimeOptData)
	{
		TimeOptSetC(Nvab,lower,upper,A,c,initial);
		lower=TimeOptData->L;
		upper=TimeOptData->U;
		A=TimeOptData->A;
		c=TimeOptData->c;
		if(initial)
			initial=TimeOptData->initial;
		if(TimeOptData->OptType==GainLossType||TimeOptData->OptType==SemiVarType)
		{
			n+=TimeOptData->tlen;
			Nvab+=TimeOptData->tlen;
		}
		else if(TimeOptData->OptType==CVarType)
		{
			n+=TimeOptData->tlen+1;
			Nvab+=TimeOptData->tlen+1;
			m+=((MVCvar*)TimeOptData)->cvarConstraintdata;
		}
		m+=TimeOptData->tlen;
		x=TimeOptData->x;
	}
	if(checkback==0)back = GOpt(Nvab,m,x,A,lower,upper,c);
	else back=checkback;
	if(TimeOptData)
	{
		size_t t;double tx;
		if(false&&TimeOptData->OptType==SemiVarType)
		{
			AddLog("Time variables for Semi Variance\n");
			AddLog("%4s %20s %20s\n"," ","Neg Variable","Time transformed w");
			for(t=0;t<TimeOptData->tlen;++t)
			{
				tx=BITA_ddot(Nvab-TimeOptData->tlen,TimeOptData->DATA+t,TimeOptData->tlen,x,1)-ddotvec(Nvab-TimeOptData->tlen,TimeOptData->meanDATA,x)-((TimeOptData->benchmark)?BITA_ddot(Nvab-TimeOptData->tlen,TimeOptData->DATA+t,TimeOptData->tlen,TimeOptData->benchmark,1)-ddotvec(Nvab-TimeOptData->tlen,TimeOptData->meanDATA,TimeOptData->benchmark):0);
				tx+=BITA_ddot(n-Nvab,TimeOptData->DATA+t+TimeOptData->tlen*(Nvab-TimeOptData->tlen),TimeOptData->tlen,x+Nvab,1)-ddotvec(n-Nvab,TimeOptData->meanDATA+(Nvab-TimeOptData->tlen),x+Nvab)-((TimeOptData->benchmark)?BITA_ddot(n-Nvab,TimeOptData->DATA+t+(Nvab-TimeOptData->tlen)*TimeOptData->tlen,TimeOptData->tlen,TimeOptData->benchmark+(Nvab-TimeOptData->tlen),1)-ddotvec(n-Nvab,TimeOptData->meanDATA+(Nvab-TimeOptData->tlen),TimeOptData->benchmark+(Nvab-TimeOptData->tlen)):0);
				AddLog("%4d %20.8e %20.8e\n",t+1,x[Nvab-TimeOptData->tlen+t],tx);
			}
		}
		if(TimeOptData->OptType==GainLossType||TimeOptData->OptType==SemiVarType)
		{
			Nvab-=TimeOptData->tlen;
			n-=TimeOptData->tlen;
			dcopyvec(n-Nvab,x+Nvab+TimeOptData->tlen,x+Nvab);
		}
		else if(TimeOptData->OptType==CVarType)
		{
			Nvab-=TimeOptData->tlen+1;
			this->AddLog("VAR variable value is %20.8e\n",x[Nvab]);
			n-=TimeOptData->tlen+1;
			dcopyvec(n-Nvab,x+Nvab+TimeOptData->tlen+1,x+Nvab);
			m-=((MVCvar*)TimeOptData)->cvarConstraintdata;
		}
		TimeOptData->usethis=false;
		m-=TimeOptData->tlen;
		lower=TimeOptData->Lst;
		upper=TimeOptData->Ust;
		A=TimeOptData->Ast;
		c=TimeOptData->cst;
		if(initial)
			initial=TimeOptData->initialst;
		dcopyvec(n,x,&(*vx)[0]);
		x=&(*vx)[0];
		TimeOptData->opt=false;
		Reorder_gen(n,optimiseorder+n,TimeOptData->DATA,TimeOptData->tlen);
		Reorder_gen(n,optimiseorder+n,TimeOptData->meanDATA,1);
	}
	if(soft_m)
	{
		size_t j;
		double ss;
		for(j=0;j<soft_m;++j)
		{
			ss=soft_b[j]*soft_l[j];
			if(ss)
			{
				BITA_daxpy(n,ss,soft_A+j,soft_m,c,1);
			}
		}
	}
	
	if(back == -1) return (char*)"Licence is not valid";
//________________________________________________________________________________________
	if(fixed_bounds)
	{
		dsubvec(n,c,&(*fixed_implied)[n],c);
		for(i = Nvab-ncomp;i < n-ncomp;++i)
		{
			daxpyvec(m,x[i+ncomp],A + i * m,lower + Nvab);
			daxpyvec(m,x[i+ncomp],A + i * m,upper + Nvab);
		}
		bound_reorganise(0,n,Nvab,m,lower);
		bound_reorganise(0,n,Nvab,m,upper);
		if(ncomp)
		{
			Reorder_gen(n,&(*vcinverse)[0],&(*dropbad)[0],1);
			Reorder_gen(n,&(*vcinverse)[0],upper,1);
			Reorder_gen(n,&(*vcinverse)[0],initial,1);
			Reorder_gen(n,&(*vcinverse)[0],lower,1);
			Reorder_gen(n,&(*vcinverse)[0],c,1);
			Reorder_gen(n,&(*vcinverse)[0],shortalphacost,1);
			Reorder_gen(n,&(*vcinverse)[0],&(*effectiveorder)[0],1);
			Reorder_gen(n,&(*vcinverse)[0],A,m);
			Reorder_gen(n,&(*vcinverse)[0],soft_A,soft_m);
			Reorder_gen(n,&(*vcinverse)[0],absoluteA,mabs);
			Reorder_gen(n,&(*vcinverse)[0],x,1);
			for(i=0;i<ncomp;++i)
			{
				Reorder_gen(n-ncomp,inverse,Composites+i*(n-ncomp),1);//I don't think we need this
				Reorder_gen(n-ncomp,inverse,&(*yc)[i*(n-ncomp)],1);
			}
		}
		Reorder_gen(n-ncomp,inverse,&(*dropbad)[0],1);
		Reorder_gen(n-ncomp,inverse,upper,1);
		Reorder_gen(n-ncomp,inverse,initial,1);
		Reorder_gen(n-ncomp,inverse,lower,1);
		Reorder_gen(n-ncomp,inverse,c,1);
		Reorder_gen(n-ncomp,inverse,shortalphacost,1);
		Reorder_gen(n-ncomp,inverse,&(*effectiveorder)[0],1);
		Reorder_gen(n-ncomp,inverse,A,m);
		Reorder_gen(n-ncomp,inverse,soft_A,soft_m);
		Reorder_gen(n-ncomp,inverse,absoluteA,mabs);
		Reorder_gen(n-ncomp,inverse,x,1);
		TransformH(0,1);
	}
	optimiseorder=0;
//________________________________________________________________________________________
	non_zero=DropCheck();//printf("%d are free\n",non_zero);
	if(threshvector)
		non_threshed=ThreshCheck(threshvector);
	else
		non_threshed=ThreshCheck(threshscalar);
	size_t ndrop=Nvab,ndropbest=non_zero,nthreshbest=non_threshed;
	unsigned char droppingOK=1;
	if(back <= 1)
	{
		std::valarray<double> tryw(n);
		double keepU=lm_max,keepnon_t=n;
		std::valarray<double> goodweights(n);
		dcopyvec(n,x,&goodweights[0]);

		if(ndrop>1&&(!non_threshed&&(nvab < non_zero)) && (nvab > ncomp))
		{
			if(nvab>=fixed_bounds-fixed_zero)
			{
				back = Drop(Nvab,nvab);
			}
			else
			{
				back=6;
				AddLog("Cannot drop anymore\n");
			}
			if(back<=1)
			{
				non_zero=DropCheck();
				AddLog("%d are free\n",non_zero);
				if(threshvector)
					non_threshed=ThreshCheck(threshvector);
				else
					non_threshed=ThreshCheck(threshscalar);
				keepnon_t=non_threshed;
				dcopyvec(n,x,&goodweights[0]);
				dcopyvec(n,x,&tryw[0]);
				ndrop=non_zero;
//				size_t oldchoice=hess_choice;
//				hess_choice=1;
				keepU=utility_base(n,x,c,H)+this->shortcost(n,x);
//				hess_choice=oldchoice;
			}
			else
				dcopyvec(n,&goodweights[0],x);
		}

		non_zero=ndropbest,non_threshed=nthreshbest;

		while(ndrop>1&&(non_threshed||(nvab < non_zero)) && (nvab > ncomp))
		{
			if(droppingOK)
			{
				if(nvab<non_zero)
					ndrop=(size_t)dmax((double)nvab,dmax(ndropbest*(1.0-dropfac) + dropfac*nvab,(double)fixed_bounds-(double)fixed_zero));
				else
					ndrop-=min(max(1,(size_t)(ndrop*threshfac)),min(ndropbest,nthreshbest));
			}
			else
				ndrop--;
			if(ndrop>=fixed_bounds-fixed_zero)
			{
				back = Drop(Nvab,ndrop);
			}
			else
			{
				back=6;
				AddLog("Cannot drop anymore\n");
			}
			if(back == 9) back = 6;
			non_zero=DropCheck();
			AddLog("%d are free\n",non_zero);
			if(back <= 2)
			{
				dcopyvec(n,x,&goodweights[0]);
				AddLog("drop %d \n",non_zero);
				if(threshvector)
					non_threshed=ThreshCheck(threshvector);
				else
					non_threshed=ThreshCheck(threshscalar);
				//printf("%d disobey threshold\n",non_threshed);
				ndropbest = non_zero;
				nthreshbest = non_threshed;
				if(keepnon_t==0 && utility_base(n,x,c,H)+this->shortcost(n,x)>keepU)
				{
					dcopyvec(n,&tryw[0],x);
					AddLog("Copied fast result\n");
					break;
				}
			}
			else
			{
				dcopyvec(n,&goodweights[0],x);
				AddLog("Problem at %d reset back to %d\n",ndrop,ndropbest);
				droppingOK=0;non_threshed=nthreshbest;ndrop=non_zero=ndropbest;
				ndrop=min(n,ndrop+1);
				if(cannot_drop_any_more)
					break;
			}
		}
	}
	return Return_Messages[back];
}
size_t	Optimise::DropCheck()
{
	size_t i,non;
	if(!drop_to_this)
	{
		for(i=0,non=0;i<n;++i)	{if(fabs(x[i]) > equalbounds){non++;}}
	}
	else
	{
		for(i=0,non=0;i<n;++i)	{if(fabs(x[i]-drop_to_this[i]) > equalbounds){non++;}}
	}
	return non;
}
size_t	Optimise::DropCheckB()
{
	size_t i,non;
	for(i=0,non=0;i<n;++i)	{if(fabs(x[i]) > equalbounds){non++;}}
	return non;
}
size_t	Optimise::DropCheckT()
{
	size_t i,non;
	for(i=0,non=0;i<n;++i)	{if(fabs(x[i]-drop_to_this[i]) > equalbounds){non++;}}
	return non;
}
size_t Optimise::ThreshCheck(double thresh)
{
	size_t i,non;
	if(!drop_to_this)
	{
		for(i=0,non=0;i<n;++i) {if(fabs(x[i]) > lm_eps && fabs(x[i]) < thresh){non++;}}
	}
	else
	{
		for(i=0,non=0;i<n;++i) {if(fabs(x[i]-drop_to_this[i]) > lm_eps && fabs(x[i]-drop_to_this[i]) < thresh){non++;}}
	}
	return non;
}
size_t Optimise::ThreshCheck(vector thresh)
{
	size_t i,non;
	if(!drop_to_this)
	{
		for(i=0,non=0;i<n;++i) {if(fabs(x[i]) > lm_eps && fabs(x[i]) < thresh[i]){non++;}}
	}
	else
	{
		for(i=0,non=0;i<n;++i) {if(fabs(x[i]-drop_to_this[i]) > lm_eps && fabs(x[i]-drop_to_this[i]) < thresh[i]){non++;}}
	}
	return non;
}
size_t Optimise::ThreshCheckT(double thresh)
{
	size_t i,non;
	for(i=0,non=0;i<n;++i) {if(fabs(x[i]-drop_to_this[i]) > lm_eps && fabs(x[i]-drop_to_this[i]) < thresh){non++;}}
	return non;
}
size_t Optimise::ThreshCheckT(vector thresh)
{
	size_t i,non;
	for(i=0,non=0;i<n;++i) {if(fabs(x[i]-drop_to_this[i]) > lm_eps && fabs(x[i]-drop_to_this[i]) < thresh[i]){non++;}}
	return non;
}
size_t Optimise::ThreshCheckB(vector thresh)
{
	size_t i,non;
	for(i=0,non=0;i<n;++i) {if(fabs(x[i]) > lm_eps && fabs(x[i]) < thresh[i]){non++;}}
	return non;
}
size_t Optimise::ThreshCheckB(double thresh)
{
	size_t i,non;
	for(i=0,non=0;i<n;++i) {if(fabs(x[i]) > lm_eps && fabs(x[i]) < thresh){non++;}}
	return non;
}
short Optimise::Drop(dimen Nvab,dimen nvab,dimen nvabt,dimen NZB,dimen NZT,dimen& nvabmin,
					 bool switcher)
{
//	This applies the re-ordering, optimises then undoes the re-ordering
	short back;
	double lostcost=0;
	cannot_drop_any_more=0;
	size_t i;
	fixed_implied->resize(2*n);
	Reorder_gen(n-ncomp,neworder,mask,1);
	Reorder_gen(n-ncomp,neworder,upper,1);
	Reorder_gen(n-ncomp,neworder,lower,1);
	Reorder_gen(n-ncomp,neworder,x,1);
	Reorder_gen(n-ncomp,neworder,c,1);
	Reorder_gen(n-ncomp,neworder,shortalphacost,1);
	Reorder_gen(n-ncomp,neworder,&(*effectiveorder)[0],1);
	Reorder_gen(n-ncomp,neworder,drop_to_this,1);
	Reorder_gen(n-ncomp,neworder,initial,1);
	Reorder_gen(n-ncomp,neworder,A,m);
	Reorder_gen(n-ncomp,neworder,soft_A,soft_m);
	Reorder_gen(n-ncomp,neworder,absoluteA,mabs);
	TransformH();
	Reorder_gen(n-ncomp,neworder,&(*dropbad)[0],1);
	nvab -= fixed_bounds-fixed_zero;
	nvabt -= fixed_bounds-fixed_zerot;
	vdroporder->resize(Nvab-ncomp);
	vdinverse->resize(Nvab-ncomp);

	std::valarray<double>dropto(n);
	dropto=0;
	drop_to_this_both=&dropto[0];


	size_t nvabminh=min(nvab,nvabt);
	size_t both,zbasket,ztrade,free_to_opt;
	for(i=0,both=0,ztrade=0,zbasket=0;i<Nvab-ncomp;++i)
	{
		if(fabs(x[i]) < 1e-12 && fabs(x[i]-drop_to_this[i]) < 1e-12) {both++;}
		if(fabs(x[i]) < 1e-12) {zbasket++;}
		if(fabs(x[i]-drop_to_this[i])  < 1e-12) {ztrade++;}
	}
	free_to_opt=Nvab-ncomp-ztrade-zbasket+both;
	AddLog("both %d, free %d\n",both,free_to_opt);


	if(switcher)
	{
		dcopyvec(Nvab-ncomp,drop_to_this,drop_to_this_both);
		AddLog("Trades first\n");
	}
	else
	{
		dzerovec(Nvab-ncomp,drop_to_this_both);
		AddLog("Basket first\n");
	}
/*	size_t db,dt;
	for(i=0,db=0,dt=0;i<Nvab-ncomp;++i)
	{
		if(fabs(x[i]) < fabs(x[i]-drop_to_this[i]))
		{
			drop_to_this_both[i]=0;db++;
		}
		else
		{
			drop_to_this_both[i]=drop_to_this[i];dt++;
		}
	}

	printf("db %d\tdt %d\n",db,dt);*/


	dsubvec(Nvab-ncomp,x,drop_to_this_both,x);
	getorder(Nvab-ncomp,x,&(*vdroporder)[0],&(*dropbad)[0]);
	daddvec(Nvab-ncomp,x,drop_to_this_both,x);

	for(i=0;i<Nvab-ncomp;++i){(*vdinverse)[(*vdroporder)[i]] = i;}
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],mask,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],upper,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],lower,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],x,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],c,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],shortalphacost,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],&(*effectiveorder)[0],1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],drop_to_this_both,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],drop_to_this,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],initial,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],A,m);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],soft_A,soft_m);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],absoluteA,mabs);
	TransformH(Nvab);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],&(*dropbad)[0],1);


	if(nvab>=NZB)
	{
//		dzerovec(Nvab-ncomp,drop_to_this_both);
		AddLog("Basket OK\n");
		dcopyvec(nvabminh,drop_to_this,drop_to_this_both);
		AddLog("Trades second\n");
		nvabminh=nvabt;
		if(nvabminh>=nvabmin)
			nvabminh=nvabmin-(NZT-nvabt);
	}
	else if(nvabt>=NZT)
	{
//		dcopyvec(Nvab-ncomp,drop_to_this,drop_to_this_both);
		AddLog("Trades OK\n");
		dzerovec(nvabminh,drop_to_this_both);
		AddLog("Basket second\n");
		nvabminh=nvab;
		if(nvabminh>=nvabmin)
			nvabminh=nvabmin-(NZB-nvab);
	}

	if(nvab>=NZB || nvabt>=NZT)
	{
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],mask,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],upper,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],lower,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],x,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],c,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],shortalphacost,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],&(*effectiveorder)[0],1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],drop_to_this_both,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],drop_to_this,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],initial,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],A,m);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],soft_A,soft_m);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],absoluteA,mabs);
		TransformH(Nvab,1);
		Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],&(*dropbad)[0],1);

		dsubvec(Nvab-ncomp,x,drop_to_this_both,x);
		getorder(Nvab-ncomp,x,&(*vdroporder)[0],&(*dropbad)[0]);
		daddvec(Nvab-ncomp,x,drop_to_this_both,x);

		for(i=0;i<Nvab-ncomp;++i){(*vdinverse)[(*vdroporder)[i]] = i;}
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],mask,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],upper,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],lower,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],x,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],c,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],shortalphacost,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],&(*effectiveorder)[0],1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],drop_to_this_both,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],drop_to_this,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],initial,1);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],A,m);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],soft_A,soft_m);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],absoluteA,mabs);
		TransformH(Nvab);
		Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],&(*dropbad)[0],1);
	}

	nvabmin=min(nvabmin-1,nvabminh);
	AddLog("nvabmin %d\n",nvabmin);
	dcopyvec(Nvab-nvabmin,drop_to_this_both+nvabmin,x+nvabmin);
	if(take_out_costs)
	{
		std::valarray<double>ww(n),ii(n);
		ww=0;
		ii=0;
		dcopyvec(Nvab-nvab,x+nvab,&ww[nvab]);
		dcopyvec(Nvab-nvab,initial+nvab,&ii[nvab]);
		linearcostpasser *info=(class linearcostpasser*)UtilObjectInfo;
		info->initial=&ii[0];
		lostcost=buysell_cost(n,&ww[0],info);
		info->initial=initial;
	}
	if(ncomp)
	{
		for(i=0;i<ncomp;++i)
		{
			Reorder_gen(n-ncomp,neworder,Composites+i*(n-ncomp),1);//I don't think we need this
			Reorder_gen(n-ncomp,neworder,&(*yc)[i*(n-ncomp)],1);
			Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],Composites+i*(n-ncomp),1);//I don't think we need this
			Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],&(*yc)[i*(n-ncomp)],1);
		}
		size_t j=(ncomp+n-nvabmin)/2;
		for(i=0;i<n;++i){(*vcomporder)[i]=i;}
		for(i=0;i<j;++i)
		{
			std::swap((*vcomporder)[i+nvabmin-ncomp],(*vcomporder)[n-i-1]);
		}
		for(i=0;i<ncomp/2;++i)//The composite order has been reversed so we change it back
		{
			std::swap((*vcomporder)[i+nvabmin-ncomp],(*vcomporder)[nvabmin-i-1]);
		}
/*		for(i=0;i<(n-nvabmin)/2;++i)//The fixed order has been reversed too so we change it back
		{
			std::swap((*vcomporder)[i+nvabmin],(*vcomporder)[n-i-1]);
		}*/
		for(i=0;i<n;++i){(*vcinverse)[(*vcomporder)[i]]=i;}
		Reorder_gen(n,&(*vcomporder)[0],&(*dropbad)[0],1);
		Reorder_gen(n,&(*vcomporder)[0],mask,1);
		Reorder_gen(n,&(*vcomporder)[0],upper,1);
		Reorder_gen(n,&(*vcomporder)[0],lower,1);
		Reorder_gen(n,&(*vcomporder)[0],x,1);
		Reorder_gen(n,&(*vcomporder)[0],c,1);
		Reorder_gen(n,&(*vcomporder)[0],shortalphacost,1);
		Reorder_gen(n,&(*vcomporder)[0],&(*effectiveorder)[0],1);
		Reorder_gen(n,&(*vcomporder)[0],drop_to_this_both,1);
		Reorder_gen(n,&(*vcomporder)[0],initial,1);
		Reorder_gen(n,&(*vcomporder)[0],A,m);// moving, comp, fixed
		Reorder_gen(n,&(*vcomporder)[0],soft_A,soft_m);// moving, comp, fixed
		Reorder_gen(n,&(*vcomporder)[0],absoluteA,mabs);// moving, comp, fixed
	}
	bound_reorganise(1,n,nvabmin,m,lower);
	bound_reorganise(1,n,nvabmin,m,upper);
	for(i = nvabmin-ncomp;i < n-ncomp;++i)
	{
		daxpyvec(m,-x[i+ncomp],A + i * m,lower + nvabmin);
		daxpyvec(m,-x[i+ncomp],A + i * m,upper + nvabmin);
	}
	if(take_out_costs && (hess_choice==2 || hess_choice==4 || hess_choice==5))
	{
		lower[nvabmin]-=lostcost;
		upper[nvabmin]-=lostcost;
	}
	dzerovec(nvabmin,&(*fixed_implied)[0]);
	dcopyvec(n-nvabmin,x+nvabmin,&(*fixed_implied)[nvabmin]);
	if(ncomp)
	{
		Reorder_gen(n,&(*vcinverse)[0],&(*fixed_implied)[0],1);
	}
	qphess_base(n,1,1,1,H,&(*fixed_implied)[0],&(*fixed_implied)[n]);
	if(ncomp)
	{
		Reorder_gen(n,&(*vcomporder)[0],&(*fixed_implied)[0],1);
		Reorder_gen(n,&(*vcomporder)[0],&(*fixed_implied)[n],1);
	}
	daddvec(n,c,&(*fixed_implied)[n],c);
//________________________________________________________________________________________
	optimiseorder=&(*effectiveorder)[0];
	for(i=0;i<n;++i){optimiseorder[optimiseorder[i]+n]=i;}
	if(soft_m)
	{
		size_t j;
		double ss;
		for(j=0;j<soft_m;++j)
		{
			ss=soft_b[j]*soft_l[j];
			if(ss)
			{
				BITA_daxpy(n,-ss,soft_A+j,soft_m,c,1);
			}
		}
	}
	back = GOpt(nvabmin,m,x,A,lower,upper,c);
	if(soft_m)
	{
		size_t j;
		double ss;
		for(j=0;j<soft_m;++j)
		{
			ss=soft_b[j]*soft_l[j];
			if(ss)
			{
				BITA_daxpy(n,ss,soft_A+j,soft_m,c,1);
			}
		}
	}

	if(back > 2)
	{
		if((*dropbad)[nvabmin]){cannot_drop_any_more=1;}
		(*dropbad)[nvabmin]=1;
	}
	else if(back == -1) return back;
//________________________________________________________________________________________
	dsubvec(n,c,&(*fixed_implied)[n],c);
	if(take_out_costs && (hess_choice==2 || hess_choice==4 || hess_choice==5))
	{
		lower[nvabmin]+=lostcost;
		upper[nvabmin]+=lostcost;
	}
	for(i = nvabmin-ncomp;i < n-ncomp;++i)
	{
		daxpyvec(m,x[i+ncomp],A + i * m,lower + nvabmin);
		daxpyvec(m,x[i+ncomp],A + i * m,upper + nvabmin);
	}
	bound_reorganise(0,n,nvabmin,m,lower);
	bound_reorganise(0,n,nvabmin,m,upper);
	if(ncomp)
	{
		Reorder_gen(n,&(*vcinverse)[0],&(*dropbad)[0],1);
		Reorder_gen(n,&(*vcinverse)[0],mask,1);
		Reorder_gen(n,&(*vcinverse)[0],upper,1);
		Reorder_gen(n,&(*vcinverse)[0],lower,1);
		Reorder_gen(n,&(*vcinverse)[0],drop_to_this_both,1);
		Reorder_gen(n,&(*vcinverse)[0],initial,1);
		Reorder_gen(n,&(*vcinverse)[0],x,1);
		Reorder_gen(n,&(*vcinverse)[0],c,1);
		Reorder_gen(n,&(*vcinverse)[0],shortalphacost,1);
		Reorder_gen(n,&(*vcinverse)[0],&(*effectiveorder)[0],1);
		Reorder_gen(n,&(*vcinverse)[0],A,m);
		Reorder_gen(n,&(*vcinverse)[0],soft_A,soft_m);
		Reorder_gen(n,&(*vcinverse)[0],absoluteA,mabs);
		for(i=0;i<ncomp;++i)
		{
			Reorder_gen(nvabmin-ncomp,&(*vdinverse)[0],Composites+i*(n-ncomp),1);//I don't think we need this
			Reorder_gen(nvabmin-ncomp,&(*vdinverse)[0],&(*yc)[i*(n-ncomp)],1);
			Reorder_gen(n-ncomp,inverse,Composites+i*(n-ncomp),1);//I don't think we need this
			Reorder_gen(n-ncomp,inverse,&(*yc)[i*(n-ncomp)],1);
		}
	}
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],mask,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],upper,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],lower,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],drop_to_this,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],drop_to_this_both,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],initial,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],x,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],c,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],shortalphacost,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],&(*effectiveorder)[0],1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],A,m);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],soft_A,soft_m);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],absoluteA,mabs);
	TransformH(Nvab,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],&(*dropbad)[0],1);
	Reorder_gen(n-ncomp,inverse,mask,1);
	Reorder_gen(n-ncomp,inverse,upper,1);
	Reorder_gen(n-ncomp,inverse,lower,1);
	Reorder_gen(n-ncomp,inverse,drop_to_this,1);
	Reorder_gen(n-ncomp,inverse,initial,1);
	Reorder_gen(n-ncomp,inverse,x,1);
	Reorder_gen(n-ncomp,inverse,c,1);
	Reorder_gen(n-ncomp,inverse,shortalphacost,1);
	Reorder_gen(n-ncomp,inverse,&(*effectiveorder)[0],1);
	Reorder_gen(n-ncomp,inverse,A,m);
	Reorder_gen(n-ncomp,inverse,soft_A,soft_m);
	Reorder_gen(n-ncomp,inverse,absoluteA,mabs);
	TransformH(0,1);
	Reorder_gen(n-ncomp,inverse,&(*dropbad)[0],1);
	drop_to_this_both=0;
	return back;
}
short Optimise::Drop(dimen Nvab,dimen nvab)
{
//	This applies the re-ordering, optimises then undoes the re-ordering
	short back;
	double lostcost=0;
	cannot_drop_any_more=0;
	size_t i;
	fixed_implied->resize(2*n);
	Reorder_gen(n-ncomp,neworder,mask,1);
	Reorder_gen(n-ncomp,neworder,upper,1);
	Reorder_gen(n-ncomp,neworder,lower,1);
	Reorder_gen(n-ncomp,neworder,x,1);
	Reorder_gen(n-ncomp,neworder,c,1);
	Reorder_gen(n-ncomp,neworder,shortalphacost,1);
	Reorder_gen(n-ncomp,neworder,&(*effectiveorder)[0],1);
	Reorder_gen(n-ncomp,neworder,drop_to_this,1);
	Reorder_gen(n-ncomp,neworder,initial,1);
	Reorder_gen(n-ncomp,neworder,A,m);
	Reorder_gen(n-ncomp,neworder,soft_A,soft_m);
	Reorder_gen(n-ncomp,neworder,absoluteA,mabs);
	TransformH();
	Reorder_gen(n-ncomp,neworder,&(*dropbad)[0],1);
	nvab -= fixed_bounds-fixed_zero;
	vdroporder->resize(Nvab-ncomp);
	vdinverse->resize(Nvab-ncomp);
	if(drop_to_this)
	{
		dsubvec(Nvab-ncomp,x,drop_to_this,x);
		getorder(Nvab-ncomp,x,&(*vdroporder)[0],&(*dropbad)[0]);
		daddvec(Nvab-ncomp,x,drop_to_this,x);
	}
	else
		getorder(Nvab-ncomp,x,&(*vdroporder)[0],&(*dropbad)[0]);
	for(i=0;i<Nvab-ncomp;++i){(*vdinverse)[(*vdroporder)[i]] = i;}
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],mask,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],upper,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],lower,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],x,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],c,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],shortalphacost,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],&(*effectiveorder)[0],1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],drop_to_this,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],initial,1);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],A,m);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],soft_A,soft_m);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],absoluteA,mabs);
	TransformH(Nvab);
	Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],&(*dropbad)[0],1);
	if(!drop_to_this)
		dzerovec(Nvab-nvab,x+nvab);
	else
		dcopyvec(Nvab-nvab,drop_to_this+nvab,x+nvab);
	if(take_out_costs)
	{
		std::valarray<double>ww(n),ii(n);
		ww=0;
		ii=0;
		dcopyvec(Nvab-nvab,x+nvab,&ww[nvab]);
		dcopyvec(Nvab-nvab,initial+nvab,&ii[nvab]);
		linearcostpasser *info=(class linearcostpasser*)UtilObjectInfo;
		info->initial=&ii[0];
		lostcost=buysell_cost(n,&ww[0],info);
		info->initial=initial;
	}
	if(ncomp)
	{
		for(i=0;i<ncomp;++i)
		{
			Reorder_gen(n-ncomp,neworder,Composites+i*(n-ncomp),1);//I don't think we need this
			Reorder_gen(n-ncomp,neworder,&(*yc)[i*(n-ncomp)],1);
			Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],Composites+i*(n-ncomp),1);//I don't think we need this
			Reorder_gen(Nvab-ncomp,&(*vdroporder)[0],&(*yc)[i*(n-ncomp)],1);
		}
		size_t j=(ncomp+n-nvab)/2;
		for(i=0;i<n;++i){(*vcomporder)[i]=i;}
		for(i=0;i<j;++i)
		{
			std::swap((*vcomporder)[i+nvab-ncomp],(*vcomporder)[n-i-1]);
		}
		for(i=0;i<ncomp/2;++i)//The composite order has been reversed so we change it back
		{
			std::swap((*vcomporder)[i+nvab-ncomp],(*vcomporder)[nvab-i-1]);
		}
/*		for(i=0;i<(n-nvab)/2;++i)//The fixed order has been reversed too so we change it back
		{
			std::swap((*vcomporder)[i+nvab],(*vcomporder)[n-i-1]);
		}*/
		for(i=0;i<n;++i){(*vcinverse)[(*vcomporder)[i]]=i;}
		Reorder_gen(n,&(*vcomporder)[0],&(*dropbad)[0],1);
		Reorder_gen(n,&(*vcomporder)[0],mask,1);
		Reorder_gen(n,&(*vcomporder)[0],upper,1);
		Reorder_gen(n,&(*vcomporder)[0],lower,1);
		Reorder_gen(n,&(*vcomporder)[0],x,1);
		Reorder_gen(n,&(*vcomporder)[0],c,1);
		Reorder_gen(n,&(*vcomporder)[0],shortalphacost,1);
		Reorder_gen(n,&(*vcomporder)[0],&(*effectiveorder)[0],1);
		Reorder_gen(n,&(*vcomporder)[0],drop_to_this,1);
		Reorder_gen(n,&(*vcomporder)[0],initial,1);
		Reorder_gen(n,&(*vcomporder)[0],A,m);// moving, comp, fixed
		Reorder_gen(n,&(*vcomporder)[0],soft_A,soft_m);// moving, comp, fixed
		Reorder_gen(n,&(*vcomporder)[0],absoluteA,mabs);// moving, comp, fixed
	}
	bound_reorganise(1,n,nvab,m,lower);
	bound_reorganise(1,n,nvab,m,upper);
	for(i = nvab-ncomp;i < n-ncomp;++i)
	{
		daxpyvec(m,-x[i+ncomp],A + i * m,lower + nvab);
		daxpyvec(m,-x[i+ncomp],A + i * m,upper + nvab);
	}
	if(take_out_costs && (hess_choice==2 || hess_choice==4 || hess_choice==5))
	{
		lower[nvab]-=lostcost;
		upper[nvab]-=lostcost;
	}
	dzerovec(nvab,&(*fixed_implied)[0]);
	dcopyvec(n-nvab,x+nvab,&(*fixed_implied)[nvab]);
	if(ncomp)
	{
		Reorder_gen(n,&(*vcinverse)[0],&(*fixed_implied)[0],1);
	}
	qphess_base(n,1,1,1,H,&(*fixed_implied)[0],&(*fixed_implied)[n]);
	if(ncomp)
	{
		Reorder_gen(n,&(*vcomporder)[0],&(*fixed_implied)[0],1);
		Reorder_gen(n,&(*vcomporder)[0],&(*fixed_implied)[n],1);
	}
	daddvec(n,c,&(*fixed_implied)[n],c);
//________________________________________________________________________________________
	optimiseorder=&(*effectiveorder)[0];
	for(i=0;i<n;++i){optimiseorder[optimiseorder[i]+n]=i;}
	if(soft_m)
	{
		size_t j;
		double ss;
		for(j=0;j<soft_m;++j)
		{
			ss=soft_b[j]*soft_l[j];
			if(ss)
			{
				BITA_daxpy(n,-ss,soft_A+j,soft_m,c,1);
			}
		}
	}
	back = GOpt(nvab,m,x,A,lower,upper,c);
	if(soft_m)
	{
		size_t j;
		double ss;
		for(j=0;j<soft_m;++j)
		{
			ss=soft_b[j]*soft_l[j];
			if(ss)
			{
				BITA_daxpy(n,ss,soft_A+j,soft_m,c,1);
			}
		}
	}
	if(back > 2)
	{
		if((*dropbad)[nvab]){cannot_drop_any_more=1;}
		(*dropbad)[nvab]=1;
	}
	else if(back == -1) return back;
//________________________________________________________________________________________
	dsubvec(n,c,&(*fixed_implied)[n],c);
	if(take_out_costs && (hess_choice==2 || hess_choice==4 || hess_choice==5))
	{
		lower[nvab]+=lostcost;
		upper[nvab]+=lostcost;
	}
	for(i = nvab-ncomp;i < n-ncomp;++i)
	{
		daxpyvec(m,x[i+ncomp],A + i * m,lower + nvab);
		daxpyvec(m,x[i+ncomp],A + i * m,upper + nvab);
	}
	bound_reorganise(0,n,nvab,m,lower);
	bound_reorganise(0,n,nvab,m,upper);
	if(ncomp)
	{
		Reorder_gen(n,&(*vcinverse)[0],&(*dropbad)[0],1);
		Reorder_gen(n,&(*vcinverse)[0],mask,1);
		Reorder_gen(n,&(*vcinverse)[0],upper,1);
		Reorder_gen(n,&(*vcinverse)[0],lower,1);
		Reorder_gen(n,&(*vcinverse)[0],drop_to_this,1);
		Reorder_gen(n,&(*vcinverse)[0],initial,1);
		Reorder_gen(n,&(*vcinverse)[0],x,1);
		Reorder_gen(n,&(*vcinverse)[0],c,1);
		Reorder_gen(n,&(*vcinverse)[0],shortalphacost,1);
		Reorder_gen(n,&(*vcinverse)[0],&(*effectiveorder)[0],1);
		Reorder_gen(n,&(*vcinverse)[0],A,m);
		Reorder_gen(n,&(*vcinverse)[0],soft_A,soft_m);
		Reorder_gen(n,&(*vcinverse)[0],absoluteA,mabs);
		for(i=0;i<ncomp;++i)
		{
			Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],Composites+i*(n-ncomp),1);//I don't think we need this
			Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],&(*yc)[i*(n-ncomp)],1);
			Reorder_gen(n-ncomp,inverse,Composites+i*(n-ncomp),1);//I don't think we need this
			Reorder_gen(n-ncomp,inverse,&(*yc)[i*(n-ncomp)],1);
		}
	}
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],mask,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],upper,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],lower,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],drop_to_this,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],initial,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],x,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],c,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],shortalphacost,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],&(*effectiveorder)[0],1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],A,m);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],soft_A,soft_m);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],absoluteA,mabs);
	TransformH(Nvab,1);
	Reorder_gen(Nvab-ncomp,&(*vdinverse)[0],&(*dropbad)[0],1);
	Reorder_gen(n-ncomp,inverse,mask,1);
	Reorder_gen(n-ncomp,inverse,upper,1);
	Reorder_gen(n-ncomp,inverse,lower,1);
	Reorder_gen(n-ncomp,inverse,drop_to_this,1);
	Reorder_gen(n-ncomp,inverse,initial,1);
	Reorder_gen(n-ncomp,inverse,x,1);
	Reorder_gen(n-ncomp,inverse,c,1);
	Reorder_gen(n-ncomp,inverse,shortalphacost,1);
	Reorder_gen(n-ncomp,inverse,&(*effectiveorder)[0],1);
	Reorder_gen(n-ncomp,inverse,A,m);
	Reorder_gen(n-ncomp,inverse,soft_A,soft_m);
	Reorder_gen(n-ncomp,inverse,absoluteA,mabs);
	TransformH(0,1);
	Reorder_gen(n-ncomp,inverse,&(*dropbad)[0],1);
	return back;
}
void	Optimise::TransformH(size_t nn,unsigned char reverse)
{
	if(!reverse)
	{
		if(nn)
			Reorder_sym(nn-ncomp,&(*vdroporder)[0],H);
		else
			Reorder_sym(n-ncomp,neworder,H);
	}
	else
	{
		if(nn)
			Reorder_sym(nn-ncomp,&(*vdinverse)[0],H);
		else
			Reorder_sym(n-ncomp,inverse,H);
	}
}
void	FOptimise::TransformH(size_t nn,unsigned char reverse)
{
#ifdef TOPPER
	dmx_transpose(n-ncomp,nfac,H+n-ncomp,H+n-ncomp);
#endif
	if(!reverse)
	{
		if(nn)
		{
			Reorder_gen(nn-ncomp,&(*vdroporder)[0],H,1);
			Reorder_gen(nn-ncomp,&(*vdroporder)[0],H+n-ncomp,nfac);
		}
		else
		{
			Reorder_gen(n-ncomp,neworder,H,1);
			Reorder_gen(n-ncomp,neworder,H+n-ncomp,nfac);
		}
	}
	else
	{
		if(nn)
		{
			Reorder_gen(nn-ncomp,&(*vdinverse)[0],H,1);
			Reorder_gen(nn-ncomp,&(*vdinverse)[0],H+n-ncomp,nfac);
		}
		else
		{
			Reorder_gen(n-ncomp,inverse,H,1);
			Reorder_gen(n-ncomp,inverse,H+n-ncomp,nfac);
		}
	}
#ifdef TOPPER
	dmx_transpose(nfac,n-ncomp,H+n-ncomp,H+n-ncomp);
#endif
}

#ifndef TOPPER
void	FOptimise::facmul(dimen nvab,double *H,vector x,vector y)
{
	vector	SV = H;
	vector	FF = SV + n-ncomp;
	long	i;
	
	if(nfac)
	{
#ifdef USE_STOREX
		vector kk=&(*storex)[0];
		for(i=0;i<nfac;++i)kk[i]=BITA_ddot(nvab,FF+i,nfac,x,1);
		dzerovec(nvab,y);
		BITA_dgemv("T",nfac,nvab,1,FF,nfac,&kk[0],1,0,y,1);//Can use OMP!!!!
#else
		dsccopy(nvab,BITA_ddot(nvab,FF,nfac,x,1),FF,nfac,y,1);
		for(i = 1;i < nfac;i++) {BITA_daxpy(nvab,BITA_ddot(nvab,FF + i,nfac,x,1),FF + i,nfac,y,1);}
#endif
	}
	else	{dzerovec(nvab,y);}
	
	for(i = 0;i < nvab;++i)	{y[i] += SV[i] * x[i];}
}
#else
void	FOptimise::facmul(dimen nvab,double *H,vector x,vector y)
{
	vector	SV = H;
	vector	FF = SV + n-ncomp;
	size_t	i;

	for(i=0;i<nvab;++i) y[i] = SV[i] * x[i];
	for(i=0;i<nfac;++i,FF+=(n-ncomp))
	{
		daxpyvec(nvab,ddotvec(nvab,FF,x),FF,y);
	}
}
#endif
real	Optimise::utility(dimen nvab,vector X,vector CC,vector Q)
{
	if(ImportantCheck()) return 0;
	if(!this->hmul)//In case it was called before an optimisation is done
		this->hmul = (pHmul)HMUL;
	if(hess_choice==1)
	{
		return	utility_base(nvab,X,CC,Q)+this->shortcost(n,x);
	}
	else if(hess_choice==2)
	{
		size_t i,j=0;
		std::valarray<double>ww(n),imp(nvab);
		for(i=0;i<nbefore;++i)
		{
			ww[i] = X[i];
			if(lab&&lab[j]==i)
				ww[i]+=X[j++ +nbefore];
		}
		dcopyvec(n-nbefore,x+nbefore,&ww[nbefore]);

//_______________________________________________________________
//|                                                              |
//|USE SECOND DERIVATIVE TERMS FOR QP IN DOUBLED SET             |
//|AS THIS WILL INCLUDE THE PENALTY THAT MAKES THE PRODUCT OF    |
//|DOUBLED VARIABLES ZERO                                        |
//|(i.e. do not use qphess_base(nbefore,1,1,1,Q,&ww[0],&imp[0])) |
//|______________________________________________________________|

		qphess(nvab,1,1,1,Q,X,&imp[0]);
		real ute_here=ddotvec(nvab,X,CC) 
			+ 0.5*ddotvec(nvab,X,&imp[0]);
		if(Util)
		{
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&ww[0],1);
			ResetInitial(0);
			ute_here+=scale_utility_external_terms*Util(n,&ww[0],UtilObjectInfo);
			ResetInitial();
		}
		return ute_here+this->shortcost(n,&ww[0]);
	}
	else if(hess_choice==3)
	{
		size_t i,j=0;
		std::valarray<double>ww(n),imp(nvab);
		for(i=0;i<nbefore;++i)
		{
			ww[i] = X[i];
			if(lab&&lab[j]==i)
				ww[i]+=X[j++ +nbefore];
		}
		daddvec(nbefore,&ww[0],initial,&ww[0]);
		dcopyvec(n-nbefore,x+nbefore,&ww[nbefore]);

//_______________________________________________________________
//|                                                              |
//|USE SECOND DERIVATIVE TERMS FOR QP IN DOUBLED SET             |
//|AS THIS WILL INCLUDE THE PENALTY THAT MAKES THE PRODUCT OF    |
//|DOUBLED VARIABLES ZERO                                        |
//|(i.e. do not use qphess_base(nbefore,1,1,1,Q,&ww[0],&imp[0])) |
//|______________________________________________________________|

		qphess(nvab,1,1,1,Q,X,&imp[0]);
		real ute_here=ddotvec(nvab,X,CC) 
			+ 0.5*ddotvec(nvab,X,&imp[0]);
		if(Util)
		{
			size_t n_here=n;
			if(TimeOptData&&TimeOptData->usethis)n_here-=TimeOptData->nextra;
			if(optimiseorder)Reorder_gen(n_here,optimiseorder+n_here,&ww[0],1);
			ResetInitial(0);
			ute_here+=scale_utility_external_terms*Util(n_here,&ww[0],UtilObjectInfo);
			ResetInitial();
		}
		return ute_here+this->shortcost(n,&ww[0]);
	}
	else if(hess_choice==4)
	{
		size_t i,j=0;
		std::valarray<double>ww(n),imp(nvab);
		for(i=0;i<nbefore;++i)
		{
			ww[i] = X[i];
			if(lab&&lab[j]==i && j < lsi)
			{
				ww[i]+=X[j++ +nbefore];
			}
		}
		dcopyvec(n-nbefore,x+nbefore,&ww[nbefore]);

//_______________________________________________________________
//|                                                              |
//|USE SECOND DERIVATIVE TERMS FOR QP IN DOUBLED SET             |
//|AS THIS WILL INCLUDE THE PENALTY THAT MAKES THE PRODUCT OF    |
//|DOUBLED VARIABLES ZERO                                        |
//|(i.e. do not use qphess_base(nbefore,1,1,1,Q,&ww[0],&imp[0])) |
//|______________________________________________________________|

		qphess(nvab,1,1,1,Q,X,&imp[0]);
		real ute_here=ddotvec(nvab,X,CC) 
			+ 0.5*ddotvec(nvab,X,&imp[0]);
		if(Util)
		{
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&ww[0],1);
			ResetInitial(0);
			ute_here+=scale_utility_external_terms*Util(n,&ww[0],UtilObjectInfo);
			ResetInitial();
		}
		return ute_here;
	}
	else //if(hess_choice==5)
	{
		size_t i,jm=0,jr=0,zeroinit_here=0;
		std::valarray<double>ww(n),imp(nvab);
		for(i = 0;i < nbefore;++i)
		{
			ww[i] = X[i]+initial[i];
			if(lab && lab[jm]==i && jm < lsi && labrev && labrev[jr]==i && jr < revi)
			{
				if(initial[i]<0)
					ww[i]+=X[nbefore+jm-zeroinit_here];
				else if(initial[i]>0)
					ww[i]+=X[nbefore+jm-zeroinit_here];
				else
					zeroinit_here++;
				ww[i]+=X[nbefore+lsi-zeroinit+jr++];
				jm++;
			}
			else if(labrev && labrev[jr]==i && jr < revi)
			{
				ww[i]+=X[nbefore+lsi-zeroinit+jr++];
			}
			else if(lab && lab[jm]==i && jm < lsi)
			{
				ww[i] += X[nbefore+jm++-zeroinit_here];
			}
		}
		dcopyvec(n-nbefore,x+nbefore,&ww[nbefore]);

//_______________________________________________________________
//|                                                              |
//|USE SECOND DERIVATIVE TERMS FOR QP IN DOUBLED SET             |
//|AS THIS WILL INCLUDE THE PENALTY THAT MAKES THE PRODUCT OF    |
//|DOUBLED VARIABLES ZERO                                        |
//|(i.e. do not use qphess_base(nbefore,1,1,1,Q,&ww[0],&imp[0])) |
//|______________________________________________________________|

		qphess(nvab,1,1,1,Q,X,&imp[0]);
		real ute_here=ddotvec(nvab,X,CC) 
			+ 0.5*ddotvec(nvab,X,&imp[0]);
		if(Util)
		{
			size_t n_here=n;
			if(TimeOptData&&TimeOptData->usethis)n_here-=TimeOptData->nextra;
			if(optimiseorder)Reorder_gen(n_here,optimiseorder+n_here,&ww[0],1);
			ResetInitial(0);
			ute_here+=scale_utility_external_terms*Util(n_here,&ww[0],UtilObjectInfo);
			ResetInitial();
		}
		return ute_here+this->shortcost(n,&ww[0]);
	}
}
inline size_t zerocount(size_t n,vector a,size_t skip=1)
{
	size_t z=0;
	while(n--)
	{
		if(*a == 0)z++;
		a+=skip;
	}
	return z;
}
void	FOptimise::factor_model_process()
{
	short_vec	P;
	size_t nreal=n-ncomp;
/*	fprintf(stderr,"ncomp %d\n",ncomp);
	fprintf(stderr,"n %d\n",n);
	fprintf(stderr,"nreal %d\n",nreal);*/
	short msglevel=0;
	vector	FC_1,FL_copy;
	dimen nfnf=((nfac*(nfac+1)) >> 1);
	FC_1 = new double[nfnf];
	P = new short_scl[nfac];
	FL_copy = new double[(nfac*nreal)];
	vQ->resize((nfac+1)*nreal);
#ifdef USE_STOREX
	storex->resize(nreal);
#endif
	H = &(*vQ)[0];
	if(nfac)
	{
		std::valarray<double> f_zero;
		std::valarray<unsigned char>dropb;
		std::valarray<size_t>facorder;
		dmx_transpose(nreal,nfac,FL,FL_copy);
/*
		if(_dsmxmpd_check(nfac,FC,FC_1,P,NULL,msglevel,this))
		{
#ifdef _DEBUG
			AddLog("The Factor Covariance was not positive definite\n");
#endif
		}
		for(i = 0,v = FL_copy;i < nreal;i++,v += nfac)
		{
			dsmxasrt(nfac,FC_1,P,SMXFAC_LEFT_ROOT,v);
		}
		*/
		dcopyvec(nfnf,FC,FC_1);
		if(dsptrf("U", nfac,FC_1,P)/*bunchf(nfac,FC_1,P)*/)
		{
#ifdef _DEBUG
			AddLog("Factorisation of Factor Covariance Matrix failed\n");
#endif
		}
		if(applyrootA(nfac,nreal,FC_1,P,FL_copy,nfac))
		{
#ifdef _DEBUG
			AddLog("The Factor Covariance Matrix was not positive definite\n");
#endif
		}
		dcopyvec(nreal * nfac,FL_copy,H + nreal);
	}
#ifdef TOPPER
	dmx_transpose(nfac,nreal,H + nreal,H + nreal);
#endif
	dcopyvec(nreal,SV,H);
	delete[] FL_copy;
	delete[] FC_1 ;
	delete[] P;
}

void Optimise::lspenaltyvec(size_t nn,vector pen)
{
//This gives the correct correlation between the split variables
	std::valarray<double> space(2*nn);
	space=0;
	vector x1=&space[0];
	vector x2=&space[nn];
	size_t i=nn;
	while(i--)
	{
		*x1 = 1;
		qphess_base(nn,1,1,1,H,&space[0],&space[nn]);
		*pen++ = 2.0 * *x2++;
		*x1++ = 0;
	}
}
double Optimise::leigen(size_t nn)
{
	//Crude method to get largest eigenvalue
	std::valarray<double>xx(nn),implied(nn);
	double large_eigen=lm_max,prev;
	size_t i=0;
	xx=1.0/sqrt((double)nn);
	do
	{
		prev=large_eigen;
		qphess_base(nn,1,1,1,H,&(xx)[0],&(implied)[0]);
		large_eigen = sqrt(ddotvec(nn,&(implied)[0],&(implied)[0]));
		implied /= large_eigen;
		xx = implied;
	}	while(i++ < 200 && fabs((large_eigen - prev)/large_eigen) > lm_rooteps);
	return large_eigen;
}
void	FOptimise::FMC(vector w,vector bench,vector MARG,vector FX)
{
	if(!MARG && !FX) return;
	if(ImportantCheck()) return;
	if(yc->size() == 0 && CompQ->size() == 0)
		CompSetup();
	size_t i;
	std::valarray<double>rel(n);
	if(bench)	{dsubvec(n,w,bench,&rel[0]);}
	else	{dcopyvec(n,w,&rel[0]);}
	if(ncomp)
	{
		for(i=0;i<ncomp;++i)
		{
			daxpyvec(n-ncomp,rel[n-ncomp+i],Composites + i * (n-ncomp),&rel[0]);
		}
	}
	ddmxmul(n-ncomp,SV,&rel[0],MARG + nfac);
	double specrisk = ddotvec(n-ncomp,MARG + nfac,&rel[0]);
	if(specrisk > lm_eps)
	{
		specrisk = sqrt(specrisk);
		dscalvec(n-ncomp,1.0 / specrisk,MARG + nfac);
	}
	else
	{
		specrisk = 0;
		dzerovec(n-ncomp,MARG + nfac);
	}
	if(ncomp)
	{
		for(i=n-ncomp;i<n;++i)
		{
			MARG[i+nfac] = ddotvec(n-ncomp,MARG+nfac,Composites + (i-n+ncomp)* (n-ncomp));
		}
	}
	dmxtmulv(n-ncomp,nfac,FL,&rel[0],FX);
	dsmxmulv(nfac,FC,FX,MARG);
	double facrisk = ddotvec(nfac,MARG,FX);
	if(facrisk > lm_eps)
	{
		facrisk = sqrt(facrisk);
		dscalvec(nfac,1.0 / facrisk,MARG);
	}
	else
	{
		facrisk = 0;
		dzerovec(nfac,MARG);
	}
}
void Optimise::ModifyC(dimen nvab,vector Q,vector X,vector newc,
					   unsigned char all=1)
{
	if(hess_choice==1)
	{
		if(all)
			ModifyC_base(nvab,Q,X,newc);//Change to c caused by centering at x
		if(ModDeriv)
		{
			std::valarray<double>ww(n);
			std::valarray<double>cmore(n);
			cmore=0;
			dcopyvec(nvab,X,&ww[0]);
			dcopyvec(n-nvab,x+nvab,&ww[nvab]);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&ww[0],1);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,newc,1);
			ResetInitial(0);
			ModDeriv(n,&ww[0],&cmore[0],ModCObjectInfo);//Change to c due extra first derivatives
			ResetInitial();
			if(keep_last_C->size()!=n){keep_last_C->resize(n);}
			*keep_last_C=cmore;
			cmore*=scale_utility_external_terms;
			if(take_out_costs<2)
				daddvec(n,newc,&cmore[0],newc);
			if(optimiseorder)Reorder_gen(n,optimiseorder,newc,1);
		}
	}
	else if(hess_choice==2)
	{
		size_t i,j=0;
		std::valarray<double>ww(n);
		for(i=0;i<nbefore;++i)
		{
			ww[i]=X[i];
			if(lab&&lab[j] == i)
			{
				ww[i]+=X[nbefore+j++];
			}
		}
		if(all)
			ModifyC_base(nbefore,Q,&ww[0],newc);
		if(ModDeriv)
		{
			std::valarray<double> cmore(n);
			cmore=0;
			dcopyvec(n-nbefore,x+nbefore,&ww[nbefore]);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&ww[0],1);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,newc,1);
			ResetInitial(0);
			ModDeriv(n,&ww[0],&cmore[0],ModCObjectInfo);
			ResetInitial();
			if(keep_last_C->size()!=n){keep_last_C->resize(n);}
			*keep_last_C=cmore;
			cmore*=scale_utility_external_terms;
			if(take_out_costs<2)
				daddvec(n,newc,&cmore[0],newc);
			if(optimiseorder)Reorder_gen(n,optimiseorder,newc,1);
		}
		if(lab)
		{
			for(i=0,j=0;i<nbefore;++i)
			{
				if(lab[j]==i)
				{
					newc[nbefore+j]=newc[i];
					j++;
				}
			}
		}
	}
	else if(hess_choice==3)
	{
		size_t n_here=n,nnn=n;
		if(TimeOptData&&TimeOptData->usethis)
		{
			n_here-=TimeOptData->nextra;
			nnn=n_here;
		}
		size_t i,j;//bool doneit=0;
		std::valarray<double>ww(n);
		std::valarray<double>cmore;
		for(i=0,j=0;i<nbefore;++i)
		{
			ww[i]=X[i];
			if(lab&&lab[j] == i)
			{
				ww[i]+=X[nbefore+j++];
			}
		}
/*		for(i=0;i<nbefore;++i)
		{
			if(ww[i]<lower[i])
			{
				ww[i]=lower[i];doneit=1;
			}
			else if(ww[i]>upper[i])
			{
				ww[i]=upper[i];doneit=1;
			}
		}
		if(doneit)AddLog("=============== Made feasible ================\n");*/
		daddvec(nbefore,&ww[0],initial,&ww[0]);
		if(all)
			ModifyC_base(nbefore,Q,&ww[0],newc);
		if(ModDeriv && DoExtraIterations)
		{
			cmore.resize(n_here);
			cmore=0;
			dcopyvec(n-nbefore,x+nbefore,&ww[nbefore]);
			if(optimiseorder)Reorder_gen(n_here,optimiseorder+n_here,&ww[0],1);
			ResetInitial(0);
			ModDeriv(n_here,&ww[0],&cmore[0],ModCObjectInfo);
			ResetInitial();
			if(keep_last_C->size()!=n){keep_last_C->resize(n);}
			*keep_last_C=cmore;
			cmore*=scale_utility_external_terms;
			if(optimiseorder)Reorder_gen(n_here,optimiseorder,&cmore[0],1);
			if(optimiseorder)Reorder_gen(n_here,optimiseorder,&ww[0],1);
		}
		for(i=0,j=0;i<nbefore;++i)
		{
			if(lab&&lab[j]==i)
			{
				newc[nbefore+j]=newc[i];
				if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
				{

				}
				else
				{
					if(ModDeriv&&take_out_costs<2)
					{
						if(ww[i] > initial[i])
						{
							newc[nbefore+j]+=(*buysell)[nnn+i];
							newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);
						}
						else if(ww[i] < initial[i])
						{
							newc[nbefore+j]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);
							newc[i]+=(*buysell)[i];
						}
						else
						{
							newc[nbefore+j]+=(*buysell)[nnn+i];
							newc[i]+=(*buysell)[i];
						}
					}
				}
				j++;
			}
			else if(ModDeriv&&take_out_costs<2)
			{
				if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
				{

				}
				else
				{
					if(ww[i] > initial[i])
					{
						newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);
					}
					else if(ww[i] < initial[i])
					{
						newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);
					}
					else
					{
						if(lowerusednow[i]>=0)
						{
							newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);
						}
						else if(upperusednow[i]<=0)
						{
							newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);
						}
					}
				}
			}
		}
	}
	else if(hess_choice==4)
	{
		size_t i,j;
		std::valarray<double>ww(n);
		std::valarray<double>cmore;
		for(i=0,j=0;i<nbefore;++i)
		{
			ww[i]=X[i];
			if(lab&&lab[j] == i && j < lsi)
			{
				ww[i]+=X[nbefore+j++];
			}
		}
		if(all)
			ModifyC_base(nbefore,Q,&ww[0],newc);
		if(ModDeriv && DoExtraIterations)
		{
			cmore.resize(n);
			cmore=0;
			dcopyvec(n-nbefore,x+nbefore,&ww[nbefore]);
			if(optimiseorder)Reorder_gen(n,optimiseorder+n,&ww[0],1);
			ResetInitial(0);
			ModDeriv(n,&ww[0],&cmore[0],ModCObjectInfo);
			ResetInitial();
			if(keep_last_C->size()!=n){keep_last_C->resize(n);}
			*keep_last_C=cmore;
			cmore*=scale_utility_external_terms;
			if(optimiseorder)Reorder_gen(n,optimiseorder,&cmore[0],1);
			if(optimiseorder)Reorder_gen(n,optimiseorder,&ww[0],1);
		}
		if(lab)
		{
			for(i=0,j=0;i<nbefore;++i)
			{
				if(lab[j]==i && j < lsi)
				{
					newc[nbefore+j]=newc[i];
					j++;
				}
			}
		}
		if(ModDeriv&&take_out_costs<2)
		{
			for(i=0,j=0;i<nbefore;++i)
			{
				if(labrev&&labrev[j]==i)
				{
					if(ww[i] > initial[i])
					{
						newc[nbefore+lsi+i]=(DoExtraIterations?cmore[i]:(*buysell)[i]);
						newc[2*nbefore+lsi+j]=(*buysell)[n+i];
					}
					else if(ww[i] < initial[i])
					{
						newc[nbefore+lsi+i]=(*buysell)[i];
						newc[2*nbefore+lsi+j]=(DoExtraIterations?cmore[i]:(*buysell)[n+i]);
					}
					else
					{
						newc[nbefore+lsi+i]=(DoExtraIterations?cmore[i]:(*buysell)[i]);
						newc[2*nbefore+lsi+j]=(DoExtraIterations?cmore[i]:(*buysell)[n+i]);
					}
					j++;
				}
				else
				{
					if(ww[i] > initial[i])
					{
						newc[nbefore+lsi+i]=(DoExtraIterations?cmore[i]:(*buysell)[i]);
					}
					else if(ww[i] < initial[i])
					{
						newc[nbefore+lsi+i]=(DoExtraIterations?cmore[i]:(*buysell)[n+i]);
					}
					else
					{
						if(lowerusednow[i]>=initial[i]){newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);}
						else if(upperusednow[i]<=initial[i]){newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[n+i]);}
					}
				}
			}
		}
	}
	else if(hess_choice==5)
	{
		size_t n_here=n,nnn=n;
		if(TimeOptData&&TimeOptData->usethis)
		{
			n_here-=TimeOptData->nextra;
			nnn=n_here;
		}
		size_t i,jm,jr,zeroinit_here=0;
		std::valarray<double>ww(n);
		std::valarray<double>cmore;
		for(i=0,jm=0,jr=0;i<nbefore;++i)
		{
			ww[i]=X[i]+initial[i];
			if(lab&&lab[jm] == i && jm < lsi && labrev&&labrev[jr] == i && jr < revi)
			{
				if(initial[i]<0)
					ww[i]+=X[nbefore+jm-zeroinit_here];
				else if(initial[i]>0)
					ww[i]+=X[nbefore+jm-zeroinit_here];
				else
					zeroinit_here++;
				ww[i]+=X[nbefore+lsi-zeroinit+jr++];
				jm++;
			}
			else if(labrev&&labrev[jr] == i && jr < revi)
			{
				ww[i]+=X[nbefore+lsi-zeroinit+jr++];
			}
			else if(lab&&lab[jm] == i && jm < lsi)
			{
				ww[i]+=X[nbefore+jm++-zeroinit_here];
			}
		}
		if(all)
			ModifyC_base(nbefore,Q,&ww[0],newc);
		if(ModDeriv && DoExtraIterations)
		{
			cmore.resize(n_here);
			cmore=0;
			dcopyvec(n-nbefore,x+nbefore,&ww[nbefore]);
			if(optimiseorder)Reorder_gen(n_here,optimiseorder+n_here,&ww[0],1);
			ResetInitial(0);
			ModDeriv(n_here,&ww[0],&cmore[0],ModCObjectInfo);
			ResetInitial();
			if(keep_last_C->size()!=n){keep_last_C->resize(n);}
			*keep_last_C=cmore;
			cmore*=scale_utility_external_terms;
			if(optimiseorder)Reorder_gen(n_here,optimiseorder,&cmore[0],1);
			if(optimiseorder)Reorder_gen(n_here,optimiseorder,&ww[0],1);
		}
		for(i=0,jm=0,jr=0,zeroinit_here=0;i<nbefore;++i)
		{
			if(lab[jm]==i && jm < lsi && labrev[jr]==i && jr < revi)
			{
				if(initial[i]<0)
					newc[nbefore+jm-zeroinit_here]=newc[i];
				else if(initial[i]>0)
					newc[nbefore+jm-zeroinit_here]=newc[i];
				else
					zeroinit_here++;
				newc[nbefore+lsi-zeroinit+jr++]=newc[i];
				jm++;
			}
			else if(labrev[jr]==i && jr < revi)
			{
				newc[nbefore+lsi-zeroinit+jr++]=newc[i];
			}
			else if(lab[jm]==i && jm < lsi)
			{
				newc[nbefore+jm++-zeroinit_here]=newc[i];
			}
		}
		if(ModDeriv&&take_out_costs<2)
		{
			for(i=0,jm=0,jr=0,zeroinit_here=0;i<nbefore;++i)
			{
				if(lab[jm]==i && jm < lsi && labrev[jr]==i && jr < revi)
				{
					if(ww[i] > initial[i])//buy
					{
						if(initial[i]<0)
						{
							if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
							{

							}
							else
							{
								if(ww[i]>0)
								{
									newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
									newc[nbefore+jm-zeroinit_here]+=(*buysell)[i];//short buy
								}
								else if(ww[i]<0)
								{
									newc[i]+=(*buysell)[i];//long buy
									newc[nbefore+jm-zeroinit_here]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//short buy
								}
								else
								{
									newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
									newc[nbefore+jm-zeroinit_here]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//short buy
								}

								newc[nbefore+lsi-zeroinit+jr]+=(*buysell)[nnn+i];//short sell
							}
						}
						else if(initial[i]>0)
						{
							if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
							{

							}
							else
							{
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
								newc[nbefore+jm-zeroinit_here]+=(*buysell)[nnn+i];//long sell
								newc[nbefore+lsi-zeroinit+jr]+=(*buysell)[nnn+i];//short sell
							}
						}
						else
						{
							if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
							{

							}
							else
							{
								if(ww[i]>0)
								{
									newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
									newc[nbefore+lsi-zeroinit+jr]+=(*buysell)[nnn+i];//short sell
								}
								else if(ww[i]<0)
								{
									newc[i]+=(*buysell)[i];//long buy
									newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
								}
								else
								{
									newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
									newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
								}
							}
							zeroinit_here++;
						}
					}
					else if(ww[i] < initial[i])//sell
					{
						if(initial[i]<0)
						{
							if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
							{

							}
							else
							{
								newc[i]+=(*buysell)[i];//long buy
								newc[nbefore+jm-zeroinit_here]+=(*buysell)[i];//short buy
								newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
							}
						}
						else if(initial[i]>0)
						{
							if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
							{

							}
							else
							{
								newc[i]+=(*buysell)[i];//long buy
								if(ww[i]<0)
								{
									newc[nbefore+jm-zeroinit_here]+=(*buysell)[n+i];//long sell
									newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
								}
								else if(ww[i]>0)
								{
									newc[nbefore+jm-zeroinit_here]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//long sell
									newc[nbefore+lsi-zeroinit+jr]+=(*buysell)[nnn+i];//short sell
								}
								else
								{
									newc[nbefore+jm-zeroinit_here]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//long sell
									newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
								}
							}
						}
						else
						{
							if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
							{

							}
							else
							{
								if(ww[i]<0)
								{
									newc[i]+=(*buysell)[i];//long buy
									newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
								}
								else if(ww[i]>0)
								{
									newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
									newc[nbefore+lsi-zeroinit+jr]+=(*buysell)[nnn+i];//short sell
								}
								else
								{
									newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
									newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
								}
							}
							zeroinit_here++;
						}
					}
					else
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
						{

						}
						else
						{
							if(initial[i]<0)
							{
								newc[i]+=(*buysell)[i];//long buy
								newc[nbefore+jm-zeroinit_here]+=(*buysell)[i];//short buy
								newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
							}
							else if(initial[i]>0)
							{
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
								newc[nbefore+jm-zeroinit_here]+=(*buysell)[nnn+i];//long sell
								newc[nbefore+lsi-zeroinit+jr]+=(*buysell)[nnn+i];//short sell
							}
							else
							{
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
								zeroinit_here++;
								newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
							}
						}
					}
					jr++;jm++;
				}
				else if(lab&&lab[jm]==i && jm < lsi)
				{
					if(ww[i] > initial[i])
					{
						//					std::cerr<<"HERE > "<<i<<std::endl;
						if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
						{

						}
						else
						{
							if(ww[i]>0)
							{
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
								newc[nbefore+jm-zeroinit_here]+=(*buysell)[3*nnn+i];//short buy
							}
							else if(ww[i]<0)
							{
								newc[i]+=(*buysell)[2*n+i];//long buy
								newc[nbefore+jm-zeroinit_here]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//short buy
							}
							else
							{
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
								newc[nbefore+jm-zeroinit_here]+=(*buysell)[3*nnn+i];//short buy
							}
						}
					}
					else if(ww[i] < initial[i])
					{
						//					std::cerr<<"HERE < "<<i<<std::endl;
						if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
						{

						}
						else
						{
							if(ww[i]<0)
							{
								newc[i]+=(*buysell)[2*n+i];//long sell
								newc[nbefore+jm-zeroinit_here]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
							}
							else if(ww[i]>0)
							{
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//long sell
								newc[nbefore+jm-zeroinit_here]+=(*buysell)[3*nnn+i];//short sell
							}
							else
							{
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[2*nnn+i]);//long sell
								newc[nbefore+jm-zeroinit_here]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
							}
						}
					}
					else
					{
						if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
						{

						}
						else
						{
							newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[2*nnn+i]);//+ bit
							newc[nbefore+jm-zeroinit_here]+=(DoExtraIterations?cmore[i]:(*buysell)[3*nnn+i]);//- bit
							//					std::cerr<<"HERE <> "<<i<<std::endl;
						}
					}
					jm++;
				}
				else if(labrev&&labrev[jr]==i&&jr<revi)
				{
					if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
					{

					}
					else
					{
						if(ww[i] > 0)
						{
							newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);//long buy
							newc[nbefore+lsi-zeroinit+jr]+=(*buysell)[n+i];//long sell
						}
						else if(ww[i] < 0)
						{
							newc[i]+=(*buysell)[i];//short buy
							newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);//short sell
						}
						else
						{
							newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);
							newc[nbefore+lsi-zeroinit+jr]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);
						}
					}
					jr++;
				}
				else
				{
					if(TimeOptData&&TimeOptData->opt&&i>=nbefore-TimeOptData->nextra)
					{

					}
					else
					{
						if(ww[i] > initial[i])
						{
							newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);
						}
						else if(ww[i] < initial[i])
						{
							newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);
						}
						else
						{
							if(lower[i]>=initial[i]&&initial[i]<upper[i])
							{
								//						std::cerr<<"li HERE > "<<i<<std::endl;
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[i]);
							}
							else if(upper[i]<=initial[i]&&initial[i]>lower[i])
							{
								//						std::cerr<<"ui HERE < "<<i<<std::endl;
								newc[i]+=(DoExtraIterations?cmore[i]:(*buysell)[nnn+i]);
							}
							/*else
							{
							std::cerr<<"What happens here??? l=(char*)"<<lower[i]<<" i=(char*)"<<initial[i]<<" u=(char*)"<<upper[i]<<std::endl;
							}*/
						}
					}
				}
			}
		}
	}
}

//	C wrappers
//__________________________________________________________________________________
void HMUL(size_t n,size_t n1,size_t n2,size_t n3,vector H,vector x,vector y,void* info)
{
	dsmxmulv(n,H,x,y);
/*	std::cout << "[";
	while(n--)
	{
		printf("%-.8e",*y++);
		if(n)std::cout << ",";
	}
	std::cout << "]" << std::endl;*/
}
void HMULbunch(size_t n,size_t n1,size_t n2,size_t n3,vector H,vector x,vector y,void* info)
{
	size_t nn=n*(n+1)>>1;
	short_scl* piv=(short_scl*)&H[nn];
	dcopyvec(n,x,y);
	applyA("U",n,1,H,piv,y,n);
}
void buysell_grad(dimen n,vector w,vector g,void *info)
{
	linearcostpasser *costs=(class linearcostpasser*)info;
	long i;
/*	if(n>3600)
	{
#pragma omp parallel for private(i) schedule(dynamic)
		for(i=0;i<n;++i)
		{
			double ww;
			ww=w[i]-(costs->initial?costs->initial[i]:0);
			if(ww<0){g[i]=-costs->sell[i];}
			else if(ww>0){g[i]=costs->buy[i];}
			else{g[i]=0;}
			if(w[i]<0)
			{
				g[i]*=costs->ShortCostScale;
			}
		}
	}
	else*/
	{
		double ww;
		for(i=0;i<n;++i)
		{
			ww=w[i]-(costs->initial?costs->initial[i]:0);
			if(ww<0)
			{
				g[i]=-costs->sell[i];
				if(costs->qsell)
					g[i]+=2*costs->qsell[i]*ww;
			}
			else if(ww>0)
			{
				g[i]=costs->buy[i];
				if(costs->qbuy)
					g[i]+=2*costs->qbuy[i]*ww;
			}
			else{g[i]=0;}
			if(w[i]<0)
			{
				g[i]*=costs->ShortCostScale;
			}
		}
	}
}
double buysell_cost(dimen n,vector w,void*info)
{
	linearcostpasser *costs=(class linearcostpasser*)info;
	size_t i;
	double total=0;
/*	if(n>3600)
	{
#pragma omp parallel for private(i) reduction(+:total) schedule(dynamic)
		for(i=0;i<n;++i)
		{
			double ww;
			if(w[i]>=0)
			{
				ww=w[i]-(costs->initial?costs->initial[i]:0);
				if(ww<0){total-=costs->sell[i]*ww;}
				else{total+=costs->buy[i]*ww;}
			}
			else
			{
			ww=w[i]-(costs->initial?costs->initial[i]:0);
			ww*=costs->ShortCostScale;
			if(ww<0){total-=costs->sell[i]*ww;}
			else{total+=costs->buy[i]*ww;}
			}
			}
			}
	else*/
	{
		double ww;
		for(i=0;i<n;++i)
		{
			ww=w[i]-(costs->initial?costs->initial[i]:0);
			if(w[i]<0)
			{
				if(ww<0)
				{
					total-=costs->ShortCostScale*(costs->sell[i]-(costs->qsell?costs->qsell[i]*ww:0))*ww;
				}
				else
				{
					total+=costs->ShortCostScale*(costs->buy[i]+(costs->qbuy?costs->qbuy[i]*ww:0))*ww;
				}
			}
			else
			{
				if(ww<0)
				{
					total-=(costs->sell[i]-(costs->qsell?costs->qsell[i]*ww:0))*ww;
				}
				else
				{
					total+=(costs->buy[i]+(costs->qbuy?costs->qbuy[i]*ww:0))*ww;
				}
			}
		}
	}
	return total;
}
void buysell_hess(dimen n,vector w,vector g,void *info)
{
	linearcostpasser *costs=(class linearcostpasser*)info;
	double ww;
	size_t i,i3;

	dzerovec(n*(n+1)>>1,g);
	if(costs->qbuy&&costs->qsell)
	{
		for(i=0,i3=0;i<n;++i)//We only set the diagonal elements; no cross terms for costs
		{
			ww=w[i]-(costs->initial?costs->initial[i]:0);
			if(ww<0)g[i3]=2*costs->qsell[i];
			else g[i3]=2*costs->qbuy[i];
			if(w[i]<0)g[i3]*=costs->ShortCostScale;
			i3+=i+2;
		}
	}
}
double buysell_cost_per_stock(dimen n,vector w,vector per_stock,void*info)
{
	linearcostpasser *costs=(class linearcostpasser*)info;
	size_t i;
	double ww,total;
	for(i=0,total=0;i<n;++i)
	{
		if(w[i]>=0)
		{
			per_stock[i]=0;
			ww=w[i]-costs->initial[i];
			if(ww<0){per_stock[i]-=(costs->sell[i]-(costs->qsell?costs->qsell[i]*ww:0))*ww;}
			else{per_stock[i]+=(costs->buy[i]+(costs->qbuy?costs->qbuy[i]*ww:0))*ww;}
			total+=per_stock[i];
		}
		else
		{
			per_stock[i]=0;
			ww=w[i]-costs->initial[i];
			if(ww<0){per_stock[i]-=costs->ShortCostScale*(costs->sell[i]-(costs->qsell?costs->qsell[i]*ww:0))*ww;}
			else{per_stock[i]+=costs->ShortCostScale*(costs->buy[i]+(costs->qbuy?costs->qbuy[i]*ww:0))*ww;}
			total+=per_stock[i];
		}
	}
	return total;
}

void piece_grad(dimen n,vector w,vector gg,void* info)
{
//This gives the cost gradient from a piecewise table
	piececostpasser *costs=(class piececostpasser*)info;
	vector hp=costs->hpiece;
	vector Iinitial=costs->initial;
	vector pg=costs->pgrad;
	size_t oldn=costs->nstocks;
	size_t npiece=costs->npiece;
	if(n!=oldn)printf("Inconsistent n in piece_grad?????????????????\n");
	long j;
/*	if(oldn>3600)
	{
#pragma omp parallel for private(j,pg,hp) schedule(dynamic)
		for(j=0;j<oldn;++j)
		{
			pg=costs->pgrad+npiece*j;
			hp=costs->hpiece+npiece*j;
			size_t i;
			double ww;
			double scale=1;
			bool done=false;
			scale=(w[j]<0?costs->ShortCostScale:1);
			ww=w[j]-(Iinitial?Iinitial[j]:0);
			if(ww<hp[0])
			{
				gg[j]=pg[0]*scale;done=true;continue;
			}
			for(i = 1;i < npiece;++i)
			{
				if(ww<hp[i]&&ww>=hp[i-1])
				{
					if(ww>0)
						gg[j]=pg[i]*scale;
					else if(ww<0)
						gg[j]=pg[i-1]*scale;
					else
						gg[j]=0;
					done=true;
					break;
				}
			}
			if(done){continue;}
			gg[j]=pg[npiece-1]*scale;
		}
	}
	else*/
	{
		for(j=0;j<oldn;++j)
		{
			pg=costs->pgrad+npiece*j;
			hp=costs->hpiece+npiece*j;
			size_t i;
			double ww;
			double scale=1;
			bool done=false;
			scale=(w[j]<0?costs->ShortCostScale:1);
			ww=w[j]-(Iinitial?Iinitial[j]:0);
			if(ww<hp[0])
			{
				gg[j]=pg[0]*scale;done=true;continue;
			}
			for(i = 1;i < npiece;++i)
			{
				if(ww<hp[i]&&ww>=hp[i-1])
				{
					if(ww>0)
						gg[j]=pg[i]*scale;
					else if(ww<0)
						gg[j]=pg[i-1]*scale;
					else
						gg[j]=0;
					done=true;
					break;
				}
			}
			if(done){continue;}
			gg[j]=pg[npiece-1]*scale;
		}
	}
}
double piece_cost(dimen n,vector w,void*info)
{
//This gives the cost from a piecewise table
	piececostpasser *costs=(class piececostpasser*)info;
	vector hp=costs->hpiece;
	vector Iinitial=costs->initial;
	vector pg=costs->pgrad;
	size_t oldn=costs->nstocks;
	size_t npiece=costs->npiece;
	long j;
	double total=0;
	if(n!=oldn)printf("Inconsistent n in piece_cost?????????????????\n");
	
/*	if(oldn>3600)
	{
#pragma omp parallel for private(j,pg,hp) reduction(+:total) schedule(dynamic)
		for(j=0;j<oldn;++j)
		{
			pg=costs->pgrad+npiece*j;
			hp=costs->hpiece+npiece*j;
			size_t i,nstart=0;
			double ww;
			bool done;
			double sofar,scale=1;
			scale=(w[j]<0?costs->ShortCostScale:1);
			for(i=0;i<npiece;++i)//Get the positive bit so we integrate from 0
			{
				if(hp[i]>lm_eps)
				{
					nstart=i;break;
				}
			}
			ww=w[j]-(Iinitial?Iinitial[j]:0);
			done=false;
			if(ww<=hp[nstart]&&ww>=0)
			{
				total+=(ww*pg[nstart]*scale);done=true;continue;
			}
			sofar=hp[nstart]*pg[nstart]*scale;
			for(i=nstart+1;i<npiece&&ww>0;++i)
			{
				if(ww<hp[i]&&ww>=hp[i-1])
				{
					total+=sofar+(ww-hp[i-1])*pg[i]*scale;done=true;break;
				}
				sofar+=(hp[i]-hp[i-1])*pg[i]*scale;
			}
			if(done){continue;}
			if(ww>=0)
			{
				total+=(sofar+(ww-hp[npiece-1])*pg[npiece-1]*scale);done=true;continue;
			}
			if(ww<0) //Should be!
				sofar=0;
			for(i=nstart;i>0;--i)
			{
				double usehpi=hp[i];
				if(i==nstart)
					usehpi=0;
				if(ww<usehpi && ww >= hp[i-1])
				{
					total+=sofar + (ww-usehpi)*pg[i-1]*scale;done=true;break;
				}
				sofar-=(usehpi-hp[i-1])*pg[i-1]*scale;
			}
			if(done){continue;}
			total+=sofar+(ww-hp[0])*pg[0]*scale;
		}
	}
	else*/
	{
		for(j=0;j<oldn;++j)
		{
			pg=costs->pgrad+npiece*j;
			hp=costs->hpiece+npiece*j;
			size_t i,nstart=0;
			double ww;
			bool done;
			double sofar,scale=1;
			scale=(w[j]<0?costs->ShortCostScale:1);
			for(i=0;i<npiece;++i)//Get the positive bit so we integrate from 0
			{
				if(hp[i]>lm_eps)
				{
					nstart=i;break;
				}
			}
			ww=w[j]-(Iinitial?Iinitial[j]:0);
			done=false;
			if(ww<=hp[nstart]&&ww>=0)
			{
				total+=(ww*pg[nstart]*scale);done=true;continue;
			}
			sofar=hp[nstart]*pg[nstart]*scale;
			for(i=nstart+1;i<npiece&&ww>0;++i)
			{
				if(ww<hp[i]&&ww>=hp[i-1])
				{
					total+=sofar+(ww-hp[i-1])*pg[i]*scale;done=true;break;
				}
				sofar+=(hp[i]-hp[i-1])*pg[i]*scale;
			}
			if(done){continue;}
			if(ww>=0)
			{
				total+=(sofar+(ww-hp[npiece-1])*pg[npiece-1]*scale);done=true;continue;
			}
			if(ww<0) //Should be!
				sofar=0;
			for(i=nstart;i>0;--i)
			{
				double usehpi=hp[i];
				if(i==nstart)
					usehpi=0;
				if(ww<usehpi && ww >= hp[i-1])
				{
					total+=sofar + (ww-usehpi)*pg[i-1]*scale;done=true;break;
				}
				sofar-=(usehpi-hp[i-1])*pg[i-1]*scale;
			}
			if(done){continue;}
			total+=sofar+(ww-hp[0])*pg[0]*scale;
		}
	}
	return(total);
}
double piece_cost_per_stock(dimen n,vector w,vector per_stock,void*info)
{
//This gives the cost from a piecewise table
	piececostpasser *costs=(class piececostpasser*)info;
	vector hp=costs->hpiece;
	vector Iinitial=costs->initial;
	vector pg=costs->pgrad;
	size_t oldn=costs->nstocks;
	size_t npiece=costs->npiece;
	if(n!=oldn)printf("Inconsistent n in piece_cost?????????????????\n");
	size_t i,j,nstart=0;
	double ww;
	bool done;
	double total=0,sofar,nextbit,scale=1;

	for(j=0;j<oldn;++j,hp+=npiece,pg+=npiece)
	{
		scale=(w[j]<0?costs->ShortCostScale:1);
		per_stock[j]=0;
		for(i=0;i<npiece;++i)//Get the positive bit so we integrate from 0
		{
			if(hp[i]>lm_eps)
			{
				nstart=i;break;
			}
		}
		ww=w[j]-(Iinitial?Iinitial[j]:0);
		done=0;
		if(ww<=hp[nstart]&&ww>=0)
		{
			per_stock[j]+=(nextbit=ww*pg[nstart]*scale);
			total+=nextbit;done=1;continue;
		}
		sofar=hp[nstart]*pg[nstart]*scale;
		for(i=nstart+1;i<npiece&&ww>0;++i)
		{
			if(ww<hp[i]&&ww>=hp[i-1])
			{
				per_stock[j]+=sofar+(nextbit=(ww-hp[i-1])*pg[i]*scale);
				total+=sofar+nextbit;done=1;break;
			}
			sofar+=(hp[i]-hp[i-1])*pg[i]*scale;
		}
		if(done){continue;}
		if(ww>=0)
		{
			per_stock[j]+=(sofar+(nextbit=(ww-hp[npiece-1])*pg[npiece-1]*scale));
			total+=(sofar+nextbit);done=1;continue;
		}
		if(ww<0) //Should be!
			sofar=0;
		for(i=nstart;i>0;--i)
		{
			double usehpi=hp[i];
			if(i==nstart)
				usehpi=0;
			if(ww<usehpi && ww >= hp[i-1])
			{
				per_stock[j]+=sofar + (nextbit=(ww-usehpi)*pg[i-1]*scale);
				total+=sofar + nextbit;done=1;break;
			}
			sofar-=(usehpi-hp[i-1])*pg[i-1]*scale;
		}
		if(done){continue;}
		per_stock[j]+=sofar+(nextbit=(ww-hp[0])*pg[0]*scale);
		total+=sofar+nextbit;
	}
	return(total);
}
extern "C" void DLLEXPORT	facmul_and_inv(dimen n,dimen nfac,vector Q,vector x,vector y,int inv=0)
{
/*	
	If Q came from factor_model_process_inverse, then inv must be 1
	If Q came from factor_model_process, then inv must be 0
*/
	vector	SV = Q;
	vector	FF = SV + n;
	size_t	i;
	
	if(nfac)
	{
		dsccopy(n,BITA_ddot(n,FF,nfac,x,1),FF,nfac,y,1);
		for(i = 1;i < nfac;i++) {BITA_daxpy(n,BITA_ddot(n,FF + i,nfac,x,1),FF + i,nfac,y,1);}
	}
	else	{dzerovec(n,y);}
	
	if(inv)	dnegvec(n,y);
	for(i = 0;i < n;++i)	{y[i] += SV[i] * x[i];}
}
extern "C" void DLLEXPORT	lowrank_facmul_and_inv(dimen n,dimen nfac,vector LL,vector A,vector x,vector y,int inv=0,short_scl*Apiv=0)
{
/*	
	we assume that A Apiv come from process_lowrank_plus_symm_inverse. 
	For inverse inv must be 1
	otherwise inv must be 0
	If inv is 1 then LL too must come from process_lowrank_plus_symm_inverse
*/
	size_t i;
	std::valarray<double>xx(n);
	if(nfac)
	{
		dsccopy(n,BITA_ddot(n,LL,nfac,x,1),LL,nfac,y,1);
		for(i = 1;i < nfac;i++) {BITA_daxpy(n,BITA_ddot(n,LL + i,nfac,x,1),LL + i,nfac,y,1);}
	}
	else	{dzerovec(n,y);}
	
	if(inv)	
	{
		dcopyvec(n,x,&xx[0]);
		dnegvec(n,y);
		dsptrs((char *)"U",n,1,A,Apiv,&xx[0],n);
		for(i=0;i<n;++i)
			y[i]+=xx[i];
	}
	else
	{
		dcopyvec(n,x,&xx[0]);
		applyA("U",n,1,A,Apiv,&xx[0],n);
		for(i=0;i<n;++i)
			y[i]+=xx[i];
	}
}

extern "C" void DLLEXPORT	process_lowrank_plus_symm_inverse(dimen n,dimen nfac,vector LL,vector A,vector LLm1,short_scl*Apiv)
{
	/* Finds the factorised form for A+L'L where A is symmetric packed order n and L is nfac by n (like factor part in Q of factor_model_process)
	so that an efficient form is given for finding y=(A+L'L).x  and y=inverse(A+L'L).x
#Python test code
n=5
nfac=2

A=[1,0.2,2,0.2,0.3,3,0.2,0.3,0.4,4,0.2,0.3,0.4,0,5]
LL=[1,1,1,1,1,2,-2,2,-2,2]
dmx_transpose(n,nfac,LL,LL)

Apiv=[-1]*n

LLm1=[-1]*(n*nfac)


process_lowrank_plus_symm_inverse(n,nfac,LL,A,LLm1,Apiv)

x=[0]*n
for i in range(n):
    x[i]=1
    back1=[0]*n
    back2=[0]*n
    lowrank_facmul_and_inv(n,nfac,LL,A,x,back1,0,Apiv)				#find (A+LL).x
    lowrank_facmul_and_inv(n,nfac,LLm1,A,back1,back2,1,Apiv)		#find (A+LL)^-1.x (so back2 should be the same as x)
    print x
    print back1
    print back2
    x[i]=0

	*/
	size_t i,j;
	dsptrf("U",n,A,Apiv);
	dmx_transpose(nfac,n,LL,LLm1);
	applyinverserootA(n,nfac,A,Apiv,LLm1,n);
	std::valarray<double> middle(nfac*(nfac+1)>>1);
	vector pM=&middle[0];
	for(i=0;i<nfac;++i)
	{
		for(j=0;j<=i;++j)
		{
			*pM=ddotvec(n,LLm1+i*n,LLm1+j*n);
			if(i==j)*pM+=1.;
			pM++;
		}
	}
	std::valarray<short_scl>P(nfac);
	dsptrf("U",nfac,&middle[0],&P[0]);
	dcopyvec(n*nfac,LL,LLm1);
	applyinverserootA(nfac,n,&middle[0],&P[0],LLm1,nfac);
	dmx_transpose(nfac,n,LLm1,LLm1);
	dsptrs((char *)"U",n,nfac,A,Apiv,LLm1,n);
	dmx_transpose(n,nfac,LLm1,LLm1);
}
extern "C" void DLLEXPORT	factor_model_process_inverse(dimen n,dimen nfac,vector Q,vector Qm1)
{
	vector SV=Q,SVm1=Qm1;
	vector F=Q+n,Fm1=Qm1+n;
	size_t i,j;
	dcopyvec(n*nfac,F,Fm1);
	for(i=0;i<n;++i)
	{
		SVm1[i]=1./SV[i];
		dscalvec(nfac,sqrt(SVm1[i]),Fm1+i*nfac);
	}
	std::valarray<double> middle(nfac*(nfac+1)>>1);
	vector pM=&middle[0];
	for(i=0;i<nfac;++i)
	{
		for(j=0;j<=i;++j)
		{
			*pM=BITA_ddot(n,Fm1+i,nfac,Fm1+j,nfac);
			if(i==j)*pM+=1.;
			pM++;
		}
	}
	std::valarray<short_scl>P(nfac);
	dsptrf("U",nfac,&middle[0],&P[0]);
	dcopyvec(n*nfac,F,Fm1);
	applyinverserootA(nfac,n,&middle[0],&P[0],Fm1,nfac);
	for(i=0;i<n;++i)
	{
		dscalvec(nfac,SVm1[i],Fm1+i*nfac);
	}
}
void	factor_model_process(dimen n,dimen nfac,vector FL,vector FC,vector SV,vector Q)
{
	bool getlog=0;
	FOptimise *opter = new FOptimise();
	opter->n=n;
	opter->SV=SV;
	opter->nfac=nfac;
	if(getlog)opter->SetLog();
	if(nfac)
	{
		opter->FL=FL;
		opter->FC=FC;
		opter->factor_model_process();
	}
	else
		opter->H=SV;
	dcopyvec(n*(nfac+1),opter->H,Q);
	if(getlog)
	{
		printf("%s\n",(*(opter->logprint)).str().c_str());
	}
	delete opter;
}
int	name_lookup(const char *name, size_t n, char **u, const char *uname)
{
	for(size_t i=0;i<n;i++) {if(stricmp(name,u[i])==0) return i;}
	return n;
}
void Extract_Factor_Information(dimen nstocks,dimen numfac,dimen Mnstocks,
								vector FL,vector SV,char** stocklist,
								vector MFL,vector MSV,char** Mstocklist)
{
	size_t i,j;
	double average=-1;
	for(i = 0;i < nstocks;++i)
	{
		j = name_lookup(stocklist[i], Mnstocks, Mstocklist, (char*)"Model UNIVERSE");
		if(j >= Mnstocks)
		{
			if(average==-1)
				average=dsumvec(Mnstocks,MSV)/Mnstocks;
			fprintf(stderr,"************* %s is not in the model **************\n",stocklist[i]);
			SV[i] = average;
			dzero(numfac,FL+i,nstocks);
		}
		else
		{
			SV[i] = MSV[j];
			dcopy(numfac,MFL+j,Mnstocks,FL+i,nstocks);
		}
	}
}

void	apt_model_process(dimen n,dimen nf,vector eigvec,vector eigval,vector SV,vector Q)
{
	dimen i,j;
	vector z,Qfac = Q + n;

	dcopyvec(n,SV,Q);
	dcopyvec(n * nf,eigvec,Qfac);

	for(i = 0,z = Qfac;i < nf;i++,z += n)
	{
	  dscalvec(n,sqrt(eigval[i]),z);
	  for(j = 0;j < n;j++) Q[j] -= z[j]*z[j];
	}
	dmx_transpose(n,nf,Qfac,Qfac);
}
char* BasicQpOpt(dimen n,dimen m,vector A,vector lower,vector upper,vector x,vector c,
				   vector H,unsigned char lp,pHmul Hmul=0,long fixn=-1,dimen ncomp=0,
				   vector Composites=0,long nfac=-1,vector SV=0,
				   vector FL=0,dimen LS=0,dimen Full=1,dimen npiece=0,vector costdata=0,
				   pUtility Util=0,
				   pModC ModDeriv=0,pModQ ModHessian=0,void *Hinfo=0,void *Uinfo=0,
				   void *Minfo=0,void* Qinfo=0)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	char* back;
	if(nfac ==  -1)
	{
		Optimise *opter = new Optimise();
		opter->n=n;
		opter->m=m;
		opter->c=c;
		opter->A=A;
		opter->lower=lower;
		opter->upper=upper;
		opter->H=H;
		opter->lp=lp;
		opter->ncomp=ncomp;
		opter->Composites=Composites;
		opter->HmulObjectInfo=Hinfo;
		opter->UtilObjectInfo=Uinfo;
		opter->ModCObjectInfo=Minfo;
		opter->ModQObjectInfo=Qinfo;
		if(!Hmul)
			opter->hmul = (pHmul)HMUL;
		else
			opter->hmul = Hmul;
		opter->Util=Util;
		opter->ModDeriv=ModDeriv;
		opter->ModHessian=ModHessian;

		opter->hess_choice=LS+1;
		opter->Full=Full;
		try
		{
			back = opter->OptSetup(fixn);
		}
		catch(MemProb mess)
		{
			printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
			back =(char*)"Not enough memory for optimisation";
		}
		if(opter->x)
			dcopyvec(n,opter->x,x);
		delete opter;
	}
	else
	{
		FOptimise *opter = new FOptimise();
		opter->n=n;
		opter->m=m;
		opter->c=c;
		opter->A=A;
		opter->lower=lower;
		opter->upper=upper;
		opter->lp=lp;
		opter->ncomp=ncomp;
		opter->Composites=Composites;
		opter->HmulObjectInfo=Hinfo;
		opter->UtilObjectInfo=Uinfo;
		opter->ModCObjectInfo=Minfo;
		opter->ModQObjectInfo=Qinfo;
		opter->SV=SV;
		opter->nfac=nfac;
		if(nfac)
		{
			opter->FL=FL;
			opter->FC=H;
			opter->factor_model_process();
		}
		else
			opter->H=SV;
		opter->Util=Util;
		opter->ModDeriv=ModDeriv;
		opter->ModHessian=ModHessian;
		opter->hess_choice=LS+1;
		opter->Full=Full;
		try
		{
			back = opter->OptSetup(fixn);
		}
		catch(MemProb mess)
		{
			printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
			back =(char*)"Not enough memory for optimisation";
		}
		if(opter->x)dcopyvec(n,opter->x,x);
		delete opter;
	}
	return back;
}
short  Optimise_internalCVPAextcosts(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util,pModC ModDeriv,pModQ ModHessian,
									double minRisk,double maxRisk,double* ogamma,
									void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,
									vector mask,int log,char* logfile,short DoExtraIterations,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale)
{
	return Optimise_internalCVPAextcostsl(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,kappa,basket,trades,revise,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,Util,ModDeriv,ModHessian,minRisk,maxRisk,ogamma,Uinfo,Minfo,Qinfo,
		take_out_costs,mask,log,logfile,DoExtraIterations,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,0,0);
}
short  Optimise_internalCVPAextcostsl(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util,pModC ModDeriv,pModQ ModHessian,
									double minRisk,double maxRisk,double* ogamma,
									void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,
									vector mask,int log,char* logfile,short DoExtraIterations,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L)
{
	return Optimise_internalCVPAextcostslSa(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,kappa,basket,trades,revise,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,Util,ModDeriv,ModHessian,minRisk,maxRisk,ogamma,Uinfo,Minfo,Qinfo,
		take_out_costs,mask,log,logfile,DoExtraIterations,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,0);
}
short  Optimise_internalCVPAextcostslSa(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util,pModC ModDeriv,pModQ ModHessian,
									double minRisk,double maxRisk,double* ogamma,
									void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,
									vector mask,int log,char* logfile,short DoExtraIterations,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost)
{
	return Optimise_internalCVPAextcostslSaM(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,kappa,basket,trades,revise,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,Util,ModDeriv,ModHessian,minRisk,maxRisk,ogamma,Uinfo,Minfo,Qinfo,
		take_out_costs,mask,log,logfile,DoExtraIterations,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,0,0);
}
short  Optimise_internalCVPAextcostslSaMSoft(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,vector min_holding,//min_holding and min_trade are now both vectors, i.e. we can have different thresh for each asset
									vector min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util,pModC ModDeriv,pModQ ModHessian,
									double minRisk,double maxRisk,double* ogamma,
									void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,
									vector mask,int log,char* logfile,short DoExtraIterations,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost,int never_slow,size_t* mem_kbytes,
									dimen soft_m,vector soft_l,vector soft_b,vector soft_L,vector soft_U,vector soft_A,double five,double ten,double forty,int*issues)
{
	double lambda_for_U=-1,ent_U_tol=lm_eps;
	bool TimeOpt=false;
	if(Uinfo)
	{
		if(!Util)
		{
			TimeOpt=true;
			ModHessian=0;
			Minfo=((TimeOptExtra*)Uinfo)->costinfo;
			Qinfo=((TimeOptExtra*)Uinfo)->costinfo;
			if(Minfo)
			{
				Util=buysell_cost;
				ModDeriv=buysell_grad;
			}
		}
	}
	if(gamma<0)lambda_for_U=-gamma;//We must be doing Cross Entropy optimisation
	if(lambda_for_U>0)gamma=1./(1+lambda_for_U);
	if(lambda_for_U>0 && lambda_for_U<1e-12){gamma=1;lambda_for_U=0;}

	if(log==2)
	{
		if(!logfile||(logfile&&!strlen(logfile)))
			logfile=(char*)"log.log";
		FILE* OOO=fopen(logfile,"w");
		if(OOO)
		{
			fprintf(OOO,"n\n%d\n",n);
			fprintf(OOO,"nfac\n%d\n",nfac);
			lineprint(OOO,"names",n,names);
			fprintf(OOO,"m\n%d\n",m);
			lineprint(OOO,"A",n*m,A);
			lineprint(OOO,"L",n+m,L);
			fprintf(OOO,"soft_m\n%d\n",soft_m);
			lineprint(OOO,"soft_A",n*soft_m,soft_A);
			lineprint(OOO,"soft_L",soft_m,soft_L);
			lineprint(OOO,"soft_U",soft_m,soft_U);
			lineprint(OOO,"soft_b",soft_m,soft_b);
			lineprint(OOO,"soft_l",soft_m,soft_l);
			lineprint(OOO,"U",n+m,U);
			lineprint(OOO,"alpha",n,alpha);
			lineprint(OOO,"shortalphacost",n,shortalphacost);
			lineprint(OOO,"bench",n,benchmark);
			if(nfac==-1)lineprint(OOO,"Q",(n-ncomp)*(n-ncomp+1)/2,Q);
			else if(Q) lineprint(OOO,"Q",(n-ncomp)*(nfac+1),Q);
			if(SV&&nfac>-1) lineprint(OOO,"SV",(n-ncomp),SV);
			if(FL&&nfac>-1) lineprint(OOO,"FL",(n-ncomp)*nfac,FL);
			if(FC&&nfac>-1) lineprint(OOO,"FC",nfac*(nfac+1)/2,FC);
			fprintf(OOO,"gamma\n%-.8e\n",gamma);
			lineprint(OOO,"initial",n,initial);
			fprintf(OOO,"delta\n%-.8e\n",delta);
			fprintf(OOO,"kappa\n%-.8e\n",kappa);
			fprintf(OOO,"basket\n%d\n",basket);
			fprintf(OOO,"longbasket\n%d\n",longbasket);
			fprintf(OOO,"downrisk\n%d\n",downrisk);
			fprintf(OOO,"downfactor\n%-.8e\n",downfactor);
			fprintf(OOO,"shortbasket\n%d\n",shortbasket);
			fprintf(OOO,"tradebuy\n%d\n",tradebuy);
			fprintf(OOO,"tradesell\n%d\n",tradesell);
			fprintf(OOO,"tradenum\n%d\n",trades);
			fprintf(OOO,"revise\n%d\n",revise);
//			fprintf(OOO,"min_holding\n%-.8e\n",min_holding);
//			fprintf(OOO,"min_trade\n%-.8e\n",min_trade);
			lineprint(OOO,"min_holding",n,min_holding);
			lineprint(OOO,"min_trade",n,min_trade);
			fprintf(OOO,"ls\n%d\n",m_LS);
			fprintf(OOO,"full\n%d\n",Fully_Invested);
			fprintf(OOO,"minRisk\n%-.8e\n",minRisk);
			fprintf(OOO,"maxRisk\n%-.8e\n",maxRisk);
			fprintf(OOO,"rmin\n%-.8e\n",Rmin);
			fprintf(OOO,"rmax\n%-.8e\n",Rmax);
			fprintf(OOO,"round\n%d\n",m_Round);
			lineprint(OOO,"min_lot",n,min_lot);
			lineprint(OOO,"size_lot",n,size_lot);
			//lineprint(OOO,"shake",n,shake);
			fprintf(OOO,"ncomp\n%d\n",ncomp);
			lineprint(OOO,"Composites",(n-ncomp)*ncomp,Composite);
			fprintf(OOO,"value\n%-.8e\n",LSValue);
			fprintf(OOO,"valuel\n%-.8e\n",LSValuel);
			fprintf(OOO,"nabs\n%d\n",nabs);
			lineprint(OOO,"A_abs",n*nabs,Abs_A);
			fprintf(OOO,"mabs\n%d\n",mabs);
			lineprint(OOO,"I_A",mabs,I_A);
			lineprint(OOO,"Abs_U",nabs+mabs,Abs_U);
			lineprint(OOO,"Abs_L",nabs+mabs,Abs_L);
			fprintf(OOO,"ShortCostScale\n%-.8e\n",ShortCostScale);
			lineprint(OOO,"mask",n,mask);
			fprintf(OOO,"log\n%d\n",log);
			lineprint(OOO, "issues", n, issues);
			fprintf(OOO, "five\n%-.8e\n", five);
			fprintf(OOO, "ten\n%-.8e\n", ten);
			fprintf(OOO, "forty\n%-.8e\n", forty);
			fprintf(OOO, "log\n%d\n", log);
			fprintf(OOO,"------------------------------------------------------------------------------------------------\n");
			fflush(OOO);
			fclose(OOO);
		}
	}
	std::valarray<double> Q0;
	if(gamma==1&& !Q)
	{
		Q0.resize((n-ncomp)*(n-ncomp+1)>>1);
		Q=&Q0[0];
	}
	if(ogamma)*ogamma=gamma;
#ifndef _OPENMP
	clock_t timestart=clock();
#else
	double timestart=omp_get_wtime();
#endif
	const char** constrnames=0;
//	if(!check_key((unsigned char*)"colincolin12"))return -1;
#ifdef PAS
//	UnlockBita("colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,"Bad PAS key\n");
		return -1;
	}
#endif
	std::valarray<double> shortalphatest;
	if(shortalphacost)
	{
		shortalphatest.resize(n);
		dzerovec(n,&shortalphatest[0]);
	}
#ifdef MEMORYTEST
	FILE* NEEDMEM=fopen("memoryinfo.txt","w");
	fclose(NEEDMEM);
#endif
#ifdef MEMORYTEST
	clock_t miketime1=clock()/CLOCKS_PER_SEC,miketime2;
	FILE* MIKEOUT=fopen("timestart.txt","w");
	fprintf(MIKEOUT,"Start time %lu\n",miketime1);
	fclose(MIKEOUT);
#endif
//#define DUMP_OUT
#ifdef DUMP_OUT
	FILE* OOO=fopen("s:\\OptDubgmp.log","w");
	if(OOO)
	{
		fprintf(OOO,"n\n%d\n",n);
		fprintf(OOO,"nfac\n%d\n",nfac);
		lineprint(OOO,"names",n,names);
		fprintf(OOO,"m\n%d\n",m);
		lineprint(OOO,"A",n*m,A);
		lineprint(OOO,"L",n+m,L);
		lineprint(OOO,"U",n+m,U);
			fprintf(OOO,"soft_m\n%d\n",soft_m);
			lineprint(OOO,"soft_A",n*soft_m,soft_A);
			lineprint(OOO,"soft_L",soft_m,soft_L);
			lineprint(OOO,"soft_U",soft_m,soft_U);
			lineprint(OOO,"soft_b",soft_m,soft_b);
			lineprint(OOO,"soft_l",soft_m,soft_l);
		lineprint(OOO,"shortalphacost",n,shortalphacost);
		lineprint(OOO,"alpha",n,alpha);
		lineprint(OOO,"bench",n,benchmark);
		fprintf(OOO,"gamma\n%-.8e\n",gamma);
		lineprint(OOO,"initial",n,initial);
		fprintf(OOO,"delta\n%-.8e\n",delta);
//		lineprint(OOO,"buy",n,buy);
//		lineprint(OOO,"sell",n,sell);
		fprintf(OOO,"kappa\n%-.8e\n",kappa);
		fprintf(OOO,"basket\n%d\n",basket);
		fprintf(OOO,"tradenum\n%d\n",trades);
		fprintf(OOO,"revise\n%d\n",revise);
//		fprintf(OOO,"costs\n%d\n",costs);
		fprintf(OOO,"min_holding\n%-.8e\n",min_holding);
		fprintf(OOO,"min_trade\n%-.8e\n",min_trade);
		fprintf(OOO,"ls\n%d\n",m_LS);
		fprintf(OOO,"full\n%d\n",Fully_Invested);
		fprintf(OOO,"rmin\n%-.8e\n",Rmin);
		fprintf(OOO,"rmax\n%-.8e\n",Rmax);
		fprintf(OOO,"round\n%d\n",m_Round);
			fprintf(OOO,"longbasket\n%d\n",longbasket);
			fprintf(OOO,"shortbasket\n%d\n",shortbasket);
			fprintf(OOO,"tradebuy\n%d\n",tradebuy);
			fprintf(OOO,"tradesell\n%d\n",tradesell);
		lineprint(OOO,"min_lot",n,min_lot);
		lineprint(OOO,"size_lot",n,size_lot);
		lineprint(OOO,"shake",n,shake);
		fprintf(OOO,"ncomp\n%d\n",ncomp);
		lineprint(OOO,"Composites",(n-ncomp)*ncomp,Composite);
		fprintf(OOO,"value\n%-.8e\n",LSValue);
		fprintf(OOO,"valuel\n%-.8e\n",LSValuel);
		fprintf(OOO,"ShortCostScale\n%-.8e\n",ShortCostScale);
//		fprintf(OOO,"npiece\n%d\n",npiece);
//		lineprint(OOO,"hpiece",n*npiece,hpiece);
//		lineprint(OOO,"pgrad",n*npiece,pgrad);
		fprintf(OOO,"nabs\n%d\n",nabs);
		lineprint(OOO,"A_abs",n*nabs,Abs_A);
		fprintf(OOO,"mabs\n%d\n",mabs);
		lineprint(OOO,"I_A",mabs,I_A);
		lineprint(OOO,"Abs_U",nabs+mabs,Abs_U);
		lineprint(OOO,"Abs_L",nabs+mabs,Abs_L);
		lineprint(OOO,"mask",n,mask);
		fprintf(OOO,"log\n%d\n",log);
	}
#endif	
	size_t i=0,j=0;
	std::valarray<double>usealpha;
	bool roughen_limit=0;
	if(m_LS)//Mustn't use m_LS options if 1) all the lower asset bounds are non-negative or 2) there are no linear constraints
	{
		bool shortp=false;
		for(i=0;i<n;++i)
		{
			if(L[i]<0)	{shortp=true;break;}
		}
		if(!shortp||!m)	m_LS=0;
	}
	if(m_LS==0)
	{
		Rmin=Rmax=-1;
	}
	if(!alpha)
	{
		usealpha.resize(n);
		usealpha=0;
		alpha=&usealpha[0];
	}
	basket=min((long)n,((size_t)basket));
	trades=min((long)n,((size_t)trades));
	if(longbasket>-1 && shortbasket==-1)shortbasket=(long)n;
	else if(shortbasket>-1 && longbasket==-1)longbasket=(long)n;
	if(tradebuy>-1 && tradesell==-1)tradesell=(long)n;
	else if(tradesell>-1 && tradebuy==-1)tradebuy=(long)n;
	if(longbasket>-1) longbasket=min(longbasket,(long)n);
	if(shortbasket>-1) shortbasket=min(shortbasket,(long)n);
	if(tradebuy>-1) tradebuy=min(tradebuy,(long)n);
	if(tradesell>-1) tradesell=min(tradesell,(long)n);
	if((lambda_for_U<0)&&((revise&&((delta>0&&delta<1&&!m_LS)||(delta>0&&delta<2&&m_LS)))||m_LS||(ModDeriv&&fabs(kappa)>lm_eps)))
		gamma=dmin(gamma,1-lm_eps);
	if(!revise)delta=-1;
	std::stringstream extralog;
	std::valarray<double> minholdlot;
	std::valarray<double> mintradelot;
	std::valarray<double> minlot_use;
	bool tradethresh=false,badbounds=false;

	bool haveneg=false;
	for(i=0;i<n;++i)
	{
		if(L[i]<0){haveneg=true;break;}
	}
	for(i=0;i<m;++i)
	{
		if(U[i+n]<L[i+n]){badbounds=true;break;}
	}
	for(i=0;i<n&&!badbounds;++i)
	{
		if(U[i]<L[i]){badbounds=true;break;}
	}
	if(badbounds)return 9;
	if(m_Round&&min_holding&&!revise)
	{
		minlot_use.resize(n);
		for(i=0;i<n;++i)
		{
			minlot_use[i]=dmax(min_holding[i],min_lot[i]);
		}
		min_lot=&minlot_use[0];
	}
	else if(m_Round&&min_trade&&revise)
	{
		minlot_use.resize(n);
		for(i=0;i<n;++i)
		{
			minlot_use[i]=dmax(min_trade[i],min_lot[i]);
		}
		min_lot=&minlot_use[0];
	}
	if(/*revise &&*/ min_trade)
	{
		mintradelot.resize(n);
		dcopyvec(n,min_trade,&mintradelot[0]);
		//min_trade=-1;
		tradethresh=true;
	}
	if(min_holding)
	{
		minholdlot.resize(n);
		dcopyvec(n,min_holding,&minholdlot[0]);
		//min_holding=-1;
	}
	char* cback;
	short back=-1;
	std::string version;
	double NaturalTurnover;
	int roundlots=0;
	for(i=0;i<m;++i)
	{
		if(BITA_ddot(n,A+i,m,A+i,m)<1e-14)
			printf("Constraint %d is null with bounds L=%f U=%f\n",i,L[n+i],U[n+i]);
	}

	if(nfac==-1)
	{
		bool erm_mess=false;//zerocount(n*(n+1)>>1,Q)!=n*(n+1)>>1;
		Optimise *opter = new Optimise();
		if(TimeOpt)
			opter->TimeOptData=(TimeOptExtra*)Uinfo;
		if(dsumvec((n-ncomp)*(n-ncomp+1)/2,Q) > 0)
		{
			if(!(TimeOpt&&opter->TimeOptData->OptType==SemiVarType))
			{
				if(Q&&fix_covariancem(n-ncomp,Q))
				{
					if(erm_mess)fprintf(stderr,"The input covariance matrix has been modified to make it +ve definite.\n");
				}
			}
		}
		std::valarray<double>c(n);
		opter->five=five;
		opter->ten=ten;
		opter->forty=forty;
		opter->issues=issues;
		opter->firstw=w;
		opter->gamma_for_eps=gamma;
		if(gamma>=1-lm_rooteps) 
			opter->lp_really=1;
		else
			opter->lp_really=0;
		if(log) opter->SetLog();
		version = opter->Version;
		opter->n=n;
		opter->m=m;
		if(soft_m)
		{
			opter->soft_A=soft_A;
			opter->soft_l=soft_l;
			opter->soft_m=soft_m;
			opter->soft_b=soft_b;
		}
		opter->longbasket=longbasket;
		opter->shortbasket=shortbasket;
		opter->tradebuy=tradebuy;
		opter->tradesell=tradesell;
		if(longbasket>-1 && shortbasket>-1 && longbasket+shortbasket<(long)n)
			basket = longbasket+shortbasket;
		if(tradebuy>-1 && tradesell>-1&& tradebuy+tradesell<(long)n)
			trades = tradebuy+tradesell;
		opter->ncomp=ncomp;
		opter->Composites=Composite;
		opter->A=A;
		opter->hmul=(pHmul)HMUL;
		opter->H=Q;
#ifdef DUMP_OUT
		if(OOO)
		{
			lineprint(OOO,"Q",(n-ncomp)*(n-ncomp+1)/2,opter->H);
			fclose(OOO);OOO=0;
		}
#endif	
//kappa was set to .5 in .....blSa() if no costs and we have shortalphacost (i.e. in case someone does it with longshort only and a short alpha problem)
		if(kappa<0)
			opter->scale_utility_external_terms=gamma/(1-gamma);
		else
			opter->scale_utility_external_terms=kappa/(1-kappa);
		opter->Composites=Composite;
		opter->delta=delta;
		opter->Full=Fully_Invested;
		opter->initial=initial;
		opter->lower=L;
		opter->LSValue=LSValue;
		opter->LSValue_Low=LSValuel;
		opter->SLRATmax=Rmax;
		opter->SLRATmin=Rmin;
		opter->upper=U;
		opter->take_out_costs=take_out_costs;
		opter->DoExtraIterations=DoExtraIterations;
		if(opter->scale_utility_external_terms<=lm_eps&&take_out_costs==1)
		{
			opter->take_out_costs=2;
			opter->scale_utility_external_terms=1;
		}
		else
		{
			opter->take_out_costs=take_out_costs;
		}
		if(opter->take_out_costs==2)
			opter->scale_utility_external_terms=1;
		if(opter->take_out_costs == 2)
			opter->DoExtraIterations=0;
		else
			opter->DoExtraIterations=DoExtraIterations;
		opter->mask=mask;
		opter->ShortCostScale=ShortCostScale;
		std::valarray<double> lowerA;
		std::valarray<double> absoluteA;
		if(nabs&&!mabs)
		{
			opter->mabs=nabs;
			opter->absoluteA=Abs_A;
			opter->upperA=Abs_U;
			if(!Abs_L)
			{
				lowerA.resize(nabs);
				lowerA=0;
				opter->lowerA=&lowerA[0];
			}
			else
				opter->lowerA=Abs_L;
		}
		else if(mabs||nabs)
		{
			opter->mabs=mabs+nabs;
			absoluteA.resize((nabs+mabs)*n);
			if(!Abs_L)
			{
				lowerA.resize(mabs+nabs);
				lowerA=0;
				opter->lowerA=&lowerA[0];
			}
			else
				opter->lowerA=Abs_L;
			for(i=0;i<nabs+mabs;++i)
			{
				if(i<nabs)
				{
					for(j=0;j<n;++j)
					{
						absoluteA[j*(nabs+mabs)+i]=Abs_A[i+j*nabs];
					}
				}
				else
				{
					for(j=0;j<n;++j)
					{
						absoluteA[j*(nabs+mabs)+i]=A[I_A[i-nabs]+j*m];
					}
				}
			}
			opter->absoluteA=&absoluteA[0];
			opter->upperA=Abs_U;
		}

		opter->hess_choice=1;
		if(gamma < 1.0-lm_eps)
		{
			if(benchmark)
			{
				if(!opter->ImportantCheck())
				{
					opter->CompSetup();
					opter->use_soft_in_hessmult=false;
					opter->qphess(n,1,1,1,opter->H,benchmark,&c[0]);
					opter->use_soft_in_hessmult=true;
				}
				c=-c;
			}
			else
				c=0;
			daxpyvec(n,-gamma/(1-gamma),alpha,&c[0]);
		}
		else
		{
			opter->lp=1;
			c=0;
			daxpyvec(n,-1.0,alpha,&c[0]);
		}
		if(shortalphacost)
		{
			opter->AddLog("We have cost penalty for short positions\n");
			opter->shortalphacost=&shortalphatest[0];
			daxpyvec(n,opter->scale_utility_external_terms,shortalphacost,opter->shortalphacost);
		}

		opter->c=&c[0];
		if(m_LS && !revise && !ModDeriv) opter->hess_choice=2;
		else if(!m_LS && (revise || (ModDeriv&&!ModHessian))) opter->hess_choice=3;
		else if(m_LS && ((ModDeriv&&!ModHessian) || revise))opter->hess_choice=5;

		if(opter->hess_choice==1&&m_LS)opter->hess_choice=2;
		if(opter->hess_choice==1&&revise)opter->hess_choice=3;
		if(m_LS==2) opter->gross=1;
		else if(m_LS==3) opter->gross=2;


		if(m_LS && gamma==0 && !((opter->TimeOptData&&opter->TimeOptData->costinfo) || (!opter->TimeOptData&&Uinfo)) && !Minfo && !Util &&!ModDeriv&&!ModHessian&&!Qinfo)
			opter->leave_out_trivial=1;
		if(opter->leave_out_trivial&&benchmark&&ddotvec(n,benchmark,benchmark)>10*lm_eps)
			opter->leave_out_trivial=0;

		roundlots=m_Round;
		opter->threshvectort=0;
		opter->threshvector=0;
		if(trades<(long)n||min_trade) 
		{
			opter->drop_to_this=new double[n];
			dcopyvec(n,initial,opter->drop_to_this);
//			dropn=trades;
/*			if(m_Round && nosizelot)
			{
				opter->threshvectort=min_lot;
				roundlots=0;
			}
			else*/
				//opter->threshscalart=min_trade;
				opter->threshvectort=min_trade;
		}
		if(basket<(long)n||min_holding) 
		{
//			dropn=basket;
/*			if(m_Round && nosizelot)
			{
				opter->threshvector=min_lot;
				roundlots=0;
			}
			else*/
				//opter->threshscalar=min_holding;
				opter->threshvector=min_holding;
		}
//		if(dropn==(size_t)-1)
//			dropn=n;
//		opter->DoExtraIterations=0;
		opter->UtilObjectInfo=opter->TimeOptData?opter->TimeOptData->costinfo:Uinfo;
		opter->ModCObjectInfo=Minfo;
		opter->Util=Util;
		opter->ModDeriv=ModDeriv;
		opter->ModHessian=ModHessian;
		opter->ModQObjectInfo=Qinfo;
		if(shake)
		{
			for(i=0;i<n;++i){shake[i]=-1;}
		}
		if(minholdlot.size() || mintradelot.size()||basket<(long)n||trades<(long)n)
		{
			roughen_limit=1;
			opter->dropbad->resize(n);
			(*(opter->dropbad))=0;
		}
		if(minholdlot.size() && trades<(long)n)
		{
			for(i=0;i<n;++i)
			{
				if(fabs(opter->initial[i])>lm_eps&&opter->initial[i]<minholdlot[i])
					(*(opter->dropbad))[i]=1;
			}
		}
		if(mintradelot.size() && basket<(long)n)
		{
			for(i=0;i<n;++i)
			{
				if(fabs(opter->initial[i])>lm_eps&&opter->initial[i]<mintradelot[i])
					(*(opter->dropbad))[i]=1;
			}
		}
		if((mintradelot.size() && minholdlot.size())&&((basket<(long)n)||(trades<(long)n)))
		{
			for(i=0;i<n;++i)
			{
				if(basket<(long)n&&fabs(opter->initial[i])>mintradelot[i] &&
					mintradelot[i]<minholdlot[i])
					(*(opter->dropbad))[i]=1;
				if(trades<(long)n&&fabs(opter->initial[i])>minholdlot[i] &&
					minholdlot[i]<mintradelot[i])
					(*(opter->dropbad))[i]=1;
			}
		}
		if(basket<(long)n)
		{
			for(i=0;i<n;++i)
			{
				if(opter->lower[i]>lm_eps||opter->upper[i]<-lm_eps)
					(*(opter->dropbad))[i]=1;
			}
		}
		if(trades<(long)n)
		{
			for(i=0;i<n;++i)
			{
				if(opter->lower[i]>lm_eps+(opter->initial?opter->initial[i]:0)||opter->upper[i]<-lm_eps+(opter->initial?opter->initial[i]:0))
					(*(opter->dropbad))[i]=1;
			}
		}
		if(maxRisk<0&&minRisk<0 && !downrisk&&lambda_for_U<0)
		{
			size_t hess_choice=opter->hess_choice;
			pModC ModDeriv=opter->ModDeriv;
			pModQ ModHessian=opter->ModHessian;
			if(opter->scale_utility_external_terms==0 && opter->ModDeriv)
			{
				if(hess_choice>3 && (opter->delta>=2 || opter->delta<-lm_eps)) 
					opter->hess_choice=2;
				else if(opter->delta>=2||opter->delta<-lm_eps) 
					opter->hess_choice=1;
				opter->AddLog("No costs here\n");
				opter->ModDeriv=0;
				opter->ModHessian=0;
			}
			try
			{
				//cback = opter->OptSetup(basket,trades);
				cback=opter->AccumOpt(basket,trades);
			}
			catch(MemProb mess)
			{
				printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
				cback =(char*)"Not enough memory for optimisation";
				back=15;
			}
			opter->hess_choice=hess_choice;
			opter->ModDeriv=ModDeriv;
			opter->ModHessian=ModHessian;
			back=opter->back;
			if(opter->x)
			{
				if(roundlots)
				{
					double init,rww,one=1.0;
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						init=(revise?initial[i]:0);
						if(fabs(fabs(opter->x[i])-(rww=fabs(round_weight(opter->x[i],init,min_lot[i],(size_lot?size_lot[i]:0))))) > round_eps)
						{
							if(fabs(fabs(opter->x[i]-init)-min_lot[i])>round_eps)
							{
								if(size_lot&&size_lot[i]>lm_eps)
								{
									long kk=(long)check_digit(floor(one+(fabs(opter->x[i]-init)-min_lot[i])/size_lot[i]));
									if(fabs(kk*size_lot[i]+min_lot[i]-fabs(opter->x[i]-init))>round_eps)
									{
										shake[i]=i;badround++;
									}
								}
							}
							else if(fabs(opter->x[i]-init)-fabs(min_lot[i])<-round_eps)
							{
								shake[i]=i;badround++;
							}
						}
					}
					if(badround)
					{
						for(i=0;i<n;++i){shake[i]=-1;}
						if(revise)opter->Rounding(basket,trades,initial,min_lot,size_lot,w,&minholdlot[0],(minholdlot.size()?min_lot:0));
						else opter->Rounding(basket,trades,0,min_lot,size_lot,w);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						init=(revise?initial[i]:0);
						if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,min_lot[i],(size_lot?size_lot[i]:0))))) > round_eps)
						{
							if(fabs(fabs(w[i]-init)-min_lot[i])>round_eps)
							{
								if(size_lot&&size_lot[i]>lm_eps)
								{
									long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-min_lot[i])/size_lot[i]));
									if(fabs(kk*size_lot[i]+min_lot[i]-fabs(w[i]-init))>round_eps)
									{
										shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*size_lot[i]+min_lot[i]);
									}
								}
							}
							else if(fabs(w[i]-init)-fabs(min_lot[i])<-round_eps)
								shake[i]=i;
						}
					}
				}
				else if(minholdlot.size()&&mintradelot.size())
				{
					//					minholdlot.resize(2*n);
					//					mintradelot.resize(2*n);
					//					dcopyvec(n,&mintradelot[0],&mintradelot[n]);
					//					dcopyvec(n,&minholdlot[0],&minholdlot[n]);
					//					opter->Thresh(basket,trades,initial,&minholdlot[n],&mintradelot[n],w,
					//						&minholdlot[0],&mintradelot[0]);
					OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
					OpSend.m=m;
					OpSend.n=n;
					OpSend.lower=opter->lower;
		OpSend.upper=opter->upper;
		OpSend.x=opter->x;
		OpSend.grad=0;//This is set in Droptwo
		OpSend.OptFunc=BaskInnerOpt;
		OpSend.UtilityFunc=BaskUtility;
		OpSend.GradFunc=BaskGrad;
		OpSend.mabs=mabs;
		OpSend.longbasket=longbasket;
		OpSend.shortbasket=shortbasket;
		OpSend.tradebuy=tradebuy;
		OpSend.tradesell=tradesell;
		OpSend.initial=initial;
//		OpSend.equalbounds=equalbounds;
		OpSend.MoreInfo=opter;
		OpSend.c=opter->c;
		OpSend.logprint=opter->logprint;
		OpSend.basket=basket;
		OpSend.trades=trades;
		size_t badround=0;
					for(i=0;i<n;++i)
					{
						if((fabs(opter->x[i]) > lm_eps && fabs(opter->x[i]) < minholdlot[i]-lm_eps) ||
								(fabs(opter->x[i]-initial[i]) > lm_eps && fabs(opter->x[i]-initial[i]) < mintradelot[i]-lm_eps))
						{
							shake[i] =i;badround++;
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){shake[i]=-1;}
		Thresh(&OpSend,initial,&mintradelot[0],w,&minholdlot[0]);
		opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						if((fabs(w[i]) > lm_eps && fabs(w[i]) < minholdlot[i]-lm_eps) ||
								(fabs(w[i]-initial[i]) > lm_eps && fabs(w[i]-initial[i]) < mintradelot[i]-lm_eps))
							shake[i] =i;
					}
				}
				else if(minholdlot.size())
				{
//					opter->Thresh(basket,trades,0,&minholdlot[0],w);
					OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
					OpSend.m=m;
					OpSend.n=n;
					OpSend.lower=opter->lower;
					OpSend.upper=opter->upper;
					OpSend.x=opter->x;
					OpSend.grad=0;//This is set in Droptwo
					OpSend.OptFunc=BaskInnerOpt;
					OpSend.UtilityFunc=BaskUtility;
					OpSend.GradFunc=BaskGrad;
					OpSend.mabs=mabs;
					OpSend.longbasket=longbasket;
					OpSend.shortbasket=shortbasket;
					OpSend.tradebuy=tradebuy;
					OpSend.tradesell=tradesell;
					OpSend.initial=initial;
					OpSend.MoreInfo=opter;
					OpSend.c=opter->c;
					OpSend.logprint=opter->logprint;
					OpSend.basket=basket;
					OpSend.trades=trades;
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],0,minholdlot[i],0))) > round_eps 
							&& fabs(fabs(opter->x[i])-minholdlot[i])>round_eps)
						{
							shake[i]=i;badround++;
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){shake[i]=-1;}
					Thresh(&OpSend,0,&minholdlot[0],w);
					opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						if(fabs(fabs(w[i])-fabs(round_weight(w[i],0,minholdlot[i],0))) > round_eps && fabs(fabs(w[i])-minholdlot[i])>round_eps)
						{
							shake[i]=i;
						}
					}
				}
				else if(mintradelot.size())
				{
					double init;
//					opter->Thresh(basket,trades,tradethresh?initial:0,&mintradelot[0],w);
					OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
					OpSend.m=m;
					OpSend.n=n;
					OpSend.lower=opter->lower;
					OpSend.upper=opter->upper;
					OpSend.x=opter->x;
					OpSend.grad=0;//This is set in Droptwo
					OpSend.OptFunc=BaskInnerOpt;
					OpSend.UtilityFunc=BaskUtility;
					OpSend.GradFunc=BaskGrad;
					OpSend.mabs=mabs;
					OpSend.longbasket=longbasket;
					OpSend.shortbasket=shortbasket;
					OpSend.tradebuy=tradebuy;
					OpSend.tradesell=tradesell;
					OpSend.initial=initial;
					OpSend.MoreInfo=opter;
					OpSend.c=opter->c;
					OpSend.logprint=opter->logprint;
					OpSend.basket=basket;
					OpSend.trades=trades;
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						init=initial[i];
						if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],init,mintradelot[i],0))) > round_eps 
							&& fabs(fabs(opter->x[i]-init)-mintradelot[i])>round_eps)
						{
							shake[i]=i;badround++;
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){shake[i]=-1;}
					Thresh(&OpSend,initial,&mintradelot[0],w);
					opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						init=initial[i];
						if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,mintradelot[i],0))) > round_eps && fabs(fabs(w[i]-init)-mintradelot[i])>round_eps)
						{
							shake[i]=i;
						}
					}
				}
				else
				{
					dcopyvec(n,opter->x,w);
				}
			}
			back=opter->back;
			if(back==9)back=6;
		}
		else if(fabs(maxRisk-minRisk) < lm_rooteps && !downrisk && lambda_for_U<0)
		{
			std::valarray<double>roundkeepw;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			optinfopasser info;
			info.kappa=kappa;
			info.alpha=alpha;
			info.shortalphacost=shortalphacost;
			info.benchmark=benchmark;
			info.desiredrisk=minRisk;
			info.dropnt=trades;
			info.dropnb=basket;
			info.nfac=-1;
			info.opter=(void*)opter;
			info.optactive_but_set_total=0;
			info.roundlots=roundlots;
			info.basket=basket;
			info.trades=trades;
			info.revise=revise;
			info.initial=initial;
			info.min_lot=min_lot;
			info.size_lot=size_lot;
			info.shake=shake;
			info.tradethresh=tradethresh;
			info.minholdlot=&minholdlot;
			info.mintradelot=&mintradelot;
			info.zetaS=zetaS;
			info.zetaF=zetaF;
			gamma=dmin(1.0-lm_rooteps,gamma);//We don't use gamma for equality risk constraint
			if(roundlots)
			{
				roundkeepw.resize(n);
				info.keepw=&roundkeepw[0];
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),1.0-2*lm_eps,(n<20?1e-12:lm_rooteps),&info);
			}
			else
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),1.0-2*lm_eps,(n<20?lm_eps:lm_rooteps),&info);
			if((long)basket>-1 && (long)basket<n)
			{
				vector lkeep=opter->lower;
				vector ukeep=opter->upper;
				std::valarray<double>L(opter->n+opter->m);
				std::valarray<double>U(opter->n+opter->m);
				for(i=0;i<opter->n+opter->m;++i)
				{
					if(i<opter->n)
					{
						if(fabs(opter->x[i])<lm_eps8)
						{
							L[i]=0;
							U[i]=0;
						}
						else
						{
							L[i]=lkeep[i];
							U[i]=ukeep[i];
						}
					}
					else
					{
						L[i]=lkeep[i];
						U[i]=ukeep[i];
					}
				}
				opter->lower=&L[0];
				opter->upper=&U[0];
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),1.0-2*lm_eps,(n<20?lm_eps:lm_rooteps),&info);
				opter->lower=lkeep;
				opter->upper=ukeep;
			}
			if(opter->back>=1||(TimeOpt&&*ogamma>1))
			{
				while(opter->back==11)//find gamma for which non-linear costs converge
				{
					gamma=.9*gamma;
					opt_func(gamma,&info);
					if(gamma<1e-2) break;
				}
				*ogamma=Solve1D(opt_func,0,gamma,lm_rooteps,&info);
			}
			back=opter->back;
			info.desiredrisk=0;
			if(*ogamma>1&&opter->back<2)
			{
				double hererisk;
				while(1)
				{
					*ogamma=1-lm_rooteps;
					hererisk=opt_func(*ogamma,&info);
					if(hererisk<maxRisk-lm_rooteps)
					{
						back=12;break;
					}
					*ogamma=0;
					hererisk=opt_func(*ogamma,&info);
					if(hererisk>minRisk+lm_rooteps)
					{
						back=12;break;
					}
					break;
				}
			}
			dcopyvec(n,opter->x,w);
			if(roundlots&&back!=6)
			{
				if(*ogamma!=info.keepgamma)
				{
					((Optimise*)(info.opter))->AddLog("Fixup\n");
					*ogamma=info.keepgamma;
					dcopyvec(n,info.keepw,w);
					for(i=0;i<n;i++)
						shake[i]=-1;
					back=info.back;
				}
			}
		}
		else if(fabs(maxRisk-minRisk) >= lm_rooteps && !downrisk&& lambda_for_U<0)
		{
			std::valarray<double>roundkeepw;
			std::valarray<double>minholdlot_here,mintradelot_here;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			optinfopasser info;
			info.kappa=kappa;
			info.alpha=alpha;
			info.shortalphacost=shortalphacost;
			info.benchmark=benchmark;
			info.desiredrisk=0;
			info.dropnt=n;
			info.dropnb=n;
			info.nfac=-1;
			info.opter=(void*)opter;
			info.optactive_but_set_total=0;
			info.roundlots=0;
			info.basket=-1;
			info.trades=-1;
			info.revise=revise;
			info.initial=initial;
			info.min_lot=0;
			info.size_lot=0;
			info.shake=shake;
			info.tradethresh=false;
			info.minholdlot=&minholdlot_here;
			info.mintradelot=&mintradelot_here;
			info.zetaS=zetaS;
			info.zetaF=zetaF;
			if(roundlots)
			{
				roundkeepw.resize(n);
				info.keepw=&roundkeepw[0];
			}
			double hererisk=opt_func(gamma,&info);
			while(opter->back==11)//find gamma for which non-linear costs converge
			{
				gamma=.9*gamma;
				hererisk=opt_func(gamma,&info);
				if(gamma<1e-2) break;
			}
			if((hererisk > maxRisk)&&opter->back<2)
			{
				info.desiredrisk=maxRisk;
				//if(roughen_limit)
				//	maxRisk-=lm_rooteps*bask_fact;
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),gamma,(roughen_limit?100*lm_rooteps:lm_rooteps),&info);
				opter->AddLog("gamma back %f\n",*ogamma);
				//if(roughen_limit)
				//	maxRisk+=lm_rooteps*bask_fact;
				info.dropnt=trades;
				info.dropnb=basket;
				info.roundlots=roundlots;
				info.basket=basket;
				info.trades=trades;
				info.min_lot=min_lot;
				info.size_lot=size_lot;
				info.minholdlot=&minholdlot;
				info.mintradelot=&mintradelot;
				if(*ogamma<1e10)hererisk=opt_func(*ogamma,&info);
				else hererisk=opt_func((haveneg?1e-8:0),&info);
			}
			else if(hererisk < minRisk&&opter->back<2)
			{
				info.desiredrisk=minRisk;
				//if(roughen_limit)
				//	minRisk+=lm_rooteps*bask_fact;
				*ogamma=Solve1D(opt_func,gamma,1-2*lm_eps,(roughen_limit?100*lm_rooteps:lm_rooteps),&info);
				opter->AddLog("gamma back %f\n",*ogamma);
				//if(roughen_limit)
				//	minRisk-=lm_rooteps*bask_fact;
				info.dropnt=trades;
				info.dropnb=basket;
				info.roundlots=roundlots;
				info.basket=basket;
				info.trades=trades;
				info.min_lot=min_lot;
				info.size_lot=size_lot;
				info.minholdlot=&minholdlot;
				info.mintradelot=&mintradelot;
				if(*ogamma<1e10)hererisk=opt_func(*ogamma,&info);
				else hererisk=opt_func(.99999,&info);
			}
			else if(opter->back<2){*ogamma=gamma;}
			back=opter->back;
			dcopyvec(n,opter->x,w);
			if(opter->back<2&&dsumvec(n*(n+1)/2,Q)>lm_eps8)//means we're not doing semivariance
			{
				hererisk=opter->risk(opter->x,(info.optactive_but_set_total?0:info.benchmark));
				if((hererisk>maxRisk+1e-12 && *ogamma > 1) || hererisk>maxRisk+20*lm_rooteps)
					back=12;
				else if((hererisk<minRisk-1e-12 && *ogamma > 1) || hererisk<minRisk-20*lm_rooteps)
					back=12;
			}
			if(roundlots&&back!=6)
			{
				*ogamma=info.keepgamma;
				dcopyvec(n,info.keepw,w);
				for(i=0;i<n;i++)
					shake[i]=-1;
				back=info.back;
			}
		}
		else if(!downrisk && lambda_for_U>=0)
		{
			std::valarray<double>roundkeepw;
			std::valarray<double>minholdlot_here,mintradelot_here;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			entropyinfopasser info;
			info.lambda=lambda_for_U;
			info.alpha=alpha;
			info.shortalphacost=shortalphacost;
			info.benchmark=benchmark;
			info.desiredU=0;
			info.dropnt=n;
			info.dropnb=n;
			info.opter=(void*)opter;
			info.roundlots=0;
			info.basket=-1;
			info.trades=-1;
			info.revise=revise;
			info.initial=initial;
			info.min_lot=0;
			info.size_lot=0;
			info.shake=shake;
			info.tradethresh=false;
			info.minholdlot=&minholdlot_here;
			info.mintradelot=&mintradelot_here;
			info.zetaS=zetaS;
			info.zetaF=zetaF;
			if(!revise)opter->hess_choice=1;
			if(roundlots)
			{
				roundkeepw.resize(n);
				info.keepw=&roundkeepw[0];
			}
			double hererisk=entropy_func(kappa,&info);
			while(opter->back==11)//find kappa for which non-linear costs converge
			{
				kappa=.9*kappa;
				hererisk=entropy_func(kappa,&info);
				if(kappa<1e-2) break;
			}
			if(info.desiredU)
			{
				hererisk*=info.desiredU;
				hererisk+=info.desiredU;
			}
			if((hererisk > maxRisk)&&opter->back<2)
			{
				info.desiredU=maxRisk;
				//if(roughen_limit)
				//	maxRisk-=lm_rooteps*bask_fact;
				*ogamma=Solve1D(entropy_func,(haveneg?1e-8:0),(maxRisk==minRisk?1-1e-13:kappa),(roughen_limit?100*lm_rooteps:ent_U_tol),&info);
				opter->AddLog("entropy_gamma back %f\n",*ogamma);
				//if(roughen_limit)
				//	maxRisk+=lm_rooteps*bask_fact;
				info.dropnt=trades;
				info.dropnb=basket;
				info.roundlots=roundlots;
				info.basket=basket;
				info.trades=trades;
				info.min_lot=min_lot;
				info.size_lot=size_lot;
				info.minholdlot=&minholdlot;
				info.mintradelot=&mintradelot;
				if(*ogamma<1e10)hererisk=entropy_func(*ogamma,&info);
				else hererisk=entropy_func((haveneg?1e-8:0),&info);
				if(info.desiredU)
				{
					hererisk*=info.desiredU;
					hererisk+=info.desiredU;
				}
			}
			else if(hererisk < minRisk&&opter->back<2)
			{
				info.desiredU=minRisk;
				//if(roughen_limit)
				//	minRisk+=lm_rooteps*bask_fact;
				*ogamma=Solve1D(entropy_func,(maxRisk==minRisk?(haveneg?1e-8:0):kappa),1-1e-13,(roughen_limit?100*lm_rooteps:ent_U_tol),&info);
				opter->AddLog("entropy_gamma back %f\n",*ogamma);
				//if(roughen_limit)
				//	minRisk-=lm_rooteps*bask_fact;
				info.dropnt=trades;
				info.dropnb=basket;
				info.roundlots=roundlots;
				info.basket=basket;
				info.trades=trades;
				info.min_lot=min_lot;
				info.size_lot=size_lot;
				info.minholdlot=&minholdlot;
				info.mintradelot=&mintradelot;
				if(*ogamma<1e10)hererisk=entropy_func(*ogamma,&info);
				else hererisk=entropy_func(.99999,&info);
				if(info.desiredU)
				{
					hererisk*=info.desiredU;
					hererisk+=info.desiredU;
				}
			}
			else if(opter->back<2){*ogamma=kappa;}
			back=opter->back;
			dcopyvec(n,opter->x,w);
			if(opter->back<2 && lambda_for_U<0)
			{
				double risk=opter->risk(opter->x,info.benchmark);
				hererisk=-ddotvec(n,info.alpha,opter->x)+(info.benchmark?ddotvec(n,info.alpha,info.benchmark):0)+0.5*risk*risk*info.lambda;
				if((hererisk>maxRisk+1e-12 && *ogamma > 1) || hererisk>maxRisk+20*lm_rooteps)
					back=12;
				else if((hererisk<minRisk-1e-12 && *ogamma > 1) || hererisk<minRisk-20*lm_rooteps)
					back=12;
			}
			else if(opter->back<2 && lambda_for_U>=0)
			{
				if(*ogamma<1e10)hererisk=entropy_func(*ogamma,&info);
				else hererisk=entropy_func((haveneg?1e-8:0),&info);
				if(info.desiredU)
				{
					hererisk*=info.desiredU;
					hererisk+=info.desiredU;
				}

				if(maxRisk==minRisk && fabs(info.desiredU-hererisk)>1e-5)
					back=19;
				else if(maxRisk==info.desiredU && minRisk!=info.desiredU && hererisk>info.desiredU+1e-5)
					back=19;
				else if(minRisk==info.desiredU && maxRisk!=info.desiredU && hererisk<info.desiredU-1e-5)
					back=19;
				if(info.desiredU||back==19) opter->AddLog("%20.8e %20.8e %20.8e %20.8e error %20.8e\n",info.desiredU,hererisk,maxRisk,minRisk,fabs(info.desiredU-hererisk));
			}
			if(roundlots&&back!=6)
			{
				*ogamma=info.keep_entropy_gamma;
				dcopyvec(n,info.keepw,w);
				for(i=0;i<n;i++)
					shake[i]=-1;
				back=info.back;
			}
		}
		else if(downrisk)
		{
			std::valarray<double>roundkeepw;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			downinfopasser info;
			info.kappa=kappa;
			info.alpha=alpha;
			info.benchmark=benchmark;
			info.dropnt=trades;
			info.dropnb=basket;
			info.nfac=-1;
			info.opter=(void*)opter;
			info.roundlots=roundlots;
			info.basket=basket;
			info.trades=trades;
			info.revise=revise;
			info.initial=initial;
			info.min_lot=min_lot;
			info.size_lot=size_lot;
			info.shake=shake;
			info.tradethresh=tradethresh;
			info.minholdlot=&minholdlot;
			info.mintradelot=&mintradelot;
			if(downrisk==1||downrisk==3) info.activedown=0;
			else if(downrisk==2||downrisk==4) info.activedown=1;
			if(downrisk==3||downrisk==4)info.leaveoutreturn=1;
			else if(downrisk==1||downrisk==2)info.leaveoutreturn=0;
			info.desireddown=minRisk;
			info.ret_coef=downfactor;
			double gammatop = gamma,gammarisk,gammatest;
			info.mult=1;
			//First find gamma that gives the desired risk
			//Then find the down side value and change gamma if it is too low
			optinfopasser oinfo;
			oinfo.alpha=alpha;
			oinfo.shortalphacost=shortalphacost;
			oinfo.benchmark=benchmark;
			oinfo.desiredrisk=maxRisk;
			oinfo.dropnt=trades;
			oinfo.dropnb=basket;
			oinfo.nfac=-1;
			oinfo.opter=(void*)opter;
			oinfo.optactive_but_set_total=!info.activedown;
			oinfo.roundlots=roundlots;
			oinfo.basket=basket;
			oinfo.trades=trades;
			oinfo.revise=revise;
			oinfo.initial=initial;
			oinfo.min_lot=min_lot;
			oinfo.size_lot=size_lot;
			oinfo.shake=shake;
			oinfo.tradethresh=tradethresh;
			oinfo.minholdlot=&minholdlot;
			oinfo.mintradelot=&mintradelot;
			oinfo.zetaS=zetaS;
			oinfo.zetaF=zetaF;
			if(roundlots)
			{
				roundkeepw.resize(n);
				oinfo.keepw=&roundkeepw[0];
			}
			opter->back=0;
			if(maxRisk>0)
			{
				gammarisk=gammatop=Solve1D(opt_func,0,1-lm_rooteps,lm_rooteps,&oinfo);
			}
			if(opter->back<2&&down_func(gammatop,&info) < 0)
			{
				double maxdownonfront;
				info.mult=-1;
				gammatop=PathMin(down_func,0,1-lm_rooteps,lm_rooteps,&info,-1);
				maxdownonfront=down_func(gammatop,&info)/info.mult+info.desireddown;
				opter->AddLog("Maximum downside on frontier is %-.14e at gamma = %-.14e\n",maxdownonfront,gammatop);

				info.mult=1;
				if(gammatop<=1&&opter->back<2)
				{
					if(maxRisk>0)
					{
						*ogamma=Solve1D(down_func,1,gammatop,lm_rooteps,&info);
						gammatest=Solve1D(down_func,0,gammatop,lm_rooteps,&info);
						opter->AddLog("gammas which give wanted downside %-.8e %-.8e\n",*ogamma,gammatest);
						if(*ogamma>1 && gammatest>1)
						{
							down_func(gammatop,&info);
							if(opter->back<2)
								opter->back=14;
						}
						else if(gammarisk<=1&&(fabs(*ogamma-gammarisk)>fabs(gammatest-gammarisk)))
						{
							*ogamma=gammatest;
							down_func(gammatest,&info);
						}
						else if(*ogamma>1)
						{
							*ogamma=gammatest;
							down_func(gammatest,&info);
						}
						else
						{
							down_func(*ogamma,&info);
						}
						if(*ogamma<1&&fabs(*ogamma-gammarisk)>lm_rooteps && opter->back<2)
							opter->back=14;
						if(*ogamma<1&&(*ogamma-gammatop)>lm_rooteps && opter->back<2)
							opter->back=14;
					}
					else
					{
						*ogamma=Solve1D(down_func,gamma,gammatop,lm_rooteps,&info);
					}
					back=opter->back;
					if(*ogamma>1) back=6;
				}
				else
				{
					*ogamma=gammatop;back = 6;
				}
			}
			else
			{
				if((gammarisk==gammatop)&&gammatop>1)
				{
					back=(opter->back<2?14:opter->back);
				}
				else
				{
					*ogamma=gamma;
					back=opter->back;
				}
			}
			dcopyvec(n,opter->x,w);
		}
		opter->hess_choice=1;
		NaturalTurnover=opter->NaturalTurnover;
		if(back==15)opter->AddLog("Memory needed %ld kbytes\n",opter->mem_kbytes);
		if(mem_kbytes)*mem_kbytes=opter->mem_kbytes;
		if(log)
			extralog<<opter->logprint->str();
		delete []opter->drop_to_this;
		delete opter;
	}
	else//This is a bit clumsy but I can't think of another way at present... I don't like all this repeated code
	{
		std::valarray<double>c(n);
		FOptimise *opter = new FOptimise();
		if(TimeOpt)
			opter->TimeOptData=(TimeOptExtra*)Uinfo;
		opter->five=five;
		opter->ten=ten;
		opter->forty=forty;
		opter->issues=issues;
		opter->firstw=w;
		opter->gamma_for_eps=gamma;
		if(gamma>=1-lm_rooteps) 
			opter->lp_really=1;
		else
			opter->lp_really=0;
		if(log) opter->SetLog();
		version = opter->Version;
		opter->n=n;
		opter->m=m;
		opter->ncomp=ncomp;
		opter->Composites=Composite;
		opter->A=A;
		if(soft_m)
		{
			opter->soft_A=soft_A;
			opter->soft_l=soft_l;
			opter->soft_m=soft_m;
			opter->soft_b=soft_b;
		}
		opter->longbasket=longbasket;
		opter->shortbasket=shortbasket;
		opter->tradebuy=tradebuy;
		opter->tradesell=tradesell;
		if(longbasket>-1 && shortbasket>-1 && longbasket+shortbasket<(long)n)
			basket = longbasket+shortbasket;
		if(tradebuy>-1 && tradesell>-1&& tradebuy+tradesell<(long)n)
			trades = tradebuy+tradesell;
		if(kappa<0)
			opter->scale_utility_external_terms=gamma/(1-gamma);
		else
			opter->scale_utility_external_terms=kappa/(1-kappa);
		opter->nfac=nfac;
		if(SV)
		{
			opter->SV=SV;
			if(nfac&&FL&&FC)
			{
				opter->FL=FL;
				opter->FC=FC;
				opter->factor_model_process();
			}
			else
			{
				opter->nfac=0;
				opter->H=SV;
			}
			if(Q)
				dcopyvec((n-ncomp)*(nfac+1),opter->H,Q);
		}
		else
		{
			if(!Q)
			{
				std::cout << "!!!!!!!!!!!!!!!!!!!!No risk model given!!!!!!!!!!!!" << std::endl;
				delete opter;
				return -1;
			}
			if(nfac==0)
			{
				double s=dsumvec(n-ncomp,Q);
				if(fabs(s)<lm_rooteps)
					dsetvec(n-ncomp,lm_rooteps,Q);
			}

			opter->H=Q;
		}
#ifdef DUMP_OUT
		if(OOO)
		{
			lineprint(OOO,"Q",(n-ncomp)*(nfac+1),opter->H);
			fclose(OOO);OOO=0;
		}
#endif	
		opter->Composites=Composite;
		opter->delta=delta;
		opter->Full=Fully_Invested;
		opter->initial=initial;
		opter->lower=L;
		opter->LSValue=LSValue;
		opter->LSValue_Low=LSValuel;
		opter->SLRATmax=Rmax;
		opter->SLRATmin=Rmin;
		opter->upper=U;
		opter->take_out_costs=take_out_costs;
		opter->DoExtraIterations=DoExtraIterations;
		if(opter->scale_utility_external_terms<=lm_eps&&take_out_costs==1)
		{
			opter->take_out_costs=2;
			opter->scale_utility_external_terms=1;
		}
		else
		{
			opter->take_out_costs=take_out_costs;
		}
		if(opter->take_out_costs == 2)
			opter->DoExtraIterations=0;
		else
			opter->DoExtraIterations=DoExtraIterations;
		if(opter->take_out_costs==2)
			opter->scale_utility_external_terms=1;
		opter->mask=mask;
		opter->ShortCostScale=ShortCostScale;
		std::valarray<double> lowerA;
		std::valarray<double> absoluteA;
		if(nabs&&!mabs)
		{
			opter->mabs=nabs;
			opter->absoluteA=Abs_A;
			opter->upperA=Abs_U;
			if(!Abs_L)
			{
				lowerA.resize(nabs);
				lowerA=0;
				opter->lowerA=&lowerA[0];
			}
			else
				opter->lowerA=Abs_L;
		}
		else if(mabs||nabs)
		{
			opter->mabs=mabs+nabs;
			absoluteA.resize((nabs+mabs)*n);
			if(!Abs_L)
			{
				lowerA.resize(nabs+mabs);
				lowerA=0;
				opter->lowerA=&lowerA[0];
			}
			else
				opter->lowerA=Abs_L;
			for(i=0;i<nabs+mabs;++i)
			{
				if(i<nabs)
				{
					for(j=0;j<n;++j)
					{
						absoluteA[j*(nabs+mabs)+i]=Abs_A[i+j*nabs];
					}
				}
				else
				{
					for(j=0;j<n;++j)
					{
						absoluteA[j*(nabs+mabs)+i]=A[I_A[i-nabs]+j*m];
					}
				}
			}
			opter->absoluteA=&absoluteA[0];
			opter->upperA=Abs_U;
		}

		opter->hess_choice=1;
		if(gamma < 1.0-lm_eps)
		{
			if(benchmark)
			{
				if(!opter->ImportantCheck())
				{
					opter->CompSetup();
					opter->use_soft_in_hessmult=false;
					opter->qphess(n,1,1,1,opter->H,benchmark,&c[0]);
					opter->use_soft_in_hessmult=true;
				}
				c=-c;
			}
			else
				c=0;
			daxpyvec(n,-gamma/(1-gamma),alpha,&c[0]);
		}
		else
		{
			opter->lp=1;
			c=0;
			daxpyvec(n,-1.0,alpha,&c[0]);
		}
		if(opter->lp_really && nfac==0)
		{
			c=0;
			daxpyvec(n,-1.0,alpha,&c[0]);
		}
		if(m_LS && !revise && !ModDeriv) opter->hess_choice=2;
		else if(!m_LS && (revise || (ModDeriv&&!ModHessian))) opter->hess_choice=3;
		else if(m_LS && ((ModDeriv&&!ModHessian) || revise))opter->hess_choice=5;

		if(m_LS==2) opter->gross=1;
		else if(m_LS==3) opter->gross=2;

		if(m_LS && gamma==0 && !Uinfo && !Minfo && !Util &&!ModDeriv&&!ModHessian&&!Qinfo)
			opter->leave_out_trivial=1;
		if(opter->leave_out_trivial&&benchmark&&ddotvec(n,benchmark,benchmark)>10*lm_eps)
			opter->leave_out_trivial=0;

		if(shortalphacost)
		{
			opter->AddLog("We have cost penalty for short positions\n");
			opter->shortalphacost=&shortalphatest[0];
			daxpyvec(n,opter->scale_utility_external_terms,shortalphacost,opter->shortalphacost);
		}
		roundlots=m_Round;
		opter->threshvectort=0;
		opter->threshvector=0;
		if(trades<(long)n||min_trade) 
		{
			opter->drop_to_this=new double[n];
			dcopyvec(n,initial,opter->drop_to_this);
//			dropn=trades;
/*			if(m_Round && nosizelot)
			{
				opter->threshvectort=min_lot;
				roundlots=0;
			}
			else*/
				//opter->threshscalart=min_trade;
				opter->threshvectort=min_trade;
		}
		if(basket<(long)n||min_holding) 
		{
//			dropn=basket;
/*			if(m_Round && nosizelot)
			{
				opter->threshvector=min_lot;
				roundlots=0;
			}
			else*/
				//opter->threshscalar=min_holding;
				opter->threshvector=min_holding;
		}
//		if(dropn==(size_t)-1)
//			dropn=n;
//		opter->DoExtraIterations=0;
		opter->UtilObjectInfo=opter->TimeOptData?opter->TimeOptData->costinfo:Uinfo;
		opter->ModCObjectInfo=Minfo;
		opter->Util=Util;
		opter->ModDeriv=ModDeriv;
		opter->ModHessian=ModHessian;
		opter->ModQObjectInfo=Qinfo;
		opter->c=&c[0];
		if(shake)
		{
			for(i=0;i<n;++i){shake[i]=-1;}
		}
		if(minholdlot.size() || mintradelot.size()||basket<(long)n||trades<(long)n)
		{
			roughen_limit=1;
			opter->dropbad->resize(n);
			(*(opter->dropbad))=0;
		}
		if(minholdlot.size() && trades<(long)n)
		{
			for(i=0;i<n;++i)
			{
				if(fabs(opter->initial[i])>lm_eps&&opter->initial[i]<minholdlot[i])
					(*(opter->dropbad))[i]=1;
			}
		}
		if(mintradelot.size() && basket<(long)n)
		{
			for(i=0;i<n;++i)
			{
				if(fabs(opter->initial[i])>lm_eps&&opter->initial[i]<mintradelot[i])
					(*(opter->dropbad))[i]=1;
			}
		}
		if((mintradelot.size() && minholdlot.size())&&((basket<(long)n)||(trades<(long)n)))
		{
			for(i=0;i<n;++i)
			{
				if(basket<(long)n&&fabs(opter->initial[i])>mintradelot[i] &&
					mintradelot[i]<minholdlot[i])
					(*(opter->dropbad))[i]=1;
				if(trades<(long)n&&fabs(opter->initial[i])>minholdlot[i] &&
					minholdlot[i]<mintradelot[i])
					(*(opter->dropbad))[i]=1;
			}
		}
		if(basket<(long)n)
		{
			for(i=0;i<n;++i)
			{
				if(opter->lower[i]>lm_eps||opter->upper[i]<-lm_eps)
					(*(opter->dropbad))[i]=1;
			}
		}
		if(trades<(long)n)
		{
			for(i=0;i<n;++i)
			{
				if(opter->lower[i]>lm_eps+(opter->initial?opter->initial[i]:0)||opter->upper[i]<-lm_eps+(opter->initial?opter->initial[i]:0))
					(*(opter->dropbad))[i]=1;
			}
		}
		if(maxRisk<0&&minRisk<0 && !downrisk&&lambda_for_U<0)
		{
			size_t hess_choice=opter->hess_choice;
			if(zetaS!=1)
				dscalvec(n-ncomp,zetaS,opter->H);
			if(zetaF!=1&&nfac>0)
				dscalvec(nfac*(n-ncomp),zetaF,opter->H+n-ncomp);
			pModC ModDeriv=opter->ModDeriv;
			pModQ ModHessian=opter->ModHessian;
			if(opter->scale_utility_external_terms==0 && opter->ModDeriv)
			{
				if(hess_choice>3 && (opter->delta>=2||opter->delta<-lm_eps)) 
					opter->hess_choice=2;
				else if(opter->delta>=2||opter->delta<-lm_eps) 
					opter->hess_choice=1;
				opter->AddLog("No costs here\n");
				opter->ModDeriv=0;
				opter->ModHessian=0;
			}
			try
			{
				cback=opter->AccumOpt(basket,trades);
				//cback = opter->OptSetup(basket,trades);
			}
			catch(MemProb mess)
			{
				printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
				cback =(char*)"Not enough memory for optimisation";
				back=15;
			}
			opter->hess_choice=hess_choice;
			opter->ModDeriv=ModDeriv;
			opter->ModHessian=ModHessian;
			back=opter->back;
			if(zetaS!=1)
				dscalvec(n-ncomp,1.0/zetaS,opter->H);
			if(zetaF!=1&&nfac>0)
				dscalvec(nfac*(n-ncomp),1.0/zetaF,opter->H+n-ncomp);
			size_t badround=0;
			if(opter->x)
			{
				if(roundlots)
				{
					double init,rww,one=1.0;
					for(i=0;i<n;++i)
					{
						init=(revise?initial[i]:0);
						if(fabs(fabs(opter->x[i])-(rww=fabs(round_weight(opter->x[i],init,min_lot[i],(size_lot?size_lot[i]:0))))) > round_eps)
						{
							if(fabs(fabs(opter->x[i]-init)-min_lot[i])>round_eps)
							{
								if(size_lot&&size_lot[i]>lm_eps)
								{
									long kk=(long)check_digit(floor(one+(fabs(opter->x[i]-init)-min_lot[i])/size_lot[i]));
									if(fabs(kk*size_lot[i]+min_lot[i]-fabs(opter->x[i]-init))>round_eps)
									{
										shake[i]=i;badround++;
									}
								}
							}
							else if(fabs(opter->x[i]-init)-fabs(min_lot[i])<-round_eps)
							{
								shake[i]=i;badround++;
							}
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){shake[i]=-1;}
					if(revise)opter->Rounding(basket,trades,initial,min_lot,size_lot,w,&minholdlot[0],(minholdlot.size()?min_lot:0));
					else opter->Rounding(basket,trades,0,min_lot,size_lot,w);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						init=(revise?initial[i]:0);
						if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,min_lot[i],(size_lot?size_lot[i]:0))))) > round_eps)
						{
							if(fabs(fabs(w[i]-init)-min_lot[i])>round_eps)
							{
								if(size_lot&&size_lot[i]>lm_eps)
								{
									long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-min_lot[i])/size_lot[i]));
									if(fabs(kk*size_lot[i]+min_lot[i]-fabs(w[i]-init))>round_eps)
									{
										shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*size_lot[i]+min_lot[i]);
									}
								}
							}
							else if(fabs(w[i]-init)-fabs(min_lot[i])<-round_eps)
								shake[i]=i;
						}
					}
				}
				else if(minholdlot.size()&&mintradelot.size())
				{
//					minholdlot.resize(2*n);
//					mintradelot.resize(2*n);
//					dcopyvec(n,&mintradelot[0],&mintradelot[n]);
//					dcopyvec(n,&minholdlot[0],&minholdlot[n]);
//					opter->Thresh(basket,trades,initial,&minholdlot[n],&mintradelot[n],w,
//						&minholdlot[0],&mintradelot[0]);
		OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
		OpSend.m=m;
		OpSend.n=n;
		OpSend.lower=opter->lower;
		OpSend.upper=opter->upper;
		OpSend.x=opter->x;
		OpSend.grad=0;//This is set in Droptwo
		OpSend.OptFunc=BaskInnerOpt;
		OpSend.UtilityFunc=BaskUtility;
		OpSend.GradFunc=BaskGrad;
		OpSend.mabs=mabs;
		OpSend.longbasket=longbasket;
		OpSend.shortbasket=shortbasket;
		OpSend.tradebuy=tradebuy;
		OpSend.tradesell=tradesell;
		OpSend.initial=initial;
//		OpSend.equalbounds=equalbounds;
		OpSend.MoreInfo=opter;
		OpSend.c=opter->c;
		OpSend.logprint=opter->logprint;
		OpSend.basket=basket;
		OpSend.trades=trades;
		size_t badround=0;
					for(i=0;i<n;++i)
					{
						if((fabs(opter->x[i]) > lm_eps && fabs(opter->x[i]) < minholdlot[i]-lm_eps) ||
								(fabs(opter->x[i]-initial[i]) > lm_eps && fabs(opter->x[i]-initial[i]) < mintradelot[i]-lm_eps))
						{
							shake[i] =i;badround++;
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){shake[i]=-1;}
		Thresh(&OpSend,initial,&mintradelot[0],w,&minholdlot[0]);
		opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						if((fabs(w[i]) > lm_eps && fabs(w[i]) < minholdlot[i]-lm_eps) ||
								(fabs(w[i]-initial[i]) > lm_eps && fabs(w[i]-initial[i]) < mintradelot[i]-lm_eps))
							shake[i] =i;
					}
				}
				else if(minholdlot.size())
				{
					//opter->Thresh(basket,trades,0,&minholdlot[0],w);
					OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
					OpSend.m=m;
					OpSend.n=n;
					OpSend.lower=opter->lower;
					OpSend.upper=opter->upper;
					OpSend.x=opter->x;
					OpSend.grad=0;//This is set in Droptwo
					OpSend.OptFunc=BaskInnerOpt;
					OpSend.UtilityFunc=BaskUtility;
					OpSend.GradFunc=BaskGrad;
					OpSend.mabs=mabs;
					OpSend.longbasket=longbasket;
					OpSend.shortbasket=shortbasket;
					OpSend.tradebuy=tradebuy;
					OpSend.tradesell=tradesell;
					OpSend.initial=initial;
					OpSend.MoreInfo=opter;
					OpSend.c=opter->c;
					OpSend.logprint=opter->logprint;
					OpSend.basket=basket;
					OpSend.trades=trades;
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],0,minholdlot[i],0))) > round_eps 
							&& fabs(fabs(opter->x[i])-minholdlot[i])>round_eps)
						{
							shake[i]=i;badround++;
						}
					}
					if(badround)
					{			
						for(i=0;i<n;++i){shake[i]=-1;}
						Thresh(&OpSend,0,&minholdlot[0],w);
						opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						if(fabs(fabs(w[i])-fabs(round_weight(w[i],0,minholdlot[i],0))) > round_eps && fabs(fabs(w[i])-minholdlot[i])>round_eps)
						{
							shake[i]=i;
						}
					}
				}
				else if(mintradelot.size())
				{
					double init;
//					opter->Thresh(basket,trades,tradethresh?initial:0,&mintradelot[0],w);
					OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
					OpSend.m=m;
					OpSend.n=n;
					OpSend.lower=opter->lower;
					OpSend.upper=opter->upper;
					OpSend.x=opter->x;
					OpSend.grad=0;//This is set in Droptwo
					OpSend.OptFunc=BaskInnerOpt;
					OpSend.UtilityFunc=BaskUtility;
					OpSend.GradFunc=BaskGrad;
					OpSend.mabs=mabs;
					OpSend.longbasket=longbasket;
					OpSend.shortbasket=shortbasket;
					OpSend.tradebuy=tradebuy;
					OpSend.tradesell=tradesell;
					OpSend.initial=initial;
					OpSend.MoreInfo=opter;
					OpSend.c=opter->c;
					OpSend.logprint=opter->logprint;
					OpSend.basket=basket;
					OpSend.trades=trades;
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						init=initial[i];
						if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],init,mintradelot[i],0))) > round_eps 
							&& fabs(fabs(opter->x[i]-init)-mintradelot[i])>round_eps)
						{
							shake[i]=i;badround++;
						}
					}
					if(badround)
					{
			for(i=0;i<n;++i){shake[i]=-1;}
						Thresh(&OpSend,initial,&mintradelot[0],w);
						opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						init=initial[i];
						if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,mintradelot[i],0))) > round_eps && fabs(fabs(w[i]-init)-mintradelot[i])>round_eps)
						{
							shake[i]=i;
						}
					}
				}
				else
				{
					dcopyvec(n,opter->x,w);
				}
			}
			back=opter->back;
			if(back==9)back=6;
		}
		else if(fabs(maxRisk-minRisk) < lm_rooteps && !downrisk && lambda_for_U<0)
		{
			std::valarray<double>roundkeepw;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			optinfopasser info;
			info.kappa=kappa;
			info.alpha=alpha;
			info.shortalphacost=shortalphacost;
			info.benchmark=benchmark;
			info.desiredrisk=minRisk;
			info.dropnt=trades;
			info.dropnb=basket;
			info.nfac=nfac;
			info.opter=(void*)opter;
			info.optactive_but_set_total=0;
			info.zetaS=zetaS;
			info.zetaF=zetaF;
			info.roundlots=roundlots;
			info.basket=basket;
			info.trades=trades;
			info.revise=revise;
			info.initial=initial;
			info.min_lot=min_lot;
			info.size_lot=size_lot;
			info.shake=shake;
			info.tradethresh=tradethresh;
			info.minholdlot=&minholdlot;
			info.mintradelot=&mintradelot;
			info.zetaS=zetaS;
			info.zetaF=zetaF;
			gamma=dmin(1.0-lm_rooteps,gamma);//gamma guess is not used for equality constrained risks
			if(roundlots)
			{
				roundkeepw.resize(n);
				info.keepw=&roundkeepw[0];
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),1-2*lm_eps,(n<20?1e-12:lm_rooteps),&info);
			}
			else
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),1-2*lm_eps,(n<20?lm_eps:lm_rooteps),&info);
			if((long)basket>-1 && (long)basket<n)
			{
				vector lkeep=opter->lower;
				vector ukeep=opter->upper;
				std::valarray<double>L(opter->n+opter->m);
				std::valarray<double>U(opter->n+opter->m);
				for(i=0;i<opter->n+opter->m;++i)
				{
					if(i<opter->n)
					{
						if(fabs(opter->x[i])<lm_eps8)
						{
							L[i]=0;
							U[i]=0;
						}
						else
						{
							L[i]=lkeep[i];
							U[i]=ukeep[i];
						}
					}
					else
					{
						L[i]=lkeep[i];
						U[i]=ukeep[i];
					}
				}
				opter->lower=&L[0];
				opter->upper=&U[0];
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),1-2*lm_eps,(n<20?lm_eps:lm_rooteps),&info);
				opter->lower=lkeep;
				opter->upper=ukeep;
			}
			if(opter->back>=1||(TimeOpt&&*ogamma>1))
			{
				while(opter->back==11)//find gamma for which non-linear costs converge
				{
					gamma=.9*gamma;
					opt_func(gamma,&info);
					if(gamma<1e-2) break;
				}
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),gamma,lm_rooteps,&info);
			}
			back=opter->back;
			info.desiredrisk=0;
			if(*ogamma>1&&opter->back<2)
			{
				double hererisk;
				while(1)
				{
					*ogamma=1-lm_rooteps;
					hererisk=opt_func(*ogamma,&info);
					if(hererisk<maxRisk-lm_rooteps)
					{
						back=12;break;
					}
					*ogamma=0;
					hererisk=opt_func(*ogamma,&info);
					if(hererisk>minRisk+lm_rooteps)
					{
						back=12;break;
					}
				}
			}
			if(roundlots)
			{
				*ogamma=info.keepgamma;
				dcopyvec(n,info.keepw,w);
				for(i=0;i<n;i++)
					shake[i]=-1;
			}
			dcopyvec(n,opter->x,w);
			if(roundlots&&back!=6)
			{
				if(*ogamma!=info.keepgamma)
				{
					((Optimise*)(info.opter))->AddLog("Fixup\n");
					*ogamma=info.keepgamma;
					dcopyvec(n,info.keepw,w);
					for(i=0;i<n;i++)
						shake[i]=-1;
					back=info.back;
				}
			}
		}
		else if(fabs(maxRisk-minRisk) >= lm_rooteps && !downrisk&& lambda_for_U<0)
		{
			std::valarray<double>roundkeepw;
			std::valarray<double>minholdlot_here,mintradelot_here;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			optinfopasser info;
			info.kappa=kappa;
			info.alpha=alpha;
			info.shortalphacost=shortalphacost;
			info.benchmark=benchmark;
			info.desiredrisk=0;
			info.dropnt=n;
			info.dropnb=n;
			info.nfac=nfac;
			info.opter=(void*)opter;
			info.optactive_but_set_total=0;
			info.zetaS=zetaS;
			info.zetaF=zetaF;
			info.roundlots=0;
			info.basket=-1;
			info.trades=-1;
			info.revise=revise;
			info.initial=initial;
			info.min_lot=0;
			info.size_lot=0;
			info.shake=shake;
			info.tradethresh=false;
			info.minholdlot=&minholdlot_here;
			info.mintradelot=&mintradelot_here;
			info.zetaS=zetaS;
			info.zetaF=zetaF;
			if(roundlots)
			{
				roundkeepw.resize(n);
				info.keepw=&roundkeepw[0];
			}
			double hererisk=opt_func(gamma,&info);
			while(opter->back==11)//find gamma for which non-linear costs converge
			{
				gamma=.9*gamma;
				hererisk=opt_func(gamma,&info);
				if(gamma<1e-2) break;
			}
			if((hererisk > maxRisk)&&opter->back<2)
			{
				info.desiredrisk=maxRisk;
				//if(roughen_limit)
				//	maxRisk-=lm_rooteps*bask_fact;
				*ogamma=Solve1D(opt_func,(haveneg?1e-8:0),gamma,(roughen_limit?100*lm_rooteps:lm_rooteps),&info);
				opter->AddLog("gamma back %f\n",*ogamma);
				//if(roughen_limit)
				//	maxRisk+=lm_rooteps*bask_fact;
				info.dropnt=trades;
				info.dropnb=basket;
				info.roundlots=roundlots;
				info.basket=basket;
				info.trades=trades;
				info.min_lot=min_lot;
				info.size_lot=size_lot;
				info.minholdlot=&minholdlot;
				info.mintradelot=&mintradelot;
				if(*ogamma<1e10)hererisk=opt_func(*ogamma,&info);
				else hererisk=opt_func((haveneg?1e-8:0),&info);
			}
			else if(hererisk < minRisk&&opter->back<2)
			{
				info.desiredrisk=minRisk;
				//if(roughen_limit)
				//	minRisk+=lm_rooteps*bask_fact;
				*ogamma=Solve1D(opt_func,gamma,1-2*lm_eps,(roughen_limit?100*lm_rooteps:lm_rooteps),&info);
				opter->AddLog("gamma back %f\n",*ogamma);
				//if(roughen_limit)
				//	minRisk-=lm_rooteps*bask_fact;
				info.dropnt=trades;
				info.dropnb=basket;
				info.roundlots=roundlots;
				info.basket=basket;
				info.trades=trades;
				info.min_lot=min_lot;
				info.size_lot=size_lot;
				info.minholdlot=&minholdlot;
				info.mintradelot=&mintradelot;
				if(*ogamma<1e10)hererisk=opt_func(*ogamma,&info);
				else hererisk=opt_func(.99999,&info);
			}
			else if(opter->back<2){*ogamma=gamma;}


			back=opter->back;
			dcopyvec(n,opter->x,w);
			info.desiredrisk=0;
			if(opter->back<2)
			{
				hererisk=opter->risk(opter->x,(info.optactive_but_set_total?0:info.benchmark));
				if((hererisk>maxRisk+1e-12 && *ogamma > 1) || hererisk>maxRisk+20*lm_rooteps)
					back=12;
				else if((hererisk<minRisk-1e-12 && *ogamma > 1) || hererisk<minRisk-20*lm_rooteps)
					back=12;
			}
			if(roundlots&&back!=6)
			{
				*ogamma=info.keepgamma;
				dcopyvec(n,info.keepw,w);
				for(i=0;i<n;i++)
					shake[i]=-1;
				back=info.back;
			}
		}
		else if(!downrisk && lambda_for_U>=0)
		{
			std::valarray<double>roundkeepw;
			std::valarray<double>minholdlot_here,mintradelot_here;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			entropyinfopasser info;
			info.lambda=lambda_for_U;
			info.alpha=alpha;
			info.shortalphacost=shortalphacost;
			info.benchmark=benchmark;
			info.desiredU=0;
			info.dropnt=n;
			info.dropnb=n;
			info.opter=(void*)opter;
			info.roundlots=0;
			info.basket=-1;
			info.trades=-1;
			info.revise=revise;
			info.initial=initial;
			info.min_lot=0;
			info.size_lot=0;
			info.shake=shake;
			info.tradethresh=false;
			info.minholdlot=&minholdlot_here;
			info.mintradelot=&mintradelot_here;
			info.zetaS=zetaS;
			info.zetaF=zetaF;
			if(!revise)opter->hess_choice=1;
			if(roundlots)
			{
				roundkeepw.resize(n);
				info.keepw=&roundkeepw[0];
			}
			double hererisk=entropy_func(kappa,&info);
			while(opter->back==11)//find kappa for which non-linear costs converge
			{
				kappa=.9*kappa;
				hererisk=entropy_func(kappa,&info);
				if(kappa<1e-2) break;
			}
			if(info.desiredU)
			{
				hererisk*=info.desiredU;
				hererisk+=info.desiredU;
			}
			if((hererisk > maxRisk)&&opter->back<2)
			{
				info.desiredU=maxRisk;
				//if(roughen_limit)
				//	maxRisk-=lm_rooteps*bask_fact;
				*ogamma=Solve1D(entropy_func,(haveneg?1e-8:0),(maxRisk==minRisk?1-1e-13:kappa),(roughen_limit?100*lm_rooteps:ent_U_tol),&info);
				opter->AddLog("entropy_gamma back %f\n",*ogamma);
				//if(roughen_limit)
				//	maxRisk+=lm_rooteps*bask_fact;
				info.dropnt=trades;
				info.dropnb=basket;
				info.roundlots=roundlots;
				info.basket=basket;
				info.trades=trades;
				info.min_lot=min_lot;
				info.size_lot=size_lot;
				info.minholdlot=&minholdlot;
				info.mintradelot=&mintradelot;
				if(*ogamma<1e10)hererisk=entropy_func(*ogamma,&info);
				else hererisk=entropy_func((haveneg?1e-8:0),&info);
			if(info.desiredU)
			{
				hererisk*=info.desiredU;
				hererisk+=info.desiredU;
			}
			}
			else if(hererisk < minRisk&&opter->back<2)
			{
				info.desiredU=minRisk;
				//if(roughen_limit)
				//	minRisk+=lm_rooteps*bask_fact;
				*ogamma=Solve1D(entropy_func,(maxRisk==minRisk?(haveneg?1e-8:0):kappa),1-1e-13,(roughen_limit?100*lm_rooteps:ent_U_tol),&info);
				opter->AddLog("entropy_gamma back %f\n",*ogamma);
				//if(roughen_limit)
				//	minRisk-=lm_rooteps*bask_fact;
				info.dropnt=trades;
				info.dropnb=basket;
				info.roundlots=roundlots;
				info.basket=basket;
				info.trades=trades;
				info.min_lot=min_lot;
				info.size_lot=size_lot;
				info.minholdlot=&minholdlot;
				info.mintradelot=&mintradelot;
				if(*ogamma<1e10)hererisk=entropy_func(*ogamma,&info);
				else hererisk=entropy_func(.99999,&info);
			if(info.desiredU)
			{
				hererisk*=info.desiredU;
				hererisk+=info.desiredU;
			}
			}
			else if(opter->back<2){*ogamma=kappa;}
			back=opter->back;
			dcopyvec(n,opter->x,w);
			if(opter->back<2 && lambda_for_U<0)
			{
				double risk=opter->risk(opter->x,info.benchmark);
				hererisk=-ddotvec(n,info.alpha,opter->x)+(info.benchmark?ddotvec(n,info.alpha,info.benchmark):0)+0.5*risk*risk*info.lambda;
				if((hererisk>maxRisk+1e-12 && *ogamma > 1) || hererisk>maxRisk+20*lm_rooteps)
					back=12;
				else if((hererisk<minRisk-1e-12 && *ogamma > 1) || hererisk<minRisk-20*lm_rooteps)
					back=12;
			}
			else if(opter->back<2 && lambda_for_U>=0)
			{
				if(*ogamma<1e10)hererisk=entropy_func(*ogamma,&info);
				else hererisk=entropy_func((haveneg?1e-8:0),&info);

				if(info.desiredU)
				{
					hererisk*=info.desiredU;
					hererisk+=info.desiredU;
				}
				if(maxRisk==minRisk && fabs(info.desiredU-hererisk)>1e-5)
					back=19;
				else if(maxRisk==info.desiredU && minRisk!=info.desiredU && hererisk>info.desiredU+1e-5)
					back=19;
				else if(minRisk==info.desiredU && maxRisk!=info.desiredU && hererisk<info.desiredU-1e-5)
					back=19;
				if(info.desiredU||back==19) opter->AddLog("%20.8e %20.8e %20.8e %20.8e error %20.8e\n",info.desiredU,hererisk,maxRisk,minRisk,fabs(info.desiredU-hererisk));
			}

			if(roundlots&&back!=6)
			{
				*ogamma=info.keep_entropy_gamma;
				dcopyvec(n,info.keepw,w);
				for(i=0;i<n;i++)
					shake[i]=-1;
				back=info.back;
			}
		}
		else if(downrisk)
		{
			std::valarray<double>roundkeepw;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			downinfopasser info;
			info.kappa=kappa;
			info.alpha=alpha;
			info.benchmark=benchmark;
			info.dropnt=trades;
			info.dropnb=basket;
			info.nfac=nfac;
			info.opter=(void*)opter;
			info.roundlots=roundlots;
			info.basket=basket;
			info.trades=trades;
			info.revise=revise;
			info.initial=initial;
			info.min_lot=min_lot;
			info.size_lot=size_lot;
			info.shake=shake;
			info.tradethresh=tradethresh;
			info.minholdlot=&minholdlot;
			info.mintradelot=&mintradelot;
			if(downrisk==1||downrisk==3) info.activedown=0;
			else if(downrisk==2||downrisk==4) info.activedown=1;
			if(downrisk==3||downrisk==4)info.leaveoutreturn=1;
			else if(downrisk==1||downrisk==2)info.leaveoutreturn=0;
			info.desireddown=minRisk;
			info.ret_coef=downfactor;
			double gammatop = gamma,gammarisk,gammatest;
			info.mult=1;
			//First find gamma that gives the desired risk
			//Then find the down side value and change gamma if it is too low
			optinfopasser oinfo;
			oinfo.shortalphacost=shortalphacost;
			oinfo.alpha=alpha;
			oinfo.benchmark=benchmark;
			oinfo.desiredrisk=maxRisk;
			oinfo.dropnt=trades;
			oinfo.dropnb=basket;
			oinfo.nfac=nfac;
			oinfo.opter=(void*)opter;
			oinfo.optactive_but_set_total=!info.activedown;
			oinfo.roundlots=roundlots;
			oinfo.basket=basket;
			oinfo.trades=trades;
			oinfo.revise=revise;
			oinfo.initial=initial;
			oinfo.min_lot=min_lot;
			oinfo.size_lot=size_lot;
			oinfo.shake=shake;
			oinfo.tradethresh=tradethresh;
			oinfo.minholdlot=&minholdlot;
			oinfo.mintradelot=&mintradelot;
			oinfo.zetaS=zetaS;
			oinfo.zetaF=zetaF;
			opter->back=0;
			if(roundlots)
			{
				roundkeepw.resize(n);
				oinfo.keepw=&roundkeepw[0];
			}
			if(maxRisk>0)
			{
				gammarisk=gammatop=Solve1D(opt_func,0,1-lm_rooteps,lm_rooteps,&oinfo);
			}
			if(opter->back<2&&down_func(gammatop,&info) < 0)
			{
				double maxdownonfront;
				info.mult=-1;
				gammatop=PathMin(down_func,0,1-lm_rooteps,lm_rooteps,&info,-1);
				maxdownonfront=down_func(gammatop,&info)/info.mult+info.desireddown;
				opter->AddLog("Maximum downside on frontier is %-.14e at gamma = %-.14e\n",maxdownonfront,gammatop);

				info.mult=1;
				if(gammatop<=1&&opter->back<2)
				{
					if(maxRisk>0)
					{
						*ogamma=Solve1D(down_func,1,gammatop,lm_rooteps,&info);
						gammatest=Solve1D(down_func,0,gammatop,lm_rooteps,&info);
						opter->AddLog("gammas which give wanted downside %-.8e %-.8e\n",*ogamma,gammatest);
						if(*ogamma>1 && gammatest>1)
						{
							down_func(gammatop,&info);
							if(opter->back<2)
								opter->back=14;
						}
						else if(gammarisk<=1&&(fabs(*ogamma-gammarisk)>fabs(gammatest-gammarisk)))
						{
							*ogamma=gammatest;
							down_func(gammatest,&info);
						}
						else if(*ogamma>1)
						{
							*ogamma=gammatest;
							down_func(gammatest,&info);
						}
						else
						{
							down_func(*ogamma,&info);
						}
						if(*ogamma<1&&fabs(*ogamma-gammarisk)>lm_rooteps && opter->back<2)
							opter->back=14;
						if(*ogamma<1&&(*ogamma-gammatop)>lm_rooteps && opter->back<2)
							opter->back=14;
					}
					else
					{
						*ogamma=Solve1D(down_func,gamma,gammatop,lm_rooteps,&info);
					}
					back=opter->back;
					if(*ogamma>1) back=6;
				}
				else
				{
					*ogamma=gammatop;back = 6;
				}
			}
			else
			{
				if((gammarisk==gammatop)&&gammatop>1)
				{
					back=(opter->back<2?14:opter->back);
				}
				else
				{
					*ogamma=gamma;
					back=opter->back;
				}
			}
			dcopyvec(n,opter->x,w);
		}
		opter->hess_choice=1;
		NaturalTurnover=opter->NaturalTurnover;
		if(back==15)opter->AddLog("Memory needed %ld kbytes\n",opter->mem_kbytes);
		if(mem_kbytes)*mem_kbytes=opter->mem_kbytes;
		if(log)
			extralog<<opter->logprint->str();
		delete []opter->drop_to_this;
		delete opter;
	}
#ifndef _OPENMP
	clock_t timeend=clock();
#else
	double timeend=omp_get_wtime();
#endif

	if(log)
	{
		FILE* OUTF;
		char name[26];
		if(logfile && strlen(logfile))
		{
			OUTF=fopen(logfile,"a");
			if(!OUTF){OUTF=stdout;}
		}
		else{OUTF=stdout;}
		fprintf(OUTF,"%s",extralog.str().c_str());
		fprintf(OUTF,"%s\n",version.c_str());
		if(soft_m)
		{
			fprintf(OUTF,"Soft Constraint Check\n");
			fprintf(OUTF,"%20s %20s %20s %20s\n"," ","Lower bound","Exposure","Upper bound");
			for(i=0;i<soft_m;++i)
			{
				if(constrnames){strncpy(name,constrnames[i],20);name[20]='\0';}
				else{sprintf(name,"Constraint %4u",i+1);}
				fprintf(OUTF,"%20s %20.8e %20.8e %20.8e\n",name,soft_L[i],
					BITA_ddot(n,soft_A+i,soft_m,w,1),soft_U[i]);
			}
		}
		if(m)
		{
			fprintf(OUTF,"Linear Constraint Check\n");
			fprintf(OUTF,"%20s %20s %20s %20s\n"," ","Lower bound","Exposure","Upper bound");
			for(i=0;i<m;++i)
			{
				if(constrnames){strncpy(name,constrnames[i],20);name[20]='\0';}
				else{sprintf(name,"Constraint %4u",i+1);}
				fprintf(OUTF,"%20s %20.8e %20.8e %20.8e\n",name,L[n+i],
					BITA_ddot(n,A+i,m,w,1),U[n+i]);
			}
		}
		fprintf(OUTF,"%20s %20s %20s %20s %20s %20s %20s %20s\n","Name","Initial","Optimal","Benchmark","|Trade|/2","alpha","lower","upper");
		double turn=0,wsum=0,bsum=0,isum=0,iii,trade,longsum=0,shortsum=0,palpha=0;
		for(i=0;i<n;++i)
		{
			iii=(initial?initial[i]:0);
			palpha=(alpha?alpha[i]:0);
			trade=fabs(w[i]-iii)*0.5;
			if(names){strncpy(name,names[i],20);name[20]='\0';}
			else{sprintf(name,"Stock %4u",i+1);}
			fprintf(OUTF,"%20s %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e\n",name,iii,w[i],
				(benchmark?benchmark[i]:0),trade,palpha,L[i],U[i]);
			wsum+=w[i];
			if(benchmark){bsum+=benchmark[i];}
			isum+=iii;
			turn+=trade;
			if(w[i]>0){longsum+=w[i];}
			else{shortsum+=w[i];}
		}
		fprintf(OUTF,"%20s %20.8e %20.8e %20.8e %20.8e\n","Total",isum,wsum,bsum,turn);
		fprintf(OUTF,"\n%20s %20.8e %20s %20.8e\n%20s %20.8e\n","Long",longsum,"Short",shortsum,"Gross",longsum-shortsum);
		if(fabs(longsum)>lm_eps)
			fprintf(OUTF,"%20s %20.8e\n","-Short/Long",-shortsum/longsum);
		if(NaturalTurnover>=0)fprintf(OUTF,"Natural Turnover is %20.8e\n",NaturalTurnover);
		size_t nround=0;
		for(i=0;shake&&i<n;++i)
		{
			if(shake[i] == (int)i) nround++;
		}
		if(nround)
		{
			fprintf(OUTF,"%d stock%s %s not rounded properly\n",nround,(nround>1?"s":" "),
			(nround>1?"were":"was"));
			for(i=0;names&&i<n;++i)
			{
				if(shake[i] == (int)i)
					fprintf(OUTF,"Stock %4d %20s was not rounded\n",i+1,names[i]);
			}
		}
		if(nabs)
		{
			fprintf(OUTF,"Absolute Linear Constraint (Abs_A) Check\n");
			fprintf(OUTF,"%20s %20s %20s %20s\n"," ","Lower bound","Exposure","Upper bound");
			double cval;
			for(i=0;i<nabs;++i)
			{
				sprintf(name,"Abs. Constraint %4u",i+1);
				for(j=0,cval=0;j<n;j++)
					cval+=fabs(w[j])*Abs_A[j*nabs+i];
				fprintf(OUTF,"%20s %20.8e %20.8e %20.8e\n",name,(Abs_L?Abs_L[i]:0),
				cval,Abs_U[i]);
			}
		}
		if(mabs)
		{
			fprintf(OUTF,"Absolute Linear Constraint (I_A) Check\n");
			fprintf(OUTF,"%20s %20s %20s %20s\n"," ","Lower bound","Exposure","Upper bound");
			double cval;
			for(i=0;i<mabs;++i)
			{
				sprintf(name,"Abs. Constraint %4u",(size_t)nabs+i+1);
				for(j=0,cval=0;j<n;j++)
					cval+=fabs(w[j])*A[j*m+I_A[i]];
				fprintf(OUTF,"%20s %20.8e %20.8e %20.8e\n",name,(Abs_L?Abs_L[nabs+i]:0),
				cval,Abs_U[nabs+i]);
			}
		}
		if(mem_kbytes)
			fprintf(OUTF,"Last optimisation attempt required %ld kbytes\n",mem_kbytes[0]);
#ifndef _OPENMP
		fprintf(OUTF,"Time taken %f secs \n",((double)(timeend-timestart)/CLOCKS_PER_SEC));
#else
		fprintf(OUTF,"Time taken %f secs \n",(timeend-timestart));
#endif
		if(logfile && strlen(logfile))
			fclose(OUTF);
		else if(logfile)
			fflush(OUTF);
	}
#ifdef MEMORYTEST
	miketime2=clock()/CLOCKS_PER_SEC;
	FILE* MIKEOUT1=fopen("timefinish.txt","w");
	fprintf(MIKEOUT1,"End time %lu\n",miketime2);
	fprintf(MIKEOUT1,"Time taken %lu secs\n",miketime2-miketime1);
	fclose(MIKEOUT1);
#endif
	return back;
}
short  Optimise_internalCVPAextcostslSaM(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util,pModC ModDeriv,pModQ ModHessian,
									double minRisk,double maxRisk,double* ogamma,
									void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,
									vector mask,int log,char* logfile,short DoExtraIterations,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost,int never_slow,size_t* mem_kbytes)
{
	return Optimise_internalCVPAextcostslSaMS(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,kappa,basket,trades,revise,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,Util,ModDeriv,ModHessian,minRisk,maxRisk,ogamma,Uinfo,Minfo,Qinfo,
		take_out_costs,mask,log,logfile,DoExtraIterations,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,
		mem_kbytes,0,0);
}
short  Optimise_internalCVPAextcostslSaMS(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util,pModC ModDeriv,pModQ ModHessian,
									double minRisk,double maxRisk,double* ogamma,
									void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,
									vector mask,int log,char* logfile,short DoExtraIterations,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost,int never_slow,size_t* mem_kbytes,
									dimen soft_m,double errorBound)
{
	vector soft_L=0,soft_U=0,soft_A=0,soft_l=0,soft_b=0;
	bool within;
	std::valarray<double>Abs_As;
	std::valarray<double> psoft_b,psoft_l;
	double soft_c;
	if(soft_m)
	{
		if(mabs)
		{
			size_t i,j;
			Abs_As.resize((nabs+mabs)*n);
			for(i=0;i<nabs+mabs;++i)
			{
				if(i<nabs)
				{
					Abs_As[j*(nabs+mabs)+i]=Abs_A[i+j*nabs];
				}
				else
				{
					for(j=0;j<n;++j)
					{
						Abs_As[j*(nabs+mabs)+i]=A[I_A[i-nabs]+j*m];
					}
				}
			}
			nabs+=mabs;
			mabs=0;
			Abs_A=&Abs_As[0];
		}
		dmx_transpose(m,n,A,A);
		m=m-soft_m;
		dmx_transpose(n,m,A,A);
		soft_A=A+n*m;
		dmx_transpose(n,soft_m,soft_A,soft_A);
		soft_L=L+n+m;
		soft_U=U+n+m;
		size_t i,j=0;
		psoft_b.resize(soft_m);soft_b=&psoft_b[0];
		psoft_l.resize(soft_m);soft_l=&psoft_l[0];
		for(i=0;i<soft_m;++i)
		{
			soft_b[i]=.5*(soft_L[i]+soft_U[i]);
			soft_l[i]=softbound;
		}
	}
	std::valarray<double>thresh_vec1,thresh_vec2;
	vector minhold=0,mintrade=0;
	if(min_holding>0)
	{
		thresh_vec1.resize(n);
		dsetvec(n,min_holding,&thresh_vec1[0]);
		minhold=&thresh_vec1[0];
	}
	if(min_trade>0)
	{
		thresh_vec2.resize(n);
		dsetvec(n,min_trade,&thresh_vec2[0]);
		mintrade=&thresh_vec2[0];
	}
	short back= Optimise_internalCVPAextcostslSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,kappa,basket,trades,revise,minhold,mintrade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,Util,ModDeriv,ModHessian,minRisk,maxRisk,ogamma,Uinfo,Minfo,Qinfo,
		take_out_costs,mask,log,logfile,DoExtraIterations,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,
		mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A);
	if(soft_m)
	{
		size_t badc=1;
		size_t j =0,i;
		while(j<50&&badc&&back<2)
		{
			for(i=0;i<soft_m;++i)
			{
				within=true;
				soft_c=BITA_ddot(n,soft_A+i,soft_m,w,1);
				if(soft_c>soft_U[i])
				{
					soft_l[i]+=fabs(soft_c-soft_b[i])*softbound;
					soft_b[i]=soft_U[i];
					within=false;
				}
				else if(soft_c<soft_L[i])
				{
					soft_l[i]+=fabs(soft_b[i]-soft_c)*softbound;
					soft_b[i]=soft_L[i];
					within=false;
				}
				else if(j<revert_to_zero)
				{
					soft_l[i]=0;
				}
				//				if(!within)printf("l[%d] = %20.8e\t(%20.8e %20.8e %20.8e)\n",i,soft_l[i],soft_L[i],soft_c,soft_U[i]);
				//				else printf("\t\tl[%d] = %20.8e\t(%20.8e %20.8e %20.8e)\n",i,soft_l[i],soft_L[i],soft_c,soft_U[i]);
			}
			if(j)printf("j = %d; number of constraint violations %d\n",j,badc);
			std::valarray<double>thresh_vec1,thresh_vec2;
			vector minhold=0,mintrade=0;
			if(min_holding>0)
			{
				thresh_vec1.resize(n);
				dsetvec(n,min_holding,&thresh_vec1[0]);
				minhold=&thresh_vec1[0];
			}
			if(min_trade>0)
			{
				thresh_vec2.resize(n);
				dsetvec(n,min_trade,&thresh_vec2[0]);
				mintrade=&thresh_vec2[0];
			}
			back= Optimise_internalCVPAextcostslSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
				delta,kappa,basket,trades,revise,minhold,mintrade,m_LS,Fully_Invested,Rmin,Rmax,
				m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,nabs,Abs_A,mabs,I_A,Abs_U,
				FC,FL,SV,Util,ModDeriv,ModHessian,minRisk,maxRisk,ogamma,Uinfo,Minfo,Qinfo,
				take_out_costs,mask,log,logfile,DoExtraIterations,downrisk,downfactor,longbasket,
				shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,
				mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A);
			++j;
			for(badc=0,i=0;i<soft_m;++i)
			{
				soft_c=BITA_ddot(n,soft_A+i,soft_m,w,1);
				if(soft_c<soft_L[i])
				{
					if((soft_L[i]-soft_c)>errorBound*fabs(soft_L[i]))
					{
						badc++;printf("BAD Lower %d %20.8e value %20.8e\n",i,soft_L[i],soft_c);soft_l[i]*=10;
					}
				}
				else if(soft_c>soft_U[i])
				{
					if((soft_c-soft_U[i])>errorBound*fabs(soft_U[i]))
					{
						badc++;printf("BAD Upper %d %20.8e value %20.8e\n",i,soft_U[i],soft_c);soft_l[i]*=10;
					}
				}
			}
			if(badc==1)printf("Cannot accept %d bound\n",badc);
			else if(badc>1)printf("Cannot accept %d bounds\n",badc);
		}
		
		dmx_transpose(soft_m,n,soft_A,soft_A);
		dmx_transpose(m,n,A,A);
		m+=soft_m;
		dmx_transpose(n,m,A,A);
	}
	return back;
}
short Optimise_internalCVP(dimen n,long nfac,char** names,vector w_opt,dimen m,
                                    vector A,vector L,vector U,vector alpha,
                                    vector benchmark,vector Q,double gamma,vector initial,
                                    double delta,vector buy,vector sell,double kappa,long basket,
                                    long trades,int revise,int costs,double min_holding,double min_trade,
                                    int m_LS,int Fully_Invested,double Rmin,double Rmax,
                                    int m_Round,vector min_lot,vector size_lot,int* shake,dimen ncomp,vector Composites,
									double LSValue,dimen npiece,vector hpiece,vector pgrad)
{
#ifdef _DEBUG
	return Optimise_internalCVPA(n,nfac,names,w_opt,m,A,L,U,alpha,benchmark,Q,gamma,initial,delta,
		buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,
		Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composites,LSValue,npiece,hpiece,pgrad,
		0,0,0,0,0,0,1,0);
#else
	return Optimise_internalCVPA(n,nfac,names,w_opt,m,A,L,U,alpha,benchmark,Q,gamma,initial,delta,
		buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,
		Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composites,LSValue,npiece,hpiece,pgrad,
		0,0,0,0,0,0,0,0);
#endif
}

short  Optimise_internalCVPA(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector mask,int log,char* logfile)
{
#ifdef TZVI_DUMP
	FILE* OOO=fopen("s:\\optCVPA.log","w");
	if(OOO)
	{
		fprintf(OOO,"n\n%d\n",n);
		fprintf(OOO,"nfac\n%d\n",nfac);
		lineprint(OOO,"names",n,names);
		fprintf(OOO,"m\n%d\n",m);
		lineprint(OOO,"A",n*m,A);
		lineprint(OOO,"L",n+m,L);
		lineprint(OOO,"U",n+m,U);
		lineprint(OOO,"alpha",n,alpha);
		lineprint(OOO,"bench",n,benchmark);
		if(nfac==-1)lineprint(OOO,"Q",(n-ncomp)*(n-ncomp+1)/2,Q);
		else lineprint(OOO,"Q",(n-ncomp)*(nfac+1),Q);
		fprintf(OOO,"gamma\n%-.8e\n",gamma);
		lineprint(OOO,"initial",n,initial);
		fprintf(OOO,"delta\n%-.8e\n",delta);
		lineprint(OOO,"buy",n,buy);
		lineprint(OOO,"sell",n,sell);
		fprintf(OOO,"kappa\n%-.8e\n",kappa);
		fprintf(OOO,"basket\n%d\n",basket);
		fprintf(OOO,"tradenum\n%d\n",trades);
		fprintf(OOO,"revise\n%d\n",revise);
		fprintf(OOO,"costs\n%d\n",costs);
		fprintf(OOO,"min_holding\n%-.8e\n",min_holding);
		fprintf(OOO,"min_trade\n%-.8e\n",min_trade);
		fprintf(OOO,"ls\n%d\n",m_LS);
		fprintf(OOO,"full\n%d\n",Fully_Invested);
		fprintf(OOO,"rmin\n%-.8e\n",Rmin);
		fprintf(OOO,"rmax\n%-.8e\n",Rmax);
		fprintf(OOO,"round\n%d\n",m_Round);
		lineprint(OOO,"min_lot",n,min_lot);
		lineprint(OOO,"size_lot",n,size_lot);
		lineprint(OOO,"shake",n,shake);
		fprintf(OOO,"ncomp\n%d\n",ncomp);
		lineprint(OOO,"Composites",(n-ncomp)*ncomp,Composite);
		fprintf(OOO,"value\n%-.8e\n",LSValue);
		fprintf(OOO,"npiece\n%d\n",npiece);
		lineprint(OOO,"hpiece",n*npiece,hpiece);
		lineprint(OOO,"pgrad",n*npiece,pgrad);
		fprintf(OOO,"nabs\n%d\n",nabs);
		lineprint(OOO,"A_abs",n*nabs,Abs_A);
		fprintf(OOO,"mabs\n%d\n",mabs);
		lineprint(OOO,"I_A",mabs,I_A);
		lineprint(OOO,"Abs_U",nabs+mabs,Abs_U);
		lineprint(OOO,"mask",n,mask);
		fprintf(OOO,"log\n%d\n",log);
		fclose(OOO);
	}
#endif	
	return Optimise_internalCVPAF(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,
		Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,
		npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,0,0,0,-1,-1,0,mask,log,logfile);
}
short  Optimise_internalCVPAF(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor)
{
	return Optimise_internalCVPAFb(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,
		Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,
		npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,
		downfactor,-1,-1,-1,-1,1,1,1);
}
short  Optimise_internalCVPAFb(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale)

{
	return Optimise_internalCVPAFbl(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,0,0);
}
short  Optimise_internalCVPAFbl(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L)

{
	return Optimise_internalCVPAFblSa(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,0);
}
short  Optimise_internalCVPAFblSa(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost)

{
	return Optimise_internalCVPAFblSaM(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,0,0);
}
short  Optimise_internalCVPAFblSaM(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost,
									int never_slow,size_t*mem_kbytes)

{
	return Optimise_internalCVPAFblSaMS(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,0,0);
}
short  Optimise_internalCVPAFblSaMS(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost,
									int never_slow,size_t*mem_kbytes,dimen soft_m,double errorBound)

{
	vector soft_L=0,soft_U=0,soft_A=0,soft_l=0,soft_b=0;
	bool within;
	std::valarray<double>Abs_As;
	std::valarray<double> psoft_b,psoft_l;
	double soft_c;
	if(soft_m)
	{
		if(mabs)
		{
			size_t i,j;
			Abs_As.resize((nabs+mabs)*n);
			for(i=0;i<nabs+mabs;++i)
			{
				if(i<nabs)
				{
					Abs_As[j*(nabs+mabs)+i]=Abs_A[i+j*nabs];
				}
				else
				{
					for(j=0;j<n;++j)
					{
						Abs_As[j*(nabs+mabs)+i]=A[I_A[i-nabs]+j*m];
					}
				}
			}
			nabs+=mabs;
			mabs=0;
			Abs_A=&Abs_As[0];
		}
		dmx_transpose(m,n,A,A);
		m=m-soft_m;
		dmx_transpose(n,m,A,A);
		soft_A=A+n*m;
		dmx_transpose(n,soft_m,soft_A,soft_A);
		soft_L=L+n+m;
		soft_U=U+n+m;
		size_t i,j=0;
		psoft_b.resize(soft_m);soft_b=&psoft_b[0];
		psoft_l.resize(soft_m);soft_l=&psoft_l[0];
		for(i=0;i<soft_m;++i)
		{
			soft_b[i]=.5*(soft_L[i]+soft_U[i]);
			soft_l[i]=softbound;
		}
	}
	short back= Optimise_internalCVPAFblSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,
		mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A);
	if(soft_m)
	{
		size_t badc=1;
		size_t j =0,i;
		while(j<50&&badc&&back<2)
		{
			for(i=0;i<soft_m;++i)
			{
				within=true;
				soft_c=BITA_ddot(n,soft_A+i,soft_m,w,1);
				if(soft_c>soft_U[i])
				{
					soft_l[i]+=fabs(soft_c-soft_b[i])*softbound;
					soft_b[i]=soft_U[i];
					within=false;
				}
				else if(soft_c<soft_L[i])
				{
					soft_l[i]+=fabs(soft_b[i]-soft_c)*softbound;
					soft_b[i]=soft_L[i];
					within=false;
				}
				else if(j<revert_to_zero)
				{
					soft_l[i]=0;
				}
//				if(!within)printf("l[%d] = %20.8e\t(%20.8e %20.8e %20.8e)\n",i,soft_l[i],soft_L[i],soft_c,soft_U[i]);
//				else printf("\t\tl[%d] = %20.8e\t(%20.8e %20.8e %20.8e)\n",i,soft_l[i],soft_L[i],soft_c,soft_U[i]);
			}
			if(j)printf("j = %d; number of constraint violations %d\n",j,badc);
			back= Optimise_internalCVPAFblSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
				delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
				m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,
				FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,
				shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,
				soft_m,soft_l,soft_b,soft_L,soft_U,soft_A);
			++j;
			for(badc=0,i=0;i<soft_m;++i)
			{
				soft_c=BITA_ddot(n,soft_A+i,soft_m,w,1);
				if(soft_c<soft_L[i])
				{
					if((soft_L[i]-soft_c)>errorBound*fabs(soft_L[i]))
					{
						badc++;printf("BAD Lower %d %20.8e value %20.8e\n",i,soft_L[i],soft_c);soft_l[i]*=10;
					}
				}
				else if(soft_c>soft_U[i])
				{
					if((soft_c-soft_U[i])>errorBound*fabs(soft_U[i]))
					{
						badc++;printf("BAD Upper %d %20.8e value %20.8e\n",i,soft_U[i],soft_c);soft_l[i]*=10;
					}
				}
			}
			if(badc==1)printf("Cannot accept %d bound\n",badc);
			else if(badc>1)printf("Cannot accept %d bounds\n",badc);
		}
		
		dmx_transpose(soft_m,n,soft_A,soft_A);
		dmx_transpose(m,n,A,A);
		m+=soft_m;
		dmx_transpose(n,m,A,A);
	}
	return back;
}
short  Optimise_internalCVPAFblSaMSoftQ(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost,
									int never_slow,size_t*mem_kbytes,dimen soft_m,vector soft_l,vector soft_b,
									vector soft_L,vector soft_U,vector soft_A,vector qbuy,vector qsell,double five,double ten,double forty,int* issues)

{
	if(log==2)
	{
		if(!logfile||(logfile&&!strlen(logfile)))
			logfile=(char*)"log.log";
		FILE* OOO=fopen(logfile,"w");
		if(OOO)
		{
			fprintf(OOO,"n\n%d\n",n);
			fprintf(OOO,"nfac\n%d\n",nfac);
			lineprint(OOO,"names",n,names);
			fprintf(OOO,"m\n%d\n",m);
			lineprint(OOO,"A",n*m,A);
			lineprint(OOO,"L",n+m,L);
			fprintf(OOO,"soft_m\n%d\n",soft_m);
			lineprint(OOO,"soft_A",n*soft_m,soft_A);
			lineprint(OOO,"soft_L",soft_m,soft_L);
			lineprint(OOO,"soft_U",soft_m,soft_U);
			lineprint(OOO,"soft_b",soft_m,soft_b);
			lineprint(OOO,"soft_l",soft_m,soft_l);
			lineprint(OOO,"U",n+m,U);
			lineprint(OOO,"alpha",n,alpha);
			lineprint(OOO,"shortalphacost",n,shortalphacost);
			lineprint(OOO,"bench",n,benchmark);
			if(nfac==-1)lineprint(OOO,"Q",(n-ncomp)*(n-ncomp+1)/2,Q);
			else if(Q) lineprint(OOO,"Q",(n-ncomp)*(nfac+1),Q);
			if(SV&&nfac>-1) lineprint(OOO,"SV",(n-ncomp),SV);
			if(FL&&nfac>-1) lineprint(OOO,"FL",(n-ncomp)*nfac,FL);
			if(FC&&nfac>-1) lineprint(OOO,"FC",nfac*(nfac+1)/2,FC);
			fprintf(OOO,"gamma\n%-.8e\n",gamma);
			lineprint(OOO,"initial",n,initial);
			fprintf(OOO,"delta\n%-.8e\n",delta);
			lineprint(OOO,"buy",n,buy);
			lineprint(OOO,"sell",n,sell);
			lineprint(OOO,"qbuy",n,qbuy);
			lineprint(OOO,"qsell",n,qsell);
			fprintf(OOO,"kappa\n%-.8e\n",kappa);
			fprintf(OOO,"basket\n%d\n",basket);
			fprintf(OOO,"longbasket\n%d\n",longbasket);
			fprintf(OOO,"downrisk\n%d\n",downrisk);
			fprintf(OOO,"downfactor\n%-.8e\n",downfactor);
			fprintf(OOO,"shortbasket\n%d\n",shortbasket);
			fprintf(OOO,"tradebuy\n%d\n",tradebuy);
			fprintf(OOO,"tradesell\n%d\n",tradesell);
			fprintf(OOO,"tradenum\n%d\n",trades);
			fprintf(OOO,"revise\n%d\n",revise);
			fprintf(OOO,"costs\n%d\n",costs);
			fprintf(OOO,"min_holding\n%-.8e\n",min_holding);
			fprintf(OOO,"min_trade\n%-.8e\n",min_trade);
			fprintf(OOO,"ls\n%d\n",m_LS);
			fprintf(OOO,"full\n%d\n",Fully_Invested);
			fprintf(OOO,"minRisk\n%-.8e\n",minRisk);
			fprintf(OOO,"maxRisk\n%-.8e\n",maxRisk);
			fprintf(OOO,"rmin\n%-.8e\n",Rmin);
			fprintf(OOO,"rmax\n%-.8e\n",Rmax);
			fprintf(OOO,"round\n%d\n",m_Round);
			lineprint(OOO,"min_lot",n,min_lot);
			lineprint(OOO,"size_lot",n,size_lot);
		//	lineprint(OOO,"shake",n,shake);
			fprintf(OOO,"ncomp\n%d\n",ncomp);
			lineprint(OOO,"Composites",(n-ncomp)*ncomp,Composite);
			fprintf(OOO,"value\n%-.8e\n",LSValue);
			fprintf(OOO,"valuel\n%-.8e\n",LSValuel);
			fprintf(OOO,"npiece\n%d\n",npiece);
			lineprint(OOO,"hpiece",n*npiece,hpiece);
			lineprint(OOO,"pgrad",n*npiece,pgrad);
			fprintf(OOO,"nabs\n%d\n",nabs);
			lineprint(OOO,"A_abs",n*nabs,Abs_A);
			fprintf(OOO,"mabs\n%d\n",mabs);
			lineprint(OOO,"I_A",mabs,I_A);
			lineprint(OOO,"Abs_U",nabs+mabs,Abs_U);
			lineprint(OOO,"Abs_L",nabs+mabs,Abs_L);
			fprintf(OOO,"ShortCostScale\n%-.8e\n",ShortCostScale);
			lineprint(OOO,"mask",n,mask);
			lineprint(OOO,"issues",n,issues);
			fprintf(OOO,"five\n%-.8e\n",five);
			fprintf(OOO,"ten\n%-.8e\n",ten);
			fprintf(OOO,"forty\n%-.8e\n",forty);
			fprintf(OOO,"log\n%d\n",log);
			fprintf(OOO,"------------------------------------------------------------------------------------------------\n");
			fflush(OOO);
			fclose(OOO);
			log=1;
		}
	}
#ifdef PAS
//	UnlockBita("colincolin");
	npiece=0;
	soft_m=0;
//	tradesell=tradebuy=longbasket=shortbasket=-1;
	ShortCostScale=1;
	shortalphacost=0;
	if(!Optimise::bitago)
	{
		fprintf(stderr,"Bad PAS key\n");
		return -1;
	}
#endif
/*	long longbasket=-1;
	long shortbasket=-1;
	long tradebuy=-1;
	long tradesell=-1;*/
	if(longbasket>-1 && shortbasket==-1)shortbasket=(long)n;
	else if(shortbasket>-1 && longbasket==-1)longbasket=(long)n;
	if(tradebuy>-1 && tradesell==-1)tradesell=(long)n;
	else if(tradesell>-1 && tradebuy==-1)tradebuy=(long)n;
	if(longbasket>-1) longbasket=min(longbasket,(long)n);
	if(shortbasket>-1) shortbasket=min(shortbasket,(long)n);
	if(tradebuy>-1) tradebuy=min(tradebuy,(long)n);
	if(tradesell>-1) tradesell=min(tradesell,(long)n);
	short back=-1;
	std::valarray<double>thresh_vec1,thresh_vec2;
	vector minhold=0,mintrade=0;
	if(min_holding>0)
	{
		thresh_vec1.resize(n);
		dsetvec(n,min_holding,&thresh_vec1[0]);
		minhold=&thresh_vec1[0];
	}
	if(min_trade>0)
	{
		thresh_vec2.resize(n);
		dsetvec(n,min_trade,&thresh_vec2[0]);
		mintrade=&thresh_vec2[0];
	}
	if(costs>0)//for CURVE
	{
		if(npiece)
		{
			piececostpasser* pcinfo = new piececostpasser;
			pcinfo->hpiece=hpiece;
			pcinfo->initial=initial;
			pcinfo->npiece=npiece;
			pcinfo->nstocks=n;
			pcinfo->pgrad=pgrad;
			pcinfo->ShortCostScale=ShortCostScale;
			back=Optimise_internalCVPAextcostslSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,
				gamma,initial,delta,kappa,basket,trades,revise,minhold,mintrade,m_LS,
				Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composite,
				LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,piece_cost,piece_grad,0,
				minRisk,maxRisk,ogamma,pcinfo,pcinfo,0,(costs?costs-1:0),mask,log,logfile,1,
				downrisk,downfactor,longbasket,shortbasket,tradebuy,tradesell,zetaS,zetaF,
				ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A,five,ten,forty,issues);
			delete pcinfo;
			return back;
		}
		else
		{
			linearcostpasser* lcinfo = new linearcostpasser;
			lcinfo->buy=buy;
			lcinfo->sell=sell;
			lcinfo->qbuy=qbuy;
			lcinfo->qsell=qsell;
			lcinfo->initial=initial;
			lcinfo->nstocks=n;
			lcinfo->ShortCostScale=ShortCostScale;

			back=Optimise_internalCVPAextcostslSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,
				gamma,initial,delta,kappa,basket,trades,revise,minhold,mintrade,m_LS,
				Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composite,
				LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,buysell_cost,buysell_grad,((qbuy&&qsell)?buysell_hess:0),
				minRisk,maxRisk,ogamma,lcinfo,lcinfo,((qbuy&&qsell)?lcinfo:0),(costs?costs-1:0),mask,log,logfile,
				(((m_LS&&ShortCostScale!=1)||(qbuy&&qsell))?1:0),
				downrisk,downfactor,longbasket,shortbasket,tradebuy,tradesell,zetaS,zetaF,
				ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A,five,ten,forty,issues);
			if(costs>1)
			{
				double cost=buysell_cost(n,w,lcinfo);
				double budgy=BITA_ddot(n,A,m,w,1);
				printf("cost %-.8e, weight sum %-.8e, total %-.8e Lower test %-.8e Upper test %-.8e\n",cost,
					budgy,cost+budgy,cost+budgy-L[n],cost+budgy-U[n]);
				if(back<2&&!m_LS && ((cost+budgy-U[n])>1e-5)&& ((cost+budgy-L[n])<-1e-5))
				{
					back=13;
				}
			}
			delete lcinfo;
			return back;
		}
	}
	else
	{
		if(shortalphacost)
			kappa=.5;
		back=Optimise_internalCVPAextcostslSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,
			gamma,initial,delta,kappa,basket,trades,revise,minhold,mintrade,m_LS,
			Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composite,
			LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,0,0,0,minRisk,maxRisk,ogamma,0,
			0,0,0,mask,log,logfile,0,downrisk,downfactor,longbasket,shortbasket,tradebuy,tradesell,
			zetaS,zetaF,1,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A,five,ten,forty,issues);
	}
	return back;
}
short  Optimise_internalCVPAFblSaMSoftQV(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,vector min_holding,
									vector min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost,
									int never_slow,size_t*mem_kbytes,dimen soft_m,vector soft_l,vector soft_b,
									vector soft_L,vector soft_U,vector soft_A,vector qbuy,vector qsell,double five,double ten,double forty,int* issues)

{
	if(log==2)
	{
		if(!logfile||(logfile&&!strlen(logfile)))
			logfile=(char*)"log.log";
		FILE* OOO=fopen(logfile,"w");
		if(OOO)
		{
			fprintf(OOO,"n\n%d\n",n);
			fprintf(OOO,"nfac\n%d\n",nfac);
			lineprint(OOO,"names",n,names);
			fprintf(OOO,"m\n%d\n",m);
			lineprint(OOO,"A",n*m,A);
			lineprint(OOO,"L",n+m,L);
			fprintf(OOO,"soft_m\n%d\n",soft_m);
			lineprint(OOO,"soft_A",n*soft_m,soft_A);
			lineprint(OOO,"soft_L",soft_m,soft_L);
			lineprint(OOO,"soft_U",soft_m,soft_U);
			lineprint(OOO,"soft_b",soft_m,soft_b);
			lineprint(OOO,"soft_l",soft_m,soft_l);
			lineprint(OOO,"U",n+m,U);
			lineprint(OOO,"alpha",n,alpha);
			lineprint(OOO,"shortalphacost",n,shortalphacost);
			lineprint(OOO,"bench",n,benchmark);
			if(nfac==-1)lineprint(OOO,"Q",(n-ncomp)*(n-ncomp+1)/2,Q);
			else if(Q) lineprint(OOO,"Q",(n-ncomp)*(nfac+1),Q);
			if(SV&&nfac>-1) lineprint(OOO,"SV",(n-ncomp),SV);
			if(FL&&nfac>-1) lineprint(OOO,"FL",(n-ncomp)*nfac,FL);
			if(FC&&nfac>-1) lineprint(OOO,"FC",nfac*(nfac+1)/2,FC);
			fprintf(OOO,"gamma\n%-.8e\n",gamma);
			lineprint(OOO,"initial",n,initial);
			fprintf(OOO,"delta\n%-.8e\n",delta);
			lineprint(OOO,"buy",n,buy);
			lineprint(OOO,"sell",n,sell);
			lineprint(OOO,"qbuy",n,qbuy);
			lineprint(OOO,"qsell",n,qsell);
			fprintf(OOO,"kappa\n%-.8e\n",kappa);
			fprintf(OOO,"basket\n%d\n",basket);
			fprintf(OOO,"longbasket\n%d\n",longbasket);
			fprintf(OOO,"downrisk\n%d\n",downrisk);
			fprintf(OOO,"downfactor\n%-.8e\n",downfactor);
			fprintf(OOO,"shortbasket\n%d\n",shortbasket);
			fprintf(OOO,"tradebuy\n%d\n",tradebuy);
			fprintf(OOO,"tradesell\n%d\n",tradesell);
			fprintf(OOO,"tradenum\n%d\n",trades);
			fprintf(OOO,"revise\n%d\n",revise);
			fprintf(OOO,"costs\n%d\n",costs);
			//fprintf(OOO,"min_holding\n%-.8e\n",min_holding);
			lineprint(OOO,"min_holding",n,min_holding);
			lineprint(OOO,"min_trade",n,min_trade);
			//fprintf(OOO,"min_trade\n%-.8e\n",min_trade);
			fprintf(OOO,"ls\n%d\n",m_LS);
			fprintf(OOO,"full\n%d\n",Fully_Invested);
			fprintf(OOO,"minRisk\n%-.8e\n",minRisk);
			fprintf(OOO,"maxRisk\n%-.8e\n",maxRisk);
			fprintf(OOO,"rmin\n%-.8e\n",Rmin);
			fprintf(OOO,"rmax\n%-.8e\n",Rmax);
			fprintf(OOO,"round\n%d\n",m_Round);
			lineprint(OOO,"min_lot",n,min_lot);
			lineprint(OOO,"size_lot",n,size_lot);
			//lineprint(OOO,"shake",n,shake);
			fprintf(OOO,"ncomp\n%d\n",ncomp);
			lineprint(OOO,"Composites",(n-ncomp)*ncomp,Composite);
			fprintf(OOO,"value\n%-.8e\n",LSValue);
			fprintf(OOO,"valuel\n%-.8e\n",LSValuel);
			fprintf(OOO,"npiece\n%d\n",npiece);
			lineprint(OOO,"hpiece",n*npiece,hpiece);
			lineprint(OOO,"pgrad",n*npiece,pgrad);
			fprintf(OOO,"nabs\n%d\n",nabs);
			lineprint(OOO,"A_abs",n*nabs,Abs_A);
			fprintf(OOO,"mabs\n%d\n",mabs);
			lineprint(OOO,"I_A",mabs,I_A);
			lineprint(OOO,"Abs_U",nabs+mabs,Abs_U);
			lineprint(OOO,"Abs_L",nabs+mabs,Abs_L);
			fprintf(OOO,"ShortCostScale\n%-.8e\n",ShortCostScale);
			lineprint(OOO,"mask",n,mask);
			lineprint(OOO,"issues",n,issues);
			fprintf(OOO,"five\n%-.8e\n",five);
			fprintf(OOO,"ten\n%-.8e\n",ten);
			fprintf(OOO,"forty\n%-.8e\n",forty);
			fprintf(OOO,"log\n%d\n",log);
			fprintf(OOO,"------------------------------------------------------------------------------------------------\n");
			fflush(OOO);
			fclose(OOO);
			log=1;
		}
	}
#ifdef PAS
//	UnlockBita("colincolin");
	npiece=0;
	soft_m=0;
//	tradesell=tradebuy=longbasket=shortbasket=-1;
	ShortCostScale=1;
	shortalphacost=0;
	if(!Optimise::bitago)
	{
		fprintf(stderr,"Bad PAS key\n");
		return -1;
	}
#endif
/*	long longbasket=-1;
	long shortbasket=-1;
	long tradebuy=-1;
	long tradesell=-1;*/
	if(longbasket>-1 && shortbasket==-1)shortbasket=(long)n;
	else if(shortbasket>-1 && longbasket==-1)longbasket=(long)n;
	if(tradebuy>-1 && tradesell==-1)tradesell=(long)n;
	else if(tradesell>-1 && tradebuy==-1)tradebuy=(long)n;
	if(longbasket>-1) longbasket=min(longbasket,(long)n);
	if(shortbasket>-1) shortbasket=min(shortbasket,(long)n);
	if(tradebuy>-1) tradebuy=min(tradebuy,(long)n);
	if(tradesell>-1) tradesell=min(tradesell,(long)n);
	short back=-1;
	std::valarray<double>thresh_vec1,thresh_vec2;
	vector minhold=min_holding,mintrade=min_trade;
	if(costs>0)//for CURVE
	{
		if(npiece)
		{
			piececostpasser* pcinfo = new piececostpasser;
			pcinfo->hpiece=hpiece;
			pcinfo->initial=initial;
			pcinfo->npiece=npiece;
			pcinfo->nstocks=n;
			pcinfo->pgrad=pgrad;
			pcinfo->ShortCostScale=ShortCostScale;
			back=Optimise_internalCVPAextcostslSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,
				gamma,initial,delta,kappa,basket,trades,revise,minhold,mintrade,m_LS,
				Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composite,
				LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,piece_cost,piece_grad,0,
				minRisk,maxRisk,ogamma,pcinfo,pcinfo,0,(costs?costs-1:0),mask,log,logfile,1,
				downrisk,downfactor,longbasket,shortbasket,tradebuy,tradesell,zetaS,zetaF,
				ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A,five,ten,forty,issues);
			delete pcinfo;
			return back;
		}
		else
		{
			linearcostpasser* lcinfo = new linearcostpasser;
			lcinfo->buy=buy;
			lcinfo->sell=sell;
			lcinfo->qbuy=qbuy;
			lcinfo->qsell=qsell;
			lcinfo->initial=initial;
			lcinfo->nstocks=n;
			lcinfo->ShortCostScale=ShortCostScale;

			back=Optimise_internalCVPAextcostslSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,
				gamma,initial,delta,kappa,basket,trades,revise,minhold,mintrade,m_LS,
				Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composite,
				LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,buysell_cost,buysell_grad,((qbuy&&qsell)?buysell_hess:0),
				minRisk,maxRisk,ogamma,lcinfo,lcinfo,((qbuy&&qsell)?lcinfo:0),(costs?costs-1:0),mask,log,logfile,
				(((m_LS&&ShortCostScale!=1)||(qbuy&&qsell))?1:0),
				downrisk,downfactor,longbasket,shortbasket,tradebuy,tradesell,zetaS,zetaF,
				ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A,five,ten,forty,issues);
			if(costs>1)
			{
				double cost=buysell_cost(n,w,lcinfo);
				double budgy=BITA_ddot(n,A,m,w,1);
				printf("cost %-.8e, weight sum %-.8e, total %-.8e Lower test %-.8e Upper test %-.8e\n",cost,
					budgy,cost+budgy,cost+budgy-L[n],cost+budgy-U[n]);
				if(back<2&&!m_LS && ((cost+budgy-U[n])>1e-5)&& ((cost+budgy-L[n])<-1e-5))
				{
					back=13;
				}
			}
			delete lcinfo;
			return back;
		}
	}
	else
	{
		if(shortalphacost)
			kappa=.5;
		back=Optimise_internalCVPAextcostslSaMSoft(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,
			gamma,initial,delta,kappa,basket,trades,revise,minhold,mintrade,m_LS,
			Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Composite,
			LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,0,0,0,minRisk,maxRisk,ogamma,0,
			0,0,0,mask,log,logfile,0,downrisk,downfactor,longbasket,shortbasket,tradebuy,tradesell,
			zetaS,zetaF,1,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,soft_m,soft_l,soft_b,soft_L,soft_U,soft_A,five,ten,forty,issues);
	}
	return back;
}
short  Optimise_internalCVPAFblSaMSoft(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector shortalphacost,
									int never_slow,size_t*mem_kbytes,dimen soft_m,vector soft_l,vector soft_b,
									vector soft_L,vector soft_U,vector soft_A)

{
			short back= Optimise_internalCVPAFblSaMSoftQ(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
				delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
				m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,
				FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,
				shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,shortalphacost,never_slow,mem_kbytes,
				soft_m,soft_l,soft_b,soft_L,soft_U,soft_A,0,0);
			return back;
}
short  Optimise_internalCVPAFblQ(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk,double maxRisk,
									double* ogamma,vector mask,int log,char* logfile,
									int downrisk,double downfactor,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale,double LSValuel,vector Abs_L,vector qbuy,vector qsell)

{
	return Optimise_internalCVPAFblSaMSoftQ(n,nfac,names,w,m,A,L,U,alpha,benchmark,Q,gamma,initial,
		delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,
		m_Round,min_lot,size_lot,shake,ncomp,Composite,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,
		FC,FL,SV,minRisk,maxRisk,ogamma,mask,log,logfile,downrisk,downfactor,longbasket,
		shortbasket,tradebuy,tradesell,zetaS,zetaF,ShortCostScale,LSValuel,Abs_L,0,1,0,0,0,0,0,0,0,qbuy,qsell);
}
void PropertiesC(dimen n,long nfac,char** names,vector w,vector alpha,
                                    vector benchmark,
                                    vector Q,double* risk,double* arisk,double* Rrisk,
									double* rreturn,
                                    double* areturn,double* Rreturn,
                                    vector MCAR,vector MCTR,vector MCRR,vector FMCRR,
                                    vector FMCTR,vector   beta,vector FX,vector RFX,
                                    vector  FL,vector FC,vector SV,dimen ncomp,
									vector Composites)
{
	PropertiesCA(n,nfac,names,w,benchmark,alpha,rreturn,areturn,Rreturn,0,Q,risk,arisk,Rrisk,0,
		0,&beta[n],MCAR,MCTR,MCRR,0,FMCRR,FMCTR,0,0,0,beta,FX,RFX,0,0,0,FL,FC,SV,ncomp,
		Composites);
}
void 	PropertiesCA(dimen n,long nfac,char** names,vector w,
									  vector benchmark,
									  vector alpha,real *rreturn,real *areturn,real *Rreturn,
									  real *breturn,
									  vector Q,real *risk,real *arisk,real *Rrisk,real *brisk,
									  real *srisk,
									  real *pbeta,
									  vector MCAR,vector MCTR,vector MCRR,vector MCBR,
									  vector FMCRR,
									  vector FMCTR,vector FMCAR,vector FMCBR,vector FMCSR,
									  vector	beta,
									  vector FX,vector RFX,vector AFX,vector BFX,vector SFX,
									  vector  FL,vector FC,vector SV,dimen ncomp,
									  vector Composite)
{
	std::valarray<double> Q0;
	if(nfac==-1&& !Q)
	{
		Q0.resize((n-ncomp)*(n-ncomp+1)>>1);
		Q=&Q0[0];
	}
#ifdef PAS
//	UnlockBita("colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,"Bad PAS key\n");
		return;
	}
#endif
	bool log=1;
#ifdef _DEBUG
	log=1;
#endif
	std::valarray<double> bench,bbeta;
	std::valarray<double>usealpha;
	if(!alpha)
	{
		usealpha.resize(n);
		usealpha=0;
		alpha=&usealpha[0];
	}
	if(!benchmark){bench.resize(n);benchmark=&bench[0];}
	if(!beta){bbeta.resize(n);beta=&bbeta[0];}
	if(nfac==-1)
	{
		real ppbeta,bbreturn;
		bool erm_mess=false;//zerocount(n*(n+1)>>1,Q)!=n*(n+1)>>1;

		if(fix_covariancem(n-ncomp,Q))
		{
			if(erm_mess)fprintf(stderr,"The input covariance matrix has been modified to make it +ve definite.\n");
		}
		Optimise* Prop=new Optimise;
		if(Prop->checker->number_of_days_left<=-1) return;
		Prop->n=n;
		Prop->ncomp=ncomp;
		if(ncomp)Prop->Composites=Composite;
		Prop->H=Q;
		Prop->hmul=(pHmul)HMUL;
		Prop->beta(benchmark,beta);
		ppbeta=ddotvec(n,w,beta);
		if(pbeta) *pbeta=ppbeta;
		if(areturn) *areturn=ddotvec(n,w,alpha);
		bbreturn=ddotvec(n,benchmark,alpha);
		if(breturn) *breturn=bbreturn;
		if(rreturn&&areturn) *rreturn=*areturn-bbreturn;
		std::valarray<double>resid(n);
		dcopyvec(n,w,&resid[0]);
		daxpyvec(n,-ppbeta,benchmark,&resid[0]);
		if(Rreturn&&areturn) *Rreturn=*areturn - ppbeta * bbreturn;
		Prop->MC(w,0,MCTR);
		Prop->MC(benchmark,0,MCBR);
		Prop->MC(w,benchmark,MCAR);
		Prop->MC(&resid[0],0,MCRR);
		if(arisk&&MCTR)*arisk=ddotvec(n,w,MCTR);
		if(Rrisk&&MCRR)*Rrisk=ddotvec(n,&resid[0],MCRR);					//Residual risk
		if(risk&&MCAR)*risk=ddotvec(n,w,MCAR)-ddotvec(n,benchmark,MCAR);
		if(brisk&&MCBR)*brisk=ddotvec(n,benchmark,MCBR);
		if(srisk&&arisk&&Rrisk)*srisk = sqrt(*arisk * *arisk - *Rrisk * *Rrisk);	//Systematic risk
		delete Prop;
	}
	else
	{
		real ppbeta,bbreturn;
		FOptimise* Prop=new FOptimise;
		if(Prop->checker->number_of_days_left<=-1) return;
		if(log)Prop->SetLog();
		Prop->n=n;
		Prop->nfac=nfac;
		Prop->ncomp=ncomp;
		if(ncomp)Prop->Composites=Composite;
		Prop->SV=SV;
		Prop->FL=FL;
		Prop->FC=FC;
		if(nfac>0&&SV&&FL&&FC)
			Prop->factor_model_process();
		else if(!nfac&&SV)
			Prop->H=SV;
		else
			Prop->H=Q;
		Prop->beta(benchmark,beta);
		ppbeta=ddotvec(n,w,beta);
		if(pbeta)*pbeta=ppbeta;
		if(areturn)*areturn=ddotvec(n,w,alpha);
		bbreturn=ddotvec(n,benchmark,alpha);
		if(breturn)*breturn=bbreturn;
		if(rreturn&&areturn)*rreturn=*areturn-bbreturn;
		std::valarray<double>resid(n);
		dcopyvec(n,w,&resid[0]);
		daxpyvec(n,-ppbeta,benchmark,&resid[0]);
		if(Rreturn&&areturn)*Rreturn=*areturn - ppbeta * bbreturn;
		Prop->MC(w,0,MCTR);
		Prop->MC(benchmark,0,MCBR);
		Prop->MC(w,benchmark,MCAR);
		Prop->MC(&resid[0],0,MCRR);
		if(arisk&&MCTR)*arisk=ddotvec(n,w,MCTR);
		if(Rrisk&&MCRR)*Rrisk=ddotvec(n,&resid[0],MCRR);					//Residual risk
		if(risk&&MCAR)*risk=ddotvec(n,w,MCAR)-ddotvec(n,benchmark,MCAR);
		if(brisk&&MCBR)*brisk=ddotvec(n,benchmark,MCBR);
		if(srisk&&arisk&&Rrisk)*srisk = sqrt(*arisk * *arisk - *Rrisk * *Rrisk);	//Systematic risk
		if(SV&&FC&&FL)
		{
			Prop->FMC(w,0,FMCTR,FX);
			Prop->FMC(w,benchmark,FMCAR,AFX);
			Prop->FMC(benchmark,0,FMCBR,BFX);
			Prop->FMC(&resid[0],0,FMCRR,RFX);
			double fac,nonfac;
			if(log&&FMCTR&&FX&&arisk)
			{
				printf("Absolute factor risk\t\t%-.8e\n",fac=ddotvec(nfac,FMCTR,FX));
				printf("Absolute non-factor risk\t%-.8e\n",nonfac=ddotvec(n,FMCTR+nfac,w));
				printf("Check abs. risk\t\t\t%-.8e %-.8e\n",*arisk,sqrt(fac*fac+nonfac*nonfac));
			}
			if(log&&FMCAR&&AFX&&risk)
			{
				printf("Active factor risk\t\t%-.8e\n",fac=ddotvec(nfac,FMCAR,AFX));
				printf("Active non-factor risk\t\t%-.8e\n",nonfac=(ddotvec(n,FMCAR+nfac,w)-ddotvec(n,FMCAR+nfac,benchmark)));
				printf("Check active risk\t\t%-.8e %-.8e\n",*risk,sqrt(fac*fac+nonfac*nonfac));
			}
			if(log&&FMCRR&&RFX&&Rrisk)
			{
				printf("Residual factor risk\t\t%-.8e\n",fac=ddotvec(nfac,FMCRR,RFX));
				printf("Residual non-factor risk\t%-.8e\n",nonfac=(ddotvec(n,FMCRR+nfac,w)-ppbeta*ddotvec(n,FMCRR+nfac,benchmark)));
				printf("Check residual risk\t\t%-.8e %-.8e\n",*Rrisk,sqrt(fac*fac+nonfac*nonfac));
			}
			if(FMCBR&&FMCSR)dcopyvec(n+nfac,FMCBR,FMCSR);//Factor MC systematic risk Qbetab/sqrt(betab.Q.betab)
			if(AFX&&RFX&&SFX)dsubvec(nfac,AFX,RFX,SFX);//Systematic Exposures
		}
		delete Prop;
	}
}
void	GetBeta(dimen n,long nfac,vector benchmark,vector Q,vector beta,dimen ncomp,vector Composite)
{
	std::valarray<double> bench;
	if(!benchmark){bench.resize(n);benchmark=&bench[0];}
	if(nfac==-1)
	{
		Optimise Prop;
		if(Prop.checker->number_of_days_left<=-1) return;
		Prop.n=n;
		Prop.ncomp=ncomp;
		if(ncomp)	Prop.Composites=Composite;
		Prop.H=Q;
		Prop.beta(benchmark,beta);
	}
	else
	{
		FOptimise Prop;
		if(Prop.checker->number_of_days_left<=-1) return;
		Prop.n=n;
		Prop.nfac=nfac;
		Prop.ncomp=ncomp;
		if(ncomp)	Prop.Composites=Composite;
		Prop.H=Q;
		Prop.beta(benchmark,beta);
	}
}
void Get_RisksC(dimen n,long nfac,vector Q,vector w,vector benchmark,double* arisk,
									 double* risk,double* Rrisk,double* brisk,
									 double *pbeta,dimen ncomp,vector Composite)
{
/*	FILE* oup=fopen("outdump","w");
	size_t i;
	if(Q)
	{
		for(i=0;i<(n-ncomp)*(nfac+1);i++)
			fprintf(oup,"Q %20.10e\n",Q[i]);
	}
	if(w)
	{
		for(i=0;i<n;i++)
			fprintf(oup,"w %20.10e\n",w[i]);
	}
	fclose(oup);*/
	std::valarray<double> bench;
	if(!benchmark){bench.resize(n);benchmark=&bench[0];}
	FOptimise*PProp=0;
	if(nfac==-1)
	{
		bool erm_mess=false;//zerocount(n*(n+1)>>1,Q)!=n*(n+1)>>1;
		if(fix_covariancem(n-ncomp,Q))
		{
			if(erm_mess)fprintf(stderr,"The input covariance matrix has been modified to make it +ve definite.\n");
		}
		Optimise* Prop=new Optimise;
#ifndef _DEBUG
		if(Prop->checker->number_of_days_left<=-1) return;
#endif
		Prop->n=n;
		PProp=(FOptimise*)Prop;
	}
	else
	{
		FOptimise* Prop=new FOptimise;
#ifndef _DEBUG
		if(Prop->checker->number_of_days_left<=-1) return;
#endif
		Prop->n=n;
		Prop->nfac=nfac;
		PProp=Prop;
	}
	PProp->ncomp=ncomp;
	if(ncomp)	PProp->Composites=Composite;
	PProp->H=Q;
	std::valarray<double>res(n);
	PProp->beta(benchmark,&res[0]);
	*pbeta=ddotvec(n,w,&res[0]);
	*arisk=PProp->risk(w,0);
	*risk=PProp->risk(w,benchmark);
	dcopyvec(n,w,&res[0]);
	daxpyvec(n,-*pbeta,benchmark,&res[0]);
	*Rrisk=PProp->risk(&res[0],0);
	*brisk=PProp->risk(benchmark,0);
	if(nfac==-1)
	{
		delete (Optimise*)PProp;
	}
	else
	{
		delete PProp;
	}
}
short FrontierCVPA(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector mask)
{
	return FrontierCVPAF(npoints,risk,arisk,rreturn,areturn,n,nfac,names,w,m,A,L,U,alpha,
		benchmark,Q,initial,delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,
		min_trade,m_LS,Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,
		ncomp,Comp,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,0,0,0,mask);
}
short FrontierCVPF(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									vector FC,vector FL,vector SV,vector mask,int DoByRisks)
{
	return FrontierCVPAF(npoints,risk,arisk,rreturn,areturn,n,nfac,names,w,m,A,L,U,alpha,
		benchmark,Q,initial,delta,buy,sell,kappa,basket,trades,revise,costs,min_holding,
		min_trade,m_LS,Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,
		Comp,LSValue,npiece,hpiece,pgrad,0,0,0,0,0,FC,FL,SV,mask,DoByRisks);
}
/*short FrontierCVPFlog(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,dimen basket,
									dimen trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									vector FC,vector FL,vector SV,vector mask,int DoByRisks)
{
	FILE* OOO=fopen("s:\\Frontier.log","w");
	fprintf(OOO,"npoints\n%d\n",npoints);
	lineprint(OOO,"risk",n*npoints,risk);
	lineprint(OOO,"arisk",n*npoints,arisk);
	lineprint(OOO,"rreturn",n*npoints,rreturn);
	lineprint(OOO,"areturn",n*npoints,areturn);
	fprintf(OOO,"n\n%d\n",n);
	fprintf(OOO,"nfac\n%d\n",nfac);
	lineprint(OOO,"names",n,names);
	lineprint(OOO,"w",n*npoints,w);
	fprintf(OOO,"m\n%d\n",m);
	lineprint(OOO,"A",n*m,A);
	lineprint(OOO,"L",n+m,L);
	lineprint(OOO,"U",n+m,U);
	lineprint(OOO,"alpha",n,alpha);
	lineprint(OOO,"benchmark",n,benchmark);
	if(nfac==-1)
		lineprint(OOO,"Q",(n-ncomp)*(n-ncomp+1)/2,Q);
	else
		lineprint(OOO,"Q",(n-ncomp)*(nfac+1),Q);
	lineprint(OOO,"initial",n,initial);
	fprintf(OOO,"delta\n%-.e\n",delta);
	lineprint(OOO,"buy",n,buy);
	lineprint(OOO,"sell",n,sell);
	fprintf(OOO,"kappa\n%-.e\n",kappa);
	fprintf(OOO,"basket\n%d\n",basket);
	fprintf(OOO,"trades\n%d\n",trades);
	fprintf(OOO,"revise\n%d\n",revise);
	fprintf(OOO,"costs\n%d\n",costs);
	fprintf(OOO,"min_holding\n%-.e\n",min_holding);
	fprintf(OOO,"min_trade\n%-.e\n",min_trade);
	fprintf(OOO,"m_LS\n%d\n",m_LS);
	fprintf(OOO,"Fully_Invested\n%d\n",Fully_Invested);
	fprintf(OOO,"Rmin\n%-.e\n",Rmin);
	fprintf(OOO,"Rmax\n%-.e\n",Rmax);
	fprintf(OOO,"m_Round\n%d\n",m_Round);
	lineprint(OOO,"min_lot",n,min_lot);
	lineprint(OOO,"size_lot",n,size_lot);
	lineprint(OOO,"shake",n,shake);
	fprintf(OOO,"ncomp\n%d\n",ncomp);
	lineprint(OOO,"Comp",(n-ncomp)*ncomp,Comp);
	fprintf(OOO,"LSValue\n%-.8e\n",LSValue);
	fprintf(OOO,"npiece\n%d\n",npiece);
	lineprint(OOO,"hpiece",n*npiece,hpiece);
	lineprint(OOO,"pgrad",n*npiece,pgrad);
	if(nfac!=-1)
	{
		lineprint(OOO,"FC",(nfac+1)*nfac/2,FC);
		lineprint(OOO,"SV",(n-ncomp),SV);
		lineprint(OOO,"FL",(n-ncomp)*nfac,FL);
	}
	else
	{
		lineprint(OOO,"FC",0,FC);
		lineprint(OOO,"SV",0,SV);
		lineprint(OOO,"FL",0,FL);
	}
	lineprint(OOO,"mask",n,mask);
	fprintf(OOO,"DoByRisks\n%d\n",DoByRisks);
	fclose(OOO);
	return 0;
}*/

short FrontierCVPAF(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,vector mask,int DoByRisks)
{
	return FrontierCVPAFb(npoints,risk,arisk,rreturn,areturn,n,nfac,
		names,w,m,A,L,U,alpha,benchmark,Q,initial,delta,buy,sell,kappa,basket,trades,
		revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,m_Round,min_lot,
		size_lot,shake,ncomp,Comp,LSValue,npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,FC,
		FL,SV,mask,DoByRisks,-1,-1,-1,-1,1);
}
short FrontierCVPAFb(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,vector mask,int DoByRisks,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double ShortCostScale)
{
	return FrontierCVPAFbl(npoints,risk,arisk,rreturn,areturn,n,nfac,names,w,m,A,
		L,U,alpha,benchmark,Q,initial,delta,buy,sell,kappa,basket,trades,revise,costs,
		min_holding,min_trade,
		m_LS,Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Comp,LSValue,
		npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,mask,DoByRisks,longbasket,
		shortbasket,tradebuy,
		tradesell,ShortCostScale,0,0);
}
short FrontierCVPAFbl(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,vector mask,int DoByRisks,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double ShortCostScale,double LSValuel,
									vector Abs_L)
{
	return FrontierCVPAFblQ(npoints,risk,arisk,rreturn,areturn,n,nfac,names,w,m,A,
		L,U,alpha,benchmark,Q,initial,delta,buy,sell,kappa,basket,trades,revise,costs,
		min_holding,min_trade,
		m_LS,Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Comp,LSValue,
		npiece,hpiece,pgrad,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,mask,DoByRisks,longbasket,
		shortbasket,tradebuy,
		tradesell,ShortCostScale,LSValuel,Abs_L,0,0);
}
short FrontierCVPAFblQ(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,vector mask,int DoByRisks,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double ShortCostScale,double LSValuel,
									vector Abs_L,vector qbuy,vector qsell)
{

	if(longbasket>-1 && shortbasket==-1)shortbasket=(long)n;
	else if(shortbasket>-1 && longbasket==-1)longbasket=(long)n;
	if(tradebuy>-1 && tradesell==-1)tradesell=(long)n;
	else if(tradesell>-1 && tradebuy==-1)tradebuy=(long)n;
	if(longbasket>-1) longbasket=min(longbasket,(long)n);
	if(shortbasket>-1) shortbasket=min(shortbasket,(long)n);
	if(tradebuy>-1) tradebuy=min(tradebuy,(long)n);
	if(tradesell>-1) tradesell=min(tradesell,(long)n);
	short back=-1;
	if(costs>0)//for CURVE
	{
		if(npiece)
		{
			piececostpasser* pcinfo = new piececostpasser;
			pcinfo->hpiece=hpiece;
			pcinfo->initial=initial;
			pcinfo->npiece=npiece;
			pcinfo->nstocks=n;
			pcinfo->pgrad=pgrad;
			pcinfo->ShortCostScale=ShortCostScale;
			back=FrontierCVPAextcostsl(npoints,risk,arisk,rreturn,areturn,n,nfac,names,w,m,A,
				L,U,alpha,benchmark,Q,
				initial,delta,kappa,basket,trades,revise,min_holding,min_trade,m_LS,
				Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Comp,
				LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,piece_cost,piece_grad,0,
				pcinfo,pcinfo,0,(costs?costs-1:0),mask,1,DoByRisks,longbasket,shortbasket,
				tradebuy,tradesell,ShortCostScale,LSValuel,Abs_L);
			delete pcinfo;
			return back;
		}
		else
		{
			linearcostpasser lcinfo;
			lcinfo.buy=buy;
			lcinfo.sell=sell;
			lcinfo.initial=initial;
			lcinfo.nstocks=n;
			lcinfo.qbuy=qbuy;
			lcinfo.qsell=qsell;
			lcinfo.ShortCostScale=ShortCostScale;
			back=FrontierCVPAextcostsl(npoints,risk,arisk,rreturn,areturn,n,nfac,names,w,m,A,
				L,U,alpha,benchmark,Q,
				initial,delta,kappa,basket,trades,revise,min_holding,min_trade,m_LS,
				Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Comp,
				LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,buysell_cost,buysell_grad,((qbuy&&qsell)?buysell_hess:0),
				&lcinfo,&lcinfo,((qbuy&&qsell)?&lcinfo:0),(costs?costs-1:0),mask,(((m_LS&&ShortCostScale!=1)||qbuy&&qsell)?1:0),DoByRisks,longbasket,shortbasket,
				tradebuy,tradesell,ShortCostScale,LSValuel,Abs_L);
			return back;
		}
	}
	else
			back=FrontierCVPAextcostsl(npoints,risk,arisk,rreturn,areturn,n,nfac,names,w,m,A,
				L,U,alpha,benchmark,Q,
				initial,delta,kappa,basket,trades,revise,min_holding,min_trade,m_LS,
				Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Comp,
				LSValue,nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,0,0,0,0,0,0,0,mask,0,DoByRisks,
				longbasket,shortbasket,
				tradebuy,tradesell,ShortCostScale,LSValuel,Abs_L);
	return back;
}
short FrontierCVPAextcosts(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,real kappa,long basket,
									long trades,dimen revise,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,
									pUtility Util,pModC ModDeriv,pModQ ModHessian,
									void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,
									vector mask,short DoExtraIterations,int DoByRisks,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double ShortCostScale)	
{
	return FrontierCVPAextcostsl(npoints,risk,arisk,rreturn,areturn,n,nfac,names,w,m,A,
		L,U,alpha,benchmark,Q,initial,delta,kappa,basket,trades,revise,min_holding,min_trade,
		m_LS,Fully_Invested,Rmin,Rmax,m_Round,min_lot,size_lot,shake,ncomp,Comp,LSValue,
		nabs,Abs_A,mabs,I_A,Abs_U,FC,FL,SV,Util,ModDeriv,ModHessian,Uinfo,Minfo,Qinfo,
		take_out_costs,mask,DoExtraIterations,DoByRisks,longbasket,shortbasket,tradebuy,
		tradesell,ShortCostScale,0,0);
}
short FrontierCVPAextcostsl(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,real kappa,long basket,
									long trades,dimen revise,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,
									pUtility Util,pModC ModDeriv,pModQ ModHessian,
									void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,
									vector mask,short DoExtraIterations,int DoByRisks,
									long longbasket,long shortbasket,
									long tradebuy,long tradesell,double ShortCostScale,
									double LSValuel,vector Abs_L)									
{
#ifdef PAS
//	UnlockBita("colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
#ifdef MEMORYTEST
	FILE* NEEDMEM=fopen("memoryinfo.txt","w");
	fclose(NEEDMEM);
#endif
	if(m_LS==0)
	{
		Rmin=Rmax=-1;
	}
	if(longbasket>-1 && shortbasket==-1)shortbasket=(long)n;
	else if(shortbasket>-1 && longbasket==-1)longbasket=(long)n;
	if(tradebuy>-1 && tradesell==-1)tradesell=(long)n;
	else if(tradesell>-1 && tradebuy==-1)tradebuy=(long)n;
	if(longbasket>-1) longbasket=min(longbasket,(long)n);
	if(shortbasket>-1) shortbasket=min(shortbasket,(long)n);
	if(tradebuy>-1) tradebuy=min(tradebuy,(long)n);
	if(tradesell>-1) tradesell=min(tradesell,(long)n);
	char* cback;
	short back=-1;
	double gamma;
	int roundlots=0;
	size_t hess_choice=1;
	size_t i=0,j=0;
	long nfront=-1;
	basket=min((long)n,((size_t)basket));
	trades=min((long)n,((size_t)trades));
	if(nfac==-1)
	{
		if(fix_covariancem(n-ncomp,Q))
		{
			fprintf(stderr,"The input covariance matrix has been modified to make it +ve definite.\n");
		}
		std::valarray<double>c(n);
		Optimise *opter = new Optimise();
		opter->firstw=w;
		opter->n=n;
		opter->m=m;
		opter->longbasket=longbasket;
		opter->shortbasket=shortbasket;
		opter->tradebuy=tradebuy;
		opter->tradesell=tradesell;
		if(longbasket>-1 && shortbasket>-1 && longbasket+shortbasket<(long)n)
			basket = longbasket+shortbasket;
		if(tradebuy>-1 && tradesell>-1&& tradebuy+tradesell<(long)n)
			trades = tradebuy+tradesell;
		opter->ShortCostScale=ShortCostScale;
		opter->ncomp=ncomp;
		opter->Composites=Comp;
		opter->A=A;
		opter->hmul=(pHmul)HMUL;
		opter->H=Q;
		opter->Composites=Comp;
		opter->delta=delta;
		opter->Full=Fully_Invested;
		opter->initial=initial;
		opter->lower=L;
		opter->LSValue=LSValue;
		opter->LSValue_Low=LSValuel;
		opter->SLRATmax=Rmax;
		opter->SLRATmin=Rmin;
		opter->upper=U;
		opter->take_out_costs=take_out_costs;
		opter->DoExtraIterations=DoExtraIterations;
		if(take_out_costs == 2)
			opter->DoExtraIterations=0;
		opter->mask=mask;
		std::valarray<double> lowerA;
		std::valarray<double> absoluteA;
		if(nabs&&!mabs)
		{
			opter->mabs=nabs;
			opter->absoluteA=Abs_A;
			opter->upperA=Abs_U;
			if(Abs_L)
				opter->upperA=Abs_L;
			else
			{
				lowerA.resize(nabs);
				lowerA=0;
				opter->lowerA=&lowerA[0];
			}
		}
		else if(mabs||nabs)
		{
			opter->mabs=mabs+nabs;
			absoluteA.resize((nabs+mabs)*n);
			if(Abs_L)
				opter->upperA=Abs_L;
			else
			{
				lowerA.resize(nabs+mabs);
				lowerA=0;
				opter->lowerA=&lowerA[0];
			}
			for(i=0;i<nabs+mabs;++i)
			{
				if(i<nabs)
				{
					absoluteA[j*(nabs+mabs)+i]=Abs_A[i+j*nabs];
				}
				else
				{
					for(j=0;j<n;++j)
					{
						absoluteA[j*(nabs+mabs)+i]=A[I_A[i-nabs]+j*m];
					}
				}
			}
			opter->absoluteA=&absoluteA[0];
			opter->upperA=Abs_U;
		}

		opter->hess_choice=1;
		if(m_LS && !revise && !ModDeriv) opter->hess_choice=2;
		else if(!m_LS && (revise || ModDeriv)) opter->hess_choice=3;
		else if(m_LS && (ModDeriv || revise))opter->hess_choice=5;

		if(opter->hess_choice==1&&m_LS)opter->hess_choice=2;
		if(opter->hess_choice==1&&revise)opter->hess_choice=3;
		hess_choice=opter->hess_choice;

		if(m_LS==2) opter->gross=1;
		else if(m_LS==3) opter->gross=2;



		roundlots=m_Round;
		opter->threshvectort=0;
		opter->threshvector=0;
		if(trades<(long)n||min_trade>0) 
		{
			opter->drop_to_this=new double[n];
			dcopyvec(n,initial,opter->drop_to_this);
//			dropn=trades;
/*			if(m_Round && nosizelot)
			{
				opter->threshvectort=min_lot;
				roundlots=0;
			}
			else*/
				opter->threshscalart=min_trade;
		}
		if(basket<(long)n||min_holding>0) 
		{
//			dropn=basket;
/*			if(m_Round && nosizelot)
			{
				opter->threshvector=min_lot;
				roundlots=0;
			}
			else*/
				opter->threshscalar=min_holding;
		}
//		if(dropn==(size_t)-1)
//			dropn=n;
//		opter->DoExtraIterations=0;
		opter->UtilObjectInfo=Uinfo;
		opter->ModCObjectInfo=Minfo;
		opter->Util=Util;
		opter->ModDeriv=ModDeriv;
		opter->ModHessian=ModHessian;
		opter->ModQObjectInfo=Qinfo;

		if(!DoByRisks)
		{
			for(nfront = npoints - 1;nfront >= 0 && back < 2;nfront--)
			{
				gamma = ((double) (nfront)) / (npoints - 1);
				gamma *= gamma;
				if(m_LS && gamma==0 && !Uinfo && !Minfo && !Util &&!ModDeriv&&!ModHessian&&!Qinfo)
					opter->leave_out_trivial=1;
				else
					opter->leave_out_trivial=0;
				if(opter->leave_out_trivial&&benchmark&&ddotvec(n,benchmark,benchmark)>10*lm_eps)
					opter->leave_out_trivial=0;
				opter->hess_choice=hess_choice;
				if(opter->hess_choice > 1){gamma=dmin(1-lm_rooteps,gamma);}
				if(kappa < 0)
					opter->scale_utility_external_terms=gamma/(1-gamma);
				else
					opter->scale_utility_external_terms=kappa/(1-kappa);
				if(opter->scale_utility_external_terms<=lm_eps&&take_out_costs==1)
				{
					opter->take_out_costs=2;
					opter->scale_utility_external_terms=1;
				}
				else
				{
					opter->take_out_costs=take_out_costs;
				}
				if(opter->take_out_costs == 2)
					opter->DoExtraIterations=0;
				else
					opter->DoExtraIterations=DoExtraIterations;
				if(opter->take_out_costs==2)
					opter->scale_utility_external_terms=1;
				try
				{
					if(gamma < 1.0-lm_eps)
					{
						opter->lp=0;
						if(benchmark)
						{
							if(!opter->ImportantCheck())
							{
								opter->hess_choice=1;
								opter->CompSetup();
								opter->qphess(n,1,1,1,opter->H,benchmark,&c[0]);
								opter->hess_choice=hess_choice;
							}
							c=-c;
						}
						else
							c=0;
						daxpyvec(n,-gamma/(1-gamma),alpha,&c[0]);
					}
					else
					{
						opter->lp=1;
						c=0;
						daxpyvec(n,-1.0,alpha,&c[0]);
					}
					opter->c=&c[0];
					cback = opter->OptSetup(basket,trades);
				}
				catch(MemProb mess)
				{
					printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
					cback =(char*)"Not enough memory for optimisation";
					back=15;
				}
				back=opter->back;
				if(opter->x)
				{
					if(roundlots)
					{
						double init,rww,one=1.0;
						opter->Rounding(basket,trades,(revise?initial:0),min_lot,size_lot,w);
						for(i=0;i<n;++i)
						{
							init=(revise?initial[i]:0);
							if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,min_lot[i],(size_lot?size_lot[i]:0))))) > round_eps)
							{
								if(fabs(fabs(w[i]-init)-min_lot[i])>round_eps)
								{
									if(size_lot&&size_lot[i]>lm_eps)
									{
										long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-min_lot[i])/size_lot[i]));
										if(fabs(kk*size_lot[i]+min_lot[i]-fabs(w[i]-init))>round_eps)
										{
											shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*size_lot[i]+min_lot[i]);
										}
									}
								}
								else if(fabs(w[i]-init)-fabs(min_lot[i])<-round_eps)
									shake[i]=i;
							}
						}
					}
					else
					{
						dcopyvec(n,opter->x,w);
					}
				}
				opter->hess_choice=1;
				arisk[npoints-nfront-1]=opter->risk(w,0);
				areturn[npoints-nfront-1]=ddotvec(n,alpha,w);
				risk[npoints-nfront-1]=opter->risk(w,benchmark);
				rreturn[npoints-nfront-1]=areturn[npoints-nfront-1]-(benchmark?ddotvec(n,alpha,benchmark):0);
				w+=n;
				shake+=n;
			}
		}
		else
		{
			std::valarray<double> keeproundw;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			opter->c=&c[0];
			optinfopasser Info;
			vector ww;
			double riskinterval;
			hess_choice=opter->hess_choice;
			Info.kappa=kappa;
			Info.alpha=alpha;
			Info.benchmark=benchmark;
			Info.desiredrisk=0;
			Info.dropnt=trades;
			Info.dropnb=basket;
			Info.nfac=-1;
			Info.opter=opter;
			Info.optactive_but_set_total=0;
			Info.zetaS=1;
			Info.zetaF=1;
			Info.roundlots=roundlots;
			Info.basket=basket;
			Info.trades=trades;
			Info.revise=revise;
			Info.initial=initial;
			Info.min_lot=min_lot;
			Info.size_lot=size_lot;
			Info.shake=shake;
			Info.tradethresh=false;
			if(Info.roundlots)
			{
				keeproundw.resize(n);
				Info.keepw=&keeproundw[0];
			}
			Info.minholdlot=0;
			Info.mintradelot=0;

			ww=w;
			opt_func(0.0,&Info);
			dcopyvec(n,opter->x,ww);
			opter->hess_choice=1;
			arisk[0]=opter->risk(ww,0);
			areturn[0]=ddotvec(n,alpha,ww);
			risk[0]=opter->risk(ww,benchmark);
			rreturn[0]=areturn[0]-(benchmark?ddotvec(n,alpha,benchmark):0);

			ww=w+(npoints-1)*n;
			opter->hess_choice=hess_choice;
			opt_func(.998,&Info);
			dcopyvec(n,opter->x,ww);
			opter->hess_choice=1;
			arisk[npoints-1]=opter->risk(ww,0);
			areturn[npoints-1]=ddotvec(n,alpha,ww);
			risk[npoints-1]=opter->risk(ww,benchmark);
			rreturn[npoints-1]=areturn[npoints-1]-(benchmark?ddotvec(n,alpha,benchmark):0);

			riskinterval = (risk[npoints-1] - risk[0]) / (npoints - 1);

			size_t k;
			double gammabot=0;
			printf("risk %-.8e, return %-.8e\n",risk[0],rreturn[0]);
			for(k=1;k<npoints-1;++k)
			{
				opter->hess_choice=hess_choice;
				Info.desiredrisk=risk[0]+k*riskinterval;
				ww=w+k*n;
				opter->hess_choice=hess_choice;
				gammabot=Solve1D(opt_func,gammabot,.998,lm_rooteps,&Info);
				dcopyvec(n,opter->x,ww);
				opter->hess_choice=1;
				arisk[k]=opter->risk(ww,0);
				areturn[k]=ddotvec(n,alpha,ww);
				risk[k]=opter->risk(ww,benchmark);
				rreturn[k]=areturn[k]-(benchmark?ddotvec(n,alpha,benchmark):0);
				printf("gamma %-.8e, risk %-.8e, return %-.8e\n",gammabot,risk[k],rreturn[k]);
			}
			printf("risk %-.8e, return %-.8e\n",risk[npoints-1],rreturn[npoints-1]);
		}
		delete []opter->drop_to_this;
		back=opter->back;
		if(back==12)back=0;
		delete opter;
	}
	else//This is a bit clumsy but I can't think of another way at present... I don't like all this repeated code
	{
		std::valarray<double>c(n);
		FOptimise *opter = new FOptimise();
		opter->firstw=w;
		opter->n=n;
		opter->m=m;
		opter->longbasket=longbasket;
		opter->shortbasket=shortbasket;
		opter->tradebuy=tradebuy;
		opter->tradesell=tradesell;
		if(longbasket>-1 && shortbasket>-1 && longbasket+shortbasket<(long)n)
			basket = longbasket+shortbasket;
		if(tradebuy>-1 && tradesell>-1&& tradebuy+tradesell<(long)n)
			trades = tradebuy+tradesell;
		opter->ShortCostScale=ShortCostScale;
		opter->ncomp=ncomp;
		opter->Composites=Comp;
		opter->A=A;
		opter->Composites=Comp;
		opter->nfac=nfac;
		if(SV)
		{
			opter->SV=SV;
			if(nfac&&FL&&FC)
			{
				opter->FL=FL;
				opter->FC=FC;
				opter->factor_model_process();
			}
			else
			{
				opter->nfac=0;
				opter->H=SV;
			}
			if(Q)
				dcopyvec((n-ncomp)*(nfac+1),opter->H,Q);
		}
		else
		{
			if(!Q)
			{
				std::cout << "!!!!!!!!!!!!!!!!!!!!No risk model given!!!!!!!!!!!!" << std::endl;
				delete opter;
				return -1;
			}
			opter->H=Q;
		}
		opter->delta=delta;
		opter->Full=Fully_Invested;
		opter->initial=initial;
		opter->lower=L;
		opter->LSValue=LSValue;
		opter->LSValue_Low=LSValuel;
		opter->SLRATmax=Rmax;
		opter->SLRATmin=Rmin;
		opter->upper=U;
		opter->take_out_costs=take_out_costs;
		opter->DoExtraIterations=DoExtraIterations;
		opter->mask=mask;
		std::valarray<double> lowerA;
		std::valarray<double> absoluteA;
		if(nabs&&!mabs)
		{
			opter->mabs=nabs;
			opter->absoluteA=Abs_A;
			opter->upperA=Abs_U;
			if(Abs_L)
				opter->upperA=Abs_L;
			else
			{
				lowerA.resize(nabs);
				lowerA=0;
				opter->lowerA=&lowerA[0];
			}
		}
		else if(mabs||nabs)
		{
			opter->mabs=mabs+nabs;
			absoluteA.resize((nabs+mabs)*n);
			if(Abs_L)
				opter->upperA=Abs_L;
			else
			{
				lowerA.resize(nabs+mabs);
				lowerA=0;
				opter->lowerA=&lowerA[0];
			}
			for(i=0;i<nabs+mabs;++i)
			{
				if(i<nabs)
				{
					absoluteA[j*(nabs+mabs)+i]=Abs_A[i+j*nabs];
				}
				else
				{
					for(j=0;j<n;++j)
					{
						absoluteA[j*(nabs+mabs)+i]=A[I_A[i-nabs]+j*m];
					}
				}
			}
			opter->absoluteA=&absoluteA[0];
			opter->upperA=Abs_U;
		}

		opter->hess_choice=1;
		if(m_LS && !revise && !ModDeriv) opter->hess_choice=2;
		else if(!m_LS && (revise || ModDeriv)) opter->hess_choice=3;
		else if(m_LS && (ModDeriv || revise))opter->hess_choice=5;
		hess_choice=opter->hess_choice;

		if(m_LS==2) opter->gross=1;
		else if(m_LS==3) opter->gross=2;



		roundlots=m_Round;
		opter->threshvectort=0;
		opter->threshvector=0;
		if(trades<(long)n||min_trade>0) 
		{
			opter->drop_to_this=new double[n];
			dcopyvec(n,initial,opter->drop_to_this);
//			dropn=trades;
/*			if(m_Round && nosizelot)
			{
				opter->threshvectort=min_lot;
				roundlots=0;
			}
			else*/
				opter->threshscalart=min_trade;
		}
		if(basket<(long)n||min_holding>0) 
		{
//			dropn=basket;
/*			if(m_Round && nosizelot)
			{
				opter->threshvector=min_lot;
				roundlots=0;
			}
			else*/
				opter->threshscalar=min_holding;
		}
//		if(dropn==(size_t)-1)
//			dropn=n;
//		opter->DoExtraIterations=0;
		opter->UtilObjectInfo=Uinfo;
		opter->ModCObjectInfo=Minfo;
		opter->Util=Util;
		opter->ModDeriv=ModDeriv;
		opter->ModHessian=ModHessian;
		opter->ModQObjectInfo=Qinfo;
		if(!DoByRisks)
		{
			for(nfront = npoints - 1;nfront >= 0 && back < 2;nfront--)
			{
				gamma = ((double) (nfront)) / (npoints - 1);
				gamma *= gamma;
				if(m_LS && gamma==0 && !Uinfo && !Minfo && !Util &&!ModDeriv&&!ModHessian&&!Qinfo)
					opter->leave_out_trivial=1;
				else
					opter->leave_out_trivial=0;
				if(opter->leave_out_trivial&&benchmark&&ddotvec(n,benchmark,benchmark)>10*lm_eps)
					opter->leave_out_trivial=0;
				opter->hess_choice=hess_choice;
				if(opter->hess_choice > 1){gamma=dmin(1-lm_rooteps,gamma);}
				if(kappa < 0)
					opter->scale_utility_external_terms=gamma/(1-gamma);
				else
					opter->scale_utility_external_terms=kappa/(1-kappa);
				if(opter->scale_utility_external_terms<=lm_eps&&take_out_costs==1)
				{
					opter->take_out_costs=2;
					opter->scale_utility_external_terms=1;
				}
				else
				{
					opter->take_out_costs=take_out_costs;
				}
				if(opter->take_out_costs == 2)
					opter->DoExtraIterations=0;
				else
					opter->DoExtraIterations=DoExtraIterations;
				if(opter->take_out_costs==2)
					opter->scale_utility_external_terms=1;

				try
				{
					if(gamma < 1.0-lm_eps)
					{
						opter->lp=0;
						if(benchmark)
						{
							if(!opter->ImportantCheck())
							{
								opter->hess_choice=1;
								opter->CompSetup();
								opter->qphess(n,1,1,1,opter->H,benchmark,&c[0]);
								opter->hess_choice=hess_choice;
							}
							c=-c;
						}
						else
							c=0;
						daxpyvec(n,-gamma/(1-gamma),alpha,&c[0]);
					}
					else
					{
						opter->lp=1;
						c=0;
						daxpyvec(n,-1.0,alpha,&c[0]);
					}
					opter->c=&c[0];
					cback = opter->OptSetup(basket,trades);
				}
				catch(MemProb mess)
				{
					printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
					cback =(char*)"Not enough memory for optimisation";
					back=15;
				}
				back=opter->back;
				if(opter->x)
				{
					if(roundlots)
					{
						double init,rww,one=1.0;
						opter->Rounding(basket,trades,(revise?initial:0),min_lot,size_lot,w);
						for(i=0;i<n;++i)
						{
							init=(revise?initial[i]:0);
							if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,min_lot[i],(size_lot?size_lot[i]:0))))) > round_eps)
							{
								if(fabs(fabs(w[i]-init)-min_lot[i])>round_eps)
								{
									if(size_lot&&size_lot[i]>lm_eps)
									{
										long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-min_lot[i])/size_lot[i]));
										if(fabs(kk*size_lot[i]+min_lot[i]-fabs(w[i]-init))>round_eps)
										{
											shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*size_lot[i]+min_lot[i]);
										}
									}
								}
								else if(fabs(w[i]-init)-fabs(min_lot[i])<-round_eps)
									shake[i]=i;
							}
						}
					}
					else
					{
						dcopyvec(n,opter->x,w);
					}
				}
				opter->hess_choice=1;
				arisk[nfront]=opter->risk(w,0);
				areturn[nfront]=ddotvec(n,alpha,w);
				risk[nfront]=opter->risk(w,benchmark);
				rreturn[nfront]=areturn[nfront]-(benchmark?ddotvec(n,alpha,benchmark):0);
				w+=n;
				shake+=n;
			}
		}
		else
		{
			std::valarray<double> keeproundw;
			opter->take_out_costs=take_out_costs;
			opter->DoExtraIterations=DoExtraIterations;
			opter->c=&c[0];
			optinfopasser Info;
			vector ww;
			double riskinterval;
			hess_choice=opter->hess_choice;
			Info.kappa=kappa;
			Info.alpha=alpha;
			Info.benchmark=benchmark;
			Info.desiredrisk=0;
			Info.dropnt=trades;
			Info.dropnb=basket;
			Info.nfac=nfac;
			Info.optactive_but_set_total=0;
			Info.opter=opter;
			Info.zetaS=1;
			Info.zetaF=1;
			Info.roundlots=roundlots;
			Info.basket=basket;
			Info.trades=trades;
			Info.revise=revise;
			Info.initial=initial;
			Info.min_lot=min_lot;
			Info.size_lot=size_lot;
			Info.shake=shake;
			Info.tradethresh=false;
			if(Info.roundlots)
			{
				keeproundw.resize(n);
				Info.keepw=&keeproundw[0];
			}
			Info.minholdlot=0;
			Info.mintradelot=0;

			ww=w;
			opt_func(0.0,&Info);
			dcopyvec(n,opter->x,ww);
			opter->hess_choice=1;
			arisk[0]=opter->risk(ww,0);
			areturn[0]=ddotvec(n,alpha,ww);
			risk[0]=opter->risk(ww,benchmark);
			rreturn[0]=areturn[0]-(benchmark?ddotvec(n,alpha,benchmark):0);

			ww=w+(npoints-1)*n;
			opter->hess_choice=hess_choice;
			opt_func(.998,&Info);
			dcopyvec(n,opter->x,ww);
			opter->hess_choice=1;
			arisk[npoints-1]=opter->risk(ww,0);
			areturn[npoints-1]=ddotvec(n,alpha,ww);
			risk[npoints-1]=opter->risk(ww,benchmark);
			rreturn[npoints-1]=areturn[npoints-1]-(benchmark?ddotvec(n,alpha,benchmark):0);

			riskinterval = (risk[npoints-1] - risk[0]) / (npoints - 1);

			size_t k;
			double gammabot=0;
			printf("risk %-.8e, return %-.8e\n",risk[0],rreturn[0]);
			for(k=1;k<npoints-1;++k)
			{
				opter->hess_choice=hess_choice;
				Info.desiredrisk=risk[0]+k*riskinterval;
				ww=w+k*n;
				opter->hess_choice=hess_choice;
				gammabot=Solve1D(opt_func,gammabot,.998,lm_rooteps,&Info);
				dcopyvec(n,opter->x,ww);
				opter->hess_choice=1;
				arisk[k]=opter->risk(ww,0);
				areturn[k]=ddotvec(n,alpha,ww);
				risk[k]=opter->risk(ww,benchmark);
				rreturn[k]=areturn[k]-(benchmark?ddotvec(n,alpha,benchmark):0);
				printf("gamma %-.8e, risk %-.8e, return %-.8e\n",gammabot,risk[k],rreturn[k]);
			}
			printf("risk %-.8e, return %-.8e\n",risk[npoints-1],rreturn[npoints-1]);
		}

		delete []opter->drop_to_this;
		back=opter->back;
		if(back==12)back=0;
		delete opter;
	}
	return back;
}

double entropy_func(double entropy_gamma,void*info)
{
	entropyinfopasser* Info=(class entropyinfopasser*) info;
	Optimise* opter=(class Optimise*) Info->opter;
	if(Info->shake)
	{
		for(size_t i=0;i<opter->n;++i){Info->shake[i]=-1;}
	}
	opter->gamma_for_eps=entropy_gamma;
	opter->AddLog("entropy_gamma %-.8e\n",entropy_gamma);
	size_t hess_choice=opter->hess_choice;
	try
	{
		int take_keep=opter->take_out_costs;
		unsigned char DoEx=opter->DoExtraIterations;
		opter->hess_choice=1;
		if(Info->lambda >0)
		{
			opter->scale_utility_external_terms=entropy_gamma/(1-entropy_gamma);
			opter->take_out_costs=0;
			opter->DoExtraIterations=DoEx;
			opter->lp=0;
			if(Info->benchmark)
			{
				if(!opter->ImportantCheck())
				{
					opter->CompSetup();
					opter->use_soft_in_hessmult=false;
					opter->qphess(opter->n,1,1,1,opter->H,Info->benchmark,opter->c);
					opter->use_soft_in_hessmult=true;
				}
				dnegvec(opter->n,opter->c);
			}
			else
				dzerovec(opter->n,opter->c);
			daxpyvec(opter->n,-1./Info->lambda,Info->alpha,opter->c);
		}
		else
		{
			opter->scale_utility_external_terms=entropy_gamma/(1-entropy_gamma);
			opter->take_out_costs=0;
			opter->DoExtraIterations=DoEx;
			opter->lp=1;
			dzerovec(opter->n,opter->c);
			daxpyvec(opter->n,-1.0,Info->alpha,opter->c);
		}
		opter->hess_choice=hess_choice;
		pModC ModDeriv=opter->ModDeriv;
		pModQ ModHessian=opter->ModHessian;
		if(opter->scale_utility_external_terms==0 && opter->ModDeriv)
		{
			if(hess_choice>3 && (opter->delta>=2||opter->delta<-lm_eps)) 
				opter->hess_choice=2;
			else if(opter->delta>=2||opter->delta<-lm_eps) 
				opter->hess_choice=1;
			opter->AddLog("No costs here\n");
			opter->ModDeriv=0;
			opter->ModHessian=0;
		}
		opter->OptSetup(Info->dropnb,Info->dropnt);
		opter->ModDeriv=ModDeriv;
		opter->ModHessian=ModHessian;
		opter->hess_choice=hess_choice;
		opter->take_out_costs=take_keep;
		opter->DoExtraIterations=DoEx;
	}
	catch(MemProb mess)
	{
		printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
	}
	if(opter->x)
	{
		size_t i,n=opter->n;
		std::valarray<double>pw(n);
		vector w=&pw[0];
		if(opter->back<2)
		{
			if(Info->roundlots)//It's a lot to ask for thresh hold and rounding; if it doesn't work quickly enough take out minholdlot and mintradelot
			{
				double init,rww,one=1.0;
				vector min__hold=(Info->minholdlot&&Info->minholdlot->size()?&(*Info->minholdlot)[0]:0);
				size_t badround=0;
				for(i=0;i<n;++i)
				{
					init=(Info->revise?Info->initial[i]:0);
					if(fabs(fabs(opter->x[i])-(rww=fabs(round_weight(opter->x[i],init,Info->min_lot[i],(Info->size_lot?Info->size_lot[i]:0))))) > round_eps)
					{
						if(fabs(opter->x[i]-init)-fabs(Info->min_lot[i])>round_eps)
						{
							if(Info->size_lot&&Info->size_lot[i]>lm_eps)
							{
								long kk=(long)check_digit(floor(one+(fabs(opter->x[i]-init)-Info->min_lot[i])/Info->size_lot[i]));
								if(fabs(kk*Info->size_lot[i]+Info->min_lot[i]-fabs(opter->x[i]-init))>round_eps)
								{
									Info->shake[i]=i;badround++;
								}
							}
						}
						else if(fabs(opter->x[i]-init)-fabs(Info->min_lot[i])<-round_eps)
						{
							Info->shake[i]=i;badround++;
						}
					}
				}
				if(badround)
				{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
				if(Info->revise)opter->Rounding(Info->basket,Info->trades,Info->initial,Info->min_lot,Info->size_lot,w,min__hold,/*min__hold?Info->min_lot:*/0);
				else opter->Rounding(Info->basket,Info->trades,0,Info->min_lot,Info->size_lot,w);
				}
				else
					dcopyvec(n,opter->x,w);
				for(i=0;i<n;++i)
				{
					init=(Info->revise?Info->initial[i]:0);
					if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,Info->min_lot[i],(Info->size_lot?Info->size_lot[i]:0))))) > round_eps)
					{
						if(fabs(w[i]-init)-fabs(Info->min_lot[i])>round_eps)
						{
							if(Info->size_lot&&Info->size_lot[i]>lm_eps)
							{
								long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-Info->min_lot[i])/Info->size_lot[i]));
								if(fabs(kk*Info->size_lot[i]+Info->min_lot[i]-fabs(w[i]-init))>round_eps)
								{
									Info->shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*Info->size_lot[i]+Info->min_lot[i]);
								}
							}
						}
						else if(fabs(w[i]-init)-fabs(Info->min_lot[i])<-round_eps)
							Info->shake[i]=i;
					}
				}
			}
			else if((Info->minholdlot&&Info->minholdlot->size())&&(Info->mintradelot&&Info->mintradelot->size()))
			{
				//					Info->minholdlot.resize(2*n);
				//					Info->mintradelot.resize(2*n);
				//					dcopyvec(n,&(Info->mintradelot)[0],&(Info->mintradelot)[n]);
				//					dcopyvec(n,&(Info->minholdlot)[0],&(Info->minholdlot)[n]);
				//					opter->Thresh(Info->basket,Info->trades,Info->initial,&(Info->minholdlot)[n],&(Info->mintradelot)[n],w,
				//						&(Info->minholdlot)[0],&(Info->mintradelot)[0]);
				OptParamRound OpSend;OpSend.back=opter->back;
				OpSend.m=opter->m;
				OpSend.n=opter->n;
				OpSend.lower=opter->lower;
				OpSend.upper=opter->upper;
				OpSend.x=opter->x;
				OpSend.grad=0;//This is set in Droptwo
				OpSend.OptFunc=BaskInnerOpt;
				OpSend.UtilityFunc=BaskUtility;
				OpSend.GradFunc=BaskGrad;
				OpSend.mabs=opter->mabs;
				OpSend.longbasket=opter->longbasket;
				OpSend.shortbasket=opter->shortbasket;
				OpSend.tradebuy=opter->tradebuy;
				OpSend.tradesell=opter->tradesell;
				OpSend.initial=opter->initial;
				OpSend.MoreInfo=opter;
				OpSend.c=opter->c;
				OpSend.logprint=opter->logprint;
				OpSend.basket=Info->basket;
				OpSend.trades=Info->trades;
				size_t badround=0;
				for(i=0;i<n;++i)
				{
					if((fabs(opter->x[i]) > lm_eps && fabs(opter->x[i]) < (*Info->minholdlot)[i]-lm_eps) ||
						(fabs(opter->x[i]-Info->initial[i]) > lm_eps && fabs(opter->x[i]-Info->initial[i]) < (*Info->mintradelot)[i]-lm_eps))
					{
						Info->shake[i] =i;badround++;
					}
				}
				if(badround)
				{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
				Thresh(&OpSend,opter->initial,&(*Info->mintradelot)[0],w,&(*Info->minholdlot)[0]);
				opter->back=(OpSend.back==2?6:OpSend.back);
				}
				else
					dcopyvec(n,opter->x,w);
				
				for(i=0;i<n;++i)
				{
					if((fabs(w[i]) > lm_eps && fabs(w[i]) < (*Info->minholdlot)[i]-lm_eps) ||
						(fabs(w[i]-Info->initial[i]) > lm_eps && fabs(w[i]-Info->initial[i]) < (*Info->mintradelot)[i]-lm_eps))
						Info->shake[i] =i;
				}
			}
			else if((Info->minholdlot&&Info->minholdlot->size()))
			{
				//					opter->Thresh(Info->basket,Info->trades,0,&(Info->minholdlot)[0],w);
				OptParamRound OpSend;OpSend.back=opter->back;
				OpSend.m=opter->m;
				OpSend.n=opter->n;
				OpSend.lower=opter->lower;
				OpSend.upper=opter->upper;
				OpSend.x=opter->x;
				OpSend.grad=0;//This is set in Droptwo
				OpSend.OptFunc=BaskInnerOpt;
				OpSend.UtilityFunc=BaskUtility;
				OpSend.GradFunc=BaskGrad;
				OpSend.mabs=opter->mabs;
				OpSend.longbasket=opter->longbasket;
				OpSend.shortbasket=opter->shortbasket;
				OpSend.tradebuy=opter->tradebuy;
				OpSend.tradesell=opter->tradesell;
				OpSend.initial=opter->initial;
				OpSend.MoreInfo=opter;
				OpSend.c=opter->c;
				OpSend.logprint=opter->logprint;
				OpSend.basket=Info->basket;
				OpSend.trades=Info->trades;
				size_t badround=0;
				for(i=0;i<n;++i)
				{
					if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],0,(*Info->minholdlot)[i],0))) > round_eps && fabs(fabs(opter->x[i])-(*Info->minholdlot)[i])>round_eps)
					{
						Info->shake[i]=i;badround++;
					}
				}
				if(badround)
				{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
				Thresh(&OpSend,0,&(*Info->minholdlot)[0],w);
				opter->back=(OpSend.back==2?6:OpSend.back);
				}
				else
					dcopyvec(n,opter->x,w);
				for(i=0;i<n;++i)
				{
					if(fabs(fabs(w[i])-fabs(round_weight(w[i],0,(*Info->minholdlot)[i],0))) > round_eps && fabs(fabs(w[i])-(*Info->minholdlot)[i])>round_eps)
					{
						Info->shake[i]=i;
					}
				}
			}
			else if((Info->mintradelot&&Info->mintradelot->size()))
			{
				double init;
				//					opter->Thresh(Info->basket,Info->trades,Info->tradethresh?Info->initial:0,&(Info->mintradelot)[0],w);
				OptParamRound OpSend;OpSend.back=opter->back;
				OpSend.m=opter->m;
				OpSend.n=opter->n;
				OpSend.lower=opter->lower;
				OpSend.upper=opter->upper;
				OpSend.x=opter->x;
				OpSend.grad=0;//This is set in Droptwo
				OpSend.OptFunc=BaskInnerOpt;
				OpSend.UtilityFunc=BaskUtility;
				OpSend.GradFunc=BaskGrad;
				OpSend.mabs=opter->mabs;
				OpSend.longbasket=opter->longbasket;
				OpSend.shortbasket=opter->shortbasket;
				OpSend.tradebuy=opter->tradebuy;
				OpSend.tradesell=opter->tradesell;
				OpSend.initial=opter->initial;
				OpSend.MoreInfo=opter;
				OpSend.c=opter->c;
				OpSend.logprint=opter->logprint;
				OpSend.basket=Info->basket;
				OpSend.trades=Info->trades;
				size_t badround=0;
				for(i=0;i<n;++i)
				{
					//						init=Info->tradethresh?Info->initial[i]:0;
					init=Info->initial[i];
					if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],init,(*Info->mintradelot)[i],0))) > round_eps && fabs(fabs(opter->x[i]-init)-(*Info->mintradelot)[i])>round_eps)
					{
						Info->shake[i]=i;badround++;
					}
				}
				if(badround)
				{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
				Thresh(&OpSend,opter->initial,&(*Info->mintradelot)[0],w);
				opter->back=(OpSend.back==2?6:OpSend.back);
				}
				else
					dcopyvec(n,opter->x,w);
				for(i=0;i<n;++i)
				{
					//						init=Info->tradethresh?Info->initial[i]:0;
					init=Info->initial[i];
					if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,(*Info->mintradelot)[i],0))) > round_eps && fabs(fabs(w[i]-init)-(*Info->mintradelot)[i])>round_eps)
					{
						Info->shake[i]=i;
					}
				}
			}
			else
			{
				dcopyvec(n,opter->x,w);
			}
			dcopyvec(n,w,opter->x);
			}
		}
		opter->hess_choice=1;
		double risk=opter->risk(opter->x,Info->benchmark);
		double rreturn=ddotvec(opter->n,opter->x,Info->alpha)-(Info->benchmark?ddotvec(opter->n,Info->benchmark,Info->alpha):0);
		double U=-rreturn+0.5*risk*risk*Info->lambda;
		opter->AddLog("entropy_gamma %-.8e -mean+0.5*l*var U %-.8e\n",entropy_gamma,U);
		opter->hess_choice=hess_choice;
		if(opter->back==6)
		{
			return -1;
		}
		if(Info->roundlots)
		{
			bool worked=true;
			for(size_t i=0;i<opter->n;++i)
			{
				if(Info->shake[i]!=-1)
				{
					worked=false;
					break;
				}
			}
			if(worked)
			{
				dcopyvec(opter->n,opter->x,Info->keepw);
				Info->keep_entropy_gamma=entropy_gamma;
				Info->back=opter->back;
			}
		}
		if(Info->desiredU)
			return U/Info->desiredU-1.0;
		else
			return U-Info->desiredU;
}
double opt_func(double gamma,void*info)
{
	optinfopasser* Info=(class optinfopasser*) info;
	if(Info->nfac == -1)
	{
		Optimise* opter=(class Optimise*) Info->opter;
		if(Info->shake)
		{
			for(size_t i=0;i<opter->n;++i)
				Info->shake[i]=-1;
		}
		opter->gamma_for_eps=gamma;
		if(gamma>=1-lm_rooteps) 
			opter->lp_really=1;
		else
			opter->lp_really=0;
		opter->AddLog("gamma %-.8e\n",gamma);
		size_t hess_choice=opter->hess_choice;
		try
		{
			int take_keep=opter->take_out_costs;
			unsigned char DoEx=opter->DoExtraIterations;
			opter->hess_choice=1;
			if(gamma < 1.0-lm_eps)
			{
				if(Info->kappa<0)
				{
					opter->AddLog("kappa %-.8e\n",gamma);
					opter->scale_utility_external_terms=gamma/(1-gamma);
				}
				else
					opter->scale_utility_external_terms=Info->kappa/(1-Info->kappa);
				if(opter->scale_utility_external_terms<=lm_eps&&take_keep==1)
				{
					opter->take_out_costs=2;
					opter->scale_utility_external_terms=1;
				}
				else
				{
					opter->take_out_costs=take_keep;
				}
				if(opter->take_out_costs == 2)
					opter->DoExtraIterations=0;
				else
					opter->DoExtraIterations=DoEx;
				if(opter->take_out_costs==2)
					opter->scale_utility_external_terms=1;
				opter->lp=0;
				if(Info->benchmark)
				{
					if(!opter->ImportantCheck())
					{
						opter->CompSetup();
						opter->use_soft_in_hessmult=false;
						opter->qphess(opter->n,1,1,1,opter->H,Info->benchmark,opter->c);
						opter->use_soft_in_hessmult=true;
					}
					dnegvec(opter->n,opter->c);
				}
				else
					dzerovec(opter->n,opter->c);
				daxpyvec(opter->n,-gamma/(1-gamma),Info->alpha,opter->c);
			}
			else
			{
				opter->lp=1;
				dzerovec(opter->n,opter->c);
				daxpyvec(opter->n,-1.0,Info->alpha,opter->c);
			}
			if(opter->shortalphacost)
			{
				dzerovec(opter->n,opter->shortalphacost);
				daxpyvec(opter->n,opter->scale_utility_external_terms,Info->shortalphacost,opter->shortalphacost);
			}
			opter->hess_choice=hess_choice;
			pModC ModDeriv=opter->ModDeriv;
			pModQ ModHessian=opter->ModHessian;
			if(opter->scale_utility_external_terms==0 && opter->ModDeriv)
			{
				if(hess_choice>3 && (opter->delta>=2||opter->delta<-lm_eps)) 
					opter->hess_choice=2;
				else if(opter->delta>=2||opter->delta<-lm_eps) 
					opter->hess_choice=1;
				opter->AddLog("No costs here\n");
				opter->ModDeriv=0;
				opter->ModHessian=0;
			}
			opter->AccumOpt(Info->dropnb,Info->dropnt);
			opter->ModDeriv=ModDeriv;
			opter->ModHessian=ModHessian;
			opter->hess_choice=hess_choice;
			opter->take_out_costs=take_keep;
			opter->DoExtraIterations=DoEx;
		}
		catch(MemProb mess)
		{
			printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
		}
		if(opter->x)
		{
			size_t i,n=opter->n;
			std::valarray<double>pw(n);
			vector w=&pw[0];
			if(opter->back<2)
			{
				if(Info->roundlots)//It's a lot to ask for thresh hold and rounding; if it doesn't work quickly enough take out minholdlot and mintradelot
				{
					double init,rww,one=1.0;
					vector min__hold=(Info->minholdlot&&Info->minholdlot->size()?&(*Info->minholdlot)[0]:0);
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						init=(Info->revise?Info->initial[i]:0);
						if(fabs(fabs(opter->x[i])-(rww=fabs(round_weight(opter->x[i],init,Info->min_lot[i],(Info->size_lot?Info->size_lot[i]:0))))) > round_eps)
						{
							if(fabs(opter->x[i]-init)-fabs(Info->min_lot[i])>round_eps)
							{
								if(Info->size_lot&&Info->size_lot[i]>lm_eps)
								{
									long kk=(long)check_digit(floor(one+(fabs(opter->x[i]-init)-Info->min_lot[i])/Info->size_lot[i]));
									if(fabs(kk*Info->size_lot[i]+Info->min_lot[i]-fabs(opter->x[i]-init))>round_eps)
									{
										Info->shake[i]=i;badround++;
									}
								}
							}
							else if(fabs(opter->x[i]-init)-fabs(Info->min_lot[i])<-round_eps)
							{
								Info->shake[i]=i;badround++;
							}
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
					if(Info->revise)opter->Rounding(Info->basket,Info->trades,Info->initial,Info->min_lot,Info->size_lot,w,min__hold,/*min__hold?Info->min_lot:*/0);
					else opter->Rounding(Info->basket,Info->trades,0,Info->min_lot,Info->size_lot,w);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						init=(Info->revise?Info->initial[i]:0);
						if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,Info->min_lot[i],(Info->size_lot?Info->size_lot[i]:0))))) > round_eps)
						{
							if(fabs(w[i]-init)-fabs(Info->min_lot[i])>round_eps)
							{
								if(Info->size_lot&&Info->size_lot[i]>lm_eps)
								{
									long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-Info->min_lot[i])/Info->size_lot[i]));
									if(fabs(kk*Info->size_lot[i]+Info->min_lot[i]-fabs(w[i]-init))>round_eps)
									{
										Info->shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*Info->size_lot[i]+Info->min_lot[i]);
									}
								}
							}
							else if(fabs(w[i]-init)-fabs(Info->min_lot[i])<-round_eps)
								Info->shake[i]=i;
						}
					}
				}
				else if((Info->minholdlot&&Info->minholdlot->size())&&(Info->mintradelot&&Info->mintradelot->size()))
				{
//					Info->minholdlot.resize(2*n);
//					Info->mintradelot.resize(2*n);
//					dcopyvec(n,&(Info->mintradelot)[0],&(Info->mintradelot)[n]);
//					dcopyvec(n,&(Info->minholdlot)[0],&(Info->minholdlot)[n]);
//					opter->Thresh(Info->basket,Info->trades,Info->initial,&(Info->minholdlot)[n],&(Info->mintradelot)[n],w,
//						&(Info->minholdlot)[0],&(Info->mintradelot)[0]);
		OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
		OpSend.m=opter->m;
		OpSend.n=opter->n;
		OpSend.lower=opter->lower;
		OpSend.upper=opter->upper;
		OpSend.x=opter->x;
		OpSend.grad=0;//This is set in Droptwo
		OpSend.OptFunc=BaskInnerOpt;
		OpSend.UtilityFunc=BaskUtility;
		OpSend.GradFunc=BaskGrad;
		OpSend.mabs=opter->mabs;
		OpSend.longbasket=opter->longbasket;
		OpSend.shortbasket=opter->shortbasket;
		OpSend.tradebuy=opter->tradebuy;
		OpSend.tradesell=opter->tradesell;
		OpSend.initial=opter->initial;
		OpSend.MoreInfo=opter;
		OpSend.c=opter->c;
		OpSend.logprint=opter->logprint;
		OpSend.basket=Info->basket;
		OpSend.trades=Info->trades;
		size_t badround=0;
					for(i=0;i<n;++i)
					{
						if((fabs(opter->x[i]) > lm_eps && fabs(opter->x[i]) < (*Info->minholdlot)[i]-lm_eps) ||
							(fabs(opter->x[i]-Info->initial[i]) > lm_eps && fabs(opter->x[i]-Info->initial[i]) < (*Info->mintradelot)[i]-lm_eps))
						{
							Info->shake[i] =i;badround++;
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
		Thresh(&OpSend,opter->initial,&(*Info->mintradelot)[0],w,&(*Info->minholdlot)[0]);
		opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					
					for(i=0;i<n;++i)
					{
						if((fabs(w[i]) > lm_eps && fabs(w[i]) < (*Info->minholdlot)[i]-lm_eps) ||
							(fabs(w[i]-Info->initial[i]) > lm_eps && fabs(w[i]-Info->initial[i]) < (*Info->mintradelot)[i]-lm_eps))
							Info->shake[i] =i;
					}
				}
				else if((Info->minholdlot&&Info->minholdlot->size()))
				{
//					opter->Thresh(Info->basket,Info->trades,0,&(Info->minholdlot)[0],w);
		OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
		OpSend.m=opter->m;
		OpSend.n=opter->n;
		OpSend.lower=opter->lower;
		OpSend.upper=opter->upper;
		OpSend.x=opter->x;
		OpSend.grad=0;//This is set in Droptwo
		OpSend.OptFunc=BaskInnerOpt;
		OpSend.UtilityFunc=BaskUtility;
		OpSend.GradFunc=BaskGrad;
		OpSend.mabs=opter->mabs;
		OpSend.longbasket=opter->longbasket;
		OpSend.shortbasket=opter->shortbasket;
		OpSend.tradebuy=opter->tradebuy;
		OpSend.tradesell=opter->tradesell;
		OpSend.initial=opter->initial;
		OpSend.MoreInfo=opter;
		OpSend.c=opter->c;
		OpSend.logprint=opter->logprint;
		OpSend.basket=Info->basket;
		OpSend.trades=Info->trades;
		size_t badround=0;
					for(i=0;i<n;++i)
					{
						if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],0,(*Info->minholdlot)[i],0))) > round_eps && fabs(fabs(opter->x[i])-(*Info->minholdlot)[i])>round_eps)
						{
							Info->shake[i]=i;badround++;
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
		Thresh(&OpSend,0,&(*Info->minholdlot)[0],w);
		opter->back=(OpSend.back==2?6:OpSend.back);
					}
					dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						if(fabs(fabs(w[i])-fabs(round_weight(w[i],0,(*Info->minholdlot)[i],0))) > round_eps && fabs(fabs(w[i])-(*Info->minholdlot)[i])>round_eps)
						{
							Info->shake[i]=i;
						}
					}
				}
				else if((Info->mintradelot&&Info->mintradelot->size()))
				{
					double init;
//					opter->Thresh(Info->basket,Info->trades,Info->tradethresh?Info->initial:0,&(Info->mintradelot)[0],w);
		OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
		OpSend.m=opter->m;
		OpSend.n=opter->n;
		OpSend.lower=opter->lower;
		OpSend.upper=opter->upper;
		OpSend.x=opter->x;
		OpSend.grad=0;//This is set in Droptwo
		OpSend.OptFunc=BaskInnerOpt;
		OpSend.UtilityFunc=BaskUtility;
		OpSend.GradFunc=BaskGrad;
		OpSend.mabs=opter->mabs;
		OpSend.longbasket=opter->longbasket;
		OpSend.shortbasket=opter->shortbasket;
		OpSend.tradebuy=opter->tradebuy;
		OpSend.tradesell=opter->tradesell;
		OpSend.initial=opter->initial;
		OpSend.MoreInfo=opter;
		OpSend.c=opter->c;
		OpSend.logprint=opter->logprint;
		OpSend.basket=Info->basket;
		OpSend.trades=Info->trades;
		size_t badround=0;
					for(i=0;i<n;++i)
					{
//						init=Info->tradethresh?Info->initial[i]:0;
						init=Info->initial[i];
						if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],init,(*Info->mintradelot)[i],0))) > round_eps && fabs(fabs(opter->x[i]-init)-(*Info->mintradelot)[i])>round_eps)
						{
							Info->shake[i]=i;badround++;
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
		Thresh(&OpSend,opter->initial,&(*Info->mintradelot)[0],w);
		opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
//						init=Info->tradethresh?Info->initial[i]:0;
						init=Info->initial[i];
						if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,(*Info->mintradelot)[i],0))) > round_eps && fabs(fabs(w[i]-init)-(*Info->mintradelot)[i])>round_eps)
						{
							Info->shake[i]=i;
						}
					}
				}
				else
				{
					dcopyvec(n,opter->x,w);
				}
				dcopyvec(n,w,opter->x);
			}
		}
		opter->hess_choice=1;
		double risk=0;
		if(opter->TimeOptData&&opter->TimeOptData->OptType==SemiVarType)
		{
			double tt,mm=ddotvec(opter->n,opter->TimeOptData->meanDATA,opter->x);
			if(opter->TimeOptData->benchmark)
				mm-=ddotvec(opter->n,opter->TimeOptData->meanDATA,opter->TimeOptData->benchmark);
			for(size_t i = 0;i<opter->TimeOptData->tlen;++i)
			{
				tt=BITA_ddot(opter->n,opter->TimeOptData->DATA+i,opter->TimeOptData->tlen,opter->x,1)-mm;
				if(opter->TimeOptData->benchmark)
				{
					tt-=BITA_ddot(opter->n,opter->TimeOptData->DATA+i,opter->TimeOptData->tlen,opter->TimeOptData->benchmark,1);
				}
				if(tt<0)
					risk+=tt*tt;
			}
			risk/=(opter->TimeOptData->tlen);
			risk-=Info->desiredrisk;
		}
		else if(opter->UtilObjectInfo&&opter->H[0]<lm_eps8)
		{
			risk=opter->Util(opter->n,opter->x,opter->UtilObjectInfo)*2 - Info->desiredrisk;
		}
		else
			risk=opter->risk(opter->x,(Info->optactive_but_set_total?0:Info->benchmark))-Info->desiredrisk;
		opter->AddLog("gamma %-.8e risk %-.8e\n",gamma,risk+Info->desiredrisk);
		opter->hess_choice=hess_choice;
		if(opter->back==6)
		{
			return -1;
		}
		if(Info->roundlots)
		{
			bool worked=true;
			for(size_t i=0;i<opter->n;++i)
			{
				if(Info->shake[i]!=-1)
				{
					worked=false;
					break;
				}
			}
			if(worked)
			{
				dcopyvec(opter->n,opter->x,Info->keepw);
				Info->keepgamma=gamma;
				Info->back=opter->back;
			}
		}
		return risk;
	}
	else
	{
		FOptimise* opter=(class FOptimise*) Info->opter;
		if(Info->shake)
		{
			for(size_t i=0;i<opter->n;++i)
				Info->shake[i]=-1;
		}
		opter->gamma_for_eps=gamma;
		if(gamma>=1-lm_rooteps) 
			opter->lp_really=1;
		else
			opter->lp_really=0;
		opter->AddLog("gamma %-.8e\n",gamma);
		size_t hess_choice=opter->hess_choice;
		if(Info->zetaS!=1)
			dscalvec(opter->n-opter->ncomp,Info->zetaS,opter->H);
		if(Info->zetaF!=1&&opter->nfac>0)
			dscalvec(opter->nfac*(opter->n-opter->ncomp),Info->zetaF,opter->H+opter->n-opter->ncomp);
		try
		{
			int take_keep=opter->take_out_costs;
			unsigned char DoEx=opter->DoExtraIterations;
			opter->hess_choice=1;
			if(gamma < 1.0-lm_eps)
			{
				if(Info->kappa<0)
				{
					opter->AddLog("kappa %-.8e\n",gamma);
					opter->scale_utility_external_terms=gamma/(1-gamma);
				}
				else
					opter->scale_utility_external_terms=Info->kappa/(1-Info->kappa);
				opter->lp=0;
				if(opter->scale_utility_external_terms<=lm_eps&&take_keep==1)
				{
					opter->take_out_costs=2;
					opter->scale_utility_external_terms=1;
				}
				else
				{
					opter->take_out_costs=take_keep;
				}
				if(opter->take_out_costs == 2)
					opter->DoExtraIterations=0;
				else
					opter->DoExtraIterations=DoEx;
				if(opter->take_out_costs==2)
					opter->scale_utility_external_terms=1;
				if(Info->benchmark)
				{
					if(!opter->ImportantCheck())
					{
						opter->CompSetup();
						opter->use_soft_in_hessmult=false;
						opter->qphess(opter->n,1,1,1,opter->H,Info->benchmark,opter->c);
						opter->use_soft_in_hessmult=true;
					}
					dnegvec(opter->n,opter->c);
				}
				else
					dzerovec(opter->n,opter->c);
				daxpyvec(opter->n,-gamma/(1-gamma),Info->alpha,opter->c);
			}
			else
			{
				opter->lp=1;
				dzerovec(opter->n,opter->c);
				daxpyvec(opter->n,-1.0,Info->alpha,opter->c);
			}
			opter->hess_choice=hess_choice;
			pModC ModDeriv=opter->ModDeriv;
			pModQ ModHessian=opter->ModHessian;
			if(opter->shortalphacost)
			{
				dzerovec(opter->n,opter->shortalphacost);
				daxpyvec(opter->n,opter->scale_utility_external_terms,Info->shortalphacost,opter->shortalphacost);
			}
			if(opter->scale_utility_external_terms==0 && opter->ModDeriv)
			{
				if(hess_choice>3 && (opter->delta>=2||opter->delta<-lm_eps)) 
					opter->hess_choice=2;
				else if(opter->delta>=2||opter->delta<-lm_eps) 
					opter->hess_choice=1;
				opter->AddLog("No costs here\n");
				opter->ModDeriv=0;
				opter->ModHessian=0;
			}
			opter->AccumOpt(Info->dropnb,Info->dropnt);
			opter->ModDeriv=ModDeriv;
			opter->ModHessian=ModHessian;
			opter->hess_choice=hess_choice;
			opter->take_out_costs=take_keep;
			opter->DoExtraIterations=DoEx;
		}
		catch(MemProb mess)
		{
			printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
		}
		if(Info->zetaS!=1)
			dscalvec(opter->n-opter->ncomp,1.0/Info->zetaS,opter->H);
		if(Info->zetaF!=1&&opter->nfac>0)
			dscalvec(opter->nfac*(opter->n-opter->ncomp),1.0/Info->zetaF,opter->H+opter->n-opter->ncomp);
		if(opter->x)
		{
			size_t i,n=opter->n;
			std::valarray<double>pw(n);
			vector w=&pw[0];
			if(opter->back<2)
			{
				if(Info->roundlots)//It's a lot to ask for thresh hold and rounding; if it doesn't work quickly enough take out minholdlot and mintradelot
				{
					double init,rww,one=1.0;
					vector min__hold=(Info->minholdlot&&Info->minholdlot->size()?&(*Info->minholdlot)[0]:0);
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						init=(Info->revise?Info->initial[i]:0);
						if(fabs(fabs(opter->x[i])-(rww=fabs(round_weight(opter->x[i],init,Info->min_lot[i],(Info->size_lot?Info->size_lot[i]:0))))) > round_eps)
						{
							if(fabs(opter->x[i]-init)-fabs(Info->min_lot[i])>round_eps)
							{
								if(Info->size_lot&&Info->size_lot[i]>lm_eps)
								{
									long kk=(long)check_digit(floor(one+(fabs(opter->x[i]-init)-Info->min_lot[i])/Info->size_lot[i]));
									if(fabs(kk*Info->size_lot[i]+Info->min_lot[i]-fabs(opter->x[i]-init))>round_eps)
									{
										Info->shake[i]=i;badround++;
									}
								}
							}
							else if(fabs(opter->x[i]-init)-fabs(Info->min_lot[i])<-round_eps)
							{
								Info->shake[i]=i;badround++;
							}
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
					if(Info->revise)opter->Rounding(Info->basket,Info->trades,Info->initial,Info->min_lot,Info->size_lot,w,min__hold,/*min__hold?Info->min_lot:*/0);
					else opter->Rounding(Info->basket,Info->trades,0,Info->min_lot,Info->size_lot,w);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						init=(Info->revise?Info->initial[i]:0);
						if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,Info->min_lot[i],(Info->size_lot?Info->size_lot[i]:0))))) > round_eps)
						{
							if(fabs(w[i]-init)-fabs(Info->min_lot[i])>round_eps)
							{
								if(Info->size_lot&&Info->size_lot[i]>lm_eps)
								{
									long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-Info->min_lot[i])/Info->size_lot[i]));
									if(fabs(kk*Info->size_lot[i]+Info->min_lot[i]-fabs(w[i]-init))>round_eps)
									{
										Info->shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*Info->size_lot[i]+Info->min_lot[i]);
									}
								}
							}
							else if(fabs(w[i]-init)-fabs(Info->min_lot[i])<-round_eps)
								Info->shake[i]=i;
						}
					}
				}
				else if((Info->minholdlot&&Info->minholdlot->size())&&(Info->mintradelot&&Info->mintradelot->size()))
				{
//					Info->minholdlot.resize(2*n);
//					Info->mintradelot.resize(2*n);
//					dcopyvec(n,&(Info->mintradelot)[0],&(Info->mintradelot)[n]);
//					dcopyvec(n,&(Info->minholdlot)[0],&(Info->minholdlot)[n]);
//					opter->Thresh(Info->basket,Info->trades,Info->initial,&(Info->minholdlot)[n],&(Info->mintradelot)[n],w,
//						&(Info->minholdlot)[0],&(Info->mintradelot)[0]);
		OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
		OpSend.m=opter->m;
		OpSend.n=opter->n;
		OpSend.lower=opter->lower;
		OpSend.upper=opter->upper;
		OpSend.x=opter->x;
		OpSend.grad=0;//This is set in Droptwo
		OpSend.OptFunc=BaskInnerOpt;
		OpSend.UtilityFunc=BaskUtility;
		OpSend.GradFunc=BaskGrad;
		OpSend.mabs=opter->mabs;
		OpSend.longbasket=opter->longbasket;
		OpSend.shortbasket=opter->shortbasket;
		OpSend.tradebuy=opter->tradebuy;
		OpSend.tradesell=opter->tradesell;
		OpSend.initial=opter->initial;
		OpSend.MoreInfo=opter;
		OpSend.c=opter->c;
		OpSend.logprint=opter->logprint;
		OpSend.basket=Info->basket;
		OpSend.trades=Info->trades;
		size_t badround=0;
					for(i=0;i<n;++i)
					{
						if((fabs(opter->x[i]) > lm_eps && fabs(opter->x[i]) < (*Info->minholdlot)[i]-lm_eps) ||
							(fabs(opter->x[i]-Info->initial[i]) > lm_eps && fabs(opter->x[i]-Info->initial[i]) < (*Info->mintradelot)[i]-lm_eps))
						{
							Info->shake[i] =i;badround++;
						}
					}
					if(badround)
					{
									for(i=0;i<n;++i){Info->shake[i]=-1;}
		Thresh(&OpSend,opter->initial,&(*Info->mintradelot)[0],w,&(*Info->minholdlot)[0]);
		opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					
					for(i=0;i<n;++i)
					{
						if((fabs(w[i]) > lm_eps && fabs(w[i]) < (*Info->minholdlot)[i]-lm_eps) ||
							(fabs(w[i]-Info->initial[i]) > lm_eps && fabs(w[i]-Info->initial[i]) < (*Info->mintradelot)[i]-lm_eps))
							Info->shake[i] =i;
					}
				}
				else if(Info->minholdlot&&Info->minholdlot->size())
				{
//					opter->Thresh(Info->basket,Info->trades,0,&(Info->minholdlot)[0],w);
					OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
					OpSend.m=opter->m;
					OpSend.n=opter->n;
					OpSend.lower=opter->lower;
					OpSend.upper=opter->upper;
					OpSend.x=opter->x;
					OpSend.grad=0;//This is set in Droptwo
					OpSend.OptFunc=BaskInnerOpt;
					OpSend.UtilityFunc=BaskUtility;
					OpSend.GradFunc=BaskGrad;
					OpSend.mabs=opter->mabs;
					OpSend.longbasket=opter->longbasket;
					OpSend.shortbasket=opter->shortbasket;
					OpSend.tradebuy=opter->tradebuy;
					OpSend.tradesell=opter->tradesell;
					OpSend.initial=opter->initial;
					OpSend.MoreInfo=opter;
					OpSend.c=opter->c;
					OpSend.logprint=opter->logprint;
					OpSend.basket=Info->basket;
					OpSend.trades=Info->trades;
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],0,(*Info->minholdlot)[i],0))) > round_eps && fabs(fabs(opter->x[i])-(*Info->minholdlot)[i])>round_eps)
						{
							Info->shake[i]=i;badround++;
						}
					}
					if(badround)
					{
						for(i=0;i<n;++i){Info->shake[i]=-1;}
						Thresh(&OpSend,0,&(*Info->minholdlot)[0],w);
						opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						if(fabs(fabs(w[i])-fabs(round_weight(w[i],0,(*Info->minholdlot)[i],0))) > round_eps && fabs(fabs(w[i])-(*Info->minholdlot)[i])>round_eps)
						{
							Info->shake[i]=i;
						}
					}
				}
				else if(Info->mintradelot&&Info->mintradelot->size())
				{
					double init;
					//					opter->Thresh(Info->basket,Info->trades,Info->tradethresh?Info->initial:0,&(Info->mintradelot)[0],w);
					OptParamRound OpSend;OpSend.back=opter->back;OpSend.TimeOptData=opter->TimeOptData;
					OpSend.m=opter->m;
					OpSend.n=opter->n;
					OpSend.lower=opter->lower;
					OpSend.upper=opter->upper;
					OpSend.x=opter->x;
					OpSend.grad=0;//This is set in Droptwo
					OpSend.OptFunc=BaskInnerOpt;
					OpSend.UtilityFunc=BaskUtility;
					OpSend.GradFunc=BaskGrad;
					OpSend.mabs=opter->mabs;
					OpSend.longbasket=opter->longbasket;
					OpSend.shortbasket=opter->shortbasket;
					OpSend.tradebuy=opter->tradebuy;
					OpSend.tradesell=opter->tradesell;
					OpSend.initial=opter->initial;
					OpSend.MoreInfo=opter;
					OpSend.c=opter->c;
					OpSend.logprint=opter->logprint;
					OpSend.basket=Info->basket;
					OpSend.trades=Info->trades;
					size_t badround=0;
					for(i=0;i<n;++i)
					{
						//	init=Info->tradethresh?Info->initial[i]:0;
						init=Info->initial[i];
						if(fabs(fabs(opter->x[i])-fabs(round_weight(opter->x[i],init,(*Info->mintradelot)[i],0))) > round_eps && fabs(fabs(opter->x[i]-init)-(*Info->mintradelot)[i])>round_eps)
						{
							Info->shake[i]=i;badround++;
						}
					}
					if(badround)
					{
						for(i=0;i<n;++i){Info->shake[i]=-1;}
						Thresh(&OpSend,opter->initial,&(*Info->mintradelot)[0],w);
						opter->back=(OpSend.back==2?6:OpSend.back);
					}
					else
						dcopyvec(n,opter->x,w);
					for(i=0;i<n;++i)
					{
						//	init=Info->tradethresh?Info->initial[i]:0;
						init=Info->initial[i];
						if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,(*Info->mintradelot)[i],0))) > round_eps && fabs(fabs(w[i]-init)-(*Info->mintradelot)[i])>round_eps)
						{
							Info->shake[i]=i;
						}
					}
				}
				else
				{
					dcopyvec(n,opter->x,w);
				}
				dcopyvec(n,w,opter->x);
			}
		}
		opter->hess_choice=1;
		if(opter->back==6)
		{
			return -1;
		}
		double risk=opter->risk(opter->x,(Info->optactive_but_set_total?0:Info->benchmark))-Info->desiredrisk;
		opter->AddLog("gamma %-.8e risk %-.8e\n",gamma,risk+Info->desiredrisk);
		opter->hess_choice=hess_choice;
		if(Info->roundlots)
		{
			bool worked=true;
			for(size_t i=0;i<opter->n;++i)
			{
				if(Info->shake[i]!=-1)
				{
					worked=false;
					break;
				}
			}
			if(worked)
			{
				dcopyvec(opter->n,opter->x,Info->keepw);
				Info->keepgamma=gamma;
				Info->back=opter->back;
			}
		}
		return risk;
	}
}
double down_func(double gamma,void*info)
{
	downinfopasser* Info=(class downinfopasser*) info;
	if(Info->nfac == -1)
	{
		Optimise* opter=(class Optimise*) Info->opter;
		if(gamma>=1-lm_rooteps) 
			opter->lp_really=1;
		else
			opter->lp_really=0;
		size_t hess_choice=opter->hess_choice;
		try
		{
			int take_keep=opter->take_out_costs;
			unsigned char DoEx=opter->DoExtraIterations;
			opter->hess_choice=1;
			if(gamma < 1.0-lm_eps)
			{
				if(Info->kappa<0)
				{
					opter->AddLog("kappa %-.8e\n",gamma);
					opter->scale_utility_external_terms=gamma/(1-gamma);
				}
				else
					opter->scale_utility_external_terms=Info->kappa/(1-Info->kappa);
				opter->lp=0;
				if(opter->scale_utility_external_terms<=lm_eps&&take_keep==1)
				{
					opter->take_out_costs=2;
					opter->scale_utility_external_terms=1;
				}
				else
				{
					opter->take_out_costs=take_keep;
				}
				if(opter->take_out_costs == 2)
					opter->DoExtraIterations=0;
				else
					opter->DoExtraIterations=DoEx;
				if(Info->benchmark)
				{
					if(!opter->ImportantCheck())
					{
						opter->CompSetup();
						opter->use_soft_in_hessmult=false;
						opter->qphess(opter->n,1,1,1,opter->H,Info->benchmark,opter->c);
						opter->use_soft_in_hessmult=true;
					}
					dnegvec(opter->n,opter->c);
				}
				else
					dzerovec(opter->n,opter->c);
				daxpyvec(opter->n,-gamma/(1-gamma),Info->alpha,opter->c);
			}
			else
			{
				opter->lp=1;
				dzerovec(opter->n,opter->c);
				daxpyvec(opter->n,-1.0,Info->alpha,opter->c);
			}
			opter->hess_choice=hess_choice;
			opter->OptSetup(Info->dropnb,Info->dropnt);
			opter->take_out_costs=take_keep;
			opter->DoExtraIterations=DoEx;
		}
		catch(MemProb mess)
		{
			printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
		}
		if(opter->x)
		{
			size_t i,n=opter->n;
			std::valarray<double>pw(n);
			vector w=&pw[0];
			if(Info->roundlots)
			{
				double init,rww,one=1.0;
				opter->Rounding(Info->basket,Info->trades,(Info->revise?Info->initial:0),Info->min_lot,Info->size_lot,w);
				for(i=0;i<n;++i)
				{
					init=(Info->revise?Info->initial[i]:0);
					if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,Info->min_lot[i],(Info->size_lot?Info->size_lot[i]:0))))) > round_eps)
					{
						if(fabs(w[i]-init)-fabs(Info->min_lot[i])>round_eps)
						{
							if(Info->size_lot&&Info->size_lot[i]>lm_eps)
							{
								long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-Info->min_lot[i])/Info->size_lot[i]));
								if(fabs(kk*Info->size_lot[i]+Info->min_lot[i]-fabs(w[i]-init))>round_eps)
								{
									Info->shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*Info->size_lot[i]+Info->min_lot[i]);
								}
							}
						}
						else if(fabs(w[i]-init)-fabs(Info->min_lot[i])<-round_eps)
							Info->shake[i]=i;
					}
				}
			}
			else if(Info->minholdlot->size()&&Info->mintradelot->size())
			{
				Info->minholdlot->resize(2*n);
				Info->mintradelot->resize(2*n);
				dcopyvec(n,&(*Info->mintradelot)[0],&(*Info->mintradelot)[n]);
				dcopyvec(n,&(*Info->minholdlot)[0],&(*Info->minholdlot)[n]);
				opter->Thresh(Info->basket,Info->trades,Info->initial,&(*Info->minholdlot)[n],&(*Info->mintradelot)[n],w,
					&(*Info->minholdlot)[0],&(*Info->mintradelot)[0]);
				
				for(i=0;i<n;++i)
				{
					if((fabs(w[i]) > lm_eps && fabs(w[i]) < (*Info->minholdlot)[i]-lm_eps) ||
						(fabs(w[i]-Info->initial[i]) > lm_eps && fabs(w[i]-Info->initial[i]) < (*Info->mintradelot)[i]-lm_eps))
						Info->shake[i] =i;
				}
			}
			else if(Info->minholdlot->size())
			{
				opter->Thresh(Info->basket,Info->trades,0,&(*Info->minholdlot)[0],w);
				for(i=0;i<n;++i)
				{
					if(fabs(fabs(w[i])-fabs(round_weight(w[i],0,(*Info->minholdlot)[i],0))) > round_eps && fabs(fabs(w[i])-(*Info->minholdlot)[i])>round_eps)
					{
						Info->shake[i]=i;
					}
				}
			}
			else if(Info->mintradelot->size())
			{
				double init;
				opter->Thresh(Info->basket,Info->trades,(Info->tradethresh?Info->initial:0),&(*Info->mintradelot)[0],w);
				for(i=0;i<n;++i)
				{
					init=(Info->tradethresh?Info->initial[i]:0);
					if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,(*Info->mintradelot)[i],0))) > round_eps && fabs(fabs(w[i]-init)-(*Info->mintradelot)[i])>round_eps)
					{
						Info->shake[i]=i;
					}
				}
			}
			else
			{
				dcopyvec(n,opter->x,w);
			}
			dcopyvec(n,w,opter->x);
		}
		opter->hess_choice=1;
		double rreturn=
			(Info->leaveoutreturn?0:ddotvec(opter->n,Info->alpha,opter->x))
			-(Info->activedown?ddotvec(opter->n,Info->alpha,Info->benchmark):0);
		double down=rreturn - Info->ret_coef*opter->risk(opter->x,(Info->activedown?Info->benchmark:0))-Info->desireddown;
		if(opter->logprint)
			*(opter->logprint)<< "gamma " << gamma<< ", Down measure " << down+Info->desireddown << std::endl;
		opter->hess_choice=hess_choice;
		return down*Info->mult;
	}
	else
	{
		FOptimise* opter=(class FOptimise*) Info->opter;
		if(gamma>=1-lm_rooteps) 
			opter->lp_really=1;
		else
			opter->lp_really=0;
		size_t hess_choice=opter->hess_choice;
		try
		{
			int take_keep=opter->take_out_costs;
			unsigned char DoEx=opter->DoExtraIterations;
			opter->hess_choice=1;
			if(gamma < 1.0-lm_eps)
			{
				if(Info->kappa<0)
				{
					opter->AddLog("kappa %-.8e\n",gamma);
					opter->scale_utility_external_terms=gamma/(1-gamma);
				}
				else
					opter->scale_utility_external_terms=Info->kappa/(1-Info->kappa);
				opter->lp=0;
				if(opter->scale_utility_external_terms<=lm_eps&&take_keep==1)
				{
					opter->take_out_costs=2;
					opter->scale_utility_external_terms=1;
				}
				else
				{
					opter->take_out_costs=take_keep;
				}
				if(opter->take_out_costs == 2)
					opter->DoExtraIterations=0;
				else
					opter->DoExtraIterations=DoEx;
				if(Info->benchmark)
				{
					if(!opter->ImportantCheck())
					{
						opter->CompSetup();
						opter->use_soft_in_hessmult=false;
						opter->qphess(opter->n,1,1,1,opter->H,Info->benchmark,opter->c);
						opter->use_soft_in_hessmult=true;
					}
					dnegvec(opter->n,opter->c);
				}
				else
					dzerovec(opter->n,opter->c);
				daxpyvec(opter->n,-gamma/(1-gamma),Info->alpha,opter->c);
			}
			else
			{
				opter->lp=1;
				dzerovec(opter->n,opter->c);
				daxpyvec(opter->n,-1.0,Info->alpha,opter->c);
			}
			opter->hess_choice=hess_choice;
			opter->OptSetup(Info->dropnb,Info->dropnt);
			opter->take_out_costs=take_keep;
			opter->DoExtraIterations=DoEx;
		}
		catch(MemProb mess)
		{
			printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
		}
		if(opter->x)
		{
			size_t i,n=opter->n;
			std::valarray<double>pw(n);
			vector w=&pw[0];
			if(Info->roundlots)
			{
				double init,rww,one=1.0;
				opter->Rounding(Info->basket,Info->trades,(Info->revise?Info->initial:0),Info->min_lot,Info->size_lot,w);
				for(i=0;i<n;++i)
				{
					init=(Info->revise?Info->initial[i]:0);
					if(fabs(fabs(w[i])-(rww=fabs(round_weight(w[i],init,Info->min_lot[i],(Info->size_lot?Info->size_lot[i]:0))))) > round_eps)
					{
						if(fabs(w[i]-init)-fabs(Info->min_lot[i])>round_eps)
						{
							if(Info->size_lot&&Info->size_lot[i]>lm_eps)
							{
								long kk=(long)check_digit(floor(one+(fabs(w[i]-init)-Info->min_lot[i])/Info->size_lot[i]));
								if(fabs(kk*Info->size_lot[i]+Info->min_lot[i]-fabs(w[i]-init))>round_eps)
								{
									Info->shake[i]=i;opter->AddLog("size_lot check %ld %-.15e %-.15e\n",kk,w[i]-init,kk*Info->size_lot[i]+Info->min_lot[i]);
								}
							}
						}
						else if(fabs(w[i]-init)-fabs(Info->min_lot[i])<-round_eps)
							Info->shake[i]=i;
					}
				}
			}
			else if(Info->minholdlot->size()&&Info->mintradelot->size())
			{
				Info->minholdlot->resize(2*n);
				Info->mintradelot->resize(2*n);
				dcopyvec(n,&(*Info->mintradelot)[0],&(*Info->mintradelot)[n]);
				dcopyvec(n,&(*Info->minholdlot)[0],&(*Info->minholdlot)[n]);
				opter->Thresh(Info->basket,Info->trades,Info->initial,&(*Info->minholdlot)[n],&(*Info->mintradelot)[n],w,
					&(*Info->minholdlot)[0],&(*Info->mintradelot)[0]);
				
				for(i=0;i<n;++i)
				{
					if((fabs(w[i]) > lm_eps && fabs(w[i]) < (*Info->minholdlot)[i]-lm_eps) ||
						(fabs(w[i]-Info->initial[i]) > lm_eps && fabs(w[i]-Info->initial[i]) < (*Info->mintradelot)[i]-lm_eps))
						Info->shake[i] =i;
				}
			}
			else if(Info->minholdlot->size())
			{
				opter->Thresh(Info->basket,Info->trades,0,&(*Info->minholdlot)[0],w);
				for(i=0;i<n;++i)
				{
					if(fabs(fabs(w[i])-fabs(round_weight(w[i],0,(*Info->minholdlot)[i],0))) > round_eps && fabs(fabs(w[i])-(*Info->minholdlot)[i])>round_eps)
					{
						Info->shake[i]=i;
					}
				}
			}
			else if(Info->mintradelot->size())
			{
				double init;
				opter->Thresh(Info->basket,Info->trades,(Info->tradethresh?Info->initial:0),&(*Info->mintradelot)[0],w);
				for(i=0;i<n;++i)
				{
					init=(Info->tradethresh?Info->initial[i]:0);
					if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,(*Info->mintradelot)[i],0))) > round_eps && fabs(fabs(w[i]-init)-(*Info->mintradelot)[i])>round_eps)
					{
						Info->shake[i]=i;
					}
				}
			}
			else
			{
				dcopyvec(n,opter->x,w);
			}
			dcopyvec(n,w,opter->x);
		}
		opter->hess_choice=1;

		double riskhere;
		double rreturn=
			(Info->leaveoutreturn?0:ddotvec(opter->n,Info->alpha,opter->x))
			-(Info->activedown?ddotvec(opter->n,Info->alpha,Info->benchmark):0);
		double down=rreturn - Info->ret_coef*(riskhere=opter->risk(opter->x,(Info->activedown?Info->benchmark:0)))-Info->desireddown;

		opter->hess_choice=hess_choice;
		if(opter->logprint)
			*(opter->logprint)<< "gamma " << gamma<< ", Down measure " << down+Info->desireddown << std::endl;
		return down*Info->mult;
	}
}
void 	MarginalUtility(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  dimen npiece,vector hpiece,vector pgrad,
									  vector buy,vector sell,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  vector utility_per_stock,
									  vector cost_per_stock,
									  dimen ncomp,
									  vector Composite)
{
	MarginalUtilityb(n,nfac,names,w,benchmark,initial,Q,gamma,kappa,npiece,hpiece,pgrad,buy,sell,alpha,tcost,utility,gradutility,
		utility_per_stock,cost_per_stock,ncomp,Composite,1);
}
void 	MarginalUtilityb(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  dimen npiece,vector hpiece,vector pgrad,
									  vector buy,vector sell,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  vector utility_per_stock,
									  vector cost_per_stock,
									  dimen ncomp,
									  vector Composite,double ShortCostScale)
{
	MarginalUtilitybSa(n,nfac,names,w,benchmark,initial,Q,gamma,kappa,npiece,hpiece,pgrad,buy,sell,alpha,tcost,utility,gradutility,
		utility_per_stock,cost_per_stock,ncomp,Composite,ShortCostScale,0);
}
void 	MarginalUtilitybSa(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  dimen npiece,vector hpiece,vector pgrad,
									  vector buy,vector sell,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  vector utility_per_stock,
									  vector cost_per_stock,
									  dimen ncomp,
									  vector Composite,double ShortCostScale,
									  vector shortalphacost)
{
	MarginalUtilitybSaQ(n,nfac,names,w,benchmark,initial,Q,gamma,kappa,npiece,hpiece,pgrad,buy,sell,alpha,tcost,utility,gradutility,
		utility_per_stock,cost_per_stock,ncomp,Composite,ShortCostScale,shortalphacost,0,0);
}
void 	MarginalUtilitybSaQ(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  dimen npiece,vector hpiece,vector pgrad,
									  vector buy,vector sell,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  vector utility_per_stock,
									  vector cost_per_stock,
									  dimen ncomp,
									  vector Composite,double ShortCostScale,
									  vector shortalphacost,vector qbuy,vector qsell)
{
#ifdef PAS
//	UnlockBita("colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,"Bad PAS key\n");
		return;
	}
#endif
	bool log=0;
#ifdef _DEBUG
	log=1;
#endif
	std::valarray<double>usealpha,bench,initI;
	if(!benchmark){bench.resize(n);benchmark=&bench[0];}
	if(!initial){initI.resize(n);initial=&initI[0];}
	if(!alpha)
	{
		usealpha.resize(n);
		usealpha=0;
		alpha=&usealpha[0];
	}
	if(kappa<0){kappa=gamma;}
	if(nfac==-1)
	{
		Optimise prop;
		if(prop.checker->number_of_days_left<=-1) return;
		size_t i;
		prop.n=n;
		prop.H=Q;
		prop.ncomp=ncomp;
		prop.Composites=Composite;
		prop.ShortCostScale=ShortCostScale;
		dzerovec(n,utility_per_stock);
		if(gamma<(1-lm_eps))
		{
			double ss=gamma/(1-gamma),su;
			prop.MC(w,benchmark,gradutility);
			*utility=ddotvec(n,w,gradutility)-(benchmark?ddotvec(n,benchmark,gradutility):0);
			su=.5* *utility;
			dscalvec(n,*utility,gradutility);
			for(i=0;i<n;++i)
			{
				utility_per_stock[i]=(0.5*gradutility[i] -ss*alpha[i])*(w[i]-
					(benchmark?benchmark[i]:0));
				gradutility[i]-=ss*alpha[i];
			}
			*utility *= su ;
			*utility -= ss*(ddotvec(n,alpha,w)-(benchmark?ddotvec(n,benchmark,alpha):0));
		}
		else
		{
			dcopyvec(n,alpha,gradutility);
			dnegvec(n,gradutility);
			*utility=-(ddotvec(n,alpha,w)-(benchmark?ddotvec(n,benchmark,alpha):0));
			for(i=0;i<n;++i)
			{
				utility_per_stock[i]=-alpha[i]*(w[i]-(benchmark?benchmark[i]:0));
			}
		}
		if((npiece==0)&&buy&&sell)
		{
			linearcostpasser pass;
			double ss=kappa/(1-kappa),Sa=0;
			pass.buy=buy;
			pass.sell=sell;
			pass.qbuy=qbuy;
			pass.qsell=qsell;
			pass.nstocks=n;
			pass.initial=initial;
			pass.ShortCostScale=ShortCostScale;
			buysell_grad(n,w,cost_per_stock,&pass);
			for(i=0;i<n;++i)
			{
				gradutility[i]+=ss*cost_per_stock[i];
				if(w[i]<0&&shortalphacost)
				{
					gradutility[i]-=ss*shortalphacost[i];
					Sa-=w[i]*shortalphacost[i];
				}
			}
			*tcost=buysell_cost_per_stock(n,w,cost_per_stock,&pass)+Sa;
			if(kappa)
			{
				for(i=0;i<n;++i)
				{
					utility_per_stock[i]+=ss*cost_per_stock[i];
					if(w[i]<0&&shortalphacost)
						utility_per_stock[i]-=ss*shortalphacost[i];
				}
				*utility+=ss* *tcost;
			}
		}
		else if(npiece)
		{
			piececostpasser pass;
			double ss=kappa/(1-kappa),Sa=0;
			pass.hpiece=hpiece;
			pass.pgrad=pgrad;
			pass.nstocks=n;
			pass.npiece=npiece;
			pass.initial=initial;
			pass.ShortCostScale=ShortCostScale;
			piece_grad(n,w,cost_per_stock,&pass);
			for(i=0;i<n;++i)
			{
				gradutility[i]+=ss*cost_per_stock[i];
				if(w[i]<0&&shortalphacost)
				{
					gradutility[i]-=ss*shortalphacost[i];
					Sa-=w[i]*shortalphacost[i];
				}
			}
			*tcost=piece_cost_per_stock(n,w,cost_per_stock,&pass)+Sa;
			if(kappa)
			{
				for(i=0;i<n;++i)
				{
					utility_per_stock[i]+=ss*cost_per_stock[i];
					if(w[i]<0&&shortalphacost)
						utility_per_stock[i]-=ss*shortalphacost[i];
				}
				*utility+=ss* *tcost;
			}
		}
	}
	else
	{
		FOptimise prop;
		if(prop.checker->number_of_days_left<=-1) return;
		size_t i;
		prop.n=n;
		prop.H=Q;
		prop.nfac=nfac;
		prop.ncomp=ncomp;
		prop.Composites=Composite;
		prop.ShortCostScale=ShortCostScale;
		dzerovec(n,utility_per_stock);
		if(gamma<(1-lm_eps))
		{
			double ss=gamma/(1-gamma),su;
			prop.MC(w,benchmark,gradutility);
			*utility=ddotvec(n,w,gradutility)-(benchmark?ddotvec(n,benchmark,gradutility):0);
			su=.5* *utility;
			dscalvec(n,*utility,gradutility);
			for(i=0;i<n;++i)
			{
				utility_per_stock[i]=(0.5*gradutility[i] -ss*alpha[i])*(w[i]-
					(benchmark?benchmark[i]:0));
				gradutility[i]-=ss*alpha[i];
			}
			*utility *= su ;
			*utility -= ss*(ddotvec(n,alpha,w)-(benchmark?ddotvec(n,benchmark,alpha):0));
		}
		else
		{
			dcopyvec(n,alpha,gradutility);
			dnegvec(n,gradutility);
			*utility=-(ddotvec(n,alpha,w)-(benchmark?ddotvec(n,benchmark,alpha):0));
			for(i=0;i<n;++i)
			{
				utility_per_stock[i]=-alpha[i]*(w[i]-(benchmark?benchmark[i]:0));
			}
		}
		if((npiece==0)&&buy&&sell)
		{
			linearcostpasser pass;
			double ss=kappa/(1-kappa),Sa=0;
			if(kappa==1)ss=1;
			pass.buy=buy;
			pass.sell=sell;
			pass.qbuy=qbuy;
			pass.qsell=qsell;
			pass.nstocks=n;
			pass.initial=initial;
			pass.ShortCostScale=ShortCostScale;
			buysell_grad(n,w,cost_per_stock,&pass);
			for(i=0;i<n;++i)
			{
				gradutility[i]+=ss*cost_per_stock[i];
			}
			if(w[i]<0&&shortalphacost)
			{
				gradutility[i]-=ss*shortalphacost[i];
				Sa-=w[i]*shortalphacost[i];
			}
			*tcost=buysell_cost_per_stock(n,w,cost_per_stock,&pass)+Sa;
			if(kappa)
			{
				for(i=0;i<n;++i)
				{
					utility_per_stock[i]+=ss*cost_per_stock[i];
					if(w[i]<0&&shortalphacost)
						utility_per_stock[i]-=ss*shortalphacost[i];
				}
				*utility+=ss* *tcost;
			}
		}
		else if(npiece)
		{
			piececostpasser pass;
			double ss=kappa/(1-kappa),Sa=0;
			if(kappa==1)ss=1;
			pass.hpiece=hpiece;
			pass.pgrad=pgrad;
			pass.nstocks=n;
			pass.npiece=npiece;
			pass.initial=initial;
			pass.ShortCostScale=ShortCostScale;
			piece_grad(n,w,cost_per_stock,&pass);
			if(w[i]<0&&shortalphacost)
			{
				gradutility[i]-=ss*shortalphacost[i];
				Sa-=w[i]*shortalphacost[i];
			}
			*tcost=piece_cost_per_stock(n,w,cost_per_stock,&pass)+Sa;
			if(kappa)
			{
				for(i=0;i<n;++i)
				{
					utility_per_stock[i]+=ss*cost_per_stock[i];
					if(w[i]<0&&shortalphacost)
						utility_per_stock[i]-=ss*shortalphacost[i];
				}
				*utility+=ss* *tcost+Sa;
			}
		}
	}
	if(log&&gradutility)
	{
		printf("%20s %20s %20s\n","Variable name","Weight","Utility gradient");
		char nn[21];
		for(size_t i = 0;i < n;++i)
		{
			if(names)
				strncpy(nn,names[i],20);
			else
				sprintf(nn,"Stock %d",i+1);
			nn[20]='\0';
			printf("%20s %20.8e %20.8e\n",nn,w[i],gradutility[i]);
		}
		printf("utility\t\t\t\t%-.8e\n",*utility);
	}
	if(log&&utility)
		printf("utility\t\t\t\t%-.8e\n",*utility);
	if(log&&tcost)
		printf("total cost\t\t\t%-.8e\n",*tcost);
}
void 	MarginalUtility_ext(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  dimen ncomp,
									  vector Composite,double ShortCostScale,
									  pUtility Util,pModC ModDeriv,
									  void *Uinfo,void *Minfo,vector shortalphacost)
{
#ifdef PAS
//	UnlockBita("colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,"Bad PAS key\n");
		return ;
	}
#endif
	bool log=0;
#ifdef _DEBUG
	log=1;
#endif
	if(kappa<0){kappa=gamma;}
	std::valarray<double>usealpha;
	if(!alpha)
	{
		usealpha.resize(n);
		usealpha=0;
		alpha=&usealpha[0];
	}
	if(nfac==-1)
	{
		Optimise prop;
		if(prop.checker->number_of_days_left<=-1) return;
		prop.n=n;
		prop.H=Q;
		prop.ncomp=ncomp;
		prop.Composites=Composite;
		prop.ShortCostScale=ShortCostScale;
		if(gamma<(1-lm_eps))
		{
			double ss=gamma/(1-gamma),su;
			prop.MC(w,benchmark,gradutility);
			*utility=ddotvec(n,w,gradutility)-(benchmark?ddotvec(n,benchmark,gradutility):0);
			su=.5* *utility;
			dscalvec(n,*utility,gradutility);
			daxpyvec(n,-ss,alpha,gradutility);
			*utility *= su ;
			*utility -= ss*(ddotvec(n,alpha,w)-(benchmark?ddotvec(n,benchmark,alpha):0));
		}
		else
		{
			dcopyvec(n,alpha,gradutility);
			dnegvec(n,gradutility);
			*utility=-(ddotvec(n,alpha,w)-(benchmark?ddotvec(n,benchmark,alpha):0));
		}
		if(kappa&&Util&&Uinfo&&ModDeriv&&Minfo)
		{
			double ss=kappa/(1-kappa),Sa=0;
			std::valarray<double> cgrad(n);
			ModDeriv(n,w,&cgrad[0],Minfo);
			daxpyvec(n,ss,&cgrad[0],gradutility);
			if(shortalphacost)
			{
				size_t i;
				for(i=0;i<n;++i)
				{
					if(w[i]<0)
					{
						gradutility[i]-=ss*shortalphacost[i];
						Sa-=w[i]*shortalphacost[i];
					}
				}
			}

			*tcost=Util(n,w,Uinfo)+Sa;
			*utility+=ss* (*tcost+Sa);
		}
	}
	else
	{
		FOptimise prop;
		if(prop.checker->number_of_days_left<=-1) return;
		prop.n=n;
		prop.H=Q;
		prop.nfac=nfac;
		prop.ncomp=ncomp;
		prop.Composites=Composite;
		prop.ShortCostScale=ShortCostScale;
		if(gamma<(1-lm_eps))
		{
			double ss=gamma/(1-gamma),su;
			prop.MC(w,benchmark,gradutility);
			*utility=ddotvec(n,w,gradutility)-(benchmark?ddotvec(n,benchmark,gradutility):0);
			su=.5* *utility;
			dscalvec(n,*utility,gradutility);
			daxpyvec(n,-ss,alpha,gradutility);
			*utility *= su ;
			*utility -= ss*(ddotvec(n,alpha,w)-(benchmark?ddotvec(n,benchmark,alpha):0));
		}
		else
		{
			dcopyvec(n,alpha,gradutility);
			dnegvec(n,gradutility);
			*utility=-(ddotvec(n,alpha,w)-(benchmark?ddotvec(n,benchmark,alpha):0));
		}
		if(kappa&&Util&&Uinfo&&ModDeriv&&Minfo)
		{
			double ss=kappa/(1-kappa),Sa=0;
			std::valarray<double> cgrad(n);
			ModDeriv(n,w,&cgrad[0],Minfo);
			daxpyvec(n,ss,&cgrad[0],gradutility);
			if(shortalphacost)
			{
				size_t i;
				for(i=0;i<n;++i)
				{
					if(w[i]<0)
					{
						gradutility[i]-=ss*shortalphacost[i];
						Sa-=w[i]*shortalphacost[i];
					}
				}
			}
			*tcost=Util(n,w,Uinfo)+Sa;
			*utility+=ss* (*tcost+Sa);
		}
	}
	if(log&&gradutility)
	{
		printf("%20s %20s %20s\n","Variable name","Weight","Utility gradient");
		char nn[21];
		for(size_t i = 0;i < n;++i)
		{
			if(names)
				strncpy(nn,names[i],20);
			else
				sprintf(nn,"Stock %d",i+1);
			nn[20]='\0';
			printf("%20s %20.8e %20.8e\n",nn,w[i],gradutility[i]);
		}
		printf("utility\t\t\t\t%-.8e\n",*utility);
	}
	if(log&&utility)
		printf("utility\t\t\t\t%-.8e\n",*utility);
	if(log&&tcost)
		printf("total cost\t\t\t%-.8e\n",*tcost);
}
int	fix_covariancem(dimen n,vector Q)
{
	vector QDecomp;
	int error = 0;
	if(dsmxmpd_check( n, Q , 0, &QDecomp)){error = 1;}

	delete[]QDecomp;
	return error;
}
short	decomp_cov(dimen n,vector Q,vector Q_Decomp)
{
	vector QDecomp;
	dimen nn = (n * (n + 1)) >> 1;
	short_vec P = (short_vec) (Q_Decomp + nn),PP;
	dimen i;

	short back=dsmxmpd_check( n, Q , 0, &QDecomp);

	PP = (short_vec) (QDecomp + nn);
	dcopyvec(nn,QDecomp,Q_Decomp);
	for(i = 0;i < n;++i){P[i] = PP[i];}
	delete[]QDecomp;
	return back;
}
short InvQ_d(dimen n,vector Q,vector d,vector Qm1d)
{
	short back=0;
	if(n > 1)
	{
		dimen nn = (n * (n + 1)) >> 1;
		vector Qcopy = new double[(2 * nn * sizeof(*Qcopy) + n * sizeof(short_vec))];

		dcopyvec(nn,Q,Qcopy);
		dcopyvec(n,d,Qm1d);
		back=decomp_cov(n,Qcopy,Qcopy + nn);
		dsmxainv(n,Qcopy + nn,(short_vec) (Qcopy + nn * 2),Qm1d);

		delete[]Qcopy;
	}
	else if(n == 1)
	{
		*Qm1d = *d / *Q;
	}
	return back;
}
short ConstrRegress(dimen n,dimen m,vector Q,vector c,vector w,vector L,vector U,vector A)
{
	dnegvec(n,c);
	Optimise opt;
	opt.n=n;
	opt.m=m;
	opt.H=Q;
	opt.c=c;
	opt.lower=L;
	opt.upper=U;
	opt.A=A;
	try
	{
		opt.OptSetup(n);
	}
	catch(MemProb mess)
	{
		printf("n=%ld. %s, cannot allocate %ld bytes\n",mess.n,mess.mess.c_str(),mess.amount);
	}
	dcopyvec(n,opt.x,w);
	dnegvec(n,c);
	return opt.back;
}
char*	Return_Message(int ifail)
{
#ifdef PAS
//	UnlockBita("colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,"Bad PAS key\n");
		return (char*)"Bad PAS key";
	}
#endif
	if(ifail==-1) return (char*)"UNLICENCED";
	if(ifail<21)return Return_Messages[ifail];
	else return (char*)"Only 21 messages";
}
char* expire_date(char*a)
{
	Optimise opt;
	strcpy(a,opt.checker->EXPIREDATE);
	return a;
}
char* version(char* a)
{
	Optimise opt;
	strcpy(a,opt.Version);
	return a;
}
char* cversion(char* a)
{
	Optimise opt;
	strcpy(a,opt.checker->VERSION);
	return a;
}
char* component_key(char* a)
{
	Optimise opt;
	strcpy(a,opt.checker->CURVECOMPS);
	return a;
}
int	days_left(char **a)
{
	Optimise opt;
	if(a && opt.checker->STOP)	
	{
		a[0]= strcpy(a[0],opt.checker->STOP);
	}
	return opt.checker->number_of_days_left;
}

//__________________________________________________________________________________



