#include "optimise.h"
#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#endif

extern "C" void patternmin(unsigned long n,double *x, double *step, 
	double *f, double scale,short iprint, short icon, 
	unsigned long maxit, double *w, pUtility calcfx,void*info);

template <typename T> void getmaxmin(size_t n,T* x,T& mmax,T& mmin)
{
	mmax=*x;
	mmin=*x;
	while(n--)
	{
		mmin=dmin(mmin,*x);
		mmax=dmax(mmax,*x);
		x++;
	}
}
inline void rescale(size_t n,vector x)
{
	double m1,m2;
	getmaxmin(n,x,m2,m1);
	std::valarray<double> u(n);
	dsetvec(n,(m2+m1)*.5,&u[0]);
	dsubvec(n,x,&u[0],x);
	dscalvec(n,1.0/(m2-m1),x);
}
inline void printx1(size_t n,vector x)
{
	for(size_t i = 0;i<n;++i)
	{
		std::cout.width(5);
		std::cout << i+1;
		std::cout.width(25);
		std::cout.precision(15);
		std::cout << x[i] << std::endl;
	}
}
char* MultiStageMessages[]=
{
	(char*)"Maximum Final Wealth found",
	(char*)"Needs more function evaluations to get a truly optimal solution",
	(char*)"Could not find a feasible solution"
};
char*	MultiStageMessage(int ifail)
{
	if(ifail<3)return MultiStageMessages[ifail];
	else return (char*)"Only 3 messages";
}
inline double turnover(size_t n,vector w,vector i,vector mask=0)
{
	double turn=0;
	while(n--){turn += fabs(*w++ - *i++) * (mask?*mask++:0);}
	return turn*.5;
}
inline short Stageopt(size_t n,char** names,vector w,vector A,vector L,vector U,vector alpha,
			   vector benchmark,vector Q,double gamma,vector initial,double delta,
			   double maxrisk,double* ogamma,vector mask)
{
	return 	Optimise_internalCVPAF(n,-1,names,w,2,A,L,U,alpha,benchmark,
		Q,gamma,initial,delta,0,0,0,-1,-1,1,0,-1,-1,0,0,-1,-1,0,0,0,0,0,0,1,0,0,0,
		0,0,0,0,0,0,0,0,0,maxrisk,ogamma,mask);
}
class stageinfo
{
public:
	char** names;
	bool print;
	size_t cashnum;
	double delta;
	double maxrisk;
	double cashlow;
	vector Alpha;
	vector first;
	size_t meth;
	size_t nstocks;
	size_t nyears;
	dimen* NumberYears;
	vector Growth;
	vector Yield;
	vector Liability;
	vector lower;
	vector upper;
	vector A;
	vector benchmark;
	vector Q;
	vector mask;
	vector WealthFactor;
	vector iallocation;
	vector ballocation;
	vector allocation;
	vector risks;
	vector lbound;
	vector ubound;
	bool	centreit;
};
inline double gammarise(double x){double x2=x*x;return x2/(1+x2);}
double finalwealth(dimen n,vector x,void* info)
{
	stageinfo *Stageinfo=(class stageinfo*)info;
	std::valarray<double> initial(Stageinfo->nstocks),w(Stageinfo->nstocks),alpha(Stageinfo->nstocks);
	std::valarray<double> gotturn(Stageinfo->nyears);
	double gamma,ogamma,wealthnow,FinalWealth=1e45;

	double arisk,risk,Rrisk,brisk,pbeta,riskscale;
	size_t i,year,periodlen;
	short back;
	bool problem=0;
	double mmax,mmin;
	dcopyvec(Stageinfo->nstocks,Stageinfo->first,&initial[0]);
	for(year=0;year<Stageinfo->nyears;++year)
	{
		if(Stageinfo->meth)
		{
			if(year<Stageinfo->nyears-1)
			{
				dcopyvec(Stageinfo->nstocks,x+year*Stageinfo->nstocks,&alpha[0]);
				if(Stageinfo->centreit)
				{
					dxminmax(alpha.size(),&alpha[0],1,&mmax,&mmin);
//					getmaxmin(alpha.size(),&alpha[0],mmax,mmin);
					if(fabs(mmax-mmin) > lm_eps)
					{
						alpha-=((mmax+mmin)*.5);
						alpha/=(mmax-mmin);
					}
					else
						alpha=0;
				}
			}
			else
				dcopyvec(Stageinfo->nstocks,Stageinfo->Alpha+year*Stageinfo->nstocks,&alpha[0]);
			gamma=1-lm_rooteps;
		}
		else
		{
			dcopyvec(Stageinfo->nstocks,Stageinfo->Alpha+year*Stageinfo->nstocks,&alpha[0]);
			if(year<n)
				gamma=gammarise(x[year]);
			else
				gamma=1-lm_rooteps;
		}
		wealthnow=dsumvec(Stageinfo->nstocks,&initial[0]);
		/*Asset bounds*/
		for(i=0;i<Stageinfo->nstocks;++i)
		{
			Stageinfo->lower[i]=wealthnow*Stageinfo->lbound[i];///(1+Stageinfo->Growth[i+year*Stageinfo->nstocks]);
			Stageinfo->upper[i]=wealthnow*Stageinfo->ubound[i];///(1+Stageinfo->Growth[i+year*Stageinfo->nstocks]);
		}
		/*Budget*/
		Stageinfo->lower[Stageinfo->nstocks]=wealthnow;
		Stageinfo->upper[Stageinfo->nstocks]=wealthnow;

		/*Set up linear constraint to make evolved cash+total yield>=liability*/
		for(i=0;i<Stageinfo->nstocks;++i)
		{
			Stageinfo->A[1+2*i]=Stageinfo->Yield[i+year*Stageinfo->nstocks];
		}
		Stageinfo->A[1+2*Stageinfo->cashnum]+=1+Stageinfo->Growth[Stageinfo->cashnum+year*Stageinfo->nstocks];
		Stageinfo->lower[Stageinfo->nstocks+1]=Stageinfo->Liability[year];
		Stageinfo->upper[Stageinfo->nstocks+1]=1e10+Stageinfo->Liability[year];


		if(Stageinfo->NumberYears)
		{
			periodlen=Stageinfo->NumberYears[year];
			if(periodlen!=1)
			{
				dscalvec(Stageinfo->nstocks*(Stageinfo->nstocks+1)/2,(double)periodlen,Stageinfo->Q);
				riskscale=sqrt((double)periodlen);
			}
			else
				riskscale=1;
		}
		else
		{
			periodlen=1;
			riskscale=1;
		}
		back=Stageopt(Stageinfo->nstocks,Stageinfo->names,&w[0],Stageinfo->A,Stageinfo->lower,Stageinfo->upper,
			&alpha[0],Stageinfo->benchmark,
			Stageinfo->Q,gamma,&initial[0],wealthnow*Stageinfo->delta,riskscale*Stageinfo->maxrisk,&ogamma,Stageinfo->mask);
		if(back==12)
		{
			if(Stageinfo->meth)
				gamma=1-lm_rooteps;
			alpha=-alpha;
//			printf((char*)"====================================Change sign because %d=======================\n",back);
			back=Stageopt(Stageinfo->nstocks,Stageinfo->names,&w[0],Stageinfo->A,Stageinfo->lower,Stageinfo->upper,
				&alpha[0],Stageinfo->benchmark,
				Stageinfo->Q,gamma,&initial[0],wealthnow*Stageinfo->delta,riskscale*Stageinfo->maxrisk,&ogamma,Stageinfo->mask);
//			if(back<=1)
//				printf((char*)"================================Good to change ====================\n");
		}
		gotturn[year]=turnover(w.size(),&w[0],&initial[0],Stageinfo->mask);
		if(periodlen!=1)
			dscalvec(Stageinfo->nstocks*(Stageinfo->nstocks+1)/2,1.0/(double)periodlen,Stageinfo->Q);
		if(back>1) 
		{
			/*Infeasible in the last stage probably leads to final wealth < 0. It's better to
			use this value than -1000 used below*/
			if(back==12||year<Stageinfo->nyears-1)
				problem=1;
			if(Stageinfo->print)printf((char*)"%s\n",Return_Message(back));
		}
		dcopyvec(Stageinfo->nstocks,&w[0],Stageinfo->ballocation+Stageinfo->nstocks*year);
		Get_RisksC(Stageinfo->nstocks,-1,Stageinfo->Q,&w[0],Stageinfo->benchmark,
			&arisk,&risk,&Rrisk,&brisk,&pbeta,0,0);
		FinalWealth=ddotvec(Stageinfo->nstocks,&w[0],&alpha[0]);
		for(i=year;i<Stageinfo->nyears;++i)
		{
			FinalWealth-=Stageinfo->Liability[i];
		}
		for(i=0;i<Stageinfo->nstocks;++i)
		{
			w[i]*=(1+Stageinfo->Growth[i+Stageinfo->nstocks*year]);
		}
		if(year==Stageinfo->nyears-1 && back>1)
		{
			if(FinalWealth > 0) problem=1;//If infeasible and final wealth > 0 we mustn't use the calculated value
		}
		w[Stageinfo->cashnum]+=ddotvec(Stageinfo->nstocks,Stageinfo->ballocation+Stageinfo->nstocks*year,Stageinfo->Yield+Stageinfo->nstocks*year);
		if(Stageinfo->print)
		{
			printf((char*)"%20s Period %d\n",(char*)" ",year+1);
            printf((char*)"%20s %20s %20s %20s %20s\n",(char*)"Asset Class",(char*)"Start",(char*)"Re-balanced",(char*)"Evolved",(char*)"Alphas used");
			for(i=0;i<Stageinfo->nstocks;++i)
			{
                printf((char*)"%20s %20.8e %20.8e %20.8e %20.8e\n",Stageinfo->names[i],initial[i],
					(Stageinfo->ballocation+Stageinfo->nstocks*year)[i],w[i],alpha[i]);
			}
            printf((char*)"Initial Wealth\t\t%20.8e\n",dsumvec(Stageinfo->nstocks,&initial[0]));
            printf((char*)"Wealth Now\t\t%20.8e\n",dsumvec(Stageinfo->nstocks,&w[0]));
            printf((char*)"Wealth Less Liability\t%20.8e\n",dsumvec(Stageinfo->nstocks,&w[0])
				-Stageinfo->Liability[year]);
			if(year == Stageinfo->nyears-1)
				printf((char*)"Expected Final Wealth\t%20.8e\n",FinalWealth);
            printf((char*)"Gamma\t\t\t%20.8e\n",gamma);
            printf((char*)"Gamma\t\t\t%20.8e\n",ogamma);
            printf((char*)"Risk\t\t\t%20.8e\n",arisk);
            printf((char*)"Turnover\t\t%20.8e\n",(turnover(Stageinfo->nstocks,
				Stageinfo->ballocation+Stageinfo->nstocks*year,&initial[0],
				Stageinfo->mask)/wealthnow));
		}
		dcopyvec(Stageinfo->nstocks,&w[0],Stageinfo->allocation+Stageinfo->nstocks*year);
		dcopyvec(Stageinfo->nstocks,&initial[0],Stageinfo->iallocation+Stageinfo->nstocks*year);
		Stageinfo->risks[year]=arisk;
		dcopyvec(Stageinfo->nstocks,&w[0],&initial[0]);
		initial[Stageinfo->cashnum]-=Stageinfo->Liability[year];
	}

/*	for(i=0;i<n;++i)
		std::cout << x[i] << " ";
	std::cout << std::endl;*/
	if(!problem)
	{
//		std::cout << -FinalWealth<<std::endl;
		return -FinalWealth;
	}
	else 
	{
//		std::cout << 1e3<<std::endl;
		return 1e3;//FinalWealth*dsumvec(gotturn.size(),&gotturn[0]);
	}
}
size_t multistage(size_t n,size_t y,vector w,vector before,vector rebalanced,vector risks,vector Growth,vector Yield,vector Liability,
				vector lbound,vector ubound,char** names,vector Q,vector first,
				double delta,double maxrisk,dimen* NumberYears,size_t meth,size_t print)
{
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return 4;
	}
	return 4;
#endif
	stageinfo Info;
	size_t i,j,k,ntime,cashnum=0;
	std::valarray<double> mask(n),lower(n+2),upper(n+2),A(2*n),WealthFactor(y*n),YY(y*n),GG(y*n);
	std::valarray<double> alpha(y*n),benchmark(n);
	std::valarray<double> x;
/*	for(i=0;i<n*y;++i)
		std::cout << Growth[i] << " ";
	std::cout << std::endl;
	for(i=0;i<n*y;++i)
		std::cout << Yield[i] << " ";
	std::cout << std::endl;
	for(i=0;i<y;++i)
		std::cout << Liability[i] << " ";
	std::cout << std::endl;
	for(i=0;NumberYears&&i<y;++i)
		std::cout << NumberYears[i] << " ";
	std::cout << std::endl;*/
#ifdef __SYSNT__
_ASSERT(0);
#endif
	mask=1.0;
	benchmark=0;
	A=1;
	std::string testname;
	for(i=0;i<n;++i)
	{
		testname=names[i];
		if(!testname.find((char*)"CASH"))
		{
			cashnum=i;
		}
	}
	mask[cashnum]=0;
	double growth;
	for(i=1;i<=y;++i)
	{
		j=y-i;
		ntime=1;
		if(NumberYears){ntime=NumberYears[j];}
		for(k=0;k<n;++k)
		{
			growth=pow(1.0+Growth[k+j*n],(int)ntime)+pow(1.0+Yield[k+j*n],(int)ntime)-1.0;
			if(i==1) 	alpha[k+j*n]=growth;
			else alpha[k+j*n]=WealthFactor[k+(j+1)*n]*alpha[k+(j+1)*n];
			WealthFactor[k+j*n]=growth;
		}
	}
	for(i=0;i<y;++i)
	{
		if(NumberYears)
		{
			ntime=NumberYears[i];
			for(k=0;k<n;++k)
			{
				GG[k+i*n]=pow(1+Growth[k+i*n],(int)ntime)-1;
				YY[k+i*n]=pow(1+Yield[k+i*n],(int)ntime)-1;
			}
		}
		else
		{
			dcopyvec(GG.size(),Growth,&GG[0]);
			dcopyvec(YY.size(),Yield,&YY[0]);
		}
	}

	dcopyvec(n,lbound,&lower[0]);
	dcopyvec(n,ubound,&upper[0]);

	Info.A=&A[0];
	Info.Alpha=&alpha[0];
	Info.benchmark=&benchmark[0];
	Info.cashnum=cashnum;
	Info.first=first;
	Info.Growth=&GG[0];
	Info.Liability=Liability;
	Info.lower=&lower[0];
	Info.meth=meth;
	Info.names=names;
	Info.nstocks=n;
	Info.NumberYears=NumberYears;
	Info.nyears=y;
	Info.upper=&upper[0];
	Info.Yield=&YY[0];
	Info.delta=delta;
	Info.maxrisk=maxrisk;
	Info.Q=Q;
	Info.mask=&mask[0];
	Info.print=print?1:0;
	Info.WealthFactor=&WealthFactor[0];
	Info.allocation=w;
	Info.iallocation=before;
	Info.ballocation=rebalanced;
	Info.risks=risks;
	Info.cashlow=lbound[cashnum];
	Info.lbound=lbound;
	Info.ubound=ubound;
	Info.centreit=1;

	double E;
	if(meth)//Optimise the alphas directly
	{
		int i;
		x.resize((y-1)*n);
		dcopyvec(x.size(),&alpha[0],&x[0]);
//		for(i=0;i<(int)(y-1);++i) rescale(n,&x[i*n]);
		E=finalwealth(x.size(),&x[0],&Info);
		if(E == 1e3)
		{
			Info.print=0;
/*            for(i=0;i<(int)(x.size());++i)
				x[i]=1e-5*(i+1);
*/			for(i=x.size()-1;i>=0;--i)
			{
                x[i]+=(.1);
                E=finalwealth(x.size(),&x[0],&Info);
                if(E<=0)break;
                x[i]-=(.2);
                E=finalwealth(x.size(),&x[0],&Info);
                if(E<=0)break;
			}
		}
	}
	else//Optimise the alphas indirectly through gamma (fewer variables but doesn't always work)
	{
		x.resize(y-1);
		x=0;
		E=finalwealth(x.size(),&x[0],&Info);
		if(E == 1e3)
		{
			for(i=0;i<(y-1)*n;++i)
				alpha[i]=-(double)i*i;
			x=1;
			E=finalwealth(x.size(),&x[0],&Info);
		}
	}
//	for(i=0;i<(y-1);++i) rescale(n,&x[i*n]);
	if(E>0&&meth)
	{
		dcopyvec(x.size(),&alpha[0],&x[0]);
	}
	{	    
		if(print)printf((char*)"Start non-linear optimisation\n");
		std::valarray<double> xmin(x.size()),step(x.size());
		double ynewlo,reqmin;
		dimen konvge,kcount,icount,numres,ifault;
		step=dmax(fabs(dsumvec(x.size(),&x[0]))*1e-2,1e-2);

		reqmin=lm_eps;
		konvge=10;
		kcount=10;

		Info.print=0;
		if(E>0)
		{
			if(print)printf((char*)"step %-.8e\n",step[0]);
			if(print)printx(x.size(),&x[0]);
			simplex(x.size(),&x[0],&xmin[0],&ynewlo,reqmin,&step[0],konvge,kcount,
				&icount,&numres,&ifault,finalwealth,&Info);
//			for(i=0;i<(y-1);++i) rescale(n,&xmin[i*n]);
			E=ynewlo;x=xmin;
			if(print)printf((char*)"ERROR code; %ld, count; %4ld, number of restarts; %4ld\n",ifault,icount,numres);
			if(print)printf((char*)"Final wealth %-.15e\n",-ynewlo);
			if(print)printx(xmin.size(),&xmin[0]);
		}
		else xmin=x;

		if(E>10)
		{
			if(print)printf((char*)"Final Wealth %-.8e\nERROR code; %4ld, count; %4ld, number of restarts; %ld\n",-E,ifault,icount,numres);
			x=-x;
			step*=10.;
			if(print)printf((char*)"step %-.8e\n",step[0]);
			if(print)printx(x.size(),&x[0]);
			simplex(x.size(),&x[0],&xmin[0],&ynewlo,reqmin,&step[0],konvge,kcount,
				&icount,&numres,&ifault,finalwealth,&Info);
//			for(i=0;i<(y-1);++i) rescale(n,&xmin[i*n]);
			E=ynewlo;
			if(print)printf((char*)"ERROR code; %ld, count; %4ld, number of restarts; %4ld\n",ifault,icount,numres);
			if(print)printf((char*)"Final wealth %-.15e\n",-ynewlo);
			if(print)printx(xmin.size(),&xmin[0]);
		}
		else 
			xmin=x;
		double Eold=E;
		while(E>10)
		{
			Eold=E;
			if(print)printf((char*)"step %-.8e\n",step[0]);
			if(step[0]<lm_rooteps)break;
			else if(step[0]>1./lm_rooteps)break;
			E=ynewlo;

			if(E>0)
			{
				if(print)printf((char*)"Final Wealth %-.8e\nERROR code; %ld, count; %4ld, number of restarts; %4ld\n",-E,ifault,icount,numres);
				dcopyvec(x.size(),&xmin[0],&x[0]);
				x=-x;
				step/=10.;
				if(print)printx(x.size(),&x[0]);
				simplex(x.size(),&x[0],&xmin[0],&ynewlo,reqmin,&step[0],konvge,kcount,
					&icount,&numres,&ifault,finalwealth,&Info);
//				for(i=0;i<(y-1);++i) rescale(n,&xmin[i*n]);
				E=ynewlo;
			}
			if(print)printf((char*)"Wealthcheck %-.10e\n",-(E-Eold)/fabs(Eold));
			if(print)printf((char*)"ERROR code; %ld, count; %4ld, number of restarts; %4ld\n",ifault,icount,numres);
			if(print)printf((char*)"Final wealth %-.15e\n",-ynewlo);
			if(print)printx(xmin.size(),&xmin[0]);
		}


		Info.print=print?1:0;
		E=finalwealth(xmin.size(),&xmin[0],&Info);x=xmin;
		double beforepattern=E;

		void*pInfo=(void*)(&Info);
		unsigned long maxit=20;
		short iprint=print?1:0;//icon=2;
		double scale=sqrt(ddotvec(x.size(),&x[0],&x[0]));

		step=scale*x.size();
		scale=sqrt(ddotvec(x.size(),&x[0],&x[0]));
		dcopyvec(x.size(),&x[0],&step[0]);
		dscalvec(step.size(),.01,&step[0]);

		std::valarray<double>work(x.size()*(x.size()+4));
		size_t toolargecheck=0;
		Info.print=0;

		if(print)printf((char*)"Start quasi search at\n");
		if(print)printf((char*)"Final wealth %-.15e\n",-E);
		if(print)printx(x.size(),&x[0]);
		Info.centreit=1;
/*		patternmin(x.size(),&x[0],&step[0],&ynewlo,scale,
		iprint,1,maxit,&work[0],finalwealth,pInfo);*/

		double conv=1000*lm_eps;
//		for(i=0;i<(y-1);++i) rescale(n,&x[i*n]);
		short wentwrong=QuasiNewton(x.size(),&x[0],print,100*(x.size()),&ynewlo,finalwealth,
			pInfo,conv,2);
		if(print)printf((char*)"Final wealth %-.15e\n",-ynewlo);
		if(print)printx(x.size(),&x[0]);
		while(wentwrong==2&&toolargecheck++<10)
		{
			for(i=0;i<(y-1);++i) rescale(n,&x[i*n]);
			wentwrong=QuasiNewton(x.size(),&x[0],print,100*(x.size()),&ynewlo,finalwealth,pInfo,conv,2);
			if(print)printf((char*)"Final wealth %-.15e\n",-ynewlo);
			if(print)printx(x.size(),&x[0]);
		}

		if(0)//wentwrong)
		{
			scale=sqrt(ddotvec(x.size(),&x[0],&x[0]));
			dcopyvec(x.size(),&x[0],&step[0]);
			dscalvec(step.size(),.01,&step[0]);
			patternmin(x.size(),&x[0],&step[0],&ynewlo,scale,
				iprint,1,maxit,&work[0],finalwealth,pInfo);
			wentwrong=QuasiNewton(x.size(),&x[0],print,100*(x.size()),&ynewlo,finalwealth,
				pInfo,conv,1);
			if(print)printf((char*)"Final wealth %-.15e\n",-ynewlo);
			if(print)printx(x.size(),&x[0]);
		}
		Info.print=print?1:0;
		E=finalwealth(x.size(),&x[0],&Info);
		if(print)printf((char*)"Quasi-Newton search reduced function by %-.8e %-.8e\n",
			beforepattern-E,(beforepattern-E)/fabs(beforepattern));
		ifault=0;

		
		if(E>0) {return 2;}
		else {return ifault==0?0:1;}
	}
}
