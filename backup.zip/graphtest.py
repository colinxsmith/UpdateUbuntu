from scrolled import *
from math import log

class SText(Frame):
    def __init__(self,root,width=80,height=4,cnf={},**kw):
        for i in kw.keys():
            cnf[i]=kw[i]
        Frame.__init__(self,root,cnf)
        text=Text(self)
        text.config(width=width,height=height,relief=SUNKEN)
        sbx=Scrollbar(self,orient=HORIZONTAL)
        sby=Scrollbar(self)
        sbx.config(command=text.xview)
        sby.config(command=text.yview)
        text.config(xscrollcommand=sbx.set,yscrollcommand=sby.set)
        sby.pack(side=RIGHT,fill=Y)
        sbx.pack(side=BOTTOM,fill=X)
        text.pack(side=TOP,fill=X)
        self.text=text
class Info(Frame):
    def __init__(self,root,cnf={},**kw):
        for i in kw.keys():
            cnf[i]=kw[i]
        Frame.__init__(self,root,cnf)
        text=SText(self,height=6)
        text.text.config(font='-*-Courier-Bold-R-Bold--*-150-*-*-*-*-*-*',fg='#6655bb',bg='#aabb55')
        text.pack(side=TOP,fill=BOTH,expand=YES)
        self.text=text
        ent=Entry(self,bg='#22dddd',font='-*-Arial-Bold-R-Bold--*-150-*-*-*-*-*-*')
        ent.config(width=80,relief=SUNKEN)
        ent.pack(side=TOP,fill=BOTH,expand=YES)
        self.ent=ent
        domain=Entry(self,bg='#22dddd',font='-*-Arial-Bold-R-Bold--*-150-*-*-*-*-*-*')
        domain.config(width=80,relief=SUNKEN)
        domain.pack(side=TOP,fill=BOTH,expand=YES)
        self.domain=domain
        Button(self,bg='#ffaadd',command=self.update,text='Update').pack(side=TOP,fill=X)
        Button(self,bg='#ffddaa',command=self.clear,text='Clear').pack(side=TOP,fill=X)
        Button(self,bg='#ff0000',command=root.destroy,text='Quit').pack(side=TOP,fill=X)
        graph=ScrolledCanvas(root)
        graph.canvas.config(width=900,height=300,bg='#ffff55')
        graph.pack(side=TOP,fill=BOTH,expand=YES)
        self.graph=graph
    def clear(self):
        self.text.text.delete(1.0,END)
    def update(self):
        a=str(self.domain.get())
        self.x=eval(compile(a,'<input>','eval'))
        self.npoints=len(self.x)
        self.func=self.ent.get()
        self.code=self.text.text.get(1.0,END)
        a={}
        exec self.code in a
        each=compile(self.func,'<input>','eval')
        y=[0]*self.npoints
        outs='Number of points %d\n'%self.npoints
        for i in range(self.npoints):
            a['x']=self.x[i]
            y[i]=eval(each,a)
            outs+=('y[%d] = '%i)+str(y[i])+'\n'
        (self.graph.xmin,self.graph.xmax) = self.graph.minmaxval(self.x)
        (self.graph.ymin,self.graph.ymax) = self.graph.minmaxval(y)
        (self.graph.x,self.graph.y,self.graph.np) = (self.x,y,self.npoints)
        self.graph.canvas.delete(ALL)
        self.graph.plot(fill='green',title=self.func)
        self.graph.canvas.postscript(file='func.ps')
            

root=Tk()
root.title('Build up a function')
I=Info(root)
I.pack(fill=BOTH,expand=YES)
I.text.text.insert(END,"""def sign(x):
	if x>0:return 1
	elif x<0:return -1
	else:return 0
class piececostdef:
    #declare the properties here to avoid recursive calls in the set/get methods
    #due to the java interface
    ShortCostScale=1
    initial=[]
    npiece=0
    pgrad=[]
    hpiece=[]
    nstocks=0
    def __init__(self,**a):
        #Overwrites
        for i in a.keys():setattr(self,i,a[i])
    def getHpiece(self):
        return getattr(self,'hpiece')
    def setHpiece(self,a):
        setattr(self,'hpiece',a)
    def getPgrad(self):
        return getattr(self,'pgrad')
    def setPgrad(self,a):
        setattr(self,'pgrad',a)
    def getInitial(self):
        return getattr(self,'initial')
    def setInitial(self,a):
        print a
        setattr(self,'initial',a)
    def getNpiece(self):
        return getattr(self,'npiece')
    def setNpiece(self,a):
        setattr(self,'npiece',a)
    def getNstocks(self):
        return getattr(self,'nstocks')
    def setNstocks(self,a):
        setattr(self,'nstocks',a)
    def getShortCostScale(self):
        return getattr(self,'ShortCostScale')
    def setShortCostScale(self,a):
        setattr(self,'ShortCostScale',a)
    def modc(self,n,w,c):
        if not (n==getattr(self,'nstocks')):raise 'n=%d nstocks=%d'%(n,self.nstocks)
        initial=getattr(self,'initial')
        npiece=getattr(self,'npiece')
        hp=getattr(self,'hpiece')
        hpstart=0
        pg=getattr(self,'pgrad')
        for j in range(n):
            done=0
            scale=1
            if w[j]<0:scale=getattr(self,'ShortCostScale')
            if initial == []:ww=w[j]
            else:ww=w[j]-initial[j]
            if ww<hp[hpstart]:
                c[j]=pg[hpstart]*scale
                done=1
                hpstart+=npiece
                continue
            for i in range(1,npiece):
                if(ww<hp[hpstart+i] and ww>=hp[hpstart+i-1]):
                   if ww>0:c[j]=pg[hpstart+i]*scale
                   elif ww<0:c[j]=pg[hpstart+i-1]*scale
                   else:c[j]=0
                   done=1
                   break
            if done:
                hpstart+=npiece                
                continue
            c[j]=pg[hpstart+npiece-1]*scale
            hpstart+=npiece                
    def util(self,n,w):
        if not (n==getattr(self,'nstocks')):raise 'n=%d nstocks=%d'%(n,self.nstocks)
        initial=getattr(self,'initial')
        npiece=getattr(self,'npiece')
        hp=getattr(self,'hpiece')
        hpstart=0
        pg=getattr(self,'pgrad')
        total=0
        nstart=0
        for j in range(n):
            nstart=0
            done=0
            scale=1
            if w[j]<0:scale=getattr(self,'ShortCostScale')
            for i in range(npiece):#Get the first positive ordinate; we integrate from 0
                if hp[hpstart+i]>0:nstart=i;break
            if initial == []:ww=w[j]
            else:ww=w[j]-initial[j]
            if ww<=hp[nstart+hpstart] and ww>=0:
                total+=ww*pg[nstart+hpstart]*scale
                done=1
                hpstart+=npiece
                continue
            sofar=hp[nstart+hpstart]*pg[nstart+hpstart]*scale
            if ww>0:
                for i in range(nstart+1,npiece):
                    if ww<hp[i+hpstart] and ww>=hp[i-1+hpstart]:
                        total+=sofar+(ww-hp[i-1+hpstart])*pg[i+hpstart]*scale
                        done=1
                        break
                    sofar+=(hp[i+hpstart]-hp[i-1+hpstart])*pg[i+hpstart]*scale
            if done:
                hpstart+=npiece
                continue
            if ww>=0:
                total+=sofar+(ww-hp[npiece-1+hpstart])*pg[npiece-1+hpstart]*scale
                done=1
                hpstart+=npiece
                continue
            if not ww<0:raise 'BIG ERROR in util'
            sofar=0
            for ii in range(nstart):
                i=nstart-ii
                usehpi=hp[hpstart+i]
                if i == nstart:usehpi=0
                if ww<usehpi and ww>= hp[i-1+hpstart]:
                    total+=sofar+(ww-usehpi)*pg[i-1+hpstart]*scale
                    done=1
                    break
                sofar-=(usehpi-hp[i-1+hpstart])*pg[i-1+hpstart]*scale
            if done:
                hpstart+=npiece
                continue
            total+=sofar+(ww-hp[hpstart])*pg[hpstart]*scale
            hpstart+=npiece
        return total

nstocks=1
npiece=16
initial=[0]*nstocks
costsf=open('../mikeOM/pcosts.log')
cl=0
hpiece=[]
pgrad=[]
seth=0
while(1):
	line=costsf.readline().strip()
	if line.find('hpiece')>-1:
		cl=0
		seth=1
		print 'set hpiece'
	elif line.find('pgrad')>-1:
		cl=0
		seth=2
		print 'set pgrad'
	elif seth==1 and cl<npiece:
		hpiece.append(float(line))
		cl+=1
	elif seth==2 and cl<npiece:
		pgrad.append(float(line))
		cl+=1
	elif pgrad!=[] and hpiece!=[] and cl==npiece:break
print hpiece
print pgrad
initial=[0]*nstocks
#   npiece=20
#   hpiece=[2*float(i-npiece/2)/npiece for i in range(npiece+1) if not (i==(npiece/2) or i>2*(npiece/2))]*nstocks
#   npiece=len(hpiece)/nstocks
#   print 'nstocks is %d; npiece is %d'%(nstocks,npiece)
#   pgrad=[sign(i) for i in hpiece]
ShortCostScale=1
PC=piececostdef(nstocks=nstocks,npiece=npiece,initial=initial,hpiece=hpiece,pgrad=pgrad,ShortCostScale=ShortCostScale)
def grad(x):
	y=[x]
	c=[0]
	PC.modc(1,y,c)
	return c[0]
def func(x):
	y=[x]
	return PC.util(1,y)
""")
I.ent.insert(END,'func(x)')
I.domain.insert(END,'[(float(i)-500)/500 for i in range(1001)]')
root.mainloop()