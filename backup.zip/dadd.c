/*
	x = y + z for general vectors

	i.e. x[i*incx] = y[i*incy]+z[i*incz] i=0,....,n-1
*/
#include "ldefns.h"

void dadd(dimen n, vector y, stride incy, vector z, stride incz, vector x, stride incx)
{
	while(n--){
		*x = *y + *z;
		y += incy;
		z += incz;
		x += incx;
		}
}
