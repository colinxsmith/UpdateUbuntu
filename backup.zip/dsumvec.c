/*
	compute the sum of a vector
*/
#include "ldefns.h"
real dsumvec(dimen n, vector v)
{
	return dsum(n,v,1);
}
