#include <pdh.h>
#include <pdhmsg.h>
#include<cstdio>
#define CNTR_CPU "\\Processor(_Total)\\% Processor Time" // % of cpu in use
#define CNTR_MEMINUSE_BYTES "\\Memory\\Committed Bytes" // mem in use measured in bytes
#define CNTR_MEMAVAIL_BYTES "\\Memory\\Available Bytes" // mem available measured in bytes
#define CNTR_MEMAVAIL_KB "\\Memory\\Available KBytes" // mem avail in kilobytes
#define CNTR_MEMAVAIL_MB "\\Memory\\Available MBytes" // mem avail in megabytes
#define CNTR_MEMINUSE_PERCENT "\\Memory\\% Committed Bytes In Use" // % of mem in use
#define CNTR_MEMLIMIT_BYTES "\\Memory\\Commit Limit" // commit limit on memory in bytes
#define MAX_RAW_VALUES 1
typedef struct _tag_PDHCounterStruct 
{
	int nIndex;				// The index of this counter, returned by AddCounter()
	LONG lValue;			// The current value of this counter
    HCOUNTER hCounter;      // Handle to the counter - given to use by PDH Library
    int nNextIndex;         // element to get the next raw value
    int nOldestIndex;       // element containing the oldes raw value
    int nRawCount;          // number of elements containing raw values
    PDH_RAW_COUNTER a_RawValue[MAX_RAW_VALUES]; // Ring buffer to contain raw values
} PDHCOUNTERSTRUCT, *PPDHCOUNTERSTRUCT;

size_t getit(HQUERY Query,const char*findout)
{
	PPDHCOUNTERSTRUCT pCounter;
	pCounter = new PDHCOUNTERSTRUCT;
	if (!pCounter) 
	{
		printf("Bad counter\n");
		return -1;
	}
	if (PdhAddCounter(Query, findout, (DWORD)pCounter, &(pCounter->hCounter)) != ERROR_SUCCESS)
	{
		printf("AddCounter Failed\n");
		delete pCounter; // clean mem
		return -1;
	}
	if (PdhCollectQueryData(Query) != ERROR_SUCCESS) 
		printf("Could not collect\n");

	PDH_FMT_COUNTERVALUE pdhFormattedValue;

	// get the value from the PDH
	if (PdhGetFormattedCounterValue(pCounter->hCounter, PDH_FMT_LONG, NULL, &pdhFormattedValue) != ERROR_SUCCESS)
	{
		printf("FormattedCounterValue Failed\n");
		return -1;
	}

	// test the value for validity
	if (pdhFormattedValue.CStatus != ERROR_SUCCESS)
	{
		printf("FormattedValue Failed\n");
		return -1;
	}

	// set value
	size_t back = pdhFormattedValue.longValue;
	delete pCounter;
	return back;
}

/*int main()
{	
	HQUERY Query; // the query to the PDH
	if (PdhOpenQuery(NULL, 1, &Query) != ERROR_SUCCESS)
		printf("Initialise Failed\n");
	
	printf("Initialise Didn't Fail\n");
	
	size_t meminuse,memavailable;
	meminuse=getit(Query,CNTR_MEMINUSE_BYTES);
	memavailable=getit(Query,CNTR_MEMLIMIT_BYTES);
	printf("Memory %u - %u = % u Mbytes\n", memavailable/1024/1024,meminuse/1024/1024, (memavailable - meminuse)/1024/1024);

	PdhCloseQuery(&Query);
	return 23;
}*/

extern "C" __declspec( dllexport ) size_t memleft()
{	
	HQUERY Query; // the query to the PDH
	if (PdhOpenQuery(NULL, 1, &Query) != ERROR_SUCCESS)
		printf("Initialise Failed\n");
	
	size_t meminuse,memavailable,back;
	meminuse=getit(Query,CNTR_MEMINUSE_BYTES);
	memavailable=getit(Query,CNTR_MEMLIMIT_BYTES);
//	printf("Memory %u - %u = % u Kbytes\n", memavailable/1024,meminuse/1024, (back=(memavailable - meminuse)/1024));

	back=(memavailable - meminuse)/1024;
	PdhCloseQuery(&Query);
	return back;
}

#define Delete(x) delete[] x;x=0;
extern "C" __declspec( dllexport ) size_t getMaxNumberOfDoubles(int wantedDoubles)
{
	//Tuan Tran 7th December 2005
	size_t mn = 0;
	size_t mx = wantedDoubles,lmx=0;
	bool stopAllocating = false;
	double* temp;
	
	while(1)
	{
        if((temp = new double[mx]))
        {
            mn = mx;
            mx = (lmx==0?mx*2:lmx);
            Delete(temp)
        }
        else
        {
			lmx=mx;
            mx = (mx + mn) / 2;
        }
//		printf("Max = %u | Min = %u %u\n", mx, mn,mx-mn);
		
		if(mx==mn)
		{
            break;
		}
	}
	return mx;
}
extern "C" __declspec( dllexport ) size_t getMaxNumberOfDoublesN(int initial)
{
	printf("maximum %u\n",initial);
	//Tuan Tran 7th December 2005
	size_t mn = 0;
	size_t mx = 1,lmx=0;
	double* temp;
	HANDLE MemAlloc=HeapCreate(0,0,initial);
	
	while(1)
	{
        if((temp = (double*)HeapAlloc(MemAlloc,0,mx*sizeof(double))))
        {
            mn = mx;
            mx = (lmx==0?mx*2:lmx);
            HeapFree(MemAlloc,0,(char*)temp);
			temp=0;
        }
        else
        {
			lmx=mx;
            mx = (mx + mn) / 2;
        }
//		printf("Max = %u | Min = %u %u\n", mx, mn,mx-mn);
		
		if(mx==mn)
		{
            break;
		}
	}
	HeapDestroy(MemAlloc);
	return mx;
}
