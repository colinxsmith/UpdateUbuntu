#include "ldefns.h"
#include "constant.h"
/*
	     dsmxfac	factors a double precision symmetric matrix stored in
			packed form by elimination with symmetric pivoting
			to solve  a*x = b , follow dspfa by dspsl
			to compute  inverse(a)*c , follow dspfa by dspsl
			to compute  determinant(a) , follow dspfa by dspdi
			to compute  inertia(a) , follow dspfa by dspdi
			to compute  inverse(a) , follow dspfa by dspdi

		on entry
		n		dimen the order of the matrix  a
		ap		double precision (n*(n+1)/2)
				the packed form of a symmetric matrix  a .  the
				columns of the upper triangle are stored sequentially
				in a one-dimensional array of length  n*(n+1)/2
				see comments below for details

		output
		ap		a block diagonal matrix and the multipliers which
				were used to obtain it stored in packed form
				the factorization can be written  a = u*d*trans(u)
				where  u  is a product of permutation and unit
				upper triangular matrices , trans(u) is the
				transpose of  u , and  d  is block diagonal
				with 1 by 1 and 2 by 2 blocks
		kpvt		short_vec (n) an integer vector of pivot indices

		return value
			= 0	normal value
			= k	if the k-th pivot block is singular. this is
				not an error condition for this subroutine,
				but it does indicate that dspsl or dspdi may
				divide by zero if called


	the following program segment will pack the upper triangle of a symmetric matrix
		k = 0
		do 20 j = 1, n
			do 10 i = 1, j
				k = k + 1
				ap(k)  = a(i,j)
		10    continue
		20 continue

	linpack. this version dated 08/14/78
	james bunch, univ. calif. san diego, argonne nat. lab
*/

short dsmxfac( dimen n, sym_matrix ap, short_vec kpvt)
{
	int	imax, jmax;
	int	j, k;
	int	km1km1;
	int	kstep;
	int	ij, ik, jj, im=1000000000, jk, kk;
	int	km1, km2;
	int	ijj, imj, imk;
	int	ikm1, jkm1, km1k;
	real	mulk;
	int	swap;
	register real	t;
	real alpha;
	real	denom;
	real	mulkm1, ak, bk;
	real	absakk;
	real	colmax;
	real	rowmax;
	real	akm1, bkm1;
	short	info;



	/* Parameter adjustments */
	--kpvt;
	--ap;

	/*alpha is used in choosing pivot block size. */
	alpha = (sqrt(17.) + 1.) / 8.;

	info = 0;

	/*main loop on k, which goes from n to 1*/
	k = n;
	ik = (n*(n - 1))>>1;

	for(;k>1;ik -= (kstep==2 ? (km1<<1)-1 : km1), k -= kstep ){
		/*
		this section of code determines the kind of
		elimination to be performed.  when it is completed,
		kstep will be set to the size of the pivot block, and
		swap will be set to 1 if an interchange is
		required
		*/
	
		km1 = k - 1;
		kk = ik + k;
		absakk = fabs(ap[kk]);
	
		/*determine the largest off-diagonal element in column k*/
		imax = idamaxvec(km1,ap+ik+1)+1; /*+1 for 1..n indeces*/
		imk = ik + imax;
		colmax = fabs(ap[imk]);
		if (absakk >= (alpha * colmax))
		{
			kstep = 1;
			swap = 0;
		}
		else
		{
			/*determine the largest off-diagonal element in row imax*/
			rowmax = 0.;
			im = (imax*(imax - 1))>>1;
			imj = im+(imax<<1);
			for(j = imax + 1; j <= k; imj+=j++) if((t= fabs(ap[imj]))>rowmax) rowmax = t;
			if(imax != 1)
			{
				jmax = idamaxvec(imax-1, ap+im + 1)+1; /*+1 for 1..n indeces*/
				if((t = fabs(ap[jmax + im]))>rowmax) rowmax = t;
			}
			if (fabs(ap[imax + im]) < (alpha * rowmax))
			{
				if (absakk < (alpha * colmax * (colmax / rowmax)))
				{
					kstep = 2;
					swap = imax != km1;
				}
				else
				{
					kstep = 1;
					swap = 0;
				}
			}
			else
			{
				kstep = 1;
				swap = 1;
			}
		}

		if (max(absakk,colmax) <= lm_rooteps ) {
			/*column k is zero.  set info and iterate the loop*/
			kpvt[k] = k;
			kstep = 1;
			info = k;
			}
		else if(kstep == 1){
			/*1 x 1 pivot block*/
			if(swap) {
				/*perform an interchange*/
				dswapvec(imax, ap+im+1, ap+ik+1);
				imj = ik + imax;
				for (jj = imax; jj <= k; ++jj){
					j = k + imax - jj;
					jk = ik + j;
					t = ap[jk];
					ap[jk] = ap[imj];
					ap[imj] = t;
					imj -= j - 1;
					}
				}
	
			/*perform the elimination*/
			ij = ik - km1;
			for(jj = 1; jj <= km1; ++jj) {
				j = k - jj;
				jk = ik + j;
				mulk = -ap[jk] / ap[kk];
				daxpyvec(j, mulk, ap+ik + 1, ap+ij + 1);
				ijj = ij + j;
				ap[jk] = mulk;
				ij -= j - 1;
				}
	
			/*set the pivot array. */
			kpvt[k] = (swap?imax:k);
			}
		else	{
			/*2 x 2 pivot block*/
			km1k = ik + km1;
			ikm1 = ik - km1;
			if(swap){
				/*perform an interchange. */
				dswapvec(imax, ap+im + 1, ap+ikm1 + 1);
				imj = ikm1 + imax;
				for (jj = imax; jj <= km1; ++jj) {
					j = km1 + imax - jj;
					jkm1 = ikm1 + j;
					t = ap[jkm1];
					ap[jkm1] = ap[imj];
					ap[imj] = t;
					imj -= j - 1;
					}
				t = ap[km1k];
				ap[km1k] = ap[imk];
				ap[imk] = t;
				}

			/*perform the elimination*/
			km2 = k - 2;
			if(km2 > 0){
				ak = ap[kk] / ap[km1k];
				km1km1 = ikm1 + km1;
				akm1 = ap[km1km1] / ap[km1k];
				denom = 1. - ak * akm1;
				ij = ik - km1 - km2;
				for (jj = 1; jj <= km2; ++jj) {
					j = km1 - jj;
					jk = ik + j;
					bk = ap[jk] / ap[km1k];
					jkm1 = ikm1 + j;
					bkm1 = ap[jkm1] / ap[km1k];
					mulk = (akm1 * bk - bkm1) / denom;
					mulkm1 = (ak * bkm1 - bk) / denom;
					daxpyvec(j, mulk, ap+ik + 1, ap+ij + 1);
					daxpyvec(j, mulkm1, ap+ikm1 + 1, ap+ij + 1);
					ap[jk] = mulk;
					ap[jkm1] = mulkm1;
					ijj = ij + j;
					ij -= j - 1;
					}
				}
	
			/*set the pivot array. */
			kpvt[k] = -(int)(swap ? imax : km1);
			kpvt[km1] = kpvt[k];
			}
		}

	/*we arrive here with k==0 or k==1*/
	if(k)	{
		kpvt[1] = 1;
		if (ap[1] == 0.) info = 1;
		}
	return info;
}
