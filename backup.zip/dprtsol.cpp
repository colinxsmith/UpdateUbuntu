#include "baseoptimise.h"
/*
	dprtsol	expands the lagrange multipliers into  clamda
	if  msg >= 10  or  msg == 1,  prtsol  then prints  x, a*x,
	c(x), their bounds,  the multipliers, and the residuals
	(distance to the nearest bound)

	dprtsol	is called by  lpcore, qpcore, lccore and npcore	 just
	before they exit
*/
void	Base_Optimise::dprtsol(	dimen nfree, dimen nrowa, dimen n, dimen nclin, dimen ncnln, dimen nctotl,
			real bigbnd, dimen nactiv, short_vec istate, short_vec kactiv,
			matrix a, vector bl, vector bu, vector c, vector clamda, vector rlamda, vector x)
{

	static char *id =(char*)"VLN";
	static char *lstate=(char*)"--++FRLLULEQTB";


    	dimen nlam, nplin, nfixed, j, k, ip, is;
    	real v, b1, b2, res, res2, wlam;
    	char *ls;
    	char id3[1];

    	--x;
    	--rlamda;
    	--clamda;
    	--c;
    	--bu;
    	--bl;
    	a -= nrowa+1;
    	--kactiv;
    	--istate;

    	nplin = n + nclin;
	/*EXPAND BOUND, LINEAR AND NONLINEAR MULTIPLIERS INTO CLAMDA*/
    	dzerovec(nctotl, &clamda[1]);
    	nfixed = n - nfree;
    	nlam = nactiv + nfixed;
    	for (k = 1; k <= nlam; ++k) {
		j = kactiv[k];
		if (k <= nactiv) j += n;
		clamda[j] = rlamda[k];
    		}
    	if (msg < 10 && msg != 1) return;
    	lm_wmsg((char*)"\n\nVARBL STATE     VALUE      LOWER BOUND    UPPER BOUND    LAGR MULT   RESIDUAL");
    	*id3 = id[0];
    	for (j = 1; j <= nctotl; ++j) {
		b1 = bl[j];
		b2 = bu[j];
		wlam = clamda[j];
		is = istate[j];
		ls = lstate + ((is + 2) << 1);
		if (j <= n) {
			/* SECTION 1 -- THE VARIABLES  X. */
			/* ------------------------------ */
			k = j;
			v = x[j];
			}
		else if (j <= nplin) {
			/* SECTION 2 -- THE LINEAR CONSTRAINTS  A*X. */
			/* ----------------------------------------- */
			if (j == n + 1) {
				lm_wmsg((char*)"\n\nLNCON STATE     VALUE      LOWER BOUND    UPPER BOUND    LAGR MULT   RESIDUAL");
				*id3 = id[1];
				}
			k = j - n;
			v = BITA_ddot(n, &a[k + nrowa], nrowa, &x[1], 1);
			}
		else	{
			/*        SECTION 3 -- THE NONLINEAR CONSTRAINTS  C(X). */
			/*        --------------------------------------------- */
			if (ncnln <= 0) continue;
			if (j == nplin + 1) {
				lm_wmsg((char*)"\n\nNLCON STATE     VALUE      LOWER BOUND    UPPER BOUND    LAGR MULT   RESIDUAL");
				*id3 = id[2];
				}
			k = j - nplin;
			v = c[k];
			}
		/* PRINT A LINE FOR THE J-TH VARIABLE OR CONSTRAINT. */
		/* ------------------------------------------------- */
		res = v - b1;
		res2 = b2 - v;
		if (fabs(res) > fabs(res2)) res = res2;
		ip = 1;
		if (b1 <= -bigbnd) ip = 2;
		if (b2 >= bigbnd) ip += 2;
	    	lm_printf((char*)"%c%3ld    %c%c%15.7lg",*id3,CL(k),ls[0],ls[1],v);
		if(ip&1) lm_printf((char*)"%15.7lg",b1);
		else lm_printf((char*)"     NONE      ");
		if(ip<3) lm_printf((char*)"%15.7lg",b2);
		else lm_printf((char*)"     NONE      ");
	    	lm_wmsg((char*)"%12.4lg%12.4lg",wlam,res);
    		}
}
