from Opt import *
from sys import argv

del argv[0]
if len(argv)>0:file=open(argv[0])
else:file=open('s:/optCVPA.log')

O=Opt()
while(1):
    i=file.readline().strip()
    if len(i)==0:break
    val=file.readline().strip()
    if len(val.split())>1:
        if i!='names':
            if val.find('.')>-1:
                val=numline(val.split())
            else:
                val=numline(val.split(),int)
        else:val=val.split()
        print 'list %s'%i
        setattr(O,i,val)
    else:
        try:
            if i in ['n','ncomp','m','basket','tradenum','revise','costs','ls','round','nabs','mabs','nfac','npiece','log','full']:
                print 'int scalar %s'%i
                setattr(O,i,int(val))
            else:
                print 'float scalar %s'%i
                setattr(O,i,float(val))
        except:
            print 'empty list %s'%i

O.opt()
O.props()
print O.risk
print O.rreturn
