#Show how to use conjugate gradients to solve Mx=y where M is symmetric

from Opt import *

def Symmult(n,n1,n2,n3,S,x,Sx):
    print 'x ',x
    """Multiply a symmetric matrix S by a vector x to get Sx.
    S is a list of length n*(n+1)/2 containing the lower triangle of a symmetric
    matrix stored in the order [00,10,11,20,21,22,.......]
    x and Sx are lists of length n
    """
    if len(x)<n:raise 'x is not long enough'
    if len(Sx)<n:raise 'Sx is not long enough'
    if len(S)<n*(n+1)/2:raise 'S is not long enough'
    ij=0
    for i in range(n):
        Sx[i]=0
        for j in range(i+1):
            Sx[i]+=S[ij]*x[j]
            if i!=j:Sx[j]+=S[ij]*x[i]
            ij+=1
    print 'Sx ',Sx

usediag=1 #Use 1/root(abs(diagonal)) elements as a preconditioner.
n=4
M=[-2,0.1,3,0.1,0.1,4,0.1,0.1,0.1,5]
y=[0,0,0,0]
Mx=[0]*4
for i in range(n):
    y[i]=1
    print '+'*100
    print 'y ',y
    x=[]
    conj_solve(n,M,y,x,0,Symmult,usediag)
    print x
    Symmult(n,1,1,1,M,x,Mx)
    print Mx
    print '_'*10
    x1=[]
    symm_inverse_x(n,M,y,x1)
    Symmult(n,1,1,1,M,x1,Mx)
    print Mx
    y[i]=0
    
usediag=0 #No preconditioner
y=[0,0,0,0]
for i in range(n):
    y[i]=1
    print '+'*100
    print 'y ',y
    x=[]
    conj_solve(n,M,y,x,0,Symmult,usediag)
    print x
    Symmult(n,1,1,1,M,x,Mx)
    print Mx
    print '_'*10
    x1=[]
    symm_inverse_x(n,M,y,x1)
    Symmult(n,1,1,1,M,x1,Mx)
    print Mx
    y[i]=0
