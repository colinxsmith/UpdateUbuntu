#! /bin/env python
from os import system
from sys import argv

patchlevel = 0
try:patchlevel=int(argv[1])
except:
    system('ls patch_* > patchlist')
    pl = open('patchlist')
    try:
        for i in pl.readlines():
            print i
            i=i.replace('patch_','')
            patchlevel = max(patchlevel,int(i.strip()))
        patchlevel+=1
    except:pass
    
ff=open('BaseOptimise.cpp')
ff1=open('tt','w')
for i in ff.readlines():
    if i.find('PATCH') == 8:
        ff1.write( '#define PATCH '+str(patchlevel)+'\n')
    else:ff1.write(i)
ff.close()
ff1.close()

system('mv tt BaseOptimise.cpp')
system('chown csmith *.c *.cpp *.h')
system('chmod 666 *.c *.cpp *.h')
system("diff -c base ./ | sed '/^Only/d' > patch_%d" % patchlevel)

system("cd base;patch < ../patch_%d" % patchlevel)

system("zip -u backup patch_%d" % patchlevel)
system("cp patch_%d last_patch" % patchlevel)

#(cd ../optimiser-core;svn co http://bitasvn/optimiser/trunk/optimiser-core safeqp)

                         

    
    

