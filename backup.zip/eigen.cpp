/*
	compute the eigenvalues and eigen vectors of a symmetric
	matrix. Using tridiagonalisation and QL algorithm with implicit shifts.

	On entry the lower part of the symmetric matrix should be stored in
	column order (like fortran) in the n by n matrix S.

	itmax	is the maximum allowable number of iterations to be allowed in
	the QL algorithm.

	fail	determines the failure mode of the routine.
	<0	noisy soft failure
	>0	quiet soft failure
	==0	noisy hard failure

	On exit d will hold the eigenvalues and the matrix S will hold the
	normalised eigenvectors in decreasing magnitude order.

	the return value indicates success (0) or failure 1 which will
	mean that too many iterations occurred.

	The real n vector work is needed for space only. We assume that
	n reals are larger than n undex values + n bytes.
*/
#include"optimise.h"
#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#endif
/*static	vector	eigen_value;
static int compare(undex *a, undex *b)
{
	real	aa = fabs(eigen_value[*a]);
	real	ab = fabs(eigen_value[*b]);

	if(aa>ab) return -1;
	else if(aa<ab) return 1;
	else return 0;
}*/

void dmx_symmetrise(dimen n, matrix S)
{
	dimen	i, n1;
	for(i=1, n1=n+1; i<n; i++, S+=n1) dcopy(n-i,S+1,1,S+n,n);
}
void dtred1(dimen n, matrix a, dimen lda, vector d, vector e, vector e2)
{
/*
	dtred1 is a translation of the algol procedure tred1,
	num. math. 11, 181-195(1968) by martin, reinsch, and wilkinson
	handbook for auto. comp., vol.ii-linear algebra, 212-226(1971)
	dtred1 reduces a real symmetric matrix to a symmetric tridiagonal matrix using
	orthogonal similarity transformations
	on input
	n	dimen: is the order of the matrix
	a	matrix: contains the real symmetric input matrix.  only the
	        lower triangle of the matrix need be supplied
	lda	dimen must be set to the row dimension of two-dimensional
		array parameters as declared in the calling program
		dimension statement

	on output
	a	contains information about the orthogonal transformations used in
		the reduction in its strict lower triangle.  the full upper triangle of a is unaltered
	d	vector: contains the diagonal elements of the tridiagonal matrix
	e	vector: contains the subdiagonal elements of the tridiagonal
		matrix in its last n-1 positions.  e(1) is set to zero
	e2	vector: contains the squares of the corresponding elements of e
		e2 may coincide with e if the squares are not needed
*/
	real f, g, h;
	int i, j, k, l;
	real scale;


	--e2;
	--e;
	--d;
	a -= lda + 1;

	for(i=1;i<=(int) n;i++){
		d[i] = a[j=n+(k=i*lda)];
		a[j] = a[i+k];
		}
	for (i = n; i > 1; --i ) {
		l = i - 1;
		/*scale row (algol tol then not needed)*/
		scale = dnrm1vec(l, d+1);
		if (scale == 0.){
			for (j = 1; j <= l; ++j) {
	    			d[j] = a[l + (k=j * lda)];
	    			a[l + k] = a[i + k];
	    			a[i + k] = 0.;
				}
			e[i] = e2[i] = 0.;
			}
		else	{
			for(h=0.0, k = 1; k <= l; ++k){
	    			d[k] /= scale;
	    			h += d[k] * d[k];
				}

			e2[i] = scale * scale * h;
			f = d[l];
			g = -dsign(sqrt(h), f);
			e[i] = scale * g;
			h -= f * g;
			d[l] = f - g;
			if (l > 1) {
				dzerovec(l,e+1);
				for (j = 1; j <= l; ++j) {
	    				f = d[j];
	    				g = e[j] + a[j + j * lda] * f;
	    				for (k = j+1; k <= l; ++k) {
						g += a[k + j * lda] * d[k];
						e[k] += a[k + j * lda] * f;
	    					}

	    				e[j] = g;
					}

				/*form p*/
				f = 0.;
				for (j = 1; j <= l; ++j) {
	    				e[j] /= h;
	    				f += e[j] * d[j];
					}

				h = f / (h + h);

				/*form q*/
				BITA_daxpy( l, -h, d+1, 1, e+1, 1);

				/*form reduced a*/
				for(j = 1; j <= l; ++j) {
	    				f = d[j];
	    				g = e[j];
	    				for (k = j; k <= l; ++k)
						a[k + j * lda] = a[k + j * lda] - f * e[k] - g * d[k];
					}
				}
			for (j = 1; j <= l; ++j) {
	    			f = d[j];
	    			d[j] = a[l + j * lda];
	    			a[l + j * lda] = a[i + j * lda];
	    			a[i + j * lda] = f * scale;
				}

			}
		}
	e[1] = 0.;
	e2[1] = 0.;
}
static dimen sturm_sequence(dimen p, dimen q, real x1, vector d, vector e, vector e2)
{
	real u = 1.;
	dimen	i;
#ifdef	DEBUG
#define DEBUGPR(A) lm_wmsg A
	lm_printf("sturm_sequence: p=%d q=%d x1=%lg", p, q, x1 );
#else
#define DEBUGPR(A)
#endif
	for (i = --p; i < q; ++i){
		u = d[i] - x1 - (u != 0.? e2[i] / u :( e2[i]== 0.? 0.:fabs(e[i])/lm_eps));
		if (u < 0.) ++p;
		}
#ifdef	DEBUG
	lm_wmsg(" k=%d u=%lg", p, u );
#endif
	return p;
}

short dtridib(dimen n, real eps1, vector d, vector e, vector e2, real *plb, real *pub, dimen m11, dimen m, vector w, short_vec ind, vector rv4)
{
/*
	this subroutine is a translation of the algol procedure bisect,
	num. math. 9, 386-393(1967) by barth, martin, and wilkinson
	handbook for auto. comp., vol.ii-linear algebra, 249-256(1971)
	this subroutine finds those eigenvalues of a tridiagonal
	symmetric matrix between specified boundary indices,
	using bisection
	on input
		n	is the order of the matrix
		eps1	is an absolute error tolerance for the computed
			eigenvalues.  if the input eps1 is non-positive,
			it is reset for each submatrix to a default value,
			namely, minus the product of the relative machine
			precision and the 1-norm of the submatrix
		d	contains the diagonal elements of the input matrix
		e	contains the subdiagonal elements of the input matrix
			in its last n-1 positions.  e(1) is arbitrary
		e2	contains the squares of the corresponding elements of e
			e2[0] is arbitrary
		m11	specifies the lower boundary index for the desired eigenvalues
		m	specifies the number of eigenvalues desired.  the upper
			boundary index m22 is then obtained as m22=m11+m-1

	on output
		d and e are unaltered
		elements of e2, corresponding to elements of e regarded
			as negligible, have been replaced by zero causing the
			matrix to split into a direct sum of submatrices
			e2[0] is also set to zero
		*plb and *pub define an interval containing exactly the desired eigenvalues
		w	contains, in its first m positions, the eigenvalues
			between indices m11 and m22 in ascending order
		ind	contains in its first m positions the submatrix indices
			associated with the corresponding eigenvalues in w --
			1 for eigenvalues belonging to the first submatrix from
			the top, 2 for those belonging to the second submatrix, etc..

	the return value is
	zero       for normal return,
	3n+1      if multiple eigenvalues at index m11 make unique selection impossible,
	3n+2      if multiple eigenvalues at index m22 make unique selection impossible

	rv4	is a temporary vector of length 2n

	note that subroutine tql1, imtql1, or tqlrat is generally faster
	than tridib, if more than n/4 eigenvalues are to be found
	questions and comments should be directed to burton s. garbow,
	mathematics and computer science div, argonne national laboratory
	this version dated august 1983
*/
	short	ierr;
	real	d__1;
	vector	rv5=rv4+n;
	dimen	i, j, k, l, p, q, r, s, m1, m2, m22;
	real	u, v, t1, t2, x0, x1, xu, tst1, tst2, lb, ub;
	dimen	tag;
	int	i__1;
	real	eps = eps1;
	int	calc_eps = eps<=0.0;
	real	u0, uu;
	dimen	s0, su;

	--rv5;
	--rv4;
	--ind;
	--w;
	--e2;
	--e;
	--d;

	ierr = 0;
	tag = 0;
	xu = d[1];
	x0 = d[1];
	u = 0.;
	/*look for small sub-diagonal entries and determine an interval containing all the eigenvalues*/
	for(i=1; i<=n; ++i){
		x1 = u;
		u = i==n?0.0:fabs(e[i + 1]);
		d__1 = d[i] - (x1 + u);
		xu = dmin(d__1,xu);
		d__1 = d[i] + (x1 + u);
		x0 = dmax(d__1,x0);
		if (i > 1) {
			tst1 = fabs(d[i])+fabs(d[i - 1]);
			tst2 = tst1 + fabs(e[i]);
			if (tst2 > tst1) continue;
			}
		e2[i] = 0.;
		}

	t1 = fabs(xu);
	t2 = fabs(x0);
	x1 = CR(n)*(lm_eps*dmax(t1,t2));
	xu -= x1;
	t1 = xu;
	x0 += x1;
	t2 = x0;

	/*determine an interval containing exactly the desired eigenvalues*/
	p = 1;
	q = n;
	m1 = m11 - 1;
	if(m1==0) goto L75;

L50:	v = x1;
	x1 = xu + (x0 - xu) * .5;
	if (x1 == v){
		ierr = 1;
		goto L980;
		}
	s = sturm_sequence(p, q, x1, d+1, e+1, e2+1);

	if ((i__1 = s - m1) < 0){
L65:		xu = x1;
		goto L50;
		}
	else if(i__1 == 0) goto L73;
	else	{
L70:		x0 = x1;
		goto L50;
		}
L73:		xu = x1;
		t1 = x1;
L75:		m22 = m1 + m;
		if(m22 < n){
			x0 = t2;
			v = x1;
			x1 = xu + (x0 - xu) * .5;
			if (x1 == v){
				ierr = 2;
				goto L980;
				}
			s = sturm_sequence(p, q, x1, d+1, e+1, e2+1);
			if ((i__1 = s - m22) < 0) goto L65;
			else if (i__1 == 0) t2 = x1;
			else goto L70;
			}
	q = 0;
	r = 0;
	while(r != m){
		/*establish and process next submatrix, refining interval by the gerschgorin bound*/
		++tag;
		p = q + 1;
		xu = d[p];
		x0 = d[p];
		u = 0.;

		for (q = p; q <= n; ++q) {
			x1 = u;
			if (q < n) {
				u = fabs(e[q + 1]);
				v = e2[q + 1];
				}
			else	{
				u = 0.;
				v = 0.;
				}
			d__1 = d[q] - (x1 + u);
			xu = dmin(d__1,xu);
			d__1 = d[q] + (x1 + u);
			x0 = dmax(d__1,x0);
			if (v == 0.) break;
			}

		DEBUGPR(("Submatrix Start p=%d q=%d x0=%lg xu=%lg",p,q,x0,xu));
		if (calc_eps){
			x1 = fabs(xu);
			eps = fabs(x0);
			eps  = lm_eps*dmax(x1,eps);
			}
		if (p == q){
			/*check for isolated root within interval*/
			if (t1 > d[p] || d[p] >= t2){
				if (q < n) continue;
				else break;
				}
			m1 = m2 = p;
			rv5[p] = d[p];
			}
		else	{
			x1 *= q - p + 1;
			d__1 = xu - x1;
			lb = dmax(t1,d__1);
			x1 += x0;
			ub = dmin(t2,x1);
			m1 = 1 + sturm_sequence(p, q, lb, d+1, e+1, e2+1);
			x1 = ub;
			m2 = sturm_sequence(p, q, x1, d+1, e+1, e2+1);
			if(m1 > m2){
				if (q < n) continue;
				else break;
				}

			/*find roots by bisection*/
			x0 = ub;

			for (i = m1; i <= m2; ++i){
				rv5[i] = ub;
				rv4[i] = lb;
				}
			/*loop for k-th eigenvalue*/
			for(k=m2;k>=m1;k--){
				xu = lb;
				DEBUGPR(("Eigenvalue %d m1=%d m2=%d lb=%lg ub=%lg",k,m1,m2,lb,ub));
				/*for i=k step -1 until m1 do --*/
				for (i=k; i>=m1; --i)
					if (xu < rv4[i]) {
						xu = rv4[i];
						break;
						}

				if(x0 > rv5[k]) x0 = rv5[k];
				DEBUGPR((" start [%lg, %lg]", x0, xu));

				uu = u0 = 0.;
				su = s0 = 0;
				while(1){
					/*next bisection step*/
					x1 = (xu + x0) * .5;
					if (x0 - xu <= eps) break;
					tst1 = (fabs(xu) + fabs(x0)) * 2.;
					tst2 = tst1 + (x0 - xu);
					if (tst2 == tst1) break;
					s = sturm_sequence(p, q, x1, d+1, e+1, e2+1);
					/*refine intervals*/
					if(s >= k){
						x0 = x1;
						}
					else	{
						xu = x1;
						if (s < m1) rv4[m1] = x1;
						else	{
							rv4[s + 1] = x1;
							if (rv5[s] > x1) rv5[s] = x1;
							}
						}
					DEBUGPR(("   new [%lg, %lg] gap=%lg", xu, x0,x0-xu));
					}

				/*k-th eigenvalue found*/
				rv5[k] = x1;
				}

			}
			/*order eigenvalues tagged with their submatrix associations*/
		s = r;
		r += m2 - m1 + 1;
		j = 1;
		k = m1;

		for (l = 1; l <= r; ++l){
			if(j<=s){
				if (k > m2) break;
				if (rv5[k] >= w[l]){
					++j;
					continue;
					}
				for (i = l+s-j; i>=l; --i) {
	    				w[i + 1] = w[i];
	    				ind[i + 1] = ind[i];
					}
				}
			w[l] = rv5[k++];
			ind[l] = tag;
			}
		}

L1001:	*plb = t1;
	*pub = t2;
	return ierr;

	/*set error -- interval cannot be found containing exactly the desired eigenvalues*/
L980:	ierr = (short)n*3+ierr;
	goto L1001;
}
short dtinvit(dimen n, vector d, vector e, vector e2, dimen m, vector w, short_vec ind, matrix z, dimen ldz, vector rv1)
{
/*
	dtinvit is a translation of the inverse iteration tech-
	nique in the algol procedure tristurm by peters and wilkinson
	handbook for auto. comp., vol.ii-linear algebra, 418-439(1971)
	this subroutine finds those eigenvectors of a tridiagonal
	symmetric matrix corresponding to specified eigenvalues,
	using inverse iteration

	on input
	n	dimen is the order of the matrix
	d	vector contains the diagonal elements of the input matrix
	e	vector contains the subdiagonal elements of the input matrix
		in its last n-1 positions.  e(1) is arbitrary
	e2	vector contains the squares of the corresponding elements of e,
		with zeros corresponding to negligible elements of e
		e(i) is considered negligible if it is not larger than
		the product of the relative machine precision and the sum
		of the magnitudes of d(i) and d(i-1).  e2(1) must contain
		0.0d0 if the eigenvalues are in ascending order, or 2.0d0
		if the eigenvalues are in descending order.  if	 bisect,
		tridib, or  imtqlv  has been used to find the eigenvalues,
		their output e2 array is exactly what is expected here
	m	dimen is the number of specified eigenvalues
	w	vector contains the m eigenvalues in ascending or descending order.
	ind	short_vec contains in its first m positions the submatrix indices
		associated with the corresponding eigenvalues in w --
		1 for eigenvalues belonging to the first submatrix from
		the top, 2 for those belonging to the second submatrix, etc.

	on output all input arrays are unaltered
	z	matrix contains the associated set of orthonormal eigenvectors
		any vector which fails to converge is set to zero
	ldz	dimen must be set to the row dimension of two-dimensional
		array parameters as declared in the calling program
		dimension statement

	The return value is
	zero	for normal return,
	-r	if the eigenvector corresponding to the r-th
		eigenvalue fails to converge in 5 iterations

	rv1	vector is torage of length 5n
*/
	vector	rv2=rv1+n;
	vector	rv3=rv2+n;
	vector	rv4=rv3+n;
	vector	rv5=rv4+n;
	real	norm;
	int	i, j, p, q, r, s;
	real	u=0, v, order;
	int	group=-1;
	real	x0=0, x1;
	int	ip=-1;
	real	uk=0, xu=0;
	int	tag=-1, its;
	real	eps2=1e4, eps3=1e4, eps4=1e4;
	short	ierr;

	--rv5;
	--rv4;
	--rv3;
	--rv2;
	--rv1;
	z -= ldz + 1;
	--ind;
	--w;
	--e2;
	--e;
	--d;

	if(m == 0) return 0;
	ierr = 0;
	tag = 0;
	order = 1. - e2[1];
	q = 0;
	while (q < (int) n){
		/*establish and process next submatrix*/
		p = q + 1;
		for (q = p; q <= (int) n; ++q) 
			if (q == (int) n || e2[q+1]==0.0) break;

		/*find vectors by inverse iteration*/
		++tag;
		s = 0;

		for (r = 1; r <= (int) m; ++r) {
			if (ind[r] != tag) continue;
			its = 1;
			x1 = w[r];
			if (s == 0){
				/*check for isolated root*/
				xu = 1.;
				if (p == q){
					rv5[p] = 1.;
					goto L870;
					}
				norm = fabs(d[p]);
				ip = p + 1;

				for (i = ip; i <= q; ++i) {
					uk = fabs(d[i])+fabs(e[i]);
					norm = dmax(norm,uk);
					}
				/*
				eps2 is the criterion for grouping,
				eps3 replaces zero pivots and equal
				roots are modified by eps3,
				eps4 is taken very small to avoid overflow
				*/
				eps2 = norm * .001;
				eps3 = lm_eps*norm;
				uk = (real) (q - p + 1);
				eps4 = uk * eps3;
				uk = eps4 / sqrt(uk);
				s = p;
				group = 0;
				}
			else	/*look for close or coincident roots*/
				if (fabs(x1 - x0) >= eps2) group = 0;
				else	{
					++group;
					if (order * (x1 - x0) <= 0.) x1 = x0 + order * eps3;
					}

			/*elimination with interchanges and initialization of vector*/
			v = 0.;

			for (i = p; i <= q; ++i) {
				rv5[i] = uk;
				if (i > p) {
					if (fabs(e[i]) >= abs(u)) {
						/*
						divide check may occur here if e2 array has
						not been specified correctly
						*/
						xu = u / e[i];
						rv4[i] = xu;
						rv1[i - 1] = e[i];
						rv2[i - 1] = d[i] - x1;
						rv3[i - 1] = 0.;
						if (i != q) {
							rv3[i - 1] = e[i + 1];
							}
						u = v - xu * rv2[i - 1];
						v = -xu * rv3[i - 1];
						continue;
						}
					xu = e[i] / u;
					rv4[i] = xu;
					rv1[i - 1] = u;
					rv2[i - 1] = v;
					rv3[i - 1] = 0.;
					}
				u = d[i] - x1 - xu * v;
				if (i != q) v = e[i + 1];
				}

			if (u == 0.) u = eps3;
			rv1[q] = u;
			rv2[q] = 0.;
			rv3[q] = 0.;
			while(1){
				/*back substitution */
				for (i = q; i >= p; --i) {
					rv5[i] = (rv5[i] - u * rv2[i] - v * rv3[i]) / rv1[i];
					v = u;
					u = rv5[i];
					}
				if (group != 0) {
					/*orthogonalize with respect to previous members of group*/
					for (j = r, i = 1; i <= group; ++i){
						while(ind[j] != tag) --j;
						xu = 0.;
						xu = ddotvec(q-p+1,rv5+p,z+p+j*ldz);
						BITA_daxpy(q-p+1,-xu,z+p+j*ldz,1,rv5+p,1);
						}

					}
				norm = dnrm1vec(q-p+1,rv5+p);
				if (norm >= 1.){
					/*normalize so that sum of squares is 1*/
					u = dnrm2vec(q-p+1,rv5+p);
					xu = 1. / u;
					break;
					}
				if(its == 5){
					/*set error -- non-converged eigenvector*/
					ierr = -r;
					xu = 0.;
					break;
					}
				/*forward substitution*/
				if(norm != 0.) {
					xu = eps4 / norm;
					for (i = p; i <= q; ++i) rv5[i] *= xu;
					}
				else	{
					rv5[s] = eps4;
					if (++s > q) s = p;
					}
				/*elimination operations on next vector iterate*/
				for(i = ip; i <= q; ++i){
					u = rv5[i];
					/*
					if rv1[i-1] == e[i], a row interchange was performed earlier in the
					triangularization process
					*/
					if (rv1[i - 1] == e[i]) {
						u = rv5[i - 1];
						rv5[i - 1] = rv5[i];
						}
					rv5[i] = u - rv4[i] * rv5[i - 1];
					}

				++its;
				}


L870:
			/*expand to full order*/
			dzerovec(p-1, z+1+r*ldz);
			dzerovec(n-q, z+q+1+r*ldz);
			dsccopyvec( q-p+1, xu, rv5+p, z+p+r*ldz);
			x0 = x1;
			}
		}
	return ierr;
}
void dtrbak1(dimen n, matrix a, stride lda, vector e, dimen m, matrix z, stride ldz)
{
/*
	dtrbak1 is a translation of the algol procedure trbak1,
	num. math. 11, 181-195(1968) by martin, reinsch, and wilkinson
	handbook for auto. comp., vol.ii-linear algebra, 212-226(1971)
	this subroutine forms the eigenvectors of a real symmetric
	matrix by back transforming those of the corresponding
	symmetric tridiagonal matrix determined by  tred1
	on input
		n	is the order of the matrix
		a	contains information about the orthogonal trans-
			formations used in the reduction by  tred1
			in its strict lower triangle
		lda	must be set to the row dimension of the matrix a
		e	contains the subdiagonal elements of the tridiagonal
			matrix in its last n-1 positions.  e(1) is arbitrary
		m	is the number of eigenvectors to be back transformed
		z	contains the eigenvectors to be back transformed
			in its first m columns
		ldz	must be set to the row dimension of the matrix z

	on output
	z contains the transformed eigenvectors
	in its first m columns
	note that dtrbak1 preserves vector euclidean norms
*/
	dimen	i, j, k;
	real	aii;
	vector	zj;

	if(m && n>1)
		for(i=1,k=0; i<n; ++i, k+=lda){
			a++;
			if(e[i] != 0.)
				for(j=0, aii=a[k], zj=z;j<m; ++j, zj+=ldz )
					/*
					divisor below is negative of h formed in tred1.
					double division avoids possible underflow
					*/
					BITA_daxpy(i,(BITA_ddot(i,a,lda,zj,1)/aii)/e[i],a,lda,zj,1);
			}
}
void dsmxtridiag(dimen n, matrix S, vector d, vector e)
{
/*
	dsmxtridiag(n,S,d,e) converts an n-th. order real symmetric matrix, S,
	to tridiagonal form. On output the original matrix S is replaced by
	the orthogonal matrix Q which effects the transformation. The vectors
	d and e will contain the diagonal and off diagonal elements of the
	transformed matrix with e[0] = 0
*/
	dimen	l, k, j, i, n1;
	real	scale, hh, h, g, f, *p, *sil, *q, *r;
	vector	ri;				/*row i*/
	vector	ci;				/*col i*/

	if(!n) return;

	n1 = n+1;
	
	for(i=n-1, ci=S+n*i, ri=S+i, sil = ci-n+i;i;i--, ci-=n, ri--, sil-=n1){
		l = i - 1;
		scale = h = 0;
		if(l)	{
			scale = dnrm1( i, ri, n );
			if(scale==0) e[i] = 0;
			else	{
				BITA_dscal(i,1.0/scale,ri,n);
				g = dnrm2(i,ri,n);
				f = *sil;
				if(f>0) g = -g;
				e[i] = scale*g;
				*sil = -( h = g - f);
				h *= g;
				f = 0;
				for(j=0,q=S+1, p=ri;j<i;j++, q+=n1, p+=n){
					ci[j] = *p/h;
					g = BITA_ddot(j+1,ri,n,S+j,n) + BITA_ddot(l-j,p+n,n,q,1);
					e[j] = g/h;
					f += e[j]* *p;
					}
				hh = f/(h+h);
				for(j=0,r=ri;j<i;j++,r+=n){
					f = *r;
					g = (e[j] -= hh*f);
					for(k=0,p=S+j,q=ri;k<=j;k++,q+=n,p+=n)
						*p -= f*e[k]+g* *q;
					}
				}
			}
		else	e[i] = *sil;
		d[i] = h;
		}

	d[0] = e[0] = 0;
	for(i=0,ri=ci=S;i<n;i++,ci+=n,ri++){
		if(d[i])
			for(j=0,p=S;j<i;j++,p+=n)
				BITA_daxpy(i,-BITA_ddot(i,ri,n,p,1),ci,1,p,1);
		d[i] = ci[i];
		ci[i] = 1;
		dzerovec(i,ci);
		dzero(i,ri,n);
		}
}
short dstdmxqli(dimen n, vector d, vector e, matrix V, dimen itmax, short fail)
{
/*
	real precision QL algorithm with implicit shifts for finding the
	eigenvalues & eigenvectors of a symmetric tridiagonal matrix.

	on entry the n vector d should hold the diagonal of the matrix 
	and the n vector e should hold the off diagonal in elements 1 .. n-1

	the n by n matrix V should be an Identity matrix or the matrix returned
	by a call to routine dsmxtridiag.

	itmax	is the maximum allowable number of iterations to be allowed.

	fail	determines the failure mode of the routine.
	<0	noisy soft failure
	>0	quiet soft failure
	==0	noisy hard failure

	On exit e is destroyed; d will hold the eigenvalues and the matrix
	V will hold the normalised eigenvectors.

	the return value indicates success (0) or failure 1 which will
	mean that too many iterations occurred.
*/
	dimen	m, l, i, iter, n1=n-1;
	real	s, r, p, g, f, dd, c, b, *z0, *z1;

	/*move the e vector down 1 element*/
	for(i=1;i<n;i++) e[i-1] = e[i];
	e[n1] = 0;

	for(l=0;l<n;l++){
		iter = itmax;
		do	{
			for(m=l;m<n1;m++){
				dd = fabs(CR(d[m]))+fabs(CR(d[m+1]));
				if(fabs(CR(e[m]))+dd == dd) break;
				}
			if(m!=l){
				if(!iter--)
					return lm_check_fail(fail,1,
								"dstdmxqli");
				g = (d[l+1]-d[l])/(2.0*e[l]);
				r = sqrt(1.0+g*g);
				g = d[m]-d[l]+e[l]/(g+dsign(r,g));
				s = c = 1;
				p = 0;
				for(i=m,z1=V+n*i;i-- > l;z1=z0){
					f=s*e[i];
					b=c*e[i];
					if(fabs(f)>=fabs(g)){
						c = g/f;
						r = sqrt(1.0+c*c);
						g = f;
						c *= (s=1.0/r);
						}
					else	{
						s = f/g;
						r = sqrt(1.0+s*s);
						s *= (c=1.0/r);
						}
					e[i+1] = g*r;
					g = d[i+1]-p;
					r = (d[i]-g)*s+2.0*c*b;
					p = s*r;
					d[i+1]=g+p;
					g=c*r-b;
					drotvec(n,z1,z0=z1-n,c,s);
					}
				d[l] -= p;
				e[l] = g;
				e[m] = 0;
				}
			} while(m!=l);
		}
	return 0;
}
real dnrm1vec(dimen n, vector x)
{
	register real	r=0.0;
	while(n--) r+= fabs(*x++);

	return r;
}
real dnrm1(dimen n, vector x, stride incx)
{
	register real	r=0.0;
	while(n--){
		r += fabs(*x);
		x += incx;
		}
	return r;
}
short eigendecomp1(dimen n, matrix S, dimen m, vector d, matrix V, dimen itmax, vector v)
{
	short	r;
	short_vec	x;
	short fail=1;
#ifdef __SYSNT__
//_ASSERT(0);
#endif
	/*first ensure that the matrix is symmetric*/
	dmx_symmetrise(n,S);

	if( m*4 <= n && V!=NULL && S!=V )
	{
		vector	e=v+n;
		vector	e2=e+n;
		vector	w=e2+n;
		real	ub, lb;

		x=(short_vec)(w+5*n);

		/*partial method*/
		dtred1( n, S, n, v, e, e2 );
		r=dtridib(n, 0.0, v, e, e2, &lb, &ub, n-m+1, m, d, x, w);
		if(!r)
		{
			dimen	i, j;
			r = dtinvit(n, v, e, e2, m, d, x, V, n, w);
			if(!r)
			{
				for(i=0, j=m; i<--j; i++ )
				{
					real	t = d[i];
					d[i] = d[j];
					d[j] = t;
					dswapvec(n, V+n*i, V+n*j);
				}
				dtrbak1( n, S, n, e, m, V, n);
			}
		}
	}
	else
	{
		/*full method, find tridiagonalisation*/
		dsmxtridiag( n, S, d, v );
		r = dstdmxqli( n, d, v, S, itmax, fail );
		std::valarray<size_t>eigenorder(n);
		std::valarray<unsigned char>dropbad(n);
		dropbad=0;
		getordereig(n,d,&eigenorder[0],&dropbad[0]);
		Reorder_gen(n,&eigenorder[0],d,1);
		Reorder_gen(n,&eigenorder[0],S,n);
	}
	return r;
}
short eigendecomp(dimen n, matrix S, vector d, dimen itmax)
{
	std::valarray<double> v(n);
	return eigendecomp1(n,S,n,d,0,itmax,&v[0]);
}
