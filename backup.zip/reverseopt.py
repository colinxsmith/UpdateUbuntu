#!/usr/bin/env python
#Colin Smith
#October 3rd. 2005

from sys import stdin
from re import sub
from Opt import *
eps=pow(epsget(),.5)
def getcov(file=stdin):
    Q=[]
    n=0
    while 1:
        line=file.readline()
        if not len(line):break
        line=sub(',*$','',line.strip())
        Q+=[float(i) for i in line.split(',')]
        n+=1
    return (n,Q)
        

    
(n,Q)=getcov(open('testcov'))
#n=10
eigval=eigen(n,Q)[0]
print 'Eigenvalues of the covariance matrix'
for i in range(n):
    print '%4d %20.8e'%(i+1,eigval[i])

#Generate our portfolio weights

w=[float(i+1) for i in range(n)]
total=sum(w)
w=[i/total for i in w]

#Reverse optimisation
alpha=[]
Sym_mult(n,Q,w,alpha)
#Get the risk of the portfolio
riskp=pow(dot(w,alpha),0.5)
retp=dot(w,alpha)
#Get the alphas which give this as the optimum portfolio
#with return/risk ratio of .1
alpha=[i*10*riskp/retp for i in alpha]
retp=dot(w,alpha)

print 'Portfolio return %20.12e'%retp
print 'Portfolio risk %20.12e'%riskp

#Generate standard error for each alpha from the diagonal of Q
alphaerror=[pow(Q[i*(i+3)/2],.5) for i in range(n)]
errorp=pow(sum([alphaerror[i]*w[i]*alphaerror[i]*w[i] for i in range(n)]),.5)
print 'Error in return %20.12e'%errorp
print 'Return + Error in return %20.12e'%(retp+errorp)

#Now let's maximise return such that the risk is <=retp  but the return error <=errorp * .9
#and sum of weights =1 and all weights are positive

#Get square root of Q and its inverse
rQ=[0]*(n*n)    #we need this for the risk constraint
rQm1=[0]*(n*n)
RootQ(n,Q,rQ,rQm1)

c=[-i for i in alpha]   #minus as we want to maximise return
m=3+n     #3+n cones for 3+n constraints

#Budget is expressed as norm(sum(w)-1)<=0              cone dim is 2
#Risk constraint is norm(rQ.w)<=riskp                   cone dim is n+1
#error contsraint is norm(diag(alphaerror).w)<=errop    cone dim is n+1
#weight bounds become wi>=0                             cone dim is 1 (n of these)

ncone=[2,n+1,n+1]+[1]*n
nx=sum(ncone)
b=[-1,0] + [0]*n+[riskp] + [0]*n+[errorp*.7] + [0]*n
A=[1]*n+[0]*n + [i for i in rQ]+[0]*n
for i in range(n):
    aa=[0]*n
    aa[i]=alphaerror[i]
    A+=aa
A+=[0]*n
for i in range(n):
    aa=[0]*n
    aa[i]=1
    A+=aa

#Primal and dual optimisation variables    
tau=[0]
kappa=[0]
x=[0]*nx
s=[0]*nx
y=[0]*n

#Get the constraints the correct way round
dmx_transpose(n,nx,A,A)

#Second order cone optimiser call
"""
tau[0]=1
SOCPopt(n,m,ncone,c,A,b,y,1e-2,10,1000,1,0,1)
"""

if SOCPinfeasHomogt(m,n,ncone,b,A,c,x,y,s,tau,kappa,100,1e-8,.5,eps,eps):print 'SOCP failed '*10
else:print 'SOCP finished properly'

if tau[0]<kappa[0]:
    print 'INFEASIBLE '*5
    if dot(c,y)>0:print 'c dot y is %20.12e primal is infeasible'%(dot(c,y))
    if dot(b,x)<0:print 'b dot x is %20.12e dual is infeasible (our problem)'%(dot(b,x))
else:
    y=[-i/tau[0] for i in y]

    #Get risk return and error for the optimal weights in y
    implied=[]
    Sym_mult(n,Q,y,implied)
    newriskp=pow(dot(y,implied),0.5)
    newretp=dot(y,alpha)
    newerrorp=pow(sum([alphaerror[i]*y[i]*alphaerror[i]*y[i] for i in range(n)]),.5)

    print '        %20s\t%20s'%('Before','After')
    for i in range(n):
        print '        %20.12e\t%20.12e'%(w[i],y[i])
    print 'Total   %20.12e\t%20.12e'%(sum(w),sum(y))

    print '                \t\t%20s\t%20s\t(%20s)'%('Before','After','bound closeness')
    print 'Portfolio return\t\t%20.12e\t%20.12e'%(retp,newretp)
    print 'Portfolio risk\t\t\t%20.12e\t%20.12e\t(%20.12e)'%(riskp,newriskp,1-newriskp/b[2+n])
    print 'Error in return\t\t\t%20.12e\t%20.12e\t(%20.12e)'%(errorp,newerrorp,1-newerrorp/b[2*n+3])
    print 'Return + Error in return\t%20.12e\t%20.12e'%(retp+errorp,newretp+newerrorp)

       
