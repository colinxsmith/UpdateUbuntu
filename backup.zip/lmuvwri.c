#include "ldefns.h"
void lm_muvwri(const char *name, dimen n, undex_vec x)
{
	lm_name_write(name, 10, 6 );
	lm_uvwrit(n, x);
}
