#include "ldefns.h"

real dnrm2vec(dimen n, vector x)
{
	if (n == 1) return (*x<0.0 ? -*x : *x);
	else	{
    		real scale=0.0, ssq=1.0;
		dsssqvec(n, x, &scale, &ssq);
		return sc_norm(scale, ssq);
    		}
}
