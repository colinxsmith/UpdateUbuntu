#!/usr/bin/env python
from Opt import *
from re import sub
from time import clock
r12=pow(12,.5)
badval=-1e20
def newW(p,p1,w):
    """Get new weights due to price change"""
    n=len(w)
    w1=[w[i]*p1[i]/p[i] for i in range(n)]
    tot=sum(w1)
    return [i/tot for i in w1]
def newWr(r,w):
    """Get new weights due to price change from returns"""
    n=len(w)
    w1=[w[i]*(1+r[i]) for i in range(n)]
    tot=sum(w1)
    return [i/tot for i in w1]
def newB(n,mcap):
    """Get mcap weighted portfolio weights"""
    tot=sum(mcap[:n])
    return [i/tot for i in mcap[:n]]
def gendates():
    """Generate a list of consequtive datas from Jan97 to Nov05"""
    months='Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split()
    years='97 98 99 00 01 02 03 04 05'.split()
    back=[]
    for i in years:
        for j in months:
            back.append(j+i)
    del back[-1]    #no Dec05
    #del back[-1]    #no Nov05
    return back
def turnover(w,wi):
    """Get turnover as half sum of absolute differences"""
    return 0.5*sum([abs(w[i]-wi[i]) for i in range(len(w))])
def var(x,Q):
    """x'.Q.x"""
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    """risk is sqrt(x'.Q.x); x is a list of length, Q is of length n*(n+1)/2"""
    return pow(var(x,Q),.5)
def meanerror(x,Q):
    """meanerror is sqrt(sum (xiQi)**2); x is a list of length, Q is of length n"""
    return pow(sum([x[i]*x[i]*Q[i]*Q[i] for i in range(len(x))]),.5)
def BITAutil(gamma,w,bench,alpha,Q):
    """The value of the BITA plus utility function"""
    gamma/=(1-gamma)
    ret=-gamma*dot(w,alpha)
    return ret+0.5*var([w[i]-bench[i] for i in range(len(w))],Q)
def readcov(a):
    """Read a covariance risk model file"""
    assets=[]
    COV=[]
    while(1):
        line=a.readline()
        if not len(line):break
        line=line.strip()
        if not len(line):continue
        line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
        try:
            r=float(line)
            COV.append(r)
        except:
            assets.append(line)
    return(assets,COV)
def readfore(a):
    """Read data in a forecast error data file"""
    bads=[]
    assets=[]
    COVfe=[]
    MEANfe=[]
    alpha=[]
    real_alpha=[]
    mcap=[]
    price=[]
    sect=[]
    types=[]
    while(1):
        line=a.readline()
        if not len(line):break
        line=line.strip()
        if not len(line):continue
        line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
        vals=line.split(',')
        if types==[]:
            types=vals
            continue
        if len(vals)>1:
            assets.append(vals[0])
            rem=0
            try:MEANfe.append(float(vals[1]))
            except:
                print vals[0],'Meanfe',vals[1]
                alpha.append(badval)
                rem=1
            try:alpha.append(float(vals[2]))
            except:
                print vals[0],'alpha',vals[2]
                alpha.append(badval)
                rem=1
            try:real_alpha.append(float(vals[3]))
            except:
                print vals[0],'real_alpha',vals[3]
                real_alpha.append(badval)
                rem=1
            try:mcap.append(float(vals[4]))
            except:
                print vals[0],'mcap',vals[4]
                mcap.append(badval)
                rem=1
            try:price.append(float(vals[5]))
            except:
                print vals[0],'price',vals[5]
                price.append(badval)
                rem=1
            try:sect.append(float(vals[6]))
            except:
                print vals[0],'sect',vals[6]
                sect.append(badval)
                rem=1
            if rem:
                print 'remove',vals[0],'due to bad float'
                bads.append(vals[0])
                del assets[-1]
                del MEANfe[-1]
                del alpha[-1]
                del real_alpha[-1]
                del mcap[-1]
                del sect[-1]
                del price[-1]
        else:
            COVfe.append(float(vals[0]))
    for i in bads:
        if i in assets:raise 'bad value problem'
    return(assets,MEANfe,alpha,real_alpha,mcap,price,sect,COVfe)
def getUniverse(badstocks,front,covfront,FEfront,dates):
    """Find the largest universe which has valid data for everything"""
    ASSETS={}
    tnumdel=0
    for date in dates:
        print date
        numdel=0
        file=front+covfront+date+'.csv'
        (assetsC,Q)=readcov(open(file))
        if ASSETS=={}:
            for stock in assetsC:
                ASSETS[stock]=1
        else:
            for stock in ASSETS.keys():
                if not stock in assetsC: del ASSETS[stock];numdel+=1
        file=front+FEfront+date+'.csv'
        (assetsF,MEANfe,alphaF,real_alpha,mcap,price,sect,COVfe)=readfore(open(file))
        for stock in ASSETS.keys():
            if not stock in assetsF: del ASSETS[stock];numdel+=1
        print '%d removed'%numdel
        tnumdel+=numdel
    print 'Total number of stocks removed',tnumdel

    if badstocks!=[]:        
        for stock in ASSETS.keys():
            if stock in badstocks:del ASSETS[stock]
    return ASSETS.keys()
class RobOpt:
    """Class for holding Robust optimsation data and doing the robust optimisation and calculation
    of the reported stuff"""
    def __init__(self):
        self.propsS='n,m,maxmeanFE,maxstderrorFE,gamma,maxRisk,mFE,rFE'.split(',')
        self.propsL='A,L,U,SV,FL,FC,alpha,alphafe,COVfe,bench,initial,real_alpha,mcap,price,sect'.split(',')
        for i in self.propsS:
            setattr(self,i,0)
        for i in self.propsL:
            setattr(self,i,[])
        self.nf=-1
    def Opt(self):
        """Do the robust optimisation"""
        for i in self.propsS:
            print i,getattr(self,i)
        for i in self.propsL:
            print i,getattr(self,i)[:5]
        w=[]
        t1=clock()
        back=SOCPRobust(self.n,self.m,w,self.A,self.L,self.U,self.nf,
                                     self.SV,self.FL,self.FC,self.alpha,self.alphafe,
                                     self.COVfe,self.maxmeanFE,self.maxstderrorFE,
                                     self.gamma,self.maxRisk,self.bench,
                                     self.initial,self.mFE,self.rFE)
        t2=clock()
        print 'Robust optimisation needed %d secs'%(t2-t1)
        setattr(self,'w',w)
        return back
    def Props(self):
        """Get return and risk numbers and the robust numbers"""
        absret=dot(self.w,self.alpha)
        benchret=dot(self.bench,self.alpha)
        relret=absret-benchret
        real_return=dot(self.w,self.real_alpha)
        bench_return=dot(self.bench,self.real_alpha)
        relrisk=risk([self.w[i]-self.bench[i] for i in range(self.n)],self.FC)
        meanerr=meanerror([self.w[i]-self.mFE*self.initial[i] for i in range(self.n)],self.alphafe)
        stderr=risk([self.w[i]-self.rFE*self.initial[i] for i in range(self.n)],self.COVfe)
        utility=BITAutil(self.gamma,self.w,self.bench,self.alpha,self.FC)
        return (real_return,bench_return,relret,relrisk,meanerr,stderr,utility)
class OutObj:
    """Use this class to hold output data items"""
    def __init__(self,real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn,bturn):
        self.attr='real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn,bturn'.split(',')
        for i in self.attr:
            setattr(self,i,eval(i))
            print i,getattr(self,i)
front='z:/Omam/OMAM Robust/'
covfront='risk models/USDoptimisercovMatrix'
FEfront='MktCap_FEDeMeaned_Strategy/USDforecastErrorMatrix'
#FEfront='MktCap_Non_FEDemeaned_Strategy/USDforecastErrorMatrix'

"""
It's time consuming to get the largest universe every time, so we store the stock names in the file
pointed to by universefile. If this exists it is used otherwise it is created.
"""
universefile='universed'   #Holds the names of the stocks in the largest universe
dates=gendates()            #Generate a list of dates for the simulation
#dates='Jan00 Feb00 Mar00 Apr00'.split()
try:
    univ=open(universefile)
    stocks=[]
    for i in univ.readlines():
        stocks.append(i.strip())
    univ.close()
except:#We get here if the universefile does not exist
    stocks=getUniverse(badstocks,front,covfront,FEfront,dates)
    univ=open(universefile,'w')
    for i in stocks:univ.write(i+'\n')
    univ.close()
print stocks


initial=[]
w=[]
Optr=RobOpt()           #Object for robust optimisations
Optr.n=n=len(stocks)
print n
Optr.m=1                #number of general linear constraints
Optr.A=[1]*n            #Constraint matrix for budget constraint
Optr.L=[0]*n+[1]        #n stock lower bounds and budget lower bound
Optr.U=[1]*n+[1]        #n stock upper bounds and budget upper bound
Optr.bench=[1.0/n]*n    #set benchmark weights (I reset them later)
Optr.gamma=0.2          #only used in BITA utility, does nothing
maxRisk=.05/r12         #Risk constraint upper bound
maxmeanFE=-2e-3          #M constraint upper bound (if - constraint is ignored)
maxstderrorFE=5e-3      #S constraint upper bound (if - constraint is ignored)
Optr.mFE=1              #Make M constraint relative to the initial weights
Optr.rFE=1              #Make S constraint relative to the initial weights
OUTPUT={}               #For holding output for robust stages
OUTPUTt={}              #For holding output for QP stages

Optq=Opt()              #Object for QP optimisations
for i in 'n,m,A,L,U,alpha,bench,initial,gamma'.split(','):
    setattr(Optq,i,getattr(Optr,i))
Optq.nfac=-1
Optq.Q=Optr.FC
Optq.names=stocks
Optq.revise=1
Optq.gamma=1
Optq.minrisk=0
Optq.maxrisk=maxRisk
oldprice=[]
oldbench=[]
for date in dates:
    print '+++++++++++++ Date %s +++++++++++++++++++++'%date
    fileC=front+covfront+date+'.csv'
    print fileC
    (assetsC,Q)=readcov(open(fileC))
    nC=len(assetsC)
    print nC,(nC*(nC+1)/2),len(Q)
    fileF=front+FEfront+date+'.csv'
    print fileF
    (assetsF,MEANfe,alphaF,real_alphaF,mcap,price,sect,COVfe)=readfore(open(fileF))
    na=len(assetsF)
    print na,(na*(na+1)/2),len(COVfe)
    #Now we have all the data for current date and must pick out just the data for the universe

        

    Ord=[0]*nC
    pickout(n,stocks,nC,assetsC,Q,Ord)  #Reorder the covariances into universe order
    fix_covariancem(n,Q)
    """Now Q is in the correct order for the list stocks, there is nothing to apply Ord to!"""

    Ord=[0]*na
    pickout(n,stocks,na,assetsF,COVfe,Ord)  #Reorder the FE covariances into universe order
    """Now COVfe is in the correct order for the list stocks, we need to apply Ord to the other entries."""

    
    for i in 'MEANfe,alphaF,real_alphaF,mcap,price,sect'.split(','):
        exec 'Reorder(na,Ord,%s)'%i

    #Now the data is in the correct order, we only use the first n values of each   
    real_alpha=real_alphaF
    alpha=alphaF
    alphafe=MEANfe
    Optr.FC=Q
    Optq.Q=Q
    Optr.mcap=mcap
    Optr.price=price
    Optr.sect=sect
    if initial==[]:
        initial=[0]*n
        Optr.maxmeanFE=10
        Optr.maxstderrorFE=10
        oldprice=[i for i in price]
        oldbench=[0]*n
    else:
        #initial=newW(price,oldprice,w)
        initial=newWr(real_alpha,w)
        oldprice=[i for i in price]
        Optr.maxmeanFE=maxmeanFE
        Optr.maxstderrorFE=maxstderrorFE
        oldbench=[i for i in Optr.bench]
    Optr.bench=newB(n,mcap)
    Optq.bench=[i for i in Optr.bench]
    Optr.maxRisk=maxRisk
    Optr.initial=initial
    Optq.initial=initial
    Optr.alpha=alpha
    Optq.alpha=alpha
    Optr.COVfe=COVfe
    Optr.alphafe=alphafe
    Optr.real_alpha=real_alpha
    while 1:#In this loop we keep doing the robust optimisation until we get a feasible solution
        retcode=Optr.Opt()
        print SOCPlstestMessage(retcode)
        (real_return,bench_return,relret,relrisk,meanerr,stderr,utility)=Optr.Props()
        if retcode==0:break
        else:#If not feasible increase the upper bounds by .001
            if Optr.maxmeanFE>0:Optr.maxmeanFE+=.001
            if Optr.maxstderrorFE>0:Optr.maxstderrorFE+=.001
            
    turn=turnover(Optr.w,Optr.initial)
    bturn=turnover(Optr.bench,oldbench)
    for i in range(n):
        print '%20s\t%20.8f\t%20.8f%20.8f'%(stocks[i],Optr.alpha[i],Optr.w[i],Optr.initial[i])
    print real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn
    #Keep robust output in OUTPUT
    OUTPUT[date]=OutObj(real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn,bturn)
    w=[i for i in Optr.w]
    #Now do QP optimisation with both risk and turnover constrained the results from robust
    Optq.delta=turn
    Optq.maxrisk=relrisk
    Optq.opt()
    Optr.w=[i for i in Optq.w]
    turn=turnover(Optr.w,Optr.initial)
    (real_return,bench_return,relret,relrisk,meanerr,stderr,utility)=Optr.Props()
    #Keep QP output in OUTPUTt
    OUTPUTt[date]=OutObj(real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn,bturn)

#outfile contains the output

#outfile=open('s:/robustoutbased3.csv','w')
outfile=open('s:/robustoutS5.csv','w')
Labels={'date':',','bench_return':'Benchmark return,','real_return':'Real Ret,','relret':'Rel Ret,','relrisk':'Rel Risk,','meanerr':'Alpha Err,',
        'stderr':'Alpha Std,','utility':'Utility,','turn':'Turnover,','bturn':'Bench Turnover,'}

for i in 'date,real_return,bench_return,relret,relrisk,meanerr,stderr,turn,bturn'.split(','):
    outfile.write(Labels[i])
outfile.write(',,')
for i in 'real_return,bench_return,relret,relrisk,meanerr,stderr,turn,bturn'.split(','):
    outfile.write(Labels[i])
outfile.write('\n\n')
for date in dates:
    outfile.write('%s,'%date)
    for i in 'real_return,bench_return,relret,relrisk,meanerr,stderr,turn,bturn'.split(','):
        outfile.write('%f,'%getattr(OUTPUT[date],i))
    outfile.write(',,')
    for i in 'real_return,bench_return,relret,relrisk,meanerr,stderr,turn,bturn'.split(','):
        outfile.write('%f,'%getattr(OUTPUTt[date],i))
    outfile.write('\n')
