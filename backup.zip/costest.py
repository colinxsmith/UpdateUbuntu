#! /usr/bin/env python
#Colin 9-4-2003, class interface to threadsafe optimiser (classes Optimise and FOptimise
#where FOptimise extends Optimise to allow factor model input)
#Here we test the general interface Optimise that allows the Hessian times vector routine
#to be defined in Python and show how to perform a risk constrained optimisation with all
#of the necessary functions defined in Python.
from safe import *
from math import sqrt
"""
Helper functions
"""
def dot(a,b):
    s=0
    for i in range(len(a)):s+=a[i]*b[i]
    return s
def listadd(a,b):
    c=[]
    for i in range(len(a)):c.append(a[i]+b[i])
    return c
def listsub(a,b):
    c=[]
    for i in range(len(a)):c.append(a[i]-b[i])
    return c
def scallistadd(gamma,a,c):
    b=[]
    for i in range(len(a)):b.append(a[i]*gamma+c[i])
    return b
def scallistsub(gamma,a,c):
    b=[]
    for i in range(len(a)):b.append(a[i]*gamma-c[i])
    return b
def turnover(a,b):
    s=0
    for i in range(len(a)):s+=abs(a[i]-b[i])
    return s/2
def longshort(a):
    s=0
    l=0
    for i in a:
        if i < 0:s+=i
        elif i > 0:l+=i
    return (l,s)
"""
The optimisation problem
"""

#_________________________________________________________________________________________________
def testmul(n,n1,n2,n3,H,x,y):
    """Define the Hessian times vector routine here in Python instead of the optimiser dll"""
    ij = 0
    for i in range(n):
        y[i] = 0
        for j in range(i+1):
            y[i] += H[ij] * x[j]
            if i != j:y[j] += H[ij] * x[i]
            ij+=1
buy=[]
sell=[]
initial=[]
scale=1 #I've put scale_utility_external_terms in the base class now so we don't need scale
def ModifyGrad(n,x,C):
    print('ModifyGrad function')
#    print x
#    print sumlist(x)
#    print C
    for i in range(n):
        if x[i] >= initial[i]:C[i]+=scale*buy[i]
        else:C[i]-=scale*sell[i]
#    print C
    
def Utility(n,x):
#    print 'Utility function'
#    print x
#    print costs
    s=0
    for i in range(n):
        if x[i] >= initial[i]:s+=scale*buy[i]*(x[i]-initial[i])
        else:s-=scale*sell[i]*(x[i]-initial[i])
    return s
                    
opt = Optimise()
opt.SetLog()
n=5
opt.n=n
opt.m=1
opt.A=[1]*n
opt.lower=[-1]*n+[0]
opt.upper=[1]*n+[0]
opt.c=c=[-.2,-.1,.1,.2,.3]
opt.H=H=[1,
       -.1,1,
       .1,-.1,1,
       .1,.1,-.1,1,
       .1,.1,.1,-.1,1]

linear=(lambda x:x)
squared=(lambda x:x*x)
cubed=(lambda x:x*x*x)
costshape=(sqrt)

buy=list(map(costshape,range(1,n+1)))
sell=list(map(lambda x:costshape(x)*1.01,range(1,n+1)))

"""
#   This sets them up as in piecewise cost format
trans=[]
dmx_transpose(len(sell),2,sell+buy,trans)
print trans
"""

opt.initial=initial=[.02,.2,.3,.4,.08]
opt.delta=-1
opt.Full=1
opt.hmul=testmul
opt.Util=Utility
opt.ModDeriv=ModifyGrad
opt.badcountlimit=5
opt.DoExtraIterations=0
opt.UseDiagPenalty=1
opt.SLRATmax=-1
opt.SLRATmin=-1
np=100
for kappa in list(map(lambda y:cubed(float(y)/np),range(np))):
#for kappa in [3e-1]:
    opt.AddLog('kappa = %f\n'%kappa)
    opt.scale_utility_external_terms=kappa/(1-kappa)
    opt.hess_choice=5
    print(opt.OptSetup(opt.n,opt.n))
    x=opt.x
    print('Turnover %f'%(turnover(x,initial)))
    print('results ',x,sum(x),longshort(x))
    opt.hess_choice=1
    print('Utility ',opt.utility(n,x,c,H))
    opt.scale_utility_external_terms=1
    print('kappa %f: Cost %20.8e' % (kappa,Utility(n,x)))

