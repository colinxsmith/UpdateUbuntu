// Optimiser.cpp : Implementation of COptimiser
//#include "stdafx.h"
//#include "Optimiser.h"


// COptimiser
// Optimiser.cpp : Implementation of COptimiser

#include "optimise.h"
#include "stdafx.h"
#include "Optimiser.h"
#include "constant.h"
#include <comdef.h>
#include <atlsafe.h>

// COptimiser
#define USE_BSTR
inline bool IS_VARIANT_NOT_NULL(VARIANT A)
{
	return(A.vt && (A.pvarVal?A.pvarVal->vt:0));
/*	if(!A.vt)
	{
		return 0;
	}
	else if(!(A.pvarVal->vt))
	{
		return 0;
	}
	else
	{
		return 1;
	}*/
}
inline size_t NUMBER_OF_ELEMENTS_FOR1D(VARIANT A)
{
	if(IS_VARIANT_NOT_NULL(A))
	{
		if(A.vt>=VT_BYREF)
		/*Dim Opt as Object sends Dim x as Variant ReDim x(n) here*/
			return (*(A.pparray))->rgsabound[0].cElements;
		else
		/*Dim Opt as Optimiser sends Dim x as Variant ReDim x(n) here*/
			return A.parray->rgsabound[0].cElements;
	}
	else
		return 0;
}
inline void    __stdcall	DeleteNames(char** A,int n)
{
	int i;
	for(i = 0;i < n;++i)
		delete A[i];
	delete []A;
}
inline void    __stdcall	DeleteNamess(char** A,int n)//When the strings were made with strdup
{
	int i;
	for(i = 0;i < n;++i)
		free(A[i]);
	delete []A;
}
inline void	__stdcall	long_to_array(BSTR	stock_list,char** stocklist,int nstocks)
{
	int i = 0;
	_bstr_t a	= stock_list;

	LPSTR	s_list = (LPSTR)a;
	LPSTR	pN = s_list;

	while(s_list[i] != '\0')
	{
		if(s_list[i] == ' ')
		{
			s_list[i] = '\0';
		}
		i++;
	}

	for(i = 0;i < nstocks;++i)
	{
		if(strlen(pN))
		{
			stocklist[i] = new char[strlen(pN)+1];
			strcpy(stocklist[i],pN);
			pN += strlen(pN) + 1;
		}
		else
		{
			stocklist[i] = new char[8];
			sprintf(stocklist[i],"Var%d",i+1);
		}
	}
}
inline HRESULT	__stdcall	Array2D2Vector(int n,VARIANT v,vector *w,TCHAR* name)
{
	int i1,i2,i;
	_variant_t ccc;
	TCHAR mess[300];

	_ASSERT(0);
	if(v.vt == (VT_R8 | VT_ARRAY | VT_BYREF))
	{
		double HUGEP* Safe;
		i1 = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
		if((*(v.pparray))->cDims == 2)
			i2 = (*(v.pparray))->rgsabound[1].cElements /*- (*(v.pparray))->rgsabound[1].lLbound*/;
		else
			i2 = 1;//Not  really 2D
		if(i1 * i2 < n)
		{
			sprintf(mess,"2D array %s is %d by %d (%d elements), %d elements were expected",name,i1,i2,i1*i2,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i1 * i2;
		SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);

#ifdef	CREATE_AND_COPY
		*w = new double[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (double) Safe[i];
		SafeArrayUnaccessData(*(v.pparray));
#else
		*w = Safe;
#endif		
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY | VT_BYREF) )
	{
		VARIANT HUGEP* Safe;
		i1 = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
		if((*(v.pparray))->cDims == 2)
			i2 = (*(v.pparray))->rgsabound[1].cElements /*- (*(v.pparray))->rgsabound[1].lLbound*/;
		else
			i2 = 1;//Not  really 2D
		if(i1 * i2 < n)
		{
			sprintf(mess,"2D array %s is %d by %d (%d elements), %d elements were expected",name,i1,i2,i1*i2,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i1 * i2;
		SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);

		*w = new double[n];
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_R8);
			Safe[i] = ccc.Detach();
			(*w)[i] = Safe[i].dblVal;
		}
		SafeArrayUnaccessData(*(v.pparray));
		ccc.Clear();
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY))
	{
		VARIANT HUGEP* Safe;
		i1 = v.parray->rgsabound[0].cElements /*- v.parray->rgsabound[0].lLbound*/;
		if(v.parray->cDims == 2)
			i2 = v.parray->rgsabound[1].cElements /*- v.parray->rgsabound[1].lLbound*/;
		else
			i2 = 1;//Not  really 2D
		if(i1 * i2 < n)
		{
			sprintf(mess,"2D array %s is %d by %d (%d elements), %d elements were expected",name,i1,i2,i1*i2,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i1 * i2;
		SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);

		*w = new double[n];
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_R8);
			Safe[i] = ccc.Detach();
			(*w)[i] = Safe[i].dblVal;
		}
		SafeArrayUnaccessData(v.parray);
		ccc.Clear();
		return S_OK;
	}
	else if(v.vt == (VT_R8 | VT_ARRAY))
	{
		double HUGEP* Safe;
		i1 = (*(v.parray)).rgsabound[0].cElements /*- (*(v.parray)).rgsabound[0].lLbound*/;
		i2 = (*(v.parray)).rgsabound[1].cElements /*- (*(v.parray)).rgsabound[1].lLbound*/;
		if(i1 * i2 < n)
		{
			sprintf(mess,"2D array %s is %d by %d (%d elements), %d elements were expected",name,i1,i2,i1*i2,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i1 * i2;
		SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new double[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (double) Safe[i];
		SafeArrayUnaccessData(v.parray);
#else
		*w = Safe;
#endif

		return S_OK;
	}
	else
	{
		sprintf(mess,"%s is not double precision",name);
		::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
}
inline HRESULT	__stdcall	SafeArray2DRelease(VARIANT v,vector h)
{
	HRESULT hh = S_OK;
	_variant_t ccc;
	int n,i1,i2,i;
	switch(v.vt)
	{
	case (VT_R8 | VT_ARRAY | VT_BYREF):
		{
#ifdef	CREATE_AND_COPY
		double HUGEP* Safe;
		i1 = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
		if((*(v.pparray))->cDims == 2)
			i2 = (*(v.pparray))->rgsabound[1].cElements /*- (*(v.pparray))->rgsabound[1].lLbound*/;
		else
			i2 = 1;//Not  really 2D
		n = i1 * i2;
		hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
		for(i = 0;i < n;++i)
			 Safe[i] = ((double HUGEP*)h)[i];
		delete [] h;
#endif
		hh = SafeArrayUnaccessData(*(v.pparray));
		break;
		}
	case (VT_VARIANT | VT_ARRAY | VT_BYREF):
		{
		VARIANT HUGEP* Safe;
		i1 = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
		if((*(v.pparray))->cDims == 2)
			i2 = (*(v.pparray))->rgsabound[1].cElements /*- (*(v.pparray))->rgsabound[1].lLbound*/;
		else
			i2 = 1;//Not  really 2D
		n = i1 * i2;
		hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_R8);
			Safe[i] = ccc.Detach();
			Safe[i].dblVal = ((double HUGEP*)h)[i];
		}
		delete [] h;

		hh = SafeArrayUnaccessData(*(v.pparray));
		break;
		}
	case (VT_R8 | VT_ARRAY):
		n = (*(v.parray)).rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;

#ifdef	CREATE_AND_COPY
		delete [] h;
		hh = S_OK;
#else
		hh = SafeArrayUnaccessData(v.parray);
#endif

		break;
	case (VT_VARIANT | VT_ARRAY):
		{
		VARIANT HUGEP* Safe;
		i1 = v.parray->rgsabound[0].cElements /*- v.parray->rgsabound[0].lLbound*/;
		if(v.parray->cDims == 2)
			i2 = v.parray->rgsabound[1].cElements /*- v.parray->rgsabound[1].lLbound*/;
		else
			i2 = 1;//Not  really 2D
		n = i1 * i2;
		hh = SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_R8);
			Safe[i] = ccc.Detach();
			Safe[i].dblVal = ((double HUGEP*)h)[i];
		}
		delete [] h;

		hh = SafeArrayUnaccessData(v.parray);
		break;
		}
	default:
		::MessageBox(NULL,"Variant was not of type double:SafeArray2DRelease","Data Unaccess",MB_OK | MB_ICONSTOP);
	}
	if(hh != S_OK)
		::MessageBox(NULL,"Error this was not a safe array","Data Unaccess",MB_OK | MB_ICONSTOP);
	ccc.Clear();
	return hh;
}
inline HRESULT __stdcall       SafeArrayRelease(VARIANT v,vector h,size_t nn)
{	
	HRESULT hh = S_OK;
	if(!h)
		return hh;
	_variant_t ccc;

	size_t n,i;
	switch(v.vt)
	{
	case (VT_R8 | VT_ARRAY | VT_BYREF):
		{
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
#ifdef	CREATE_AND_COPY
			double HUGEP* Safe;
			hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			for(i = 0;i < n;++i)
				 Safe[i] = ((double HUGEP*)h)[i];
			delete [] h;
#endif
			hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];
				double HUGEP* Safe;

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_R8,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					Safe[i] = ((double HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_R8 | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			double HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_R8,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				Safe[i] = ((double HUGEP*)h)[i];
			}
			delete[] h;

			v.vt = VT_R8 | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
	break;
	}
	case (VT_VARIANT | VT_ARRAY | VT_BYREF):
		{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
				hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
				for(i = 0;i < n;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_R8);
					Safe[i] = ccc.Detach();
					Safe[i].dblVal = ((double HUGEP*)h)[i];
				}
				delete [] h;
				hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_VARIANT,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_R8);
					Safe[i] = ccc.Detach();
					Safe[i].dblVal = ((double HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_R8);
				Safe[i] = ccc.Detach();
				Safe[i].dblVal = ((double HUGEP*)h)[i];
			}
			delete[] h;

			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
		break;
		}
	case (VT_VARIANT | VT_ARRAY):
		{
		VARIANT HUGEP* Safe;
		n = v.parray?v.parray->rgsabound[0].cElements:0 /*- v.parray->rgsabound[0].lLbound*/;
		if(n)hh = SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);

		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_R8);
			Safe[i] = ccc.Detach();
			Safe[i].dblVal = ((double HUGEP*)h)[i];
		}

		if(h)delete [] h;
		if(n)hh = SafeArrayUnaccessData(v.parray);
		else
			hh=S_OK;
		break;
		}
	case (VT_R8 | VT_ARRAY):
		n = (*(v.parray)).rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
#ifdef	CREATE_AND_COPY
		delete [] h;
		hh = S_OK;
#else
		hh = SafeArrayUnaccessData(v.parray);
#endif
		break;
	case 0:
		if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			VARIANT HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);
			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			v.pparray = &pArray;


	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_R8);
				Safe[i] = ccc.Detach();
				Safe[i].dblVal = ((double HUGEP*)h)[i];
			}
			delete[] h;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
		{
		//	::MessageBox(NULL,"No elements for output array","[in,out] array has length 0",MB_OK | MB_ICONSTOP);
			hh = S_OK;
		}
		break;
	default:
		::MessageBox(NULL,"Variant was not of type double:SafeArrayRelease","Data Unaccess",MB_OK | MB_ICONSTOP);
	}
	if(hh != S_OK)
		::MessageBox(NULL,"Error this was not a safe array","Data Unaccess",MB_OK | MB_ICONSTOP);
	ccc.Clear();
	return hh;
}
inline HRESULT __stdcall       SafeArrayRelease(VARIANT v,int* h,size_t nn)
{	
	HRESULT hh = S_OK;
	if(!h)
		return hh;
	_variant_t ccc;

	size_t n,i;
	switch(v.vt)
	{
	case (VT_I4 | VT_ARRAY | VT_BYREF):
		{
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
#ifdef	CREATE_AND_COPY
			int HUGEP* Safe;
			hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			for(i = 0;i < n;++i)
				 Safe[i] = ((int HUGEP*)h)[i];
			delete [] h;
#endif
			hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];
				int HUGEP* Safe;

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_I4,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					Safe[i] = ((int HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_I4 | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			int HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_I4,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				Safe[i] = ((int HUGEP*)h)[i];
			}
			delete[] h;

			v.vt = VT_I4 | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
	break;
	}
	case (VT_VARIANT | VT_ARRAY | VT_BYREF):
		{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
				hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
				for(i = 0;i < n;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_I4);
					Safe[i] = ccc.Detach();
					Safe[i].lVal = ((int HUGEP*)h)[i];
				}
				delete [] h;
				hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_VARIANT,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_I4);
					Safe[i] = ccc.Detach();
					Safe[i].lVal = ((int HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				Safe[i].lVal = ((int HUGEP*)h)[i];
			}
			delete[] h;

			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
		break;
		}
	case (VT_VARIANT | VT_ARRAY):
		{
		VARIANT HUGEP* Safe;
		n = v.parray->rgsabound[0].cElements /*- v.parray->rgsabound[0].lLbound*/;
		hh = SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);

		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_I4);
			Safe[i] = ccc.Detach();
			Safe[i].lVal = ((int HUGEP*)h)[i];
		}

		delete [] h;
		hh = SafeArrayUnaccessData(v.parray);
		break;
		}
	case (VT_I4 | VT_ARRAY):
		n = (*(v.parray)).rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
#ifdef	CREATE_AND_COPY
		delete [] h;
		hh = S_OK;
#else
		hh = SafeArrayUnaccessData(v.parray);
#endif
		break;
	case 0:
		if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			VARIANT HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);
			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			v.pparray = &pArray;


	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				Safe[i].lVal = ((int HUGEP*)h)[i];
			}
			delete[] h;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
		{
		//	::MessageBox(NULL,"No elements for output array","[in,out] array has length 0",MB_OK | MB_ICONSTOP);
			hh = S_OK;
		}
		break;
	default:
		::MessageBox(NULL,"Variant was not of type int:SafeArrayRelease","Data Unaccess",MB_OK | MB_ICONSTOP);
	}
	if(hh != S_OK)
		::MessageBox(NULL,"Error this was not a safe array","Data Unaccess",MB_OK | MB_ICONSTOP);
	ccc.Clear();
	return hh;
}
inline HRESULT __stdcall       SafeArrayRelease(VARIANT v,char** h,size_t nn)
{	
	HRESULT hh = S_OK;
	if(!h)
		return hh;
	_variant_t ccc;
	_bstr_t bstring;

	size_t n,i;
	switch(v.vt)
	{
	case (VT_BSTR | VT_ARRAY | VT_BYREF):
		{
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
#if defined(USE_BSTR)
				BSTR HUGEP* Safe;
				hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
				for(i = 0;i < n;++i)
				{
					bstring=h[i];
					Safe[i] = bstring.copy();
				}
				DeleteNamess(h,n);
#endif
				hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];
				char* HUGEP* Safe;

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_I4,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					Safe[i] = ((char* HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_BSTR | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			BSTR HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_BSTR,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				bstring=h[i];
				Safe[i] = bstring.copy();
			}
			DeleteNames(h,nn);

			v.vt = VT_BSTR | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
	break;
	}
	case (VT_VARIANT | VT_ARRAY | VT_BYREF):
		{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
				hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
				for(i = 0;i < n;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_BSTR);
					Safe[i] = ccc.Detach();
					bstring = h[i];
					Safe[i].bstrVal = bstring.copy();
				}
			DeleteNamess(h,n);
				hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_VARIANT,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_BSTR);
					Safe[i] = ccc.Detach();
					bstring = h[i];
					Safe[i].bstrVal = bstring.copy();
				}
			DeleteNamess(h,nn);

				v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_BSTR);
					Safe[i] = ccc.Detach();
					bstring = h[i];
					Safe[i].bstrVal = bstring.copy();
			}
			DeleteNames(h,nn);

			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
		break;
		}
	case (VT_VARIANT | VT_ARRAY):
		{
		VARIANT HUGEP* Safe;
		n = v.parray->rgsabound[0].cElements /*- v.parray->rgsabound[0].lLbound*/;
		hh = SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);

		for(i = 0;i < n;++i)
		{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_BSTR);
					Safe[i] = ccc.Detach();
					bstring = h[i];
					Safe[i].bstrVal = bstring.copy();
		}

			DeleteNamess(h,n);
		hh = SafeArrayUnaccessData(v.parray);
		break;
		}
	case (VT_BSTR | VT_ARRAY):
		n = (*(v.parray)).rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
#if defined(USE_BSTR)
		DeleteNamess(h,n);
		hh = S_OK;
#else
		hh = SafeArrayUnaccessData(v.parray);
#endif
		break;
	case 0:
		if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			VARIANT HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);
			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			v.pparray = &pArray;


	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_BSTR);
					Safe[i] = ccc.Detach();
					bstring = h[i];
					Safe[i].bstrVal = bstring.copy();
			}
			DeleteNamess(h,nn);

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
		{
		//	::MessageBox(NULL,"No elements for output array","[in,out] array has length 0",MB_OK | MB_ICONSTOP);
			hh = S_OK;
		}
		break;
	default:
		::MessageBox(NULL,"Variant was not of type BSTR:SafeArrayRelease","Data Unaccess",MB_OK | MB_ICONSTOP);
	}
	if(hh != S_OK)
		::MessageBox(NULL,"Error this was not a safe array","Data Unaccess",MB_OK | MB_ICONSTOP);
	ccc.Clear();
	return hh;
}
inline HRESULT __stdcall       SafeArrayRelease(VARIANT v,dimen* h,size_t nn)
{	
	HRESULT hh = S_OK;
	if(!h)
		return hh;
	_variant_t ccc;

	size_t n,i;
	switch(v.vt)
	{
	case (VT_I4 | VT_ARRAY | VT_BYREF):
		{
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
#ifdef	CREATE_AND_COPY
			dimen HUGEP* Safe;
			hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			for(i = 0;i < n;++i)
				 Safe[i] = ((dimen HUGEP*)h)[i];
			delete [] h;
#endif
			hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];
				dimen HUGEP* Safe;

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_I4,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					Safe[i] = ((dimen HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_I4 | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			dimen HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_I4,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				Safe[i] = ((dimen HUGEP*)h)[i];
			}
			delete[] h;

			v.vt = VT_I4 | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
	break;
	}
	case (VT_VARIANT | VT_ARRAY | VT_BYREF):
		{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
				hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
				for(i = 0;i < n;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_I4);
					Safe[i] = ccc.Detach();
					Safe[i].lVal = ((dimen HUGEP*)h)[i];
				}
				delete [] h;
				hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_VARIANT,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_I4);
					Safe[i] = ccc.Detach();
					Safe[i].lVal = ((dimen HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				Safe[i].lVal = ((dimen HUGEP*)h)[i];
			}
			delete[] h;

			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
		break;
		}
	case (VT_VARIANT | VT_ARRAY):
		{
		VARIANT HUGEP* Safe;
		n = v.parray?v.parray->rgsabound[0].cElements:0 /*- v.parray->rgsabound[0].lLbound*/;
		hh = SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);

		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_I4);
			Safe[i] = ccc.Detach();
			Safe[i].lVal = ((dimen HUGEP*)h)[i];
		}

		delete [] h;
		hh = SafeArrayUnaccessData(v.parray);
		break;
		}
	case (VT_I4 | VT_ARRAY):
		n = (*(v.parray)).rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
#ifdef	CREATE_AND_COPY
		delete [] h;
		hh = S_OK;
#else
		hh = SafeArrayUnaccessData(v.parray);
#endif
		break;
	case 0:
		if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			VARIANT HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);
			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			v.pparray = &pArray;


	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				Safe[i].lVal = ((dimen HUGEP*)h)[i];
			}
			delete[] h;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
		{
		//	::MessageBox(NULL,"No elements for output array","[in,out] array has length 0",MB_OK | MB_ICONSTOP);
			hh = S_OK;
		}
		break;
	default:
		::MessageBox(NULL,"Variant was not of type int:SafeArrayRelease","Data Unaccess",MB_OK | MB_ICONSTOP);
	}
	if(hh != S_OK)
		::MessageBox(NULL,"Error this was not a safe array","Data Unaccess",MB_OK | MB_ICONSTOP);
	ccc.Clear();
	return hh;
}
inline HRESULT __stdcall       SafeArrayRelease(VARIANT v,size_t* h,size_t nn)
{	
	HRESULT hh = S_OK;
	if(!h)
		return hh;
	_variant_t ccc;

	size_t n,i;
	switch(v.vt)
	{
	case (VT_I4 | VT_ARRAY | VT_BYREF):
		{
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
#ifdef	CREATE_AND_COPY
			size_t HUGEP* Safe;
			hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			for(i = 0;i < n;++i)
				 Safe[i] = ((size_t HUGEP*)h)[i];
			delete [] h;
#endif
			hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];
				size_t HUGEP* Safe;

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_I4,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					Safe[i] = ((size_t HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_I4 | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			size_t HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_I4,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				Safe[i] = ((size_t HUGEP*)h)[i];
			}
			delete[] h;

			v.vt = VT_I4 | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
	break;
	}
	case (VT_VARIANT | VT_ARRAY | VT_BYREF):
		{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			n = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(n == nn)
			{
				hh = SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
				for(i = 0;i < n;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_I4);
					Safe[i] = ccc.Detach();
					Safe[i].lVal = ((size_t HUGEP*)h)[i];
				}
				delete [] h;
				hh = SafeArrayUnaccessData(*(v.pparray));
			}
			else if(nn)
			{
		//Set bounds for the output VARIANT
				SAFEARRAY FAR *pArray;
				SAFEARRAYBOUND bound[1];

				bound[0].cElements = nn;
				bound[0].lLbound = 0;

		//Create the space
				pArray = SafeArrayCreate(VT_VARIANT,1,bound);

		//Copy the real array data

				hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
				for(i = 0;i < nn;++i)
				{
					ccc.Attach(Safe[i]);
					ccc.ChangeType(VT_I4);
					Safe[i] = ccc.Detach();
					Safe[i].lVal = ((size_t HUGEP*)h)[i];
				}
				delete[] h;

				v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
				*(v.pparray) = pArray;

				hh = SafeArrayUnaccessData(pArray);
				//hh = SafeArrayDestroy(pArray);
			}
		}
		else if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);

	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				Safe[i].lVal = ((size_t HUGEP*)h)[i];
			}
			delete[] h;

			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			*(v.pparray) = pArray;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
			hh = S_FALSE;
		break;
		}
	case (VT_VARIANT | VT_ARRAY):
		{
		VARIANT HUGEP* Safe;
		n = v.parray?v.parray->rgsabound[0].cElements:0 /*- v.parray->rgsabound[0].lLbound*/;
		hh = SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);

		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_I4);
			Safe[i] = ccc.Detach();
			Safe[i].lVal = ((size_t HUGEP*)h)[i];
		}

		delete [] h;
		hh = SafeArrayUnaccessData(v.parray);
		break;
		}
	case (VT_I4 | VT_ARRAY):
		n = (*(v.parray)).rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
#ifdef	CREATE_AND_COPY
		delete [] h;
		hh = S_OK;
#else
		hh = SafeArrayUnaccessData(v.parray);
#endif
		break;
	case 0:
		if(nn)
		{
	//Set bounds for the output VARIANT
			SAFEARRAY FAR *pArray;
			SAFEARRAYBOUND bound[1];
			VARIANT HUGEP* Safe;

			bound[0].cElements = nn;
			bound[0].lLbound = 0;

	//Create the space
			pArray = SafeArrayCreate(VT_VARIANT,1,bound);
			v.vt = VT_VARIANT | VT_BYREF | VT_ARRAY;
			v.pparray = &pArray;


	//Copy the real array data

			hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
			for(i = 0;i < nn;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				Safe[i].lVal = ((size_t HUGEP*)h)[i];
			}
			delete[] h;

			hh = SafeArrayUnaccessData(pArray);
			//hh = SafeArrayDestroy(pArray);
		}
		else
		{
		//	::MessageBox(NULL,"No elements for output array","[in,out] array has length 0",MB_OK | MB_ICONSTOP);
			hh = S_OK;
		}
		break;
	default:
		::MessageBox(NULL,"Variant was not of type int:SafeArrayRelease","Data Unaccess",MB_OK | MB_ICONSTOP);
	}
	if(hh != S_OK)
		::MessageBox(NULL,"Error this was not a safe array","Data Unaccess",MB_OK | MB_ICONSTOP);
	ccc.Clear();
	return hh;
}
inline HRESULT	__stdcall	Variant2Vector(int n,VARIANT v,vector *w,TCHAR* name)
{
	int i;
	TCHAR mess[300];
	_variant_t ccc;

//	_ASSERT(0);
	if(v.vt == (VT_R8 | VT_ARRAY | VT_BYREF))
	{
		if(v.pparray && *(v.pparray))
		{
		double HUGEP* Safe;
		i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
		if(i < n)
		{
			if(i == 0)
			{
				*w = new double[n];
				for(i = 0;i < n;++i)
				{
					(*w)[i] = 0;
				}
				return S_OK;
			}
			else
			{
				sprintf(mess,"Double array %s has only %d elements, %d were expected",name,i,n);
				::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
				return S_FALSE;
			}
		}
		n = i;
		SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new double[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (double) Safe[i];
		SafeArrayUnaccessData(*(v.pparray));
#else
		*w = Safe;
#endif
		}
		else
		{
			if(n)
			{
				*w = new double[n];
				for(i = 0;i < n;++i)
					(*w)[i] = 0;
			}
			else
				*w=0;
		}

		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY | VT_BYREF))
	{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(i < n)
			{
				if(i == 0)
				{
					*w = new double[n];
					for(i = 0;i < n;++i)
					{
						(*w)[i] = 0;
					}
					return S_OK;
				}
				else
				{
					sprintf(mess,"Double array %s has only %d elements, %d were expected",name,i,n);
					::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
					return S_FALSE;
				}
			}
			n = i;
			SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			*w = new double[n];
			for(i = 0;i < n;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_R8);
				Safe[i] = ccc.Detach();
				(*w)[i] = Safe[i].dblVal;
			}
			SafeArrayUnaccessData(*(v.pparray));
			ccc.Clear();
		}
		else
		{
			if(n)
			{
				*w = new double[n];
				for(i = 0;i < n;++i)
				{
					(*w)[i] = 0;
				}
			}
			else 
				*w=0;
		}
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY ) )
	{
		VARIANT HUGEP* Safe;
		i = v.parray?v.parray->rgsabound[0].cElements:0 /*- v.parray->rgsabound[0].lLbound*/;
		if(i < n && i!=0)
		{
			sprintf(mess,"Double array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		if(n)
		{
			SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
			*w = new double[n];
		}
		else
			*w=0;
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_R8);
			Safe[i] = ccc.Detach();
			(*w)[i] = Safe[i].dblVal;
		}
		if(n)SafeArrayUnaccessData(v.parray);
		ccc.Clear();
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_BYREF))
	{
		::MessageBox(NULL,"Don't do Dim x as Variant follwed by ReDim x(n)!!!",name,MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
	else if(v.vt == (VT_R8 | VT_ARRAY))
	{
		double HUGEP* Safe;
		i = v.parray?(*(v.parray)).rgsabound[0].cElements:0 /*- (*(v.parray)).rgsabound[0].lLbound*/;
		if(i < n)
		{
			sprintf(mess,"Double array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		if(n) SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new double[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (double) Safe[i];
		SafeArrayUnaccessData(v.parray);
#else
		*w = (n>0)?Safe:0;
#endif
		return S_OK;
	}
	else if(v.vt == 0 && n)
	{
		*w = new double[n];
		for(i = 0;i < n;++i)
		{
			(*w)[i] = 0;
		}
		return S_OK;
	}
	else if(v.vt==VT_EMPTY)
	{
		*w=0;
		return S_OK;
	}
	else
	{
		sprintf(mess,"%s is not double precision %i %i %i %i %i",name,v.vt,VT_ARRAY,VT_R8,VT_VARIANT,VT_BYREF);
		::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
}
inline HRESULT	__stdcall	Variant2Vector(int n,VARIANT v,int **w,TCHAR* name)
{
	int i;
	TCHAR mess[300];
	_variant_t ccc;

//	_ASSERT(0);
	if(v.vt == (VT_I4 | VT_ARRAY | VT_BYREF))
	{
		if(v.pparray && *(v.pparray))
		{
		int HUGEP* Safe;
		i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
		if(i < n)
		{
			if(i == 0)
			{
				*w = new int[n];
				for(i = 0;i < n;++i)
				{
					(*w)[i] = 0;
				}
				return S_OK;
			}
			else
			{
				sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
				::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
				return S_FALSE;
			}
		}
		n = i;
		SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new int[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (int) Safe[i];
		SafeArrayUnaccessData(*(v.pparray));
#else
		*w = Safe;
#endif
		}
		else
		{
			*w = new int[n];
			for(i = 0;i < n;++i)
				(*w)[i] = 0;
		}

		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY | VT_BYREF))
	{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(i < n)
			{
				if(i == 0)
				{
					*w = new int[n];
					for(i = 0;i < n;++i)
					{
						(*w)[i] = 0;
					}
					return S_OK;
				}
				else
				{
					sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
					::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
					return S_FALSE;
				}
			}
			n = i;
			SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			*w = new int[n];
			for(i = 0;i < n;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				(*w)[i] = Safe[i].lVal;
			}
			SafeArrayUnaccessData(*(v.pparray));
			ccc.Clear();
		}
		else
		{
			*w = new int[n];
			for(i = 0;i < n;++i)
			{
				(*w)[i] = 0;
			}
		}
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY ) )
	{
		VARIANT HUGEP* Safe;
		i = v.parray->rgsabound[0].cElements /*- v.parray->rgsabound[0].lLbound*/;
		if(i < n)
		{
			sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
		*w = new int[n];
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_I4);
			Safe[i] = ccc.Detach();
			(*w)[i] = Safe[i].lVal;
		}
		SafeArrayUnaccessData(v.parray);
		ccc.Clear();
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_BYREF))
	{
		::MessageBox(NULL,"Don't do Dim x as Variant follwed by ReDim x(n)!!!",name,MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
	else if(v.vt == (VT_I4 | VT_ARRAY))
	{
		int HUGEP* Safe;
		i = (*(v.parray)).rgsabound[0].cElements /*- (*(v.parray)).rgsabound[0].lLbound*/;
		if(i < n)
		{
			sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new int[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (int) Safe[i];
		SafeArrayUnaccessData(v.parray);
#else
		*w = Safe;
#endif
		return S_OK;
	}
	else if(v.vt == 0 && n)
	{
		*w = new int[n];
		for(i = 0;i < n;++i)
		{
			(*w)[i] = 0;
		}
		return S_OK;
	}
	else if(v.vt==VT_EMPTY)
	{
		*w=0;
		return S_OK;
	}
	else
	{
		sprintf(mess,"%s is not long",name);
		::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
}
inline HRESULT	__stdcall	Variant2Vector(int n,VARIANT v,char ***w,TCHAR* name)
{
	int i;
	TCHAR mess[300];
	_variant_t ccc;
	_bstr_t bstring;

//	_ASSERT(0);
	if(v.vt == (VT_BSTR | VT_ARRAY | VT_BYREF))
	{
		if(v.pparray && *(v.pparray))
		{
			BSTR HUGEP* Safe;
			i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(i < n)
			{
				if(i == 0)
				{
					*w = new char*[n];
					for(i = 0;i < n;++i)
					{
						(*w)[i] = new char[100];
					}
					return S_OK;
				}
				else
				{
					sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
					::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
					return S_FALSE;
				}
			}
			n = i;
			SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
#if defined(USE_BSTR)
			*w = new char*[n];
			for(i = 0;i < n;++i)
			{
				bstring = Safe[i];
				(*w)[i] = strdup((char*)bstring);
			}
			SafeArrayUnaccessData(*(v.pparray));
//			ccc.Clear();
#else
			*w = *(char***)&Safe;
#endif
		}
		else
		{
			*w = new char*[n];
			for(i = 0;i < n;++i)
				(*w)[i] = new char[100];
		}
		
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY | VT_BYREF))
	{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(i < n)
			{
				if(i == 0)
				{
					*w = new char*[n];
					for(i = 0;i < n;++i)
					{
						(*w)[i] = new char[100];
					}
					return S_OK;
				}
				else
				{
					sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
					::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
					return S_FALSE;
				}
			}
			n = i;
			SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			*w = new char*[n];
			for(i = 0;i < n;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_BSTR);
				Safe[i] = ccc.Detach();
			bstring = Safe[i];
			(*w)[i] = strdup((char*)bstring);
			}
			SafeArrayUnaccessData(*(v.pparray));
			ccc.Clear();
		}
		else
		{
			*w = new char*[n];
			for(i = 0;i < n;++i)
			{
				(*w)[i] = new char[100];
			}
		}
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY ) )
	{
		VARIANT HUGEP* Safe;
		i = v.parray->rgsabound[0].cElements /*- v.parray->rgsabound[0].lLbound*/;
		if(i < n)
		{
			sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
		*w = new char*[n];
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_BSTR);
			Safe[i] = ccc.Detach();
			bstring = Safe[i];
			(*w)[i] = strdup((char*)bstring);
		}
		SafeArrayUnaccessData(v.parray);
		ccc.Clear();
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_BYREF))
	{
		::MessageBox(NULL,"Don't do Dim x as Variant follwed by ReDim x(n)!!!",name,MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
	else if(v.vt == (VT_BSTR | VT_ARRAY))
	{
		BSTR HUGEP* Safe;
		i = (*(v.parray)).rgsabound[0].cElements /*- (*(v.parray)).rgsabound[0].lLbound*/;
		if(i < n)
		{
			sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
#if defined(USE_BSTR)
		*w = new char*[n];
		for(i = 0;i < n;++i)
		{
			bstring=Safe[i];
			(*w)[i] = strdup((char*)bstring);
		}
		SafeArrayUnaccessData(v.parray);
#else
		*w = Safe;
#endif
		return S_OK;
	}
	else if(v.vt == 0 && n)
	{
		*w = new char*[n];
		for(i = 0;i < n;++i)
		{
			(*w)[i] = new char[100];
		}
		return S_OK;
	}
	else if(v.vt==VT_EMPTY)
	{
		*w=0;
		return S_OK;
	}
	else
	{
		sprintf(mess,"%s is not long",name);
		::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
}
inline HRESULT	__stdcall	Variant2Vector(int n,VARIANT v,dimen **w,TCHAR* name)
{
	int i;
	TCHAR mess[300];
	_variant_t ccc;

//	_ASSERT(0);
	if(v.vt == (VT_I4 | VT_ARRAY | VT_BYREF))
	{
		if(v.pparray && *(v.pparray))
		{
		dimen HUGEP* Safe;
		i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
		if(i < n)
		{
			if(i == 0)
			{
				*w = new dimen[n];
				for(i = 0;i < n;++i)
				{
					(*w)[i] = 0;
				}
				return S_OK;
			}
			else
			{
				sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
				::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
				return S_FALSE;
			}
		}
		n = i;
		SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new dimen[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (dimen) Safe[i];
		SafeArrayUnaccessData(*(v.pparray));
#else
		*w = Safe;
#endif
		}
		else
		{
			if(n)
			{
				*w = new dimen[n];
				for(i = 0;i < n;++i)
					(*w)[i] = 0;
			}
			else
				*w=0;
		}

		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY | VT_BYREF))
	{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(i < n)
			{
				if(i == 0)
				{
					*w = new dimen[n];
					for(i = 0;i < n;++i)
					{
						(*w)[i] = 0;
					}
					return S_OK;
				}
				else
				{
					sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
					::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
					return S_FALSE;
				}
			}
			n = i;
			SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			*w = new dimen[n];
			for(i = 0;i < n;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				(*w)[i] = Safe[i].lVal;
			}
			SafeArrayUnaccessData(*(v.pparray));
			ccc.Clear();
		}
		else
		{
			if(n)
			{
				*w = new dimen[n];
				for(i = 0;i < n;++i)
				{
					(*w)[i] = 0;
				}
			}
			else
				*w=0;
		}
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY ) )
	{
		VARIANT HUGEP* Safe;
		i = v.parray?v.parray->rgsabound[0].cElements:0 /*- v.parray->rgsabound[0].lLbound*/;
		if(i < n && i!=0)
		{
			sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		if(n)
		{
			SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
			*w = new dimen[n];
		}
		else
			*w=0;
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_I4);
			Safe[i] = ccc.Detach();
			(*w)[i] = Safe[i].lVal;
		}
		if(n)
			SafeArrayUnaccessData(v.parray);
		ccc.Clear();
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_BYREF))
	{
		::MessageBox(NULL,"Don't do Dim x as Variant follwed by ReDim x(n)!!!",name,MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
	else if(v.vt == (VT_I4 | VT_ARRAY))
	{
		dimen HUGEP* Safe;
		i = v.parray?(*(v.parray)).rgsabound[0].cElements:0 /*- (*(v.parray)).rgsabound[0].lLbound*/;
		if(i < n)
		{
			sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		if(n)
			SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new dimen[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (dimen) Safe[i];
		SafeArrayUnaccessData(v.parray);
#else
		*w = n?Safe:0;
#endif
		return S_OK;
	}
	else if(v.vt == 0 && n)
	{
		*w = new dimen[n];
		for(i = 0;i < n;++i)
		{
			(*w)[i] = 0;
		}
		return S_OK;
	}
	else if(v.vt==VT_EMPTY)
	{
		*w=0;
		return S_OK;
	}
	else
	{
		sprintf(mess,"%s is not long",name);
		::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
}
inline HRESULT	__stdcall	Variant2Vector(int n,VARIANT v,size_t **w,TCHAR* name)
{
	int i;
	TCHAR mess[300];
	_variant_t ccc;

//	_ASSERT(0);
	if(v.vt == (VT_I4 | VT_ARRAY | VT_BYREF))
	{
		if(v.pparray && *(v.pparray))
		{
		size_t HUGEP* Safe;
		i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
		if(i < n)
		{
			if(i == 0)
			{
				*w = new size_t[n];
				for(i = 0;i < n;++i)
				{
					(*w)[i] = 0;
				}
				return S_OK;
			}
			else
			{
				sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
				::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
				return S_FALSE;
			}
		}
		n = i;
		SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new size_t[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (size_t) Safe[i];
		SafeArrayUnaccessData(*(v.pparray));
#else
		*w = Safe;
#endif
		}
		else
		{
			if(n)
			{
				*w = new size_t[n];
				for(i = 0;i < n;++i)
					(*w)[i] = 0;
			}
			else
				*w=0;
		}

		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY | VT_BYREF))
	{
		VARIANT HUGEP* Safe;
		if(v.pparray && *(v.pparray))
		{
			i = (*(v.pparray))->rgsabound[0].cElements /*- (*(v.pparray))->rgsabound[0].lLbound*/;
			if(i < n)
			{
				if(i == 0)
				{
					*w = new size_t[n];
					for(i = 0;i < n;++i)
					{
						(*w)[i] = 0;
					}
					return S_OK;
				}
				else
				{
					sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
					::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
					return S_FALSE;
				}
			}
			n = i;
			SafeArrayAccessData(*(v.pparray),(void HUGEP* FAR*) &Safe);
			*w = new size_t[n];
			for(i = 0;i < n;++i)
			{
				ccc.Attach(Safe[i]);
				ccc.ChangeType(VT_I4);
				Safe[i] = ccc.Detach();
				(*w)[i] = Safe[i].lVal;
			}
			SafeArrayUnaccessData(*(v.pparray));
			ccc.Clear();
		}
		else
		{
			if(n)
			{
				*w = new size_t[n];
				for(i = 0;i < n;++i)
				{
					(*w)[i] = 0;
				}
			}
			else
				*w=0;
		}
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_ARRAY ) )
	{
		VARIANT HUGEP* Safe;
		i = v.parray?v.parray->rgsabound[0].cElements:0 /*- v.parray->rgsabound[0].lLbound*/;
		if(i < n && i!=0)
		{
			sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		if(n)
		{
			SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
			*w = new size_t[n];
		}
		else
			*w=0;
		for(i = 0;i < n;++i)
		{
			ccc.Attach(Safe[i]);
			ccc.ChangeType(VT_I4);
			Safe[i] = ccc.Detach();
			(*w)[i] = Safe[i].lVal;
		}
		if(n)
			SafeArrayUnaccessData(v.parray);
		ccc.Clear();
		return S_OK;
	}
	else if(v.vt == (VT_VARIANT | VT_BYREF))
	{
		::MessageBox(NULL,"Don't do Dim x as Variant follwed by ReDim x(n)!!!",name,MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
	else if(v.vt == (VT_I4 | VT_ARRAY))
	{
		size_t HUGEP* Safe;
		i = v.parray?(*(v.parray)).rgsabound[0].cElements:0 /*- (*(v.parray)).rgsabound[0].lLbound*/;
		if(i < n)
		{
			sprintf(mess,"int array %s has only %d elements, %d were expected",name,i,n);
			::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
			return S_FALSE;
		}
		n = i;
		if(n)
			SafeArrayAccessData(v.parray,(void HUGEP* FAR*) &Safe);
#ifdef	CREATE_AND_COPY
		*w = new size_t[n];
		for(i = 0;i < n;++i)
			(*w)[i] = (size_t) Safe[i];
		SafeArrayUnaccessData(v.parray);
#else
		*w = n?Safe:0;
#endif
		return S_OK;
	}
	else if(v.vt == 0 && n)
	{
		*w = new size_t[n];
		for(i = 0;i < n;++i)
		{
			(*w)[i] = 0;
		}
		return S_OK;
	}
	else if(v.vt==VT_EMPTY)
	{
		*w=0;
		return S_OK;
	}
	else
	{
		sprintf(mess,"%s is not long",name);
		::MessageBox(NULL,mess,"Data Access",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
}
inline void Namelistget(size_t n,int& nsize,const VARIANT Nnames,char** &names)
{
/* 
	We allow the COM user to specify the list of stock names either as an array
	or as a single string with the names separated by commas.
	Which was used is decided here.
*/
	nsize=-1;
	if(Nnames.vt == VT_VARIANT||Nnames.vt == VT_BSTR||
		Nnames.vt == (VT_BYREF|VT_VARIANT)||Nnames.vt == (VT_BYREF|VT_BSTR))
	{
		//Must be a single string
		BSTR Names;
		_bstr_t bstring;
		bstring = Nnames;
		Names=bstring.copy();
		names= new char*[n];
		long_to_array(Names,names,n);
	}
	else
	{
		//Must be an array
		nsize=NUMBER_OF_ELEMENTS_FOR1D(Nnames);
		if(nsize)Variant2Vector(n,Nnames,&names,"namelist processing");
		else names=0;
	}

}
/*STDMETHODIMP COptimiser::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IOptimiser,
	};

	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}*/

extern "C" char* version(char*a);

HRESULT __stdcall COptimiser::Version(BSTR* retval)
{
	char vv[500];
	char* ivv=vv;
	version(ivv);
	_bstr_t a=ivv;
	*retval = a.copy();
	return S_OK;
}
extern "C" void	factor_model_process(dimen n,dimen nfac,vector FL,vector FC,
									 vector SV,vector Q);
HRESULT __stdcall COptimiser::FactorModelProcess(int n,int nfac,VARIANT FL,VARIANT FC,VARIANT SV,VARIANT *Q)
{
	HRESULT hh;
	size_t n1 = nfac * (nfac + 1) / 2,n2 = n * nfac;
// ========================================
	vector cFL;
	hh = Variant2Vector(n2,FL,&cFL,"FL:FactorModelProcess");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cFC;
	hh = Variant2Vector(n1,FC,&cFC,"FC:FactorModelProcess");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cSV;
	hh = Variant2Vector(n,SV,&cSV,"SV:FactorModelProcess");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	hh = Variant2Vector(n2+n,*Q,&cQ,"Q:FactorModelProcess");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	factor_model_process(n,nfac,cFL,cFC,cSV,cQ);
// ========================================
	SafeArrayRelease(FL,cFL,n2);
	SafeArrayRelease(FC,cFC,n1);
	SafeArrayRelease(SV,cSV,n);
	SafeArrayRelease(*Q,cQ,n2+n);
// ========================================
	return S_OK;
}
extern "C" short Optimise_internalCVP(dimen n,long nfac,char** names,vector w_opt,dimen m,vector A,vector L,vector U,vector alpha,vector benchmark,vector Q,double gamma,vector initial,double delta,vector buy,vector sell,double kappa,long basket,long trades,int revise,int costs,double min_holding,double min_trade,int m_LS,int Fully_Invested,double Rmin,double Rmax,int m_Round,vector min_lot,vector size_lot,int* shake,dimen ncomp,vector Composites,double LSValue,dimen npiece,vector hpiece,vector pgrad);
HRESULT __stdcall COptimiser::OptimiseInternalCVP(int n,int nfac,VARIANT Names,VARIANT *w_opt,int m,VARIANT A,VARIANT L,VARIANT U,VARIANT alpha,VARIANT benchmark,VARIANT Q,double gamma,VARIANT initial,double delta,VARIANT buy,VARIANT sell,double kappa,int basket,int trades,int revise,int costs,double min_holding,double min_trade,int m_LS,int Fully_Invested,double Rmin,double Rmax,int m_Round,VARIANT min_lot,VARIANT size_lot,VARIANT *shake,int ncomp,VARIANT Composites,double LSValue,int npiece,VARIANT hpiece,VARIANT pgrad,int* retval)
{
	HRESULT hh;

	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
// ========================================
	vector cw_opt;
	hh = Variant2Vector(n,*w_opt,&cw_opt,"w_opt:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Array2D2Vector(n*m,A,&cA,"A:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbenchmark;
	hh = Variant2Vector(n,benchmark,&cbenchmark,"benchmark:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:OptimiseInternalCVP");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cinitial;
	hh = Variant2Vector(n,initial,&cinitial,"initial:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbuy;
	hh = Variant2Vector(n,buy,&cbuy,"buy:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csell;
	hh = Variant2Vector(n,sell,&csell,"sell:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmin_lot;
	hh = Variant2Vector(n,min_lot,&cmin_lot,"min_lot:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csize_lot;
	hh = Variant2Vector(n,size_lot,&csize_lot,"size_lot:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cComposites;
	hh = Variant2Vector(ncomp*(n-ncomp),Composites,&cComposites,"Composites:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector chpiece;
	hh = Variant2Vector(n*npiece,hpiece,&chpiece,"hpiece:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cpgrad;
	hh = Variant2Vector(n*npiece,pgrad,&cpgrad,"pgrad:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
	int* cshake;
	hh = Variant2Vector(n,*shake,&cshake,"shake:OptimiseInternalCVP");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=Optimise_internalCVP(n,nfac,names,cw_opt,m,cA,cL,cU,calpha,cbenchmark,cQ,gamma,cinitial,delta,cbuy,csell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,m_Round,cmin_lot,csize_lot, cshake,ncomp,cComposites,LSValue,npiece,chpiece,cpgrad);
// ========================================
	SafeArrayRelease(*w_opt,cw_opt,n);
	SafeArray2DRelease(A,cA);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(benchmark,cbenchmark,n);
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(initial,cinitial,n);
	SafeArrayRelease(buy,cbuy,n);
	SafeArrayRelease(sell,csell,n);
	SafeArrayRelease(min_lot,cmin_lot,n);
	SafeArrayRelease(size_lot,csize_lot,n);
	SafeArrayRelease(Composites,cComposites,ncomp*(n-ncomp));
	SafeArrayRelease(hpiece,chpiece,n*npiece);
	SafeArrayRelease(pgrad,cpgrad,n*npiece);
	SafeArrayRelease(*shake,cshake,n);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
extern "C" void GetBeta(dimen n,long nfac,vector benchmark,vector Q,vector beta,dimen ncomp,vector Composite);
HRESULT __stdcall COptimiser::GetBetaVector(int n,long nfac,VARIANT benchmark,VARIANT Q,VARIANT *beta,int ncomp,VARIANT Composite)
{
	HRESULT hh;
// ========================================
	vector cbenchmark;
	hh = Variant2Vector(n,benchmark,&cbenchmark,"benchmark:GetBeta");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:GetBeta");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:GetBeta");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbeta;
	hh = Variant2Vector(n,*beta,&cbeta,"beta:GetBeta");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cComposite;
	hh = Variant2Vector((n-ncomp)*ncomp,Composite,&cComposite,"Composite:GetBeta");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	GetBeta(n,nfac,cbenchmark,cQ,cbeta,ncomp,cComposite);
// ========================================
	SafeArrayRelease(benchmark,cbenchmark,n);
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(*beta,cbeta,n);
	SafeArrayRelease(Composite,cComposite,(n-ncomp)*ncomp);
// ========================================
	return S_OK;
}


//typedef real (*pUtility) (dimen nvab,vector x,void* info);
typedef real  (__stdcall *COMutility)(int nvab,VARIANT x);
static double CallUtil(dimen n,vector x,void* func)
{
	//We have to copy the contents of x into a 1D VARIANT array.
	VARIANT v;
	_variant_t ccc;

	//Set bounds for the VARIANT
	SAFEARRAY FAR *pArray;
	SAFEARRAYBOUND bound[1];
	VARIANT HUGEP* Safe;

	bound[0].cElements = n;
	bound[0].lLbound = 0;

	//Create the space
	pArray = SafeArrayCreate(VT_VARIANT,1,bound);
	v.vt = VT_VARIANT |  VT_ARRAY;
	v.parray = pArray;


	//Copy the double array data

	HRESULT hh = SafeArrayAccessData(pArray,(void HUGEP* FAR*) &Safe);
	size_t i;
	for(i = 0;i < n;++i)
	{
		ccc.Attach(Safe[i]);
		ccc.ChangeType(VT_R8);
		Safe[i] = ccc.Detach();
		Safe[i].dblVal = ((double HUGEP*)x)[i];
	}

	ccc.Clear();

	//Now call the callback function defined somewhere over the COM interface
	double util = ((COMutility)func)((int)n,v);

	hh = SafeArrayUnaccessData(pArray);
	//hh = SafeArrayDestroy(pArray);


	return util;
}

extern "C" void simplex(dimen n,vector start,vector xmin,vector ynewlo,double reqmin,vector step,dimen konvge,dimen kcount,dimen *icount,dimen *numres,dimen *ifault,pUtility fn,void* info);
HRESULT __stdcall COptimiser::SimpOpt(int n,VARIANT start,VARIANT *xmin,VARIANT *ynewlo,double reqmin,VARIANT step,int konvge,int kcount,VARIANT *icount,VARIANT *numres,VARIANT *ifault,int function)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	pUtility fn=(pUtility)CallUtil;
	
	HRESULT hh;
// ========================================
	vector cstart;
	hh = Variant2Vector(n,start,&cstart,"start:simplex");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cxmin;
	hh = Variant2Vector(n,*xmin,&cxmin,"xmin:simplex");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cynewlo;
	hh = Variant2Vector(1,*ynewlo,&cynewlo,"ynewlo:simplex");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cstep;
	hh = Variant2Vector(n,step,&cstep,"step:simplex");
	if(hh == S_FALSE)
		return S_FALSE;
	dimen* cicount;
	hh = Variant2Vector(1,*icount,&cicount,"icount:simplex");
	if(hh == S_FALSE)
		return S_FALSE;
	dimen* cnumres;
	hh = Variant2Vector(1,*numres,&cnumres,"numres:simplex");
	if(hh == S_FALSE)
		return S_FALSE;
	dimen* cifault;
	hh = Variant2Vector(1,*ifault,&cifault,"ifault:simplex");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	simplex(n,cstart,cxmin,cynewlo,reqmin,cstep,konvge,kcount,cicount,cnumres,cifault,fn, (void*)function);
// ========================================
	SafeArrayRelease(start,cstart,n);
	SafeArrayRelease(*xmin,cxmin,n);
	SafeArrayRelease(*ynewlo,cynewlo,1);
	SafeArrayRelease(step,cstep,n);
	SafeArrayRelease(*icount,cicount,1);
	SafeArrayRelease(*numres,cnumres,1);
	SafeArrayRelease(*ifault,cifault,1);
// ========================================
//	fptr.Detach();
//	fptr.Clear();
	return S_OK;
}
extern "C" extern	void	NaiveRound(size_t n,vector w,vector initial,vector minlot,vector sizelot,vector roundw);
HRESULT __stdcall COptimiser::NaiveRounding(int n,VARIANT w,VARIANT initial,VARIANT minlot,VARIANT sizelot,VARIANT *roundw)
{
	HRESULT hh;
// ========================================
	vector cw;
	hh = Variant2Vector(n,w,&cw,"w:NaiveRounding");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cinitial;
	hh = Variant2Vector(n,initial,&cinitial,"initial:NaiveRounding");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cminlot;
	hh = Variant2Vector(n,minlot,&cminlot,"minlot:NaiveRounding");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csizelot;
	hh = Variant2Vector(n,sizelot,&csizelot,"sizelot:NaiveRounding");
	if(hh == S_FALSE)
		return S_FALSE;
	vector croundw;
	hh = Variant2Vector(n,*roundw,&croundw,"roundw:NaiveRounding");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	NaiveRound(n,cw,cinitial,cminlot,csizelot,croundw);
// ========================================
	SafeArrayRelease(w,cw,n);
	SafeArrayRelease(initial,cinitial,n);
	SafeArrayRelease(minlot,cminlot,n);
	SafeArrayRelease(sizelot,csizelot,n);
	SafeArrayRelease(*roundw,croundw,n);
// ========================================
	return S_OK;
}
//typedef	double	(*p1DFunc)(double kappa,void* info);
typedef double  (__stdcall *COM1DFunc)(double kappa);
static double COMRiskE(double x,void* info)
{
	return ((COM1DFunc) info)(x);
}
extern "C" double	Solve1D(p1DFunc RiskE,double gammabot,double gammatop,double tol,void* info);
HRESULT __stdcall COptimiser::Solve1DFunction(int function,double gammabot,double gammatop,double tol,double *retval)
{
	p1DFunc RiskE=(p1DFunc) COMRiskE;
// ========================================
// ========================================
	*retval=	Solve1D(RiskE,gammabot,gammatop,tol, (void*)function);
// ========================================
// ========================================
	return S_OK;
}
extern "C" double	PathMin(p1DFunc RiskE,double gammabot,double gammatop,double tol,void* info,int stopifpos);
HRESULT __stdcall COptimiser::PathMinimise(int function,double gammabot,double gammatop,double tol,int stopifpos,double *retval)
{
	p1DFunc RiskE=(p1DFunc) COMRiskE;
// ========================================
// ========================================
	*retval=	PathMin(RiskE,gammabot,gammatop,tol, (void*)function,stopifpos);
// ========================================
// ========================================
	return S_OK;
}
extern "C" void Extract_Factor_Information(dimen nstocks,dimen numfac,dimen Mnstocks,vector FL,vector SV,char** stocklist,vector MFL,vector MSV,char** Mstocklist);
HRESULT __stdcall COptimiser::ExtractFactorInformation(int nstocks,int numfac,int Mnstocks,VARIANT *FL,VARIANT *SV,VARIANT stocklist,VARIANT MFL,VARIANT MSV,VARIANT Mstocklist)
{
	HRESULT hh;
	int nsize=-1;
	char** stocks= new char*[nstocks];	

	Namelistget(nstocks,nsize,stocklist,stocks);
//	long_to_array(stocklist,stocks,nstocks);
	char** Mstocks= new char*[Mnstocks];
	Namelistget(Mnstocks,nsize,Mstocklist,Mstocks);
//	long_to_array(Mstocklist,Mstocks,Mnstocks);
// ========================================
	vector cFL;
	hh = Variant2Vector(numfac*nstocks,*FL,&cFL,"FL:Extract_Factor_Information");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cSV;
	hh = Variant2Vector(nstocks,*SV,&cSV,"SV:Extract_Factor_Information");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cMFL;
	hh = Variant2Vector(numfac*Mnstocks,MFL,&cMFL,"MFL:Extract_Factor_Information");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cMSV;
	hh = Variant2Vector(Mnstocks,MSV,&cMSV,"MSV:Extract_Factor_Information");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	Extract_Factor_Information(nstocks,numfac,Mnstocks,cFL,cSV,stocks,cMFL,cMSV,Mstocks);
// ========================================
	SafeArrayRelease(*FL,cFL,numfac*nstocks);
	SafeArrayRelease(*SV,cSV,nstocks);
	SafeArrayRelease(MFL,cMFL,numfac*Mnstocks);
	SafeArrayRelease(MSV,cMSV,Mnstocks);
// ========================================
//	DeleteNames(stocks,nstocks);
//	DeleteNames(Mstocks,Mnstocks);
	if(nsize==-1)
		DeleteNames(stocks,nstocks);
	else
		DeleteNamess(stocks,nstocks);
	if(nsize==-1)
		DeleteNames(Mstocks,Mnstocks);
	else
		DeleteNamess(Mstocks,Mnstocks);

	return S_OK;
}
extern "C" char* expire_date(char*a);
HRESULT __stdcall COptimiser::ExpireDate(BSTR* retval)
{
	char vv[500];
	char* ivv=vv;
	expire_date(ivv);
	_bstr_t a=ivv;
	*retval = a.copy();
	return S_OK;
}
extern "C" int days_left(char**a);
HRESULT __stdcall COptimiser::DaysLeft(BSTR* cvers,int* retval)
{
	char vv[500];
	char* ivv=vv;
	*retval=days_left(&ivv);
	_bstr_t a=ivv;
	*cvers = a.copy();
	return S_OK;
}
extern "C" int	fix_covariancem(dimen n,vector Q);
HRESULT __stdcall COptimiser::FixCovariancem(int n,VARIANT *Q,int *retval)
{
	HRESULT hh;
	size_t NNN=n*(n+1)/2;
// ========================================
	vector cQ;
	hh = Variant2Vector(NNN,*Q,&cQ,"Q:FixCovariancem");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=fix_covariancem(n,cQ);
// ========================================
	SafeArrayRelease(*Q,cQ,NNN);
// ========================================
	return S_OK;
}
extern "C" short InvQ_d(dimen n,vector Q,vector d,vector Qm1d);
HRESULT __stdcall COptimiser::InverseQtimesD(int n,VARIANT Q,VARIANT d,
											VARIANT *Qm1d,int *retval)
{
	HRESULT hh;
// ========================================
	vector cQ;
	hh = Variant2Vector(n*(n+1)/2,Q,&cQ,"Q:InverseQtimesD");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cd;
	hh = Variant2Vector(n,d,&cd,"d:InverseQtimesD");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQm1d;
	hh = Variant2Vector(n,*Qm1d,&cQm1d,"Qm1d:InverseQtimesD");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=(int)InvQ_d(n,cQ,cd,cQm1d);
// ========================================
	SafeArrayRelease(Q,cQ,n*(n+1)/2);
	SafeArrayRelease(d,cd,n);
	SafeArrayRelease(*Qm1d,cQm1d,n);
// ========================================
	return S_OK;
}
extern "C" short ConstrRegress(dimen n,dimen m,vector Q,vector c,vector w,vector L,
							   vector U,vector A);
HRESULT __stdcall COptimiser::ConstrainedRegression(int n,int m,VARIANT Q,VARIANT c,
												   VARIANT *w,VARIANT L,VARIANT U,
												   VARIANT A,int *retval)
{
// ========================================
	vector cQ;
	HRESULT hh = Variant2Vector(n*(n+1)/2,Q,&cQ,"Q:ConstrainedRegression");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cc;
	hh = Variant2Vector(n,c,&cc,"c:ConstrainedRegression");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cw;
	hh = Variant2Vector(n,*w,&cw,"w:ConstrainedRegression");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:ConstrainedRegression");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:ConstrainedRegression");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Array2D2Vector(IS_VARIANT_NOT_NULL(A)?n*m:0,A,&cA,"A:ConstrainedRegression");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=(int)ConstrRegress(n,m,cQ,cc,cw,cL,cU,cA);
// ========================================
	SafeArrayRelease(Q,cQ,n*(n+1)/2);
	SafeArrayRelease(c,cc,n);
	SafeArrayRelease(*w,cw,n);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	SafeArray2DRelease(A,cA);

// ========================================
	return S_OK;
}
extern "C" int	pickout(dimen nstocks,char **stocklist,dimen M_nstocks,char** M_stocklist,
						vector Q,size_t* Order);
HRESULT __stdcall COptimiser::PickoutCovFromCov(int nstocks,BSTR stocklist,int Mnstocks,
											   BSTR M_stocklist,VARIANT *Q,int *retval)
{
	HRESULT hh;
	size_t NNN=Mnstocks*(Mnstocks+1)/2;
	char** stocks= new char*[nstocks];
	long_to_array(stocklist,stocks,nstocks);
	char** Mstocks= new char*[Mnstocks];
	long_to_array(M_stocklist,Mstocks,Mnstocks);
// ========================================
	vector cQ;
	hh = Variant2Vector(NNN,*Q,&cQ,"Q:PickoutCovFromCov");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=pickout(nstocks,stocks,Mnstocks,Mstocks,cQ,0);
// ========================================
	SafeArrayRelease(*Q,cQ,NNN);
// ========================================
	DeleteNames(stocks,nstocks);
	DeleteNames(Mstocks,Mnstocks);
	return S_OK;
}
extern "C"  char*	Return_Message(int ifail);
HRESULT __stdcall COptimiser::ReturnMessage(int ifail,BSTR* retval)
{
	_bstr_t a;
	if (ifail == -1)
	{
		a=(char*)"Optimiser is not licensed";
	}
	else
	{
		a=Return_Message(ifail);
	}
	*retval = a.copy();
	return S_OK;
}
extern "C" void Get_RisksC(dimen n,long nfac,vector Q,vector w,vector benchmark,
						   vector arisk,vector risk,vector Rrisk,vector brisk,vector pbeta,
						   dimen ncomp,vector Composite);
HRESULT __stdcall COptimiser::GetRisks(int n,int nfac,VARIANT Q,VARIANT w,VARIANT benchmark,
									  VARIANT *arisk,VARIANT *risk,VARIANT *Rrisk,VARIANT *brisk,
									  VARIANT *pbeta,int ncomp,VARIANT Composite)
{
	HRESULT hh;
// ========================================
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:GetRisks");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cw;
	hh = Variant2Vector(n,w,&cw,"w:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbenchmark;
	hh = Variant2Vector(n,benchmark,&cbenchmark,"benchmark:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
	vector carisk;
	hh = Variant2Vector(1,*arisk,&carisk,"arisk:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
	vector crisk;
	hh = Variant2Vector(1,*risk,&crisk,"risk:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cRrisk;
	hh = Variant2Vector(1,*Rrisk,&cRrisk,"Rrisk:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbrisk;
	hh = Variant2Vector(1,*brisk,&cbrisk,"brisk:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cpbeta;
	hh = Variant2Vector(1,*pbeta,&cpbeta,"pbeta:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cComposite;
	hh = Variant2Vector((n-ncomp)*ncomp,Composite,&cComposite,"Composite:GetRisks");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	Get_RisksC(n,nfac,cQ,cw,cbenchmark,carisk,crisk,cRrisk,cbrisk,cpbeta,ncomp,cComposite);
// ========================================
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(w,cw,n);
	SafeArrayRelease(benchmark,cbenchmark,n);
	SafeArrayRelease(*arisk,carisk,1);
	SafeArrayRelease(*risk,crisk,1);
	SafeArrayRelease(*Rrisk,cRrisk,1);
	SafeArrayRelease(*brisk,cbrisk,1);
	SafeArrayRelease(*pbeta,cpbeta,1);
	SafeArrayRelease(Composite,cComposite,(n-ncomp)*ncomp);
// ========================================
	return S_OK;
}
extern "C" void 	MarginalUtility(dimen n,long nfac,char** names,vector w,vector benchmark,
									vector initial,vector Q,real gamma,real kappa,
									dimen npiece,vector hpiece,vector pgrad,vector buy,
									vector sell,vector alpha,vector tcost,vector utility,
									vector gradutility,vector utility_per_stock,
									vector cost_per_stock,dimen ncomp,vector Composite);
HRESULT __stdcall COptimiser::MarginalUtilityandCost(int n,int nfac,VARIANT Names,VARIANT w,
											 VARIANT benchmark,VARIANT initial,
											 VARIANT Q,double gamma,double kappa,int npiece,
											 VARIANT hpiece,VARIANT pgrad,VARIANT buy,
											 VARIANT sell,VARIANT alpha,VARIANT *tcost,
											 VARIANT *utility,VARIANT *gradutility,
											 VARIANT *utility_per_stock,
											 VARIANT *cost_per_stock,int ncomp,
											 VARIANT Composite)
{
	HRESULT hh;
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
// ========================================
	vector cw;
	hh = Variant2Vector(n,w,&cw,"w:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbenchmark;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(benchmark)?n:0,benchmark,&cbenchmark,"benchmark:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cinitial;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(initial)?n:0,initial,&cinitial,"initial:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:MarginalUtility");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector chpiece;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(hpiece)?n*npiece:0,hpiece,&chpiece,"hpiece:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cpgrad;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(pgrad)?n*npiece:0,pgrad,&cpgrad,"pgrad:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbuy;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(buy)?n:0,buy,&cbuy,"buy:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csell;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(sell)?n:0,sell,&csell,"sell:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector ctcost;
	hh = Variant2Vector(1,*tcost,&ctcost,"tcost:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cutility;
	hh = Variant2Vector(1,*utility,&cutility,"utility:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cgradutility;
	hh = Variant2Vector(n,*gradutility,&cgradutility,"gradutility:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cutility_per_stock;
	hh = Variant2Vector(n,*utility_per_stock,&cutility_per_stock,"utility_per_stock:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector ccost_per_stock;
	hh = Variant2Vector(n,*cost_per_stock,&ccost_per_stock,"cost_per_stock:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cComposite;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(Composite)?(n-ncomp)*ncomp:0,Composite,&cComposite,"Composite:MarginalUtility");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	MarginalUtility(n,nfac,names,cw,cbenchmark,cinitial,cQ,gamma,kappa,npiece,chpiece,cpgrad,cbuy,csell,calpha,ctcost,cutility,cgradutility,cutility_per_stock,ccost_per_stock,ncomp,cComposite);
// ========================================
	SafeArrayRelease(w,cw,n);
	SafeArrayRelease(benchmark,cbenchmark,n);
	SafeArrayRelease(initial,cinitial,n);
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(hpiece,chpiece,npiece*n);
	SafeArrayRelease(pgrad,cpgrad,npiece*n);
	SafeArrayRelease(buy,cbuy,n);
	SafeArrayRelease(sell,csell,n);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(*tcost,ctcost,1);
	SafeArrayRelease(*utility,cutility,1);
	SafeArrayRelease(*gradutility,cgradutility,n);
	SafeArrayRelease(*utility_per_stock,cutility_per_stock,n);
	SafeArrayRelease(*cost_per_stock,ccost_per_stock,n);
	SafeArrayRelease(Composite,cComposite,(n-ncomp)*n);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
extern "C" short  Optimise_internalCVPA(dimen n,long nfac,char** names,vector w,dimen m,
										vector A,vector L,vector U,vector alpha,
										vector benchmark,vector Q,double gamma,vector initial,
										double delta,vector buy,vector sell,double kappa,
										long basket,long trades,int revise,int costs,
										double min_holding,double min_trade,int m_LS,
										int Fully_Invested,double Rmin,double Rmax,
										int m_Round,vector min_lot,vector size_lot,
										int* shake,dimen ncomp,vector Composite,
										double LSValue,dimen npiece,vector hpiece,
										vector pgrad,dimen nabs,vector Abs_A,dimen mabs,
										dimen* I_A,vector Abs_U,vector mask,int log,
										char* logfile);
HRESULT __stdcall COptimiser::OptimiseInternalCVPA(int n,int nfac,VARIANT Names,VARIANT *w,int m,
												  VARIANT A,VARIANT L,VARIANT U,VARIANT alpha,
												  VARIANT benchmark,VARIANT Q,double gamma,
												  VARIANT initial,double delta,VARIANT buy,
												  VARIANT sell,double kappa,int basket,
												  int trades,int revise,int costs,
												  double min_holding,double min_trade,
												  int m_LS,int Fully_Invested,double Rmin,
												  double Rmax,int m_Round,VARIANT min_lot,
												  VARIANT size_lot,VARIANT *shake,int ncomp,
												  VARIANT Composite,double LSValue,int npiece,
												  VARIANT hpiece,VARIANT pgrad,int nabs,
												  VARIANT Abs_A,int mabs,VARIANT I_A,
												  VARIANT Abs_U,VARIANT mask,int log,
												  BSTR Logfile,int *retval)
{
	HRESULT hh;
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
	_bstr_t a=Logfile;
	char* logfile=(char*)a;
// ========================================
	vector cw;
	hh = Variant2Vector(n,*w,&cw,"w:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Array2D2Vector(n*m,A,&cA,"A:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbenchmark;
	hh = Variant2Vector(n,benchmark,&cbenchmark,"benchmark:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:OptimiseInternalCVPA");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cinitial;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(initial)?n:0,initial,&cinitial,"initial:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbuy;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(buy)?n:0,buy,&cbuy,"buy:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csell;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(sell)?n:0,sell,&csell,"sell:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmin_lot;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(min_lot)?n:0,min_lot,&cmin_lot,"min_lot:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csize_lot;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(size_lot)?n:0,size_lot,&csize_lot,"size_lot:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	int* cshake;
	hh = Variant2Vector(n,*shake,&cshake,"shake:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cComposite;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(Composite)?(n-ncomp)*ncomp:0,Composite,&cComposite,"Composite:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector chpiece;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(hpiece)?n*npiece:0,hpiece,&chpiece,"hpiece:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cpgrad;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(pgrad)?n*npiece:0,pgrad,&cpgrad,"pgrad:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cAbs_A;
	hh = Variant2Vector(n*nabs,Abs_A,&cAbs_A,"Abs_A:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	dimen* cI_A;
	hh = Variant2Vector(mabs,I_A,&cI_A,"I_A:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cAbs_U;
	hh = Variant2Vector(nabs+mabs,Abs_U,&cAbs_U,"Abs_U:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmask;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(mask)?n:0,mask,&cmask,"mask:OptimiseInternalCVPA");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=Optimise_internalCVPA(n,nfac,names,cw,m,cA,cL,cU,calpha,cbenchmark,cQ,gamma,cinitial,delta,cbuy,csell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,m_Round,cmin_lot,csize_lot,cshake,ncomp,cComposite,LSValue,npiece,chpiece,cpgrad,nabs,cAbs_A,mabs,cI_A,cAbs_U,cmask,log,logfile);
// ========================================
	SafeArrayRelease(*w,cw,n);
	SafeArray2DRelease(A,cA);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(benchmark,cbenchmark,n);
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(initial,cinitial,n);
	SafeArrayRelease(buy,cbuy,n);
	SafeArrayRelease(sell,csell,n);
	SafeArrayRelease(min_lot,cmin_lot,n);
	SafeArrayRelease(size_lot,csize_lot,n);
	SafeArrayRelease(*shake,cshake,n);
	SafeArrayRelease(Composite,cComposite,(n-ncomp)*ncomp);
	SafeArrayRelease(hpiece,chpiece,n*npiece);
	SafeArrayRelease(pgrad,cpgrad,n*npiece);
	SafeArrayRelease(Abs_A,cAbs_A,n*nabs);
	SafeArrayRelease(I_A,cI_A,mabs);
	SafeArrayRelease(Abs_U,cAbs_U,nabs+mabs);
	SafeArrayRelease(mask,cmask,n);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
extern "C" short  Optimise_internalCVPAF(dimen n,long nfac,char** names,vector w,dimen m,
										 vector A,vector L,vector U,vector alpha,
										 vector benchmark,vector Q,double gamma,
										 vector initial,double delta,vector buy,vector sell,
										 double kappa,long basket,long trades,int revise,
										 int costs,double min_holding,double min_trade,
										 int m_LS,int Fully_Invested,double Rmin,double Rmax,
										 int m_Round,vector min_lot,vector size_lot,
										 int* shake,dimen ncomp,vector Composite,
										 double LSValue,dimen npiece,vector hpiece,
										 vector pgrad,dimen nabs,vector Abs_A,dimen mabs,
										 dimen* I_A,vector Abs_U,vector FC,vector FL,
										 vector SV,double minRisk,double maxRisk,
										 vector ogamma,vector mask,int log,char* logfile,
										 int downrisk,double downfactor);
HRESULT __stdcall COptimiser::OptimiseInternalCVPAF(int n,int nfac,VARIANT Names,VARIANT *w,
												   int m,VARIANT A,VARIANT L,VARIANT U,
												   VARIANT alpha,VARIANT benchmark,
												   VARIANT Q,double gamma,VARIANT initial,
												   double delta,VARIANT buy,VARIANT sell,
												   double kappa,int basket,int trades,
												   int revise,int costs,double min_holding,
												   double min_trade,int m_LS,
												   int Fully_Invested,double Rmin,double Rmax,
												   int m_Round,VARIANT min_lot,
												   VARIANT size_lot,VARIANT *shake,int ncomp,
												   VARIANT Composite,double LSValue,
												   int npiece,VARIANT hpiece,VARIANT pgrad,
												   int nabs,VARIANT Abs_A,int mabs,
												   VARIANT I_A,VARIANT Abs_U,VARIANT FC,
												   VARIANT FL,VARIANT SV,double minRisk,
												   double maxRisk,VARIANT *ogamma,VARIANT mask,
												   int log,BSTR Logfile,int downrisk,
												   double downfactor,int*retval)
{
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);

	_bstr_t a=Logfile;
	char* logfile=(char*)a;
	HRESULT hh;
// ========================================
	vector cw;
	hh = Variant2Vector(n,*w,&cw,"w:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Array2D2Vector(n*m,A,&cA,"A:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbenchmark;
	hh = Variant2Vector(n,benchmark,&cbenchmark,"benchmark:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:OptimiseInternalCVPAF");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cinitial;
	hh = Variant2Vector(n,initial,&cinitial,"initial:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbuy;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(buy)?n:0,buy,&cbuy,"buy:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csell;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(sell)?n:0,sell,&csell,"sell:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmin_lot;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(min_lot)?n:0,min_lot,&cmin_lot,"min_lot:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csize_lot;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(size_lot)?n:0,size_lot,&csize_lot,"size_lot:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	int* cshake;
	hh = Variant2Vector(n,*shake,&cshake,"shake:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cComposite;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(Composite)?(n-ncomp)*ncomp:0,Composite,&cComposite,"Composite:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector chpiece;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(hpiece)?npiece*n:0,hpiece,&chpiece,"hpiece:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cpgrad;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(pgrad)?npiece*n:0,pgrad,&cpgrad,"pgrad:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cAbs_A;
	hh = Variant2Vector(n*nabs,Abs_A,&cAbs_A,"Abs_A:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	dimen* cI_A;
	hh = Variant2Vector(mabs,I_A,&cI_A,"I_A:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cAbs_U;
	hh = Variant2Vector(nabs+mabs,Abs_U,&cAbs_U,"Abs_U:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cFC=0;
	vector cFL=0;
	vector cSV=0;
	if(nfac>-1)
	{
		hh = Variant2Vector(nfac*(nfac+1)/2,FC,&cFC,"FC:OptimiseInternalCVPAF");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector((n-ncomp)*nfac,FL,&cFL,"FL:OptimiseInternalCVPAF");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector((n-ncomp),SV,&cSV,"SV:OptimiseInternalCVPAF");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cogamma;
	hh = Variant2Vector(1,*ogamma,&cogamma,"ogamma:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmask;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(mask)?n:0,mask,&cmask,"mask:OptimiseInternalCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=Optimise_internalCVPAF(n,nfac,names,cw,m,cA,cL,cU,calpha,cbenchmark,cQ,gamma,cinitial,delta,cbuy,csell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,m_Round,cmin_lot,csize_lot,cshake,ncomp,cComposite,LSValue,npiece,chpiece,cpgrad,nabs,cAbs_A,mabs,cI_A,cAbs_U,cFC,cFL,cSV,minRisk,maxRisk,cogamma,cmask,log,logfile,downrisk,downfactor);
// ========================================
	SafeArrayRelease(*w,cw,n);
	SafeArray2DRelease(A,cA);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(benchmark,cbenchmark,n);
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(initial,cinitial,n);
	SafeArrayRelease(buy,cbuy,n);
	SafeArrayRelease(sell,csell,n);
	SafeArrayRelease(min_lot,cmin_lot,n);
	SafeArrayRelease(size_lot,csize_lot,n);
	SafeArrayRelease(*shake,cshake,n);
	SafeArrayRelease(Composite,cComposite,(n-ncomp)*ncomp);
	SafeArrayRelease(hpiece,chpiece,n*npiece);
	SafeArrayRelease(pgrad,cpgrad,n*npiece);
	SafeArrayRelease(Abs_A,cAbs_A,n*nabs);
	SafeArrayRelease(I_A,cI_A,mabs);
	SafeArrayRelease(Abs_U,cAbs_U,nabs+mabs);
	if(nfac > -1)
	{
		SafeArrayRelease(FC,cFC,nfac*(nfac+1)/2);
		SafeArrayRelease(FL,cFL,(n-ncomp)*nfac);
		SafeArrayRelease(SV,cSV,n-ncomp);
	}
	SafeArrayRelease(*ogamma,cogamma,1);
	SafeArrayRelease(mask,cmask,n);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
extern "C" void 	PropertiesCA(dimen n,long nfac,char** names,vector w,vector benchmark,
								 vector alpha,vector rreturn,vector areturn,vector Rsreturn,
								 vector breturn,vector Q,vector risk,vector arisk,
								 vector Rrisk,vector brisk,vector srisk,vector pbeta,
								 vector MCAR,vector MCTR,vector MCRR,vector MCBR,
								 vector FMCRR,vector FMCTR,vector FMCAR,vector FMCBR,
								 vector FMCSR,vector	beta,vector FX,vector RFX,
								 vector AFX,vector BFX,vector SFX,vector  FL,vector FC,
								 vector SV,dimen ncomp,vector Composite);
HRESULT __stdcall COptimiser::Properties(int n,int nfac,VARIANT Names,VARIANT w,
										  VARIANT benchmark,VARIANT alpha,VARIANT *rreturn,
										  VARIANT *areturn,VARIANT *Rsreturn,VARIANT *breturn,
										  VARIANT Q,VARIANT *risk,VARIANT *arisk,
										  VARIANT *Rrisk,VARIANT *brisk,VARIANT *srisk,
										  VARIANT *pbeta,VARIANT *MCAR,VARIANT *MCTR,
										  VARIANT *MCRR,VARIANT *MCBR,VARIANT *FMCRR,
										  VARIANT *FMCTR,VARIANT *FMCAR,VARIANT *FMCBR,
										  VARIANT *FMCSR,VARIANT *beta,VARIANT *FX,
										  VARIANT *RFX,VARIANT *AFX,VARIANT *BFX,VARIANT *SFX,
										  VARIANT  FL,VARIANT FC,VARIANT SV,int ncomp,
										  VARIANT Composite)
{
	HRESULT hh;
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
// ========================================
	vector cw;
	hh = Variant2Vector(n,w,&cw,"w:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbenchmark;
	hh = Variant2Vector(n,benchmark,&cbenchmark,"benchmark:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector crreturn;
	hh = Variant2Vector(1,*rreturn,&crreturn,"rreturn:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector careturn;
	hh = Variant2Vector(1,*areturn,&careturn,"areturn:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cRsreturn;
	hh = Variant2Vector(1,*Rsreturn,&cRsreturn,"Rsreturn:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbreturn;
	hh = Variant2Vector(1,*breturn,&cbreturn,"breturn:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:Properties");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector crisk;
	hh = Variant2Vector(1,*risk,&crisk,"risk:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector carisk;
	hh = Variant2Vector(1,*arisk,&carisk,"arisk:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cRrisk;
	hh = Variant2Vector(1,*Rrisk,&cRrisk,"Rrisk:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbrisk;
	hh = Variant2Vector(1,*brisk,&cbrisk,"brisk:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csrisk;
	hh = Variant2Vector(1,*srisk,&csrisk,"srisk:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cpbeta;
	hh = Variant2Vector(1,*pbeta,&cpbeta,"pbeta:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cMCAR;
	hh = Variant2Vector(n,*MCAR,&cMCAR,"MCAR:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cMCTR;
	hh = Variant2Vector(n,*MCTR,&cMCTR,"MCTR:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cMCRR;
	hh = Variant2Vector(n,*MCRR,&cMCRR,"MCRR:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cMCBR;
	hh = Variant2Vector(n,*MCBR,&cMCBR,"MCBR:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cFMCRR=0;
	vector cFMCTR=0;
	vector cFMCAR=0;
	vector cFMCBR=0;
	vector cFMCSR=0;
	vector cFX=0;
	vector cRFX=0;
	vector cAFX=0;
	vector cBFX=0;
	vector cSFX=0;
	if(nfac>-1)
	{
		hh = Variant2Vector((n-ncomp)+nfac,*FMCRR,&cFMCRR,"FMCRR:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector((n-ncomp)+nfac,*FMCTR,&cFMCTR,"FMCTR:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector((n-ncomp)+nfac,*FMCAR,&cFMCAR,"FMCAR:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector((n-ncomp)+nfac,*FMCBR,&cFMCBR,"FMCBR:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector((n-ncomp)+nfac,*FMCSR,&cFMCSR,"FMCSR:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nfac,*FX,&cFX,"FX:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nfac,*RFX,&cRFX,"RFX:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nfac,*AFX,&cAFX,"AFX:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nfac,*BFX,&cBFX,"BFX:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nfac,*SFX,&cSFX,"SFX:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cbeta;
	hh = Variant2Vector(n,*beta,&cbeta,"beta:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cFL=0;
	vector cFC=0;
	vector cSV=0;
	if(nfac>-1)
	{
		hh = Variant2Vector((n-ncomp)*nfac,FL,&cFL,"FL:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nfac*(nfac+1)/2,FC,&cFC,"FC:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(n-ncomp,SV,&cSV,"SV:Properties");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cComposite;
	hh = Variant2Vector((n-ncomp)*ncomp,Composite,&cComposite,"Composite:Properties");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	PropertiesCA(n,nfac,names,cw,cbenchmark,calpha,crreturn,careturn,cRsreturn,cbreturn,cQ,crisk,carisk,cRrisk,cbrisk,csrisk,cpbeta,cMCAR,cMCTR,cMCRR,cMCBR,cFMCRR,cFMCTR,cFMCAR,cFMCBR,cFMCSR,cbeta,cFX,cRFX,cAFX,cBFX,cSFX,cFL,cFC,cSV,ncomp,cComposite);
// ========================================
	SafeArrayRelease(w,cw,n);
	SafeArrayRelease(benchmark,cbenchmark,n);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(*rreturn,crreturn,1);
	SafeArrayRelease(*areturn,careturn,1);
	SafeArrayRelease(*Rsreturn,cRsreturn,1);
	SafeArrayRelease(*breturn,cbreturn,1);
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(*risk,crisk,1);
	SafeArrayRelease(*arisk,carisk,1);
	SafeArrayRelease(*Rrisk,cRrisk,1);
	SafeArrayRelease(*brisk,cbrisk,1);
	SafeArrayRelease(*srisk,csrisk,1);
	SafeArrayRelease(*pbeta,cpbeta,1);
	SafeArrayRelease(*MCAR,cMCAR,n);
	SafeArrayRelease(*MCTR,cMCTR,n);
	SafeArrayRelease(*MCRR,cMCRR,n);
	SafeArrayRelease(*MCBR,cMCBR,n);
	if(nfac>-1)
	{
		SafeArrayRelease(*FMCRR,cFMCRR,nfac+n-ncomp);
		SafeArrayRelease(*FMCTR,cFMCTR,nfac+n-ncomp);
		SafeArrayRelease(*FMCAR,cFMCAR,nfac+n-ncomp);
		SafeArrayRelease(*FMCBR,cFMCBR,nfac+n-ncomp);
		SafeArrayRelease(*FMCSR,cFMCSR,nfac+n-ncomp);
		SafeArrayRelease(*FX,cFX,nfac);
		SafeArrayRelease(*RFX,cRFX,nfac);
		SafeArrayRelease(*AFX,cAFX,nfac);
		SafeArrayRelease(*BFX,cBFX,nfac);
		SafeArrayRelease(*SFX,cSFX,nfac);
		SafeArrayRelease(FL,cFL,(n-ncomp)*nfac);
		SafeArrayRelease(FC,cFC,nfac*(nfac+1)/2);
		SafeArrayRelease(SV,cSV,n-ncomp);
	}
	SafeArrayRelease(*beta,cbeta,n);
	SafeArrayRelease(Composite,cComposite,(n-ncomp)*ncomp);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
//typedef void (*pModC)(dimen nvab,vector x,vector c,void* info);
//typedef void (*pModQ)(dimen nvab,vector x,vector q,void* info);
typedef void (__stdcall *COMModVec)(int nvab,VARIANT x,VARIANT *v);
static void  CostGrad(dimen n,vector x,vector c,void* func)
{
	//We have to copy the contents of x into a 1D VARIANT array.
	VARIANT vx,vc;
	_variant_t ccc;

	//Set bounds for the VARIANT
	SAFEARRAY FAR *pArrayx,*pArrayc;
	SAFEARRAYBOUND bound[1];
	VARIANT HUGEP* Safex,*Safec;

	bound[0].cElements = n;
	bound[0].lLbound = 0;

	//Create the space
	pArrayx = SafeArrayCreate(VT_VARIANT,1,bound);
	vx.vt = VT_VARIANT |  VT_ARRAY;
	vx.parray = pArrayx;

	pArrayc = SafeArrayCreate(VT_VARIANT,1,bound);
	vc.vt = VT_VARIANT |  VT_ARRAY;
	vc.parray = pArrayc;


	//Copy the double array data

	HRESULT hhx = SafeArrayAccessData(pArrayx,(void HUGEP* FAR*) &Safex);
	HRESULT hhc = SafeArrayAccessData(pArrayc,(void HUGEP* FAR*) &Safec);
	size_t i;
	for(i = 0;i < n;++i)
	{
		ccc.Attach(Safex[i]);
		ccc.ChangeType(VT_R8);
		Safex[i] = ccc.Detach();
		Safex[i].dblVal = ((double HUGEP*)x)[i];
	}

	ccc.Clear();

	//Now call the callback function defined somewhere over the COM interface
	((COMModVec)func)((int)n,vx,&vc);


	//Copy back the c values 
	for(i = 0;i < n;++i)
	{
		ccc.Attach(Safec[i]);
		ccc.ChangeType(VT_R8);
		Safec[i] = ccc.Detach();
		c[i] = (double)(Safec[i].dblVal);
	}

	hhx = SafeArrayUnaccessData(pArrayx);
	hhc = SafeArrayUnaccessData(pArrayc);


	ccc.Clear();
	//hhx=SafeArrayDestroy(pArrayx);
	//hhc=SafeArrayDestroy(pArrayc);
}
static void  CostHess(dimen n,vector x,vector c,void* func)
{
	//We have to copy the contents of x into a 1D VARIANT array.
	VARIANT vx,vc;
	_variant_t ccc;

	//Set bounds for the VARIANT
	SAFEARRAY FAR *pArrayx,*pArrayc;
	SAFEARRAYBOUND boundx[1],boundc[1];
	VARIANT HUGEP* Safex,*Safec;

	boundx[0].cElements = n;
	boundx[0].lLbound = 0;
	boundc[0].cElements = n*(n+1)/2;
	boundc[0].lLbound = 0;

	//Create the space
	pArrayx = SafeArrayCreate(VT_VARIANT,1,boundx);
	vx.vt = VT_VARIANT |  VT_ARRAY;
	vx.parray = pArrayx;

	pArrayc = SafeArrayCreate(VT_VARIANT,1,boundc);
	vc.vt = VT_VARIANT |  VT_ARRAY;
	vc.parray = pArrayc;


	//Copy the double array data

	HRESULT hhx = SafeArrayAccessData(pArrayx,(void HUGEP* FAR*) &Safex);
	HRESULT hhc = SafeArrayAccessData(pArrayc,(void HUGEP* FAR*) &Safec);
	size_t i;
	for(i = 0;i < n;++i)
	{
		ccc.Attach(Safex[i]);
		ccc.ChangeType(VT_R8);
		Safex[i] = ccc.Detach();
		Safex[i].dblVal = ((double HUGEP*)x)[i];
	}

	ccc.Clear();

	//Now call the callback function defined somewhere over the COM interface
	((COMModVec)func)((int)n,vx,&vc);


	//Copy back the c values 
	for(i = 0;i < n*(n+1)/2;++i)
	{
		ccc.Attach(Safec[i]);
		ccc.ChangeType(VT_R8);
		Safec[i] = ccc.Detach();
		c[i] = (double)(Safec[i].dblVal);
	}

	hhx = SafeArrayUnaccessData(pArrayx);
	hhc = SafeArrayUnaccessData(pArrayc);


	ccc.Clear();
	//hhx=SafeArrayDestroy(pArrayx);
	//hhc=SafeArrayDestroy(pArrayc);
}
extern "C" short  Optimise_internalCVPAextcosts(dimen n,long nfac,char** names,vector w,
												dimen m,vector A,vector L,vector U,
												vector alpha,vector benchmark,vector Q,
												double gamma,vector initial,double delta,
												double kappa,long basket,long trades,
												int revise,double min_holding,
												double min_trade,int m_LS,int Fully_Invested,
												double Rmin,double Rmax,int m_Round,
												vector min_lot,vector size_lot,int* shake,
												dimen ncomp,vector Composite,double LSValue,
												dimen nabs,vector Abs_A,dimen mabs,
												dimen* I_A,vector Abs_U,vector FC,vector FL,
												vector SV,pUtility Util,pModC ModDeriv,pModQ ModHessian,double minRisk,double maxRisk,vector ogamma,void *Uinfo,void *Minfo,void *Qinfo,short take_out_costs,vector mask,int log,char* logfile,short DoExtraIterations,int downrisk,double downfactor,long longbasket,long shortbasket,
									long tradebuy,long tradesell,double zetaS,double zetaF,
									double ShortCostScale);
HRESULT __stdcall COptimiser::OptimiseInternalCVPAextcosts(int n,int nfac,VARIANT Names,
														  VARIANT *w,int m,VARIANT A,
														  VARIANT L,VARIANT U,VARIANT alpha,
														  VARIANT benchmark,VARIANT Q,
														  double gamma,VARIANT initial,
														  double delta,double kappa,
														  int basket,int trades,
														  int revise,double min_holding,
														  double min_trade,int m_LS,
														  int Fully_Invested,double Rmin,
														  double Rmax,int m_Round,
														  VARIANT min_lot,VARIANT size_lot,
														  VARIANT *shake,int ncomp,
														  VARIANT Composite,double LSValue,
														  int nabs,VARIANT Abs_A,int mabs,
														  VARIANT I_A,VARIANT Abs_U,
														  VARIANT FC,VARIANT FL,VARIANT SV,
														  int Util,int ModDeriv,
														  int ModHessian,double minRisk,
														  double maxRisk,VARIANT *ogamma,
														  int take_out_costs,VARIANT mask,
														  int log,BSTR Logfile,
														  int DoExtraIterations,int downrisk,
														  double downfactor,int *retval)
{
	HRESULT hh;
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
	_bstr_t a=Logfile;
	char* logfile=(char*)a;
// ========================================
	vector cw;
	hh = Variant2Vector(n,*w,&cw,"w:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Array2D2Vector(n*m,A,&cA,"A:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbenchmark;
	hh = Variant2Vector(n,benchmark,&cbenchmark,"benchmark:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:OptimiseInternalCVPAextcosts");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cinitial;
	hh = Variant2Vector(n,initial,&cinitial,"initial:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmin_lot;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(min_lot)?n:0,min_lot,&cmin_lot,"min_lot:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csize_lot;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(size_lot)?n:0,size_lot,&csize_lot,"size_lot:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	int* cshake;
	hh = Variant2Vector(n,*shake,&cshake,"shake:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cComposite;
	hh = Variant2Vector((n-ncomp)*ncomp,Composite,&cComposite,"Composite:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cAbs_A;
	hh = Variant2Vector(nabs*n,Abs_A,&cAbs_A,"Abs_A:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	dimen* cI_A;
	hh = Variant2Vector(mabs,I_A,&cI_A,"I_A:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cAbs_U;
	hh = Variant2Vector(nabs+mabs,Abs_U,&cAbs_U,"Abs_U:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cFC=0;
	vector cFL=0;
	vector cSV=0;
	if(nfac>-1)
	{
		hh = Variant2Vector(nfac*(nfac+1)/2,FC,&cFC,"FC:OptimiseInternalCVPAextcosts");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector((n-ncomp)*nfac,FL,&cFL,"FL:OptimiseInternalCVPAextcosts");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(n-ncomp,SV,&cSV,"SV:OptimiseInternalCVPAextcosts");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cogamma;
	hh = Variant2Vector(1,*ogamma,&cogamma,"ogamma:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmask;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(mask)?n:0,mask,&cmask,"mask:OptimiseInternalCVPAextcosts");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=Optimise_internalCVPAextcosts(n,nfac,names,cw,m,cA,cL,cU,calpha,cbenchmark,cQ,gamma,cinitial,delta,kappa,basket,trades,revise,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,m_Round,cmin_lot,csize_lot,cshake,ncomp,cComposite,LSValue,nabs,cAbs_A,mabs,cI_A,cAbs_U,cFC,cFL,cSV,Util?CallUtil:0,ModDeriv?CostGrad:0,ModHessian?CostHess:0,minRisk,maxRisk,cogamma,(void*)Util,(void*)ModDeriv,(void*)ModHessian,take_out_costs,cmask,log,logfile,DoExtraIterations,downrisk,downfactor,-1,-1,-1,-1,1,1,1);
// ========================================
	SafeArrayRelease(*w,cw,n);
	SafeArray2DRelease(A,cA);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(benchmark,cbenchmark,n);
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(initial,cinitial,n);
	SafeArrayRelease(min_lot,cmin_lot,n);
	SafeArrayRelease(size_lot,csize_lot,n);
	SafeArrayRelease(*shake,cshake,n);
	SafeArrayRelease(Composite,cComposite,(n-ncomp)*ncomp);
	SafeArrayRelease(Abs_A,cAbs_A,nabs*n);
	SafeArrayRelease(I_A,cI_A,mabs);
	SafeArrayRelease(Abs_U,cAbs_U,nabs+mabs);
	if(nfac>-1)
	{
		SafeArrayRelease(FC,cFC,nfac*(nfac+1)/2);
		SafeArrayRelease(FL,cFL,nfac*(n-ncomp));
		SafeArrayRelease(SV,cSV,n-ncomp);
	}
	SafeArrayRelease(*ogamma,cogamma,1);
	SafeArrayRelease(mask,cmask,n);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
HRESULT __stdcall COptimiser::TestDeriv(int n,VARIANT x,VARIANT *c,int func)
{
_ASSERT(0);
	char mess[200];
	vector cx,cc;
	HRESULT hh;

	if(!IS_VARIANT_NOT_NULL(*c))
	{
		::MessageBox(NULL,"*c null variant ByRef","TestDeriv",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}

	if(!(x.vt))
	{
		::MessageBox(NULL,"x null variant ByVal","TestDeriv",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}
	else if(!(x.pvarVal->vt))
	{
		::MessageBox(NULL,"x null variant ByRef","TestDeriv",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}

	int xsize=NUMBER_OF_ELEMENTS_FOR1D(x);
	int csize=NUMBER_OF_ELEMENTS_FOR1D(*c);

	if(xsize != n)
	{
		sprintf(mess,"xsize is wrong n=%d, xsize=%d",n,xsize);
		::MessageBox(NULL,mess,"xsize is wrong in TestDeriv",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}

	if(csize == n)
	{
		hh = Variant2Vector(n,x,&cx,"x:TestDeriv");
		hh = Variant2Vector(csize,*c,&cc,"c:TestDeriv");
		CostGrad(n,cx,cc,(void*)func);
	}
	else if(csize == n*(n+1)/2)
	{
		hh = Variant2Vector(n,x,&cx,"x:TestDeriv");
		hh = Variant2Vector(csize,*c,&cc,"c:TestDeriv");
		CostHess(n,cx,cc,(void*)func);
	}
	else
	{
		sprintf(mess,"csize is wrong n=%d, csize=%d",n,csize);
		::MessageBox(NULL,mess,"csize is wrong in TestDeriv",MB_OK | MB_ICONSTOP);
		return S_FALSE;
	}

	SafeArrayRelease(x,cx,n);
	SafeArrayRelease(*c,cc,csize);
	return S_OK;
}

extern "C" short FrontierCVPAF(dimen npoints,vector risk,vector arisk,vector rreturn,
							   vector areturn,dimen n,long nfac,char** names,vector w,
							   dimen m,vector A,vector L,vector U,vector alpha,
							   vector benchmark,vector Q,vector initial,double delta,
							   vector buy,vector sell,double kappa,long basket,
							   long trades,dimen revise,int costs,double min_holding,
							   double min_trade,int m_LS,int Fully_Invested,
							   double Rmin,double Rmax,int m_Round,vector min_lot,
							   vector size_lot,int* shake,dimen ncomp,vector Comp,
							   double LSValue,dimen npiece,vector hpiece,vector pgrad,
							   dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
							   vector FC,vector FL,vector SV,vector mask,int DoByRisks);
HRESULT __stdcall COptimiser::Frontier(int npoints,VARIANT *risk,VARIANT *arisk,
										   VARIANT *rreturn,VARIANT *areturn,int n,
										   int nfac,VARIANT Names,VARIANT *w,int m,
										   VARIANT A,VARIANT L,VARIANT U,VARIANT alpha,
										   VARIANT benchmark,VARIANT Q,VARIANT initial,
										   double delta,VARIANT buy,VARIANT sell,
										   double kappa,int basket,int trades,int revise,
										   int costs,double min_holding,double min_trade,
										   int m_LS,int Fully_Invested,double Rmin,
										   double Rmax,int m_Round,VARIANT min_lot,
										   VARIANT size_lot,VARIANT *shake,int ncomp,
										   VARIANT Comp,double LSValue,int npiece,
										   VARIANT hpiece,VARIANT pgrad,int nabs,
										   VARIANT Abs_A,int mabs,VARIANT I_A,VARIANT Abs_U,
										   VARIANT FC,VARIANT FL,VARIANT SV,VARIANT mask,
										   int DoByRisks,int *retval)
{
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
	HRESULT hh;
// ========================================
	vector crisk;
	hh = Variant2Vector(1,*risk,&crisk,"risk:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector carisk;
	hh = Variant2Vector(1,*arisk,&carisk,"arisk:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector crreturn;
	hh = Variant2Vector(1,*rreturn,&crreturn,"rreturn:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector careturn;
	hh = Variant2Vector(1,*areturn,&careturn,"areturn:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cw;
	hh = Variant2Vector(npoints*n,*w,&cw,"w:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Array2D2Vector(n*m,A,&cA,"A:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbenchmark;
	hh = Variant2Vector(n,benchmark,&cbenchmark,"benchmark:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	if(nfac>-1)
		hh = Variant2Vector((n-ncomp)*(nfac+1),Q,&cQ,"Q:FrontierCVPAF");
	else
		hh = Variant2Vector((n-ncomp)*((n-ncomp)+1)/2,Q,&cQ,"Q:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cinitial;
	hh = Variant2Vector(n,initial,&cinitial,"initial:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbuy;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(buy)?n:0,buy,&cbuy,"buy:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csell;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(sell)?n:0,sell,&csell,"sell:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmin_lot;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(min_lot)?n:0,min_lot,&cmin_lot,"min_lot:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector csize_lot;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(size_lot)?n:0,size_lot,&csize_lot,"size_lot:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	int* cshake;
	hh = Variant2Vector(npoints*n,*shake,&cshake,"shake:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cComp;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(Comp)?(n-ncomp)*ncomp:0,Comp,&cComp,"Comp:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector chpiece;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(hpiece)?npiece*n:0,hpiece,&chpiece,"hpiece:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cpgrad;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(pgrad)?npiece*n:0,pgrad,&cpgrad,"pgrad:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cAbs_A;
	hh = Variant2Vector(nabs*n,Abs_A,&cAbs_A,"Abs_A:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	dimen* cI_A;
	hh = Variant2Vector(mabs,I_A,&cI_A,"I_A:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cAbs_U;
	hh = Variant2Vector(nabs+mabs,Abs_U,&cAbs_U,"Abs_U:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cFC=0;
	vector cSV=0;
	vector cFL=0;
	if(nfac>-1)
	{
		hh = Variant2Vector(nfac*(nfac+1)/2,FC,&cFC,"FC:FrontierCVPAF");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector((n-ncomp)*nfac,FL,&cFL,"FL:FrontierCVPAF");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(n-ncomp,SV,&cSV,"SV:FrontierCVPAF");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cmask;
	hh = Variant2Vector(IS_VARIANT_NOT_NULL(mask)?n:0,mask,&cmask,"mask:FrontierCVPAF");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=FrontierCVPAF(npoints,crisk,carisk,crreturn,careturn,n,nfac,names,cw,m,cA,cL,cU,calpha,cbenchmark,cQ,cinitial,delta,cbuy,csell,kappa,basket,trades,revise,costs,min_holding,min_trade,m_LS,Fully_Invested,Rmin,Rmax,m_Round,cmin_lot,csize_lot,cshake,ncomp,cComp,LSValue,npiece,chpiece,cpgrad,nabs,cAbs_A,mabs,cI_A,cAbs_U,cFC,cFL,cSV,cmask,DoByRisks);
// ========================================
	SafeArrayRelease(*risk,crisk,1);
	SafeArrayRelease(*arisk,carisk,1);
	SafeArrayRelease(*rreturn,crreturn,1);
	SafeArrayRelease(*areturn,careturn,1);
	SafeArrayRelease(*w,cw,npoints*n);
	SafeArray2DRelease(A,cA);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(benchmark,cbenchmark,n);
	if(nfac>-1)
		SafeArrayRelease(Q,cQ,(n-ncomp)*(nfac+1));
	else
		SafeArrayRelease(Q,cQ,(n-ncomp)*((n-ncomp)+1)/2);
	SafeArrayRelease(initial,cinitial,n);
	SafeArrayRelease(buy,cbuy,n);
	SafeArrayRelease(sell,csell,n);
	SafeArrayRelease(min_lot,cmin_lot,n);
	SafeArrayRelease(size_lot,csize_lot,n);
	SafeArrayRelease(*shake,cshake,npoints*n);
	SafeArrayRelease(Comp,cComp,(n-ncomp)*ncomp);
	SafeArrayRelease(hpiece,chpiece,npiece*n);
	SafeArrayRelease(pgrad,cpgrad,npiece*n);
	SafeArrayRelease(Abs_A,cAbs_A,nabs*n);
	SafeArrayRelease(I_A,cI_A,mabs);
	SafeArrayRelease(Abs_U,cAbs_U,nabs+mabs);
	if(nfac>-1)
	{
		SafeArrayRelease(FC,cFC,nfac*(nfac+1)/2);
		SafeArrayRelease(FL,cFL,(n-ncomp)*ncomp);
		SafeArrayRelease(SV,cSV,n-ncomp);
	}
	SafeArrayRelease(mask,cmask,n);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
extern "C" size_t multistage(size_t n,size_t y,vector w,vector before,vector rebalanced,
							 vector risks,vector Growth,vector Yield,vector Liability,
							 vector lbound,vector ubound,char** names,vector Q,vector first,
							 double delta,double maxrisk,dimen* NumberYears,size_t meth,
							 size_t print);
HRESULT __stdcall COptimiser::MultiStage(int n,int y,VARIANT *w,VARIANT *before,
										VARIANT *rebalanced,VARIANT *risks,VARIANT Growth,
										VARIANT Yield,VARIANT Liability,VARIANT lbound,
										VARIANT ubound,VARIANT Names,VARIANT Q,VARIANT first,
										double delta,double maxrisk,VARIANT NumberYears,
										int meth,int print,int *retval)
{
	HRESULT hh;
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
// ========================================
	vector cw;
	hh = Variant2Vector(n*y,*w,&cw,"w:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbefore;
	hh = Variant2Vector(n*y,*before,&cbefore,"before:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector crebalanced;
	hh = Variant2Vector(n*y,*rebalanced,&crebalanced,"rebalanced:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector crisks;
	hh = Variant2Vector(y,*risks,&crisks,"risks:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cGrowth;
	hh = Variant2Vector(n*y,Growth,&cGrowth,"Growth:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cYield;
	hh = Variant2Vector(n*y,Yield,&cYield,"Yield:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cLiability;
	hh = Variant2Vector(y,Liability,&cLiability,"Liability:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector clbound;
	hh = Variant2Vector(n,lbound,&clbound,"lbound:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cubound;
	hh = Variant2Vector(n,ubound,&cubound,"ubound:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cQ;
	hh = Variant2Vector(n*(n+1)/2,Q,&cQ,"Q:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cfirst;
	hh = Variant2Vector(n,first,&cfirst,"first:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
	dimen* cNumberYears;
	hh = Variant2Vector(y,NumberYears,&cNumberYears,"NumberYears:MultiStage");
	if(hh == S_FALSE)
		return S_FALSE;
/*	char mess[200];
	sprintf(mess,"delta = %20.8e",delta);
	::MessageBox(NULL,mess,"delta",MB_OK | MB_ICONSTOP);*/
// ========================================
	*retval=multistage(n,y,cw,cbefore,crebalanced,crisks,cGrowth,cYield,cLiability,clbound,cubound,names,cQ,cfirst,delta,maxrisk,cNumberYears,meth,print);
// ========================================
	SafeArrayRelease(*w,cw,n*y);
	SafeArrayRelease(*before,cbefore,n*y);
	SafeArrayRelease(*rebalanced,crebalanced,n*y);
	SafeArrayRelease(*risks,crisks,y);
	SafeArrayRelease(Growth,cGrowth,n*y);
	SafeArrayRelease(Yield,cYield,n*y);
	SafeArrayRelease(Liability,cLiability,y);
	SafeArrayRelease(lbound,clbound,n);
	SafeArrayRelease(ubound,cubound,n);
	SafeArrayRelease(Q,cQ,n*(n+1)/2);
	SafeArrayRelease(first,cfirst,n);
	SafeArrayRelease(NumberYears,cNumberYears,y);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
extern "C"  char*	MultiStageMessage(int ifail);
HRESULT __stdcall COptimiser::MultistageMessage(int ifail,BSTR* retval)
{
	_bstr_t a=MultiStageMessage(ifail);
	*retval = a.copy();
	return S_OK;
}
extern "C" short eigendecomp(dimen n,vector S,vector d,dimen itmax);
HRESULT __stdcall COptimiser::EigenDecomp(int n,VARIANT *S,VARIANT *d,int itmax,int* retval)
{
	HRESULT hh;
// ========================================
	vector cS;
	hh = Variant2Vector(n*n,*S,&cS,"S:EigenDecomp");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cd;
	hh = Variant2Vector(n,*d,&cd,"d:EigenDecomp");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=eigendecomp(n,cS,cd,itmax);
// ========================================
	SafeArrayRelease(*S,cS,n*n);
	SafeArrayRelease(*d,cd,n);
// ========================================
	return S_OK;
}

extern "C" size_t get_nstocks(char*name);
HRESULT __stdcall COptimiser::Get_nstocks(BSTR name,int* retval)
{
	_bstr_t a	= name;
	LPSTR	s_name = (LPSTR)a;
// ========================================
// ========================================
	*retval=get_nstocks(s_name);
// ========================================
// ========================================
	return S_OK;
}
extern "C"	 size_t get_nfac(char* name);
HRESULT __stdcall COptimiser::Get_nfac(BSTR name,int*retval)
{
	_bstr_t a	= name;
	LPSTR	s_name = (LPSTR)a;
// ========================================
// ========================================
	*retval=(int) get_nfac(s_name);
// ========================================
// ========================================
	return S_OK;
}
extern "C"	 void getdata(size_t nstocks,size_t nfac,char** namelist,double* FLOUT,double* SVOUT,double* FCOUT,char* name);
HRESULT __stdcall COptimiser::Getdata(int nstocks,int nfac,VARIANT namelist,VARIANT* FLOUT,VARIANT* SVOUT,VARIANT* FCOUT,BSTR name)
{
	HRESULT hh;
	_bstr_t a	= name;
	LPSTR	s_name = (LPSTR)a;
	char** names;
	hh = Variant2Vector(nstocks,namelist,&names,"namelist:Getdata");
// ========================================
	vector cFLOUT,cSVOUT,cFCOUT;
	hh = Variant2Vector(nstocks*nfac,*FLOUT,&cFLOUT,"FLOUT:Getdata");
	if(hh == S_FALSE)
		return S_FALSE;
	hh = Variant2Vector(nstocks,*SVOUT,&cSVOUT,"SVOUT:Getdata");
	if(hh == S_FALSE)
		return S_FALSE;
	hh = Variant2Vector(nfac*(nfac+1)/2,*FCOUT,&cFCOUT,"FCOUT:Getdata");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	getdata(nstocks,nfac,names, cFLOUT, cSVOUT, cFCOUT, s_name);
	SafeArrayRelease(namelist,names,nstocks);
// ========================================
	SafeArrayRelease(*FLOUT,cFLOUT,nstocks*nfac);
	SafeArrayRelease(*SVOUT,cSVOUT,nstocks);
	SafeArrayRelease(*FCOUT,cFCOUT,nfac*(nfac+1)/2);
// ========================================
	return S_OK;
}
extern "C" void get_stocknames(char** sname,char*name);
HRESULT __stdcall COptimiser::Get_stocknames(VARIANT* sname,BSTR name)
{
	HRESULT hh;
	_bstr_t a	= name;
	LPSTR	s_name = (LPSTR)a;
	size_t nstocks=get_nstocks(s_name);
// ========================================
	char** names;
	hh = Variant2Vector(nstocks,*sname,&names,"sname:Get_stocknames");
// ========================================
	get_stocknames(names,s_name);
// ========================================
	SafeArrayRelease(*sname,names,nstocks);
// ========================================
	return S_OK;
}
extern "C" void get_factornames(char** fname,char*name);
HRESULT __stdcall COptimiser::Get_factornames(VARIANT* fname, BSTR name)
{
	HRESULT hh;
	_bstr_t a	= name;
	LPSTR	s_name = (LPSTR)a;
	size_t nfac=get_nfac(s_name);
// ========================================
	char** names;
	hh = Variant2Vector(nfac,*fname,&names,"fname:Get_factornames");
// ========================================
	get_factornames(names,s_name);
// ========================================
	SafeArrayRelease(*fname,names,nfac);
// ========================================
	return S_OK;
}

extern "C" short SOCPinfeasHomogt(size_t n,size_t m,int *ncone,vector c,vector A,
										 vector b,vector x,vector y,vector s,double *tau,
										 double *kappa,size_t maxit=100,double beta=1e-8,double delta=.5,double ccomp=1.4902e-8,
										 double cgap=1.4902e-8,int signtest=0,double changeratio=4,
										 double rhoconv=1.4902e-8);
HRESULT __stdcall COptimiser::SOCPinfeasHomog(int n,int m,VARIANT ncone,VARIANT c,
											 VARIANT A,VARIANT b,VARIANT *x,VARIANT *y,
											 VARIANT *s,VARIANT *tau,VARIANT *kappa,int*retval)
{
	HRESULT hh;
// ========================================
	size_t nn,i;
	int*cncone;
	hh = Variant2Vector(n,ncone,&cncone,"ncone:SOCPinfeasHomog");
	for(i=0,nn=0;i<(size_t)n;++i)
		nn+=cncone[i];
	if(hh == S_FALSE)
		return S_FALSE;
	vector cc;
	hh = Variant2Vector(nn,c,&cc,"c:SOCPinfeasHomog");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Variant2Vector(nn*m,A,&cA,"A:SOCPinfeasHomog");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cb;
	hh = Variant2Vector(m,b,&cb,"b:SOCPinfeasHomog");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cx;
	hh = Variant2Vector(nn,*x,&cx,"x:SOCPinfeasHomog");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cy;
	hh = Variant2Vector(m,*y,&cy,"y:SOCPinfeasHomog");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cs;
	hh = Variant2Vector(nn,*s,&cs,"s:SOCPinfeasHomog");
	if(hh == S_FALSE)
		return S_FALSE;
	double*ctau;
	hh = Variant2Vector(1,*tau,&ctau,"tau:SOCPinfeasHomog");
	if(hh == S_FALSE)
		return S_FALSE;
	double*ckappa;
	hh = Variant2Vector(1,*kappa,&ckappa,"kappa:SOCPinfeasHomog");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=SOCPinfeasHomogt(n,m,cncone,cc,cA,cb,cx,cy,cs,ctau,ckappa);
// ========================================
	SafeArrayRelease(ncone,cncone,n);
	SafeArrayRelease(c,cc,nn);
	SafeArrayRelease(A,cA,nn*m);
	SafeArrayRelease(b,cb,m);
	SafeArrayRelease(*x,cx,nn);
	SafeArrayRelease(*y,cy,m);
	SafeArrayRelease(*s,cs,nn);
	SafeArrayRelease(*tau,ctau,1);
	SafeArrayRelease(*kappa,ckappa,1);
// ========================================
	return S_OK;
}
extern "C" short SOCPRobust(size_t n,size_t m,vector w,vector A,vector L,vector U,long nf,
							vector SV,vector FL,vector FC,vector alpha,vector meanFE,
							vector covFE,double maxmeanFE,double maxstderrorFE,double gamma,
							double maxRisk,vector bench,vector initial,int mFE,int rFE,vector sectors=0);
HRESULT __stdcall COptimiser::SOCPRobustOpt(int n,int m,VARIANT *w,VARIANT A,VARIANT L,VARIANT U,
										int nf,VARIANT SV,VARIANT FL,VARIANT FC,VARIANT alpha,
										VARIANT meanFE,VARIANT covFE,double maxmeanFE,
										double maxstderrorFE,double gamma,double maxRisk,
										VARIANT bench,VARIANT initial,int mFE,int rFE,int*retval)
{
	HRESULT hh;
// ========================================
	vector cw;
	hh = Variant2Vector(n,*w,&cw,"w:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Variant2Vector(n*m,A,&cA,"A:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cSV=0;
	vector cFL=0;
	size_t nnf=n;
	if(nf>-1)
	{
		nnf=nf;
		hh = Variant2Vector(n,SV,&cSV,"SV:SOCPRobust");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(n*nf,FL,&cFL,"FL:SOCPRobust");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cFC;
	hh = Variant2Vector(nnf*(nnf+1)/2,FC,&cFC,"FC:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cmeanFE;
	hh = Variant2Vector(n,meanFE,&cmeanFE,"meanFE:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector ccovFE;
	hh = Variant2Vector(n*(n+1)/2,covFE,&ccovFE,"covFE:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cbench;
	hh = Variant2Vector(n,bench,&cbench,"bench:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cinitial;
	hh = Variant2Vector(n,initial,&cinitial,"initial:SOCPRobust");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=SOCPRobust(n,m,cw,cA,cL,cU,nf,cSV,cFL,cFC,calpha,cmeanFE,ccovFE,
		maxmeanFE,maxstderrorFE,
		gamma,maxRisk,cbench,cinitial,mFE,rFE);
// ========================================
	SafeArrayRelease(*w,cw,n);
	SafeArrayRelease(A,cA,n*n);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	if(nf>-1)
	{
		SafeArrayRelease(SV,cSV,n);
		SafeArrayRelease(FL,cFL,n*nf);
	}
	SafeArrayRelease(FC,cFC,nnf*(nnf+1)/2);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(meanFE,cmeanFE,n);
	SafeArrayRelease(covFE,ccovFE,n*(n+1)/2);
	SafeArrayRelease(bench,cbench,n);
	SafeArrayRelease(initial,cinitial,n);
// ========================================
	return S_OK;
}
extern "C" void RootQ(size_t n,vector Q,vector RQ,vector RQm1);
HRESULT __stdcall COptimiser::RootQget(int n,VARIANT Q,VARIANT *RQ,VARIANT *RQm1)
{
	HRESULT hh;
	size_t nn=n*(n+1)/2,n2=n*n;
// ========================================
	vector cQ;
	hh = Variant2Vector(nn,Q,&cQ,"Q:RootQ");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cRQ;
	hh = Variant2Vector(n2,*RQ,&cRQ,"RQ:RootQ");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cRQm1;
	hh = Variant2Vector(n2,*RQm1,&cRQm1,"RQm1:RootQ");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	RootQ(n,cQ,cRQ,cRQm1);
// ========================================
	SafeArrayRelease(Q,cQ,nn);
	SafeArrayRelease(*RQ,cRQ,n2);
	SafeArrayRelease(*RQm1,cRQm1,n2);
// ========================================
	return S_OK;
}
extern "C" short SOCPlsRobustl(size_t n,size_t m,vector w,vector A,long nf,vector SV,
							  vector FL,vector FC,vector alpha,int full,double rmin,
							  double rmax,vector L,vector U,double val,double TopRisk,
							  vector dalpha,double MaxDalpha,vector covalpha,double MaxValpha,
							  size_t nabs,vector Aabs,vector Labs,vector Uabs,vector bench,vector initialm,
							  vector initials,int signtest,int fast=0,int maxrobust=0,char*SOCPdump=0);
HRESULT __stdcall COptimiser::SOCPlsRobustOpt(int n,int m,VARIANT* w,VARIANT A,int nf,
											 VARIANT SV,VARIANT FL,VARIANT FC,VARIANT alpha,
											 int full,double rmin,double rmax,VARIANT L,
											 VARIANT U,double val,double TopRisk,VARIANT dalpha,
											 double MaxDalpha,VARIANT covalpha,double MaxValpha,
											 int nabs,VARIANT Aabs,VARIANT Uabs,VARIANT bench,
											 VARIANT initialm,VARIANT initials,int signtest,int fast,
											 int*retval)
{
	_ASSERT(0);
	HRESULT hh;
// ========================================
	vector cw;
	hh = Variant2Vector(n,*w,&cw,"w:SOCPlsRobustOpt");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Variant2Vector(n*m,A,&cA,"A:SOCPlsRobustOpt");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cSV=0;
	vector cFL=0;
	vector cFC=0;
	if(TopRisk>0)
	{
		if(nf!=-1)
		{
			hh = Variant2Vector(n,SV,&cSV,"SV:SOCPlsRobustOpt");
			if(hh == S_FALSE)
				return S_FALSE;
			hh = Variant2Vector(n*nf,FL,&cFL,"FL:SOCPlsRobustOpt");
			if(hh == S_FALSE)
				return S_FALSE;
			hh = Variant2Vector(nf*(nf+1)/2,FC,&cFC,"FC:SOCPlsRobustOpt");
			if(hh == S_FALSE)
				return S_FALSE;
		}
		else
		{
			hh = Variant2Vector(n*(n+1)/2,FC,&cFC,"FC:SOCPlsRobustOpt");
			if(hh == S_FALSE)
				return S_FALSE;
		}
	}
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:SOCPlsRobustOpt");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:SOCPlsRobustOpt");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:SOCPlsRobustOpt");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cdalpha=0;
	if(MaxDalpha>0)
	{
		hh = Variant2Vector(n,dalpha,&cdalpha,"dalpha:SOCPlsRobustOpt");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector ccovalpha=0;
	if(MaxValpha>0)
	{
		hh = Variant2Vector(n*(n+1)/2,covalpha,&ccovalpha,"covalpha:SOCPlsRobustOpt");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cAabs=0;
	vector cUabs=0;
	if(nabs)
	{
		hh = Variant2Vector(n*nabs,Aabs,&cAabs,"Aabs:SOCPlsRobustOpt");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nabs,Uabs,&cUabs,"Uabs:SOCPlsRobustOpt");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cbench=0;
	if(TopRisk>0)
	{
		hh = Variant2Vector(n,bench,&cbench,"bench:SOCPlsRobustOpt");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cinitialm=0;
	if(MaxDalpha>0)
	{
		hh = Variant2Vector(n,initialm,&cinitialm,"initialm:SOCPlsRobustOpt");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cinitials=0;
	if(MaxValpha>0)
	{
		hh = Variant2Vector(n,initials,&cinitials,"initials:SOCPlsRobustOpt");
		if(hh == S_FALSE)
			return S_FALSE;
	}
// ========================================
	*retval=SOCPlsRobustl(n,m,cw,cA,nf,cSV,cFL,cFC,calpha,full,rmin,
		rmax,cL,cU,val,TopRisk,cdalpha,MaxDalpha,ccovalpha,MaxValpha,
		nabs,cAabs,0,cUabs,cbench,cinitialm,cinitials,signtest,fast);
// ========================================
	SafeArrayRelease(*w,cw,n);
	SafeArrayRelease(A,cA,n*m);
	if(nf!=-1)
	{
		SafeArrayRelease(SV,cSV,n);
		SafeArrayRelease(FL,cFL,n*nf);
		SafeArrayRelease(FC,cFC,nf*(nf+1)/2);
	}
	else
		SafeArrayRelease(FC,cFC,n*(n+1)/2);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	SafeArrayRelease(dalpha,cdalpha,n);
	SafeArrayRelease(covalpha,ccovalpha,n*(n+1)/2);
	SafeArrayRelease(Aabs,cAabs,n*nabs);
	SafeArrayRelease(Uabs,cUabs,nabs);
	SafeArrayRelease(bench,cbench,n);
	SafeArrayRelease(initialm,cinitialm,n);
	SafeArrayRelease(initials,cinitials,n);
	// ========================================
	return S_OK;
}
HRESULT __stdcall COptimiser::SOCPlsRobustOptl(int n,int m,VARIANT* w,VARIANT A,int nf,
											 VARIANT SV,VARIANT FL,VARIANT FC,VARIANT alpha,
											 int full,double rmin,double rmax,VARIANT L,
											 VARIANT U,double val,double TopRisk,VARIANT dalpha,
											 double MaxDalpha,VARIANT covalpha,double MaxValpha,
											 int nabs,VARIANT Aabs,VARIANT Labs,VARIANT Uabs,VARIANT bench,
											 VARIANT initialm,VARIANT initials,int signtest,int fast,int maxrobust,BSTR dump,
											 int*retval)
{
	_ASSERT(0);
	HRESULT hh;
// ========================================
	vector cw;
	hh = Variant2Vector(n,*w,&cw,"w:SOCPlsRobustOptl");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
	hh = Variant2Vector(n*m,A,&cA,"A:SOCPlsRobustOptl");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cSV=0;
	vector cFL=0;
	vector cFC=0;
	if(TopRisk>0)
	{
		if(nf!=-1)
		{
			hh = Variant2Vector(n,SV,&cSV,"SV:SOCPlsRobustOptl");
			if(hh == S_FALSE)
				return S_FALSE;
			hh = Variant2Vector(n*nf,FL,&cFL,"FL:SOCPlsRobustOptl");
			if(hh == S_FALSE)
				return S_FALSE;
			hh = Variant2Vector(nf*(nf+1)/2,FC,&cFC,"FC:SOCPlsRobustOptl");
			if(hh == S_FALSE)
				return S_FALSE;
		}
		else
		{
			hh = Variant2Vector(n*(n+1)/2,FC,&cFC,"FC:SOCPlsRobustOptl");
			if(hh == S_FALSE)
				return S_FALSE;
		}
	}
	vector calpha;
	hh = Variant2Vector(n,alpha,&calpha,"alpha:SOCPlsRobustOptl");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:SOCPlsRobustOptl");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:SOCPlsRobustOptl");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cdalpha=0;
	if(MaxDalpha>0)
	{
		hh = Variant2Vector(n,dalpha,&cdalpha,"dalpha:SOCPlsRobustOptl");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector ccovalpha=0;
	if(MaxValpha>0)
	{
		hh = Variant2Vector(n*(n+1)/2,covalpha,&ccovalpha,"covalpha:SOCPlsRobustOptl");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cAabs=0;
	vector cUabs=0;
	vector cLabs=0;
	if(nabs)
	{
		hh = Variant2Vector(n*nabs,Aabs,&cAabs,"Aabs:SOCPlsRobustOptl");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nabs,Uabs,&cUabs,"Uabs:SOCPlsRobustOptl");
		if(hh == S_FALSE)
			return S_FALSE;
		hh = Variant2Vector(nabs,Labs,&cLabs,"Labs:SOCPlsRobustOptl");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cbench=0;
	if(TopRisk>0)
	{
		hh = Variant2Vector(n,bench,&cbench,"bench:SOCPlsRobustOptl");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cinitialm=0;
	if(MaxDalpha>0)
	{
		hh = Variant2Vector(n,initialm,&cinitialm,"initialm:SOCPlsRobustOptl");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	vector cinitials=0;
	if(MaxValpha>0)
	{
		hh = Variant2Vector(n,initials,&cinitials,"initials:SOCPlsRobustOptl");
		if(hh == S_FALSE)
			return S_FALSE;
	}
	_bstr_t ddump=dump;
	char* cdump=(char*)ddump;

// ========================================
	*retval=SOCPlsRobustl(n,m,cw,cA,nf,cSV,cFL,cFC,calpha,full,rmin,
		rmax,cL,cU,val,TopRisk,cdalpha,MaxDalpha,ccovalpha,MaxValpha,
		nabs,cAabs,cLabs,cUabs,cbench,cinitialm,cinitials,signtest,fast,maxrobust,cdump);
// ========================================
	SafeArrayRelease(*w,cw,n);
	SafeArrayRelease(A,cA,n*m);
	if(nf!=-1)
	{
		SafeArrayRelease(SV,cSV,n);
		SafeArrayRelease(FL,cFL,n*nf);
		SafeArrayRelease(FC,cFC,nf*(nf+1)/2);
	}
	else
		SafeArrayRelease(FC,cFC,n*(n+1)/2);
	SafeArrayRelease(alpha,calpha,n);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
	SafeArrayRelease(dalpha,cdalpha,n);
	SafeArrayRelease(covalpha,ccovalpha,n*(n+1)/2);
	SafeArrayRelease(Aabs,cAabs,n*nabs);
	SafeArrayRelease(Uabs,cUabs,nabs);
	SafeArrayRelease(Labs,cLabs,nabs);
	SafeArrayRelease(bench,cbench,n);
	SafeArrayRelease(initialm,cinitialm,n);
	SafeArrayRelease(initials,cinitials,n);
	// ========================================
	return S_OK;
}
extern "C"  char*	SOCPlstestMessage(int ifail);
HRESULT __stdcall COptimiser::SOCPMessage(int ifail,BSTR* retval)
{
	_bstr_t a=SOCPlstestMessage(ifail);
	*retval = a.copy();
	return S_OK;
	
}
extern "C" short OmegaOpt(size_t n,size_t tlen,vector data,char** names,
						  vector w,double C,double R,double Low,
						  double*gain,double*loss,int log);
HRESULT __stdcall COptimiser::Omegaopt(int n,int tlen,VARIANT DATA,
									  VARIANT Names,VARIANT* weights,
									  double C,double R,double Low,
									  VARIANT* Gain,VARIANT* Loss,int log,int*retval)
{
	HRESULT hh;
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
// ========================================
	vector cDATA=0;
	hh = Variant2Vector(n*tlen,DATA,&cDATA,"DATA:OmegaOpt");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cweights=0;
	hh = Variant2Vector(n,*weights,&cweights,"weights:OmegaOpt");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cGain=0;
	hh = Variant2Vector(1,*Gain,&cGain,"Gain:OmegaOpt");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cLoss=0;
	hh = Variant2Vector(1,*Loss,&cLoss,"Loss:OmegaOpt");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	*retval=OmegaOpt(n,tlen,cDATA,names,cweights,C,R,Low,cGain,cLoss,log);
// ========================================
	SafeArrayRelease(DATA,cDATA,n*tlen);
	SafeArrayRelease(*weights,cweights,n);
	SafeArrayRelease(*Gain,cGain,1);
	SafeArrayRelease(*Loss,cLoss,1);
// ========================================
	if(names)
	{
		if(nsize==-1)
			DeleteNames(names,n);
		else
			DeleteNamess(names,n);
	}
	return S_OK;
}
extern "C" short OmegaGeneral(size_t n,size_t tlen,size_t m,double* DATA,char** names,vector w,double C,double R,vector L,vector U,vector A,double*Top,double*Bot,double* Prob,int log,int useSV,char*outfile,double gpower,double lpower);
HRESULT __stdcall COptimiser::OmegaGen(int n,int tlen,int m,VARIANT DATA,
									  VARIANT Names,VARIANT *w,double C,
									  double R,VARIANT L,VARIANT U,VARIANT A,
									  VARIANT *Top,VARIANT *Bot,VARIANT *Prob,
									  int log,int useSV,BSTR outfile,double gpower,double lpower,
									  int *retval)
{
	HRESULT hh;
	char** names;
	int nsize;
	Namelistget(n,nsize,Names,names);
// ========================================
	vector cDATA;
//	hh = Variant2Vector(n*tlen,DATA,&cDATA,"DATA:OmegaGen");
	hh = Array2D2Vector(n*tlen,DATA,&cDATA,"DATA:OmegaGen");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cw=0;
	hh = Variant2Vector(n,*w,&cw,"w:OmegaGen");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cL;
	hh = Variant2Vector(n+m,L,&cL,"L:OmegaGen");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cU;
	hh = Variant2Vector(n+m,U,&cU,"U:OmegaGen");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cA;
//	hh = Variant2Vector(n*m,A,&cA,"A:OmegaGen");
	hh = Array2D2Vector(n*m,A,&cA,"A:OmegaGen");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cTop;
	hh = Variant2Vector(1,*Top,&cTop,"Top:OmegaGen");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cBot;
	hh = Variant2Vector(1,*Bot,&cBot,"Bot:OmegaGen");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cProb;
	hh = Variant2Vector(1,*Prob,&cProb,"Prob:OmegaGen");
	if(hh == S_FALSE)
		return S_FALSE;
	_bstr_t ddump=outfile;
	char* coutfile=(char*)ddump;
// ========================================
	*retval=(int)OmegaGeneral(n,tlen,m, cDATA,names,cw,C,R,cL,cU,cA,cTop,cBot, cProb,log,useSV,coutfile,gpower,lpower);
// ========================================
//	SafeArrayRelease(DATA,cDATA,n*tlen);
	SafeArray2DRelease(DATA,cDATA);
	SafeArrayRelease(*w,cw,n);
	SafeArrayRelease(L,cL,n+m);
	SafeArrayRelease(U,cU,n+m);
//	SafeArrayRelease(A,cA,n*m);
	SafeArray2DRelease(A,cA);
	SafeArrayRelease(*Top,cTop,1);
	SafeArrayRelease(*Bot,cBot,1);
	SafeArrayRelease(*Prob,cProb,1);
// ========================================
	return S_OK;
}
extern "C" void OmegaProps(size_t n,size_t tlen,vector DATA,vector w,double R,double* Prob,double* Gain,double* Loss,
						   vector gains,vector losses,vector isolated_gains,
									 vector isolated_losses);
HRESULT __stdcall COptimiser::OmegaProperties(int n,int tlen,VARIANT DATA,VARIANT w,double R,VARIANT *Prob,VARIANT *Gain,VARIANT *Loss,
											 VARIANT *gains,VARIANT *losses,VARIANT *igains,VARIANT *ilosses)
{
	HRESULT hh;
// ========================================
	vector cDATA;
	hh = Variant2Vector(n*tlen,DATA,&cDATA,"DATA:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cw;
	hh = Variant2Vector(n,w,&cw,"w:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
	double* cProb;
	hh = Variant2Vector(1,*Prob,&cProb,"Prob:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
	double* cGain;
	hh = Variant2Vector(1,*Gain,&cGain,"Gain:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
	double* cLoss;
	hh = Variant2Vector(1,*Loss,&cLoss,"Loss:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cgains;
	hh = Variant2Vector(n,*gains,&cgains,"gains:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector closses;
	hh = Variant2Vector(n,*losses,&closses,"losses:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cigains;
	hh = Variant2Vector(n,*igains,&cigains,"igains:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
	vector cilosses;
	hh = Variant2Vector(n,*ilosses,&cilosses,"ilosses:OmegaProperties");
	if(hh == S_FALSE)
		return S_FALSE;
// ========================================
	OmegaProps(n,tlen,cDATA,cw,R,cProb,cGain,cLoss,cgains,closses,cigains,cilosses);
// ========================================
	SafeArrayRelease(DATA,cDATA,n*tlen);
	SafeArrayRelease(w,cw,n);
	SafeArrayRelease(*Prob,cProb,1);
	SafeArrayRelease(*Gain,cGain,1);
	SafeArrayRelease(*Loss,cLoss,1);
	SafeArrayRelease(*gains,cgains,n);
	SafeArrayRelease(*losses,closses,n);
	SafeArrayRelease(*igains,cigains,n);
	SafeArrayRelease(*ilosses,cilosses,n);
// ========================================
	return S_OK;
}

typedef double  (__stdcall *COMFunc)(VARIANT x);
static double COMFuncE(dimen n,vector x,void* info)
{
	size_t i;
	CComSafeArray<double>*xxx =new CComSafeArray<double>(n);
	for(i=0;i<n;++i)
		xxx->SetAt(i,x[i]);
	VARIANT xx;
	V_VT(&xx) = VT_R8|VT_ARRAY;
	V_ARRAY(&xx)=xxx->m_psa;
	double back= ((COMFunc) info)(xx);
	delete xxx;
	return back;
}
typedef double  (__stdcall *COMDeriv)(VARIANT x,VARIANT* c);
static void COMDerivE(dimen n,vector x,vector c,void* info)
{
	size_t i;
	CComSafeArray<double>*xxx =new CComSafeArray<double>(n);
	for(i=0;i<n;++i)
		xxx->SetAt(i,x[i]);
	VARIANT xx;
	V_VT(&xx) = VT_R8|VT_ARRAY;
	V_ARRAY(&xx)=xxx->m_psa;
	VARIANT cc;
	V_VT(&cc)=VT_R8|VT_ARRAY;
	CComSafeArray<double>*ccc =new CComSafeArray<double>(n);
	V_ARRAY(&cc)=ccc->m_psa;
	((COMDeriv) info)(xx,&cc);
	for(i=0;i<n;++i)
		c[i]=ccc->GetAt(i);
	delete xxx;
	delete ccc;
}
typedef double  (__stdcall *COMHess)(VARIANT x,VARIANT* h);
static void COMHessE(dimen n,vector x,vector h,void* info)
{
	size_t i,nn=n*(n+1)>>1;
	CComSafeArray<double>*xxx =new CComSafeArray<double>(n);
	for(i=0;i<n;++i)
		xxx->SetAt(i,x[i]);
	VARIANT xx;
	V_VT(&xx) = VT_R8|VT_ARRAY;
	V_ARRAY(&xx)=xxx->m_psa;
	VARIANT hh;
	V_VT(&hh)=VT_R8|VT_ARRAY;
	CComSafeArray<double>*hhh =new CComSafeArray<double>(nn);
	V_ARRAY(&hh)=hhh->m_psa;
	((COMHess) info)(xx,&hh);
	for(i=0;i<nn;++i)
		h[i]=hhh->GetAt(i);
	delete xxx;
	delete hhh;
}

extern "C" short OptimiseGeneral(dimen n,vector w,dimen m,vector A,vector L,vector U,vector c,vector H,pUtility Util,pModC ModDeriv,pModQ ModHessian,void *Uinfo,void *Minfo,void *Qinfo);
HRESULT __stdcall COptimiser::OptimiseGeneralBAS(int n,VARIANT *w,int m,VARIANT A,VARIANT L,VARIANT U,VARIANT Util,VARIANT ModDeriv,VARIANT ModHessian,int *retval)
{
	//::MessageBox(NULL,"OptimiseGeneralBAS","Just inside",MB_OK | MB_ICONSTOP);
	//We use VARIANT to pass the function address rather than long because 64 bit windows doesn't handle the longlong VBA type in the COM interface
        HRESULT hh;

// ========================================
        vector cw;
        hh = Variant2Vector(n,*w,&cw,"w:OptimiseGeneral");
        if(hh == S_FALSE)
                return S_FALSE;
        vector cA;
        hh = Array2D2Vector(n*m,A,&cA,"A:OptimiseGeneral");
        if(hh == S_FALSE)
                return S_FALSE;
        vector cL;
        hh = Variant2Vector(n+m,L,&cL,"L:OptimiseGeneral");
        if(hh == S_FALSE)
                return S_FALSE;
        vector cU;
        hh = Variant2Vector(n+m,U,&cU,"U:OptimiseGeneral");
        if(hh == S_FALSE)
                return S_FALSE;
// ========================================
	//::MessageBox(NULL,"OptimiseGeneralBAS","Just before",MB_OK | MB_ICONSTOP);
        *retval=(int)OptimiseGeneral(n,cw,m,cA,cL,cU,0,0,COMFuncE,ModDeriv.ulVal?COMDerivE:0,ModHessian.ulVal?COMHessE:0,(void*)(Util.ulVal),(void*)(ModDeriv.ulVal),(void*)(ModHessian.ulVal));
	//::MessageBox(NULL,"OptimiseGeneralBAS","Just after",MB_OK | MB_ICONSTOP);
// ========================================
        SafeArrayRelease(*w,cw,n);
        SafeArray2DRelease(A,cA);
        SafeArrayRelease(L,cL,n+m);
        SafeArrayRelease(U,cU,n+m);
// ========================================
        return S_OK;
}
