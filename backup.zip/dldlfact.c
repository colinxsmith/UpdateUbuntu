#include "ldefns.h"
#include "constant.h"
/*
	dldlfact( dimen n, sym_matrix S, vector E, undex_vec P )

	computes the LDL' factorization of the symmetric order n matrix
	S, with pivoting if P is non-null.

	on exit S will contain the LDL' factors and E any required
	diagonal modification so that

		P'.S.P + E = L.D.L'

	if P is NULL on entry then P=I
	the returned undex is the number of non-zero elements of E
*/
DLLEXPORT void dldlfactNULL(dimen n, matrix S);
dimen dldlfact(dimen n, sym_matrix S, vector E, undex_vec P)
{
	real	theta;
	real	beta;
	undex	j, nzde=0;
	real	*Sj1;		/*points to S(j,1)*/
	int	pivoting, nullE;
	real	t;


	if(n==0) return 0;

	/*allocate E if not given*/
	if((nullE=(E==0))) E = (double*)malloc(n*sizeof(double));
	/*work out the element bounds*/
	beta = theta = lm_eps;
	pivoting = P!=0;
	Sj1 = S;
	for(j=0;j<n;j++){
		Sj1 += j;
		if((t = disamaxvec( j, Sj1, 0 ))>beta) beta = t;
		if((t=fabs(CD(Sj1[j])))>theta) theta = t;
		if(pivoting) P[j] = j;
		}
	if(n>1) beta /= sqrt(CD(n*n-1));
	if(theta>beta) beta = theta;

	for(j=0,Sj1=S;j<n;){
		real	cjj, *Sii, *Sij, *Sjj;
		undex	i;
		undex	jp1 = j+1;
		Sj1 += j;
		Sjj = Sj1+j;
		if(pivoting){
			undex	q=jp1;
			theta = 0.0;
			for(i=jp1,Sii=Sjj;i<=n;Sii += ++i){
				if((t=fabs(CD(*Sii)))>theta){
					q = i;
					theta = t;
					}
				}
			/*exchange the rows and columns to bring pivot to jj*/
			if( j!=--q ){
				dsmxrcx( n, S, j, q );
				i = P[j];
				P[j] = P[q];		/*record the pivot*/
				P[q] = i;
				}
			}
		Sii = S;
		Sij = Sj1;
		for(i=1;i<=j;){
			*Sij++ /= *Sii;
			Sii += ++i;
			}
		theta = 0.0;
		Sij = Sjj;
		for(i=jp1;i<n;i++){
			Sij += i;
			*Sij -= ddotvec( j, Sj1, Sij-j);
			if((t = fabs(CD(*Sij)))>theta) theta=t;
			}

		/*compute the D element and the modification*/
		cjj = *Sjj;
		t= fabs(CD(cjj));
		theta = theta*theta/beta;
		if(theta<lm_eps) theta=lm_eps;
		if(theta>t) t=theta;
		*Sjj = t;
		nzde += (E[j] = t-cjj)!=0;
		/*update prospective diagonal elements*/
		for(i=j=jp1,Sii=Sij=Sjj;i<n;){
			Sij += i;
			Sii += ++i;
			*Sii -= (*Sij)*(*Sij)/t;
			}
		}
#ifdef	DEBUGW
	printf("nzde = %u\n", nzde );
#endif
	if(nullE) free(E);
	return nzde;
}
void dldlfactNULL(dimen n, sym_matrix S)
{
	dimen i;
	i=dldlfact(n,S,0,0);
	if(i)
		lm_wmsg("dldlfact returned diagonal matrix as well");
}
