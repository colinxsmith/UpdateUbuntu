public class Test2D	
{
	public static double[][] Allocate(int n,int m)
	{
		double [][] y=new double[n][m];
		return y;
	}
	public static double[][] single2double(int n,int m,double[]x)
	{
		int i,j;
		double [][] y=new double[n][m];
		for(i=0;i<n;++i)
		{
			for(j=0;j<m;++j)
			{
				y[i][j]=x[i+n*j];
			}
		}
		return y;
	}
	public static void Print(int n,int m,long[][]y)
	{
		int i,j;
		for(i=0;i<n;++i)
		{
			for(j=0;j<m;++j)
			{
				System.out.println("i "+i+" j "+j+" "+y[i][j]);
			}
		}
	}
	public static void Print(int n,int m,int[][]y)
	{
		int i,j;
		for(i=0;i<n;++i)
		{
			for(j=0;j<m;++j)
			{
				System.out.println("i "+i+" j "+j+" "+y[i][j]);
			}
		}
	}
	public static void Print(int n,int m,String[][]y)
	{
		int i,j;
		for(i=0;i<n;++i)
		{
			for(j=0;j<m;++j)
			{
				System.out.println("i "+i+" j "+j+" "+y[i][j]);
			}
		}
	}
	public static void Print(int n,int m,double[][]y)
	{
		int i,j;
		for(i=0;i<n;++i)
		{
			for(j=0;j<m;++j)
			{
				System.out.println("i "+i+" j "+j+" "+y[i][j]);
			}
		}
	}
	public static double[][] Change(int n,int m,double[][]y)
	{
		int i,j;
		for(i=0;i<n;++i)
		{
			for(j=0;j<m;++j)
			{
				y[i][j]*=2;
			}
		}
		return y;
	}
	public static String[] [] Convert(String[][]y)
	{
		return y;
	}
	public static double[] [] Convert(double[][]y)
	{
		return y;
	}
	public static long[] [] Convert(long[][]y)
	{
		return y;
	}
	public static int[] [] Convert(int[][]y)
	{
		return y;
	}
	public static double[] Convert(double[]y)
	{
		return y;
	}
	public static long[] Convert(long[]y)
	{
		return y;
	}
	public static int[] Convert(int[]y)
	{
		return y;
	}
	public static String[] Convert(String[]y)
	{
		return y;
	}
}
