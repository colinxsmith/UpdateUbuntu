#!/bin/env python
#Colin 13-1-2005
#Semi-definite optimisation interior point algorithm

from safe import OptSemiGen,vec2symm,DOT,combineS
snn=lambda x:x*(x+1)/2

#Maximise the vector [.1,.2,.3,.4] such that risk is 3e-2
n=4
cov=[0.082413214985258054, 0.0085237134681903914, 0.089070270882033536, 0.0052971882656530911, -0.010020600571815669, 0.079791663443914862, 0.016249612103159561, -0.012009661280024869, -0.0056633461502720861, 0.092481531373906162]
g=[-.1,-.2,-.3,-.4]
C=[0]*(snn(n+1))
combineS(n,C,g,C)

m=3
A1=[0]*(snn(n+1))
vec2symm(n,[-1]*n,A1)
A1[-1]=1

A2=[0]*(snn(n+1)-1)+[1]

A3=[0]*(snn(n+1))
combineS(n,cov,[0]*n,A3)
A3[-1]=-3e-2


b=[0,1,0]
A=A1+A2+A3

X=[0]*(snn(n+1))
print OptSemiGen(n+1,m,X,C,A,b,1000)

print X[snn(n+1)-n-1:snn(n+1)-1]

XX=[0]*(snn(n+1))
vec2symm(n,X[snn(n+1)-n-1:snn(n+1)-1],XX)
XX[-1]=1
diff=[XX[i]-X[i] for i in range(len(X))]
print diff,sum(diff)

