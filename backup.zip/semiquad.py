#!/usr/bin/env python
from Opt import *
from SOCPsetup import *
#Do simple risk constrained optimisation and minimum risk optimisation using SOCP and show
#how to combine the setup with Semidefinite programming (at the expense of creating huge
#problems). Similar to what's described in paper by Sunyoung Kim and Masakazu Kojima.
#In principle we can linearise what seems to be a non-convex problem. I.e. I think we can
#set up the constraint xy=0 where x>=0 and y<=0. Also we could do
#ni(ni-1) = 0, sum(ni)=N; xi*ni = xi etc as a way to do a basket constraint
def var(x,Q):
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return pow(dot(x,y),.5)
O=SOCPOPT()#Risk constraint
n=3
Q=[1,.1,2,.1,.1,3]
Rb=.777481
alpha=[.1,.2,.3]
O.Q=Q
O.FactoriseQ(n)
O.b=[-i for i in alpha]
O.m=n
O.A=[1,1,1]+[0,0,0]
O.c=[-1]+[0]
O.A+=O.rQ+[0,0,0]
O.c+=[0]*n+[Rb]
O.nd=[2]+[n+1]
O.n=2
nn=sum(O.nd)
dmx_transpose(n,nn,O.A,O.A)
if O.Opt():print 'FAILED'
else:
    w=[-i for i in O.y]
    print w
    print sum(w),risk(w,Q),dot(alpha,w)

O=SOCPOPT()#Min risk
n=3
Q=[1,.1,2,.1,.1,3]
alpha=[.1,.2,.3]
O.Q=Q
O.FactoriseQ(n)
O.b=[0]*n+[1]
O.m=n+1
O.A=[1,1,1,0]+[0,0,0,0]
O.c=[-1]+[0]
O.A+=O.rQ[:n]+[0]+O.rQ[n:2*n]+[0]+O.rQ[2*n:3*n]+[0]+[0,0,0,1]
O.c+=[0]*(n)+[0]
O.nd=[2]+[n+1]
O.n=2
nn=sum(O.nd)
dmx_transpose(n+1,nn,O.A,O.A)
if O.Opt():print 'FAILED'
else:
    w=[-i for i in O.y[:-1]]
    print w
    print sum(w),risk(w,Q),dot(alpha,w)

O=SOCPOPT()#min risk using semi-definite relaxation with SOCP
n=3
Q=[1,0,2,0,-pow(6,.5)+.1,3]
QQ=[]
X=[]
ij=0
for i in range(n):
    for j in range(i+1):
        if i==j:QQ.append(Q[ij])
        else:QQ.append(Q[ij]*2)
        X.append(w[i]*w[j])
        ij+=1
QQ+=[0]*(n+1)
X+=w+[1]
try:print QQ,X,pow(dot(QQ,X),.5)
except:pass
#Set up min risk problem as a semi-definite problem in SOCP framework
#The weight vector w is embedded in a symmetric matrix W=[w;1][w;1]' so
#that quadratic expressions in w become linear with matrix W treated as
#a vector. All the usual linear constraints in w are applied to the
#second degree terms in W (i.e. a.w=b bacomes a.ww.a=b*b). To make sure
#the optimiser tries to give pos semi def W we must also ensure that
#Wij*Wij<=Wii*Wjj (although this is necessary it's not sufficient). Lastly
#we need to constrain W[-1] to 1. By doing the linear constraints for the
#linear parts of W and also the quadratic parts, we keep W[0] associated
#with first W in last column squared obeying the same relations.

O.m=len(X)
O.b=QQ
O.n=6+3+2+1   #6 cones for ij, 3 for ii, 2 for budget, 1 for X[-1]=1
O.nd=[3]*6+[1]*3+[2]*2+[2]
nn=sum(O.nd)
O.A=[]
O.c=[]
for i in range(4):#Try to keep dual positive semi-definite
    for j in range(i):
        pp=[0]*O.m
        pp[i*(i+3)/2]=1;pp[j*(j+3)/2]=-1
        O.A+=pp
        pp=[0]*O.m
        pp[i*(i+1)/2+j]=2
        O.A+=pp
        pp=[0]*O.m
        pp[i*(i+3)/2]=1;pp[j*(j+3)/2]=1
        O.A+=pp
        O.c+=[0]*3
for i in range(3):
    pp=[0]*O.m
    pp[i*(i+3)/2]=1
    O.A+=pp
    O.c+=[0]
pp=[0]*O.m
for i in range(3):
    pp[6+i]=1
O.A+=pp+[0]*O.m
O.c+=[-1,0]
pp=[1,2,1,2,2,1,2,2,2,1]
O.A+=pp+[0]*O.m
O.c+=[-4,0]
pp=[0]*O.m
pp[-1]=1
O.A+=pp+[0]*O.m
O.c+=[-1,0]
dmx_transpose(O.m,nn,O.A,O.A)
if O.Opt():print 'FAILED'
else:
    W=[-i for i in O.y]
    w=[pow(W[i*(i+3)/2],.5) for i in range(n)]
    print w
    print sum(w),dot(alpha,w)
    print 'should be the same',dot(QQ,W),var(w,Q)
    w=W[6:O.m-1]
    print w
    print sum(w),dot(alpha,w)
    print 'should be the same',dot(QQ,W),var(w,Q)
    #print dot(QQ,X),dot(QQ,W)
    print '_'*30
    print 'Checking it gets what we expect'
#    for i in range(O.m):
#        print '%20.12e %20.12e'%(X[i],W[i])
#    print eigen(n,X)[0]
    print eigen(n+1,W)[0]
    for i in range(4):
        print 'diag %20.12e %20.12e'%(W[i*(i+3)/2],sqr(W[6+i]))
        for j in range(i):
            print '%20.12e %20.12e %20.12e'%(sqr(W[i*(i+1)/2+j]),W[i*(i+3)/2]*W[j*(j+3)/2],sqr(W[6+i]*W[6+j]))
    print '_'*30
print eigen(n,Q)[0]

        
    


