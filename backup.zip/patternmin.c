#include<math.h>
#include"ldefns.h"
#include"constant.h"
#include<stdio.h>
#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#endif
 //Repeat the definition in baseoptimise.h

#if defined (__SYSNT__) || defined(MSDOSS)
#define MYSTDCALL //__stdcall
#else
#define MYSTDCALL 
#endif

typedef double (MYSTDCALL *pUtility)(unsigned long nvab,double* x,void* info);

//_________________________________________

static void printx(size_t n,vector a)
{
    size_t i=0;
    while(n--)
	{
		printf("%21.13e ",*a++);
		if(i++%5==4)printf("\n");
    }
	printf("\n");
}
DLLEXPORT void patternmin(unsigned long n,double *x,double *step,
	double *f,double scale,short iprint,short icon,
	unsigned long maxit,double *w,pUtility calcfx,void*info)
{
    double d1;

    double a,b,d__;
    unsigned long i,j,k;
    double da,db,dc,dd,fa,fb,fc,di,fi,dl;
    double fp;
    short is,ind,inn,isgrad;
    double aaa;
    unsigned long jj,jjj,jil,ixp;
    double sum,dacc,dmag;
    unsigned long nfcc;
    double dmax__,scer,ddmag,fkeep,fhold,ddmax;
    unsigned long iline,idirn,iterc,itone;
    double fprev;
	vector wdir,xlowest=w+n*(n+3);
	double flowest;



    ddmag = scale * .1;
    scer = .05 / scale;
    jj = n * n + n;
    jjj = jj + n;
    nfcc = 1;
    ind = 1;
    inn = 1;
	dsetvec(n,scale,w);
	for(i=0,wdir=w+n;i<n;++i,wdir+=n)
	{
		dsetvec(n,fabs(step[i]),wdir);
		wdir[i]=0;
	}
    iterc = 1;
    isgrad = 2;
    *f=calcfx(n,x,info);
	flowest=*f;
	dcopyvec(n,x,xlowest);
    fkeep = fabs(*f) + fabs(*f);
L5:
    itone = 1;
    fp = *f;
    sum = 0.;
	dcopyvec(n,x,w+jj);
    idirn = n;
    iline = 1;
L7:
    dmax__ = w[iline-1];
    dacc = dmax(lm_rooteps,dmax__ * scer);
    dmag = dmin(ddmag,dmax__*.1);
    dmag = dmax(dmag,dacc*20);
    ddmax = dmag * 10.;
    switch(itone) 
	{
	case 1:  goto L70;
	case 2:  goto L70;
	case 3:  goto L71;
    }
L70:
    dl = 0.;
    d__ = dmag;
    fprev = *f;
    is = 5;
    fa = *f;
    da = dl;
L8:
    dd = d__ - dl;
    dl = d__;
L58:
	daxpyvec(n,dd,w+idirn,x);
    *f=calcfx(n,x,info);
	if(*f < flowest)
	{
		flowest=*f;
		dcopyvec(n,x,xlowest);
	}
    ++nfcc;
//	if(iprint) printf("delt %-.14e At func eval %ld,f %-.14e\n",dd,nfcc,*f);
//	if(iprint) printx(n,x);
    switch(is) 
	{
	case 1:  goto L10;
	case 2:  goto L11;
	case 3:  goto L12;
	case 4:  goto L13;
	case 5:  goto L14;
	case 6:  goto L96;
    }
L14:
    if(*f < fa) 
	{
		fb = *f;
		db = d__;
		goto L21;
    } 
	else if(*f==fa) 
	{
		if(fabs(d__) <= dmax__) 
		{
			d__ += d__;
			goto L8;
		} 
		else 
		{
			if(iprint)printf("Pattern search: maximum change does not alter the function\n");
			*f=flowest;
			dcopyvec(n,xlowest,x);
			return;
		}
    }
    fb = fa;
    db = da;
    fa = *f;
    da = d__;
L21:
    switch(isgrad)
	{
		case 1:  goto L83;
		case 2:  goto L23;
    }
L23:
    d__ = db + db - da;
    is = 1;
    goto L8;
L83:
    d__ = (da + db - (fa - fb) / (da - db)) * .5;
    is = 4;
    if((da - d__) * (d__ - db) >= 0.) 
	{
		goto L8;
    } 
L25:
    is = 1;
    if(fabs(d__-db)<=ddmax) 
	{
		goto L8;
    } 
L26:
    d__ = db + dsign(ddmax,(db-da));
    is = 1;
    ddmax += ddmax;
    ddmag += ddmag;
    if(ddmax > dmax__) 
	{
	    ddmax = dmax__;
	}
    goto L8;
L13:
    if(*f >= fa) 
	{
		goto L23;
    } 
L28:
    fc = fb;
    dc = db;
L29:
    fb = *f;
    db = d__;
    goto L30;
L12:
    if(*f <= fb)
	{
		goto L28;
    }
    fa = *f;
    da = d__;
    goto L30;
L11:
    if(*f >= fb)
	{
		goto L10;
    }
    fa = fb;
    da = db;
    goto L29;
L71:
    dl = 1.;
    ddmax = 5.;
    fa = fp;
    da = -1.;
    fb = fhold;
    db = 0.;
    d__ = 1.;
L10:
    fc = *f;
    dc = d__;
L30:
/*	{	//Parabolic fit
		double AA = (fb*(dc-da)+fa*(db-dc)+fc*(da-db))/(db-da)/(dc-da)/(db-dc);
		double BB = (fb-fa)/(db-da)-AA*(db+da);
		double CC=fa-da*BB-da*da*AA;
		double xmin=-0.5*BB/AA;
		double fmin=CC-0.25*BB*BB/AA;
	}*/
    a = (db - dc) * (fa - fc);
    b = (dc - da) * (fb - fc);
    if((a + b) * (da - dc) <= 0) //It really must be 0
	{
		fa = fb;
		da = db;
		fb = fc;
		db = dc;
		goto L26;
    }
	else 
	{
		d__ = (a * (db + dc) + b * (da + dc)) * .5 / (a + b);
		di = db;
		fi = fb;
//		if(iprint)printf("fi from fb\n");
		if(fb <= fc)
		{
			goto L44;
		} 
    }
    di = dc;
    fi = fc;
//	if(iprint)printf("fi from fc\n");
L44:
    switch(itone) 
	{
		case 1:  goto L86;
		case 2:  goto L86;
		case 3:  goto L85;
    }
L85:
    itone = 2;
    goto L45;
L86:
    if(fabs(d__-di)<=dacc) 
	{
		goto L41;
    }
    if(fabs(d__-di)<=fabs(d__)*.03) 
	{
		goto L41;
    }
L45:
    if((da - dc) * (dc - d__) < 0)
	{
		goto L47;
    }
    fa = fb;
    da = db;
    fb = fc;
    db = dc;
    goto L25;
L47:
    is = 2;
    if((db - d__) * (d__ - dc) < 0)
	{
		is = 3;
    }
    goto L8;
L41:
    *f = fi;
//	if(iprint) printf("%ld set from fi %-.14e\n",nfcc,*f);
    d__ = di - dl;
    dd = sqrt((dc - db) * (dc - da) * (da - db) / (a + b));
	daxpyvec(n,d__,w+idirn,x);
//	if(iprint) printf("delt %-.14e fi  = %-.14e f(x) = %-.14e\n",d__,fi,calcfx(n,x,info));
//	if(iprint) printx(n,x);
	dscalvec(n,dd,w+idirn);
	idirn+=n;
	if(dd==0) goto L78;
    w[iline-1] /= dd;
    ++iline;
    if(iprint != 1) 
	{
		goto L51;
    }
L50:
    printf("iteration %3ld,%15ld function values\tf = %-.14e\n",iterc,nfcc,*f);
	printx(n,x);
    switch(iprint)
	{
		case 1:  goto L51;
		case 2:  goto L53;
    }
L51:
    switch(itone) 
	{
		case 1:  goto L55;
		case 2:  goto L38;
    }
L55:
    if((fprev - *f) < sum)
	{
		if(dd==0) goto L78;
		goto L94;
    }
    sum = fprev - *f;
    jil = iline;
L94:
    if(idirn < jj) 
	{
		goto L7;
    }
    switch(ind)
	{
		case 1:  goto L92;
		case 2:  goto L72;
    }
L92:
    fhold = *f;
//	if(iprint) printf("Set fhold at %ld f = %-.14e\n",nfcc,fhold);
    is = 6;
//	if(iprint) printf("fhold  = %-.14e f(x) = %-.14e\n",fhold,calcfx(n,x,info));
//	if(iprint) printx(n,x);
	dsubvec(n,x,w+jj,w+jj);
    dd = 1.;
    goto L58;
L96:
    switch(ind) 
	{
		case 1:  goto L112;
		case 2:  goto L87;
    }
L112:
    if(fp <= *f)
	{
		goto L37;
    }
    d1 = fp - *f;
    d__ = (fp + *f - fhold * 2.) * 2. / (d1 * d1);
    d1 = fp - fhold - sum;
    if(d__ * (d1 * d1) >=sum)
	{
		goto L37;
    }
L87:
    j = jil * n + 1;
    if(j<=jj) 
	{
		dcopyvec(jj-j+1,w+j-1,w+j-1-n);
		dcopyvec(n-jil+1,w+jil-1,w+jil-2);
	}
    idirn -= n;
    itone = 3;
    aaa = 0.;
	dcopyvec(n,w+jj,w+idirn);
    for(i = 0,k=idirn,ixp=jj; i <n; ++i,++ixp,++k)
	{
		if(aaa < (d1=fabs(w[k]/step[i])))
		{
			aaa = dmax(lm_eps,d1);
		}
    }
    ddmag = 1.;
    w[n-1] = scale / aaa;
    iline = n;
    goto L7;
L37:
    aaa = 0.;
    *f = fhold;
//	if(iprint) printf("%ld set from fhold %-.14e\n",nfcc,*f);
	dsubvec(n,x,w+jj,x);
//	if(iprint) printx(n,x);
//	if(iprint) printf("fhold = %-.14e f(x) = %-.14e\n",fhold,calcfx(n,x,info));
    for(i = 0,ixp=jj; i <n; ++i,++ixp)
	{
		if(aaa*fabs(step[i]) < fabs(w[ixp]))
		{
			aaa = fabs(w[ixp]/step[i]);
		}
    }
    goto L72;
L38:
    aaa *= di + 1.;
    switch(ind)
	{
		case 1:  goto L72;
		case 2:  goto L106;
    }
L72:
    if(iprint  >= 2) 
	{
		goto L50;
    } 
L53:
    switch(ind) {
	case 1:  goto L109;
	case 2:  goto L88;
    }
L109:
    if(aaa > 1)
	{
		goto L76;
    }
//	printf("Stop if icon is 1; f=%20.8e\n",flowest);
	if(icon==1)
	{
		*f=flowest;
		dcopyvec(n,xlowest,x);
		return;
	}
    ind = 2;
    switch(inn) 
	{
		case 1:  goto L100;
		case 2:  goto L101;
    }
L100:
    inn = 2;
	dcopyvec(n,x,w+jjj);
	daxpyvec(n,10,step,x);
    fkeep = *f;
    *f=calcfx(n,x,info);
	if(*f < flowest)
	{
		flowest=*f;
		dcopyvec(n,x,xlowest);
	}
    ++nfcc;
    ddmag = 0.;
    goto L108;
L76:
    if(*f<fp)
	{
		goto L35;
    }
L78:
    if(iprint)printf("Pattern search: cannot find a lower value for the function\n");
	*f=flowest;
	dcopyvec(n,xlowest,x);
    return;
L88:
    ind = 1;
L35:
    ddmag = sqrt(fp - *f) * .4;
    isgrad = 1;
L108:
    ++iterc;
    if(iterc <= maxit)
	{
		goto L5;
    }
    printf("%5ld,iterations completed by pattern search.\n",maxit);
	*f=flowest;
	dcopyvec(n,xlowest,x);
    return;
L101:
    jil = 1;
    fp = fkeep;
    if(*f<fkeep) 
	{
		goto L105;
    } 
    jil = 2;
    fp = *f;
    *f = fkeep;
//	if(iprint) printf("%ld set from fkeep %-.14e\n",nfcc,*f);
L105:
    for(i = 0,ixp=jj; i < n; ++i,++ixp)
	{
		k = ixp + n;
		switch(jil) 
		{
		case 1:
			w[ixp] = w[k];
			break;
		case 2:  
			w[ixp] = x[i-1];
			x[i] = w[k];
			break;
		}
    }
    jil = 2;
    goto L92;
L106:
    if(aaa > 1) 
	{
		inn = 1;
		goto L35;
    }
	*f=flowest;
	dcopyvec(n,xlowest,x);
}

DLLEXPORT void setunitHess(size_t n,vector H)
{
	/*For the Hessian as used in pattern6. (netlib's upper format.)*/
	dzerovec((n*(n+1)>>1),H);
	while(n--)
	{
		*H=1;
		H+=n+1;
	}
}
DLLEXPORT void pattern6(size_t n, vector x, double *f, 
	vector g, vector hess, pUtility funct, void*info,vector w, double 
	dfn, vector xm, double hh, double eps, unsigned long mode, 
	unsigned long maxfn, unsigned long iprint, int *iexit,int repeat)
{
 /*

	x dimension n input guess of answer varaibles
	f lowest function value is put here
	g space for gradients dimension n
	hess space for hessian estimate dimension n*(n+1)/2
	w working space dimension 4*n

	dfn >0 dfn is the likely reduction in function value
	dfn =0 estimate of minimum function value is given in *f
	dfn <0 -dfn times *f is an estimate of reduction in function value

	xm dimension n xm[i] is approximate magnitude of expected x[i]
	hh the interval used in calculating numercial gradients
	eps accuracy required is eps*xm[i] for x[i]

	mode=1 initial hessian is unit matrix
	mode=2 initial hessian given in hess
	mode=3 initial hessian given in hess in product form (in the way it is outputted by pattern6)

	maxfn maximum allowed function calls
	iprint controls printing (0 no printing)
	iexit 0 (if mode is 2 hessian estimate is not pos def) 1 (normal exit change in x[i] < xm[i]*eps) 2 rounding error problem, 3 function called maxfn times

	repeat 1 update solution with lowest f found during derivative estimation
*/

    double zero = 0.;
    double half = .5;
    double one = 1.;
    double two = 2.;


    integer i, j, k;
    double z, f1, f2;
    integer i1, n1;
    double df;
    integer ib;
    double ff;
    integer ij, ik, jk, nn, is, np, iu, iv;
    double zz, gs0;
    integer ifn=0;
    double dgs, sig;
    integer itn, int__;
    double gys, tot, dmin__, aeps;
    integer link, idiff;
    double alpha;

	vector xkeep=(vector)malloc(n*sizeof(*xkeep));
	vector xkeeplocal=(vector)malloc(n*sizeof(*xkeeplocal));
	vector gradkeep=(vector)malloc((n+1)*sizeof(*gradkeep));
	double fkeep,fkeeplocal=lm_max;
    --xm;
    --w;
    --hess;
    --g;
    --x;

    np = n + 1;
    n1 = n - 1;
    nn = n * np / 2;
    is = n;
    iu = n;
    iv = n + n;
    ib = iv + n;
    idiff = 1;
	*iexit = 0;
	if (mode == 3)//Use input hessian
	{
		goto L15;
	}
	if (mode == 2) 
	{
		goto L10;
    }
	/*ij = nn + 1;
	for (i = 1; i <= n; ++i) 
	{
		for (j = 1; j <= i; ++j)
		{
			--ij;
			hess[ij] = zero;
		}
		hess[ij] = one;
	}*/
	setunitHess(n,hess+1);
	goto L15;
L10:
	ij = 1;
	for (i = 2; i <= n; ++i)
	{
		z = hess[ij];
		if (z <= zero)
		{
			free(xkeep);
			free(xkeeplocal);
			free(gradkeep);
			return;
		}
		++ij;
		i1 = ij;
		for (j = i; j <= n; ++j)
		{
			zz = hess[ij];
			hess[ij] /= z;
			jk = ij;
			ik = i1;
			for (k = i; k <= j; ++k)
			{
				jk = jk + np - k;
				hess[jk] -= hess[ik] * zz;
				++ik;
			}
			++ij;
		}
	}
	if (hess[ij] <= zero)
	{
		free(xkeep);
		free(xkeeplocal);
		free(gradkeep);
		return;
	}
L15:
	ij = np;
	dmin__ = hess[1];
	for (i = 2; i <= n; ++i) 
	{
		if (hess[ij] < dmin__)
			dmin__ = hess[ij];
		ij = ij + np - i;
	}
	if (dmin__ <= zero)
	{
		free(xkeep);
		free(xkeeplocal);
		free(gradkeep);
		return;
	}
	z = *f;
	itn = 0;
	//printx(n*(n+1)/2,hess+1);
	fkeep=*f = funct(n,&x[1], info);
	if(iprint)
		printf("Set fkeep %22.15e\n",fkeep);
	dcopyvec(n,x+1,xkeep);
	ifn++;
	df = dfn;
	if (dfn == zero) 
	{
		df = *f - z;
	}
	if (dfn < zero)
	{
		df = fabs(df * *f);
	}
	if (df <= zero)
	{
		df = one;
	}
L17:
	if(fkeeplocal<*f)
	{
		if(iprint)
			printf("Use fkeeplocal (from %22.15e to %22.15e) and reset Hessian\n",*f,fkeeplocal);
		dcopyvec(n,xkeeplocal,x+1);
		setunitHess(n,hess+1);
		*f=fkeeplocal;
		idiff=1;
	}
	else if(fkeep<*f)
	{
		if(iprint)
			printf("Use fkeep (from %22.15e to %22.15e) and reset Hessian\n",*f,fkeep);
		dcopyvec(n,xkeep,x+1);
		setunitHess(n,hess+1);
		*f=fkeep;
		idiff=1;
	}
	dcopyvec(n,x+1,w+1);
	link = 1;
	if (idiff  <= 1)
	{
		goto L100;
	} else
	{
		goto L110;
	}
L18:
	if (ifn >= maxfn)
	{
		goto L90;
	}
L20:
	if (iprint == 0)
	{
		goto L21;
	}
	if (itn % iprint != 0)
	{
		goto L21;
	}
	/* 	write (*,1001) itn, ifn */
	/* 1001 format (1x,'itn = ',i5,' ifn = ',i5) */
	/* 	write (*,1002) f */
	/* 1002 format (1x,'f = ',e15.7) */
	printf("itn = %5ld ifn = %5ld\nf = %22.15e\n",itn,ifn,*f);
	if (iprint < 0) 
	{
		goto L21;
	}
	/* 	write (*,1003) (x(i), i = 1, n) */
	/* 1003 format (1x,'x = ',4e15.7 / (5x, 4e15.7)) */
	/* 	write (*,1004) (g(i), i = 1, n) */
	/* 1004 format (1x,'g = ',4e15.7 / (5x, 4e15.7)) */
	printx(n,x+1);
	printx(n,g+1);
	/*    for(i=1;i <= n;++i)
	printf("%20.15e ",x[i]);
	printf("\n");
    for(i=1;i <= n;++i)
		printf("%20.15e ",g[i]);
	printf("\n");*/
L21:
	++itn;
	w[1] = -g[1];
	for (i = 2; i <= n; ++i)
	{
		ij = i;
		i1 = i - 1;
		z = -g[i];
		for (j = 1; j <= i1; ++j) 
		{
			z -= hess[ij] * w[j];
			ij = ij + n - j;
		}
		w[i] = z;
	}
	w[is + n] = w[n] / hess[nn];
	ij = nn;
	for (i = 1; i <= n1; ++i)
	{
		--ij;
		z = zero;
		for (j = 1; j <= i; ++j)
		{
			z += hess[ij] * w[is + np - j];
			--ij;
		}
		w[is + n - i] = w[n - i] / hess[ij] - z;
	}
	z = zero;
	gs0 = zero;
	for (i = 1; i <= n; ++i)
	{
		if (z * xm[i] < fabs(w[is + i])) 
			z = (fabs(w[is + i])) / xm[i];
		gs0 += g[i] * w[is + i];
	}
	aeps = eps / z;
	*iexit = 2;
	if (gs0 >= zero)
	{
		goto L92;
	}
	alpha = -two * df / gs0;
	if (alpha > one)
	{
		alpha = one;
	}
	ff = *f;
	tot = zero;
	int__ = 0;
	*iexit = 1;
L30:
	if (ifn >= maxfn)
	{
		goto L90;
	}
	for (i = 1; i <= n; ++i)
	{
		w[i] = x[i] + alpha * w[is + i];
	}
	f1 = funct(n,&w[1], info);
	++ifn;
	if (f1 >= *f)
	{
		goto L40;
	}
	f2 = *f;
	tot += alpha;
L32:
	dcopyvec(n,w+1,x+1);
	*f = f1;
	if (int__< 1) 
	{
		goto L35;
	} else if (int__== 1) 
	{
		goto L49;
	} 
	else 
	{
		goto L50;
	}
L35:
	if (ifn >= maxfn)
	{
		goto L90;
	}
	for (i = 1; i <= n; ++i)
	{
		w[i] = x[i] + alpha * w[is + i];
	}
	f1 = funct(n,&w[1], info);
	++ifn;
	if (f1 >= *f)
	{
		goto L50;
	}
	if (f1 + f2 >= *f + *f && f1 * 7. + f2 * 5. > *f * 12.) 
	{
		int__ = 2;
	}
	tot += alpha;
	alpha = two * alpha;
	goto L32;
L40:
	if (alpha < aeps)
	{
		goto L92;
	}
	if (ifn >= maxfn)
	{
		goto L90;
	}
	alpha = half * alpha;
	for (i = 1; i <= n; ++i)
	{
		w[i] = x[i] + alpha * w[is + i];
	}
	f2 = funct(n,&w[1], info);
	++ifn;
	if (f2 >= *f)
	{
		goto L45;
	}
	tot += alpha;
	*f = f2;
	dcopyvec(n,w+1,x+1);
	goto L49;
L45:
	z = .1;
	if (f1 + *f > f2 + f2) 
	{
		z = one + half * (*f - f1) / (*f + f1 - f2 - f2);
	}
	if (z < .1) 
	{
		z = .1;
	}
	alpha = z * alpha;
	int__ = 1;
	goto L30;
L49:
	if (tot < aeps)
	{
		goto L92;
	}
L50:
	alpha = tot;
	for (i = 1; i <= n; ++i)
	{
		w[i] = x[i];
		w[ib + i] = g[i];
	}
	link = 2;
	if (idiff  <= 1)
	{
		goto L100;
	}
	else 
	{
		goto L110;
	}
L54:
	if (ifn >= maxfn)
	{
		goto L90;
	}
	gys = zero;
	for (i = 1; i <= n; ++i)
	{
		w[i] = w[ib + i];
		gys += g[i] * w[is + i];
	}
	df = ff - *f;
	dgs = gys - gs0;
	if (dgs <= zero)
	{
		goto L20;
	}
	link = 1;
	if (dgs + alpha * gs0 > zero)
	{
		goto L52;
	}
	for (i = 1; i <= n; ++i)
	{
		w[iu + i] = g[i] - w[i];
	}
	sig = one / (alpha * dgs);
	goto L70;
L52:
	zz = alpha / (dgs - alpha * gs0);
	z = dgs * zz - one;
	for (i = 1; i <= n; ++i)
	{
		w[iu + i] = z * w[i] + g[i];
	}
	sig = one / (zz * dgs * dgs);
	goto L70;
L60:
	link = 2;
	for (i = 1; i <= n; ++i)
	{
		w[iu + i] = w[i];
	}
	if (dgs + alpha * gs0 > zero)
	{
		goto L62;
	}
	sig = one / gs0;
	goto L70;
L62:
	sig = -zz;
L70:
	w[iv + 1] = w[iu + 1];
	for (i = 2; i <= n; ++i)
	{
		ij = i;
		i1 = i - 1;
		z = w[iu + i];
		for (j = 1; j <= i1; ++j) 
		{
			z -= hess[ij] * w[iv + j];
			ij = ij + n - j;
		}
		w[iv + i] = z;
	}
	ij = 1;
	for (i = 1; i <= n; ++i)
	{
		z = hess[ij] + sig * w[iv + i] * w[iv + i];
		if (z <= zero) 
		{
			z = dmin__;
		}
		if (z < dmin__)
		{
			dmin__ = z;
		}
		hess[ij] = z;
		w[ib + i] = w[iv + i] * sig / z;
		sig -= w[ib + i] * w[ib + i] * z;
		ij = ij + np - i;
	}
	ij = 1;
	for (i = 1; i <= n1; ++i)
	{
		++ij;
		i1 = i + 1;
		for (j = i1; j <= n; ++j)
		{
			w[iu + j] -= hess[ij] * w[iv + i];
			hess[ij] += w[ib + i] * w[iu + j];
			++ij;
		}
	}
	switch (link) {
	case 1:  goto L60;
	case 2:  goto L20;
	}
L90:
	*iexit = 3;
	goto L94;
L92:
	if (idiff == 2) 
	{
		goto L94;
	}
	idiff = 2;
	goto L17;
L94:
	if(fkeep<*f&&*iexit==1)
		goto L17;
	if (iprint == 0) 
	{
		free(xkeep);
		free(xkeeplocal);
		free(gradkeep);
		return;
	}
	/* 	write (*,1005) itn, ifn, iexit */
	/* 1005 format (1x,'itn = ',i5, ' ifn = ',i5,' iexit = ',i5) */
	/* 	write (*,1002) f */
	/* 	write (*,1003) (x(i), i = 1, n) */
	/* 	write (*,1004) (g(i), i = 1, n) */
	printf("Final f = %22.15e with x and g, exit code %d\n",*f,*iexit);
	printx(n,x+1);
	printx(n,g+1);
	/*    for(i=1;i <= n;++i)
	printf("%20.15e ",x[i]);
	printf("\n");
	for(i=1;i <= n;++i)
	printf("%20.15e ",g[i]);
	printf("\n");*/
	free(xkeep);
	free(xkeeplocal);
	free(gradkeep);
	return;
L100:
	if(iprint)
	{
		printf("One-sided calculation of derivatives link %d\n",link);
	}
	if(fkeep>*f)
	{
		fkeep=*f;
		dcopyvec(n,x+1,xkeep);
		if(iprint)
			printf("Set fkeep %22.15e\n",fkeep);
	}
	fkeeplocal=*f;
	*gradkeep=*f;
	dcopyvec(n,x+1,xkeeplocal);
	for (i = 1; i <= n; ++i)
	{
		z = hh * xm[i];
		w[i] += z;
		f1 = funct(n,&w[1], info);ifn++;
		if(f1<fkeeplocal)
		{
			fkeeplocal=f1;
			if(iprint)
			printf("Set fkeeplocal %22.15e\n",fkeeplocal);
			dcopyvec(n,w+1,xkeeplocal);
		}
		if(f1<fkeep)
		{
			fkeep=f1;
			if(iprint)
			printf("Set fkeep %22.15e\n",fkeep);
			dcopyvec(n,w+1,xkeep);
			if(repeat)
			{
				dcopyvec(n,w+1,x+1);
				break;
			}
		}
		g[i] = (f1 - *f) / z;
		gradkeep[i]=f1;
		w[i] -= z;
	}
	while(repeat&&fkeep<*f)
	{
		if(iprint)
		{
			printf("One-sided calculation of derivatives repeat link %d\n",link);
		}
		*f=fkeep;
		dcopyvec(n,xkeep,w+1);
		setunitHess(n,hess+1);
		fkeeplocal=*f;
		*gradkeep=*f;
		dcopyvec(n,x+1,xkeeplocal);
		for (i = 1; i <= n; ++i)
		{
			z = hh * xm[i];
			w[i] += z;
			f1 = funct(n,&w[1], info);ifn++;
			if(f1<fkeep)
			{
				fkeep=f1;
				dcopyvec(n,w+1,xkeep);
				dcopyvec(n,w+1,x+1);
				break;
			}
			g[i] = (f1 - *f) / z;
			gradkeep[i]=f1;
			w[i] -= z;
		}
	}
	switch (link) 
	{
	case 1:  goto L18;
	case 2:  goto L54;
	}
L110:
	if(iprint)
	{
		printf("Two-sided calculation of derivatives link %d\n",link);
	}
	if(fkeep>*f)
	{
		fkeep=*f;
		dcopyvec(n,x+1,xkeep);
		if(iprint)
			printf("Set fkeep %22.15e\n",fkeep);
	}
	fkeeplocal=*f;
	dcopyvec(n,x+1,xkeeplocal);
	for (i = 1; i <= n; ++i)
	{
		z = hh * xm[i];
		w[i] += z;
		if(link==1 && *gradkeep==*f)
		{
			f1=gradkeep[i];
			if(iprint)
				printf("Don't repeat one-sided part of calculation f=%22.15e\n",f1);
		}
		else
		{
			f1 = funct(n,&w[1], info);ifn++;
		}
		if(f1<fkeeplocal)
		{
			fkeeplocal=f1;
			if(iprint)
				printf("Set fkeeplocal %22.15e\n",fkeeplocal);
			dcopyvec(n,w+1,xkeeplocal);
		}
		if(f1<fkeep)
		{
			fkeep=f1;
			if(iprint)
			printf("Set fkeep %22.15e\n",fkeep);
			dcopyvec(n,w+1,xkeep);
			if(repeat)
			{
				dcopyvec(n,w+1,x+1);
				break;
			}
		}
		w[i] = w[i] - z - z;
		f2 = funct(n,&w[1], info);ifn++;
		if(f2<fkeeplocal)
		{
			fkeeplocal=f2;
			if(iprint)
			printf("Set fkeeplocal %22.15e\n",fkeeplocal);
			dcopyvec(n,w+1,xkeeplocal);
		}
		if(f2<fkeep)
		{
			fkeep=f2;
			if(iprint)
			printf("Set fkeep %22.15e\n",fkeep);
			dcopyvec(n,w+1,xkeep);
			if(repeat)
			{
				dcopyvec(n,w+1,x+1);
				break;
			}
		}
		g[i] = (f1 - f2) / (two * z);
		w[i] += z;
	}
	while(repeat&&fkeep<*f)
	{
		*f=fkeep;
		if(iprint)
		{
			printf("Two-sided calculation of derivatives repeat link %d\n",link);
		}
		dcopyvec(n,xkeep,w+1);
		setunitHess(n,hess+1);
		for (i = 1; i <= n; ++i)
		{
			z = hh * xm[i];
			w[i] += z;
			f1 = funct(n,&w[1], info);ifn++;
			if(f1<fkeep)
			{
				fkeep=f1;
				dcopyvec(n,w+1,xkeep);
				dcopyvec(n,w+1,x+1);
				break;
			}
			w[i] = w[i] - z - z;
			f2 = funct(n,&w[1], info);ifn++;
			if(f2<fkeep)
			{
				fkeep=f2;
				dcopyvec(n,w+1,xkeep);
				dcopyvec(n,w+1,x+1);
				break;
			}
			g[i] = (f1 - f2) / (two * z);
			w[i] += z;
		}
	}
	switch (link)
	{
	case 1:  goto L18;
	case 2:  goto L54;
	}
	if(iprint)printf("free at the end\n");
	free(xkeep);
	free(xkeeplocal);
	free(gradkeep);
}
