#include "ldefns.h"


int	_dsmxmpd_check(dimen n, sym_matrix F, ldl_matrix L, short_vec P, sym_matrix S, short msglvl )

{
	dsmxmpd_info_rec	info;
	int was_fixed = 0;
	vector		w = new double[n];
	dsmxmpd( n, F, L, w, P, &info );
	if(msglvl)
	{
//		if(S&&L!=F)
//			lm_wmsg((char*)"dmsxmpd finished after %10.4lg\" 1b=%u 2b=%u #c=%u MaxC=%lg ||err||=%lg",
//				clockit(0), info.oneb, info.twob, info.ncor, info.maxc, denrm2vec((n*(n+1))>>1, F, S));
//		else
//			lm_wmsg((char*)"dmsxmpd finished after %10.4lg\" 1b=%u 2b=%u #c=%u MaxC=%lg",
//				clockit(0), info.oneb, info.twob, info.ncor, info.maxc );
		lm_wmsg((char*)"  min/max Abs = %lg/%lg min/max = %lg/%lg", info.minA, info.maxA, info.minE, info.maxE );
	}
/*	while(info.ncor!=0 && info.twob > 0)
	{
		if(msglvl > 1)
			lm_wmsg((char*)"Fix again");
		was_fixed = 1;
		dsmxmpd( n, F, L, w, P, &info );
		if(msglvl)
		{
//			if(S&&L!=F)
//				lm_wmsg((char*)"dmsxmpd finished after %10.4lg\" 1b=%u 2b=%u #c=%u MaxC=%lg ||err||=%lg",
//					clockit(0), info.oneb, info.twob, info.ncor, info.maxc, denrm2vec((n*(n+1))>>1, F, S));
//			else
//				lm_wmsg((char*)"dmsxmpd finished after %10.4lg\" 1b=%u 2b=%u #c=%u MaxC=%lg",
//					clockit(0), info.oneb, info.twob, info.ncor, info.maxc );
			lm_wmsg((char*)"  min/max Abs = %lg/%lg min/max = %lg/%lg", info.minA, info.maxA, info.minE, info.maxE );
		}
	}*/
	delete[] w;
	return (info.ncor!=0 || was_fixed);
}
