#include "baseoptimise.h"
static integer c__1 = 1;
/*
	daddcon updates the factorization of the matrix of
	constraints in the working set,  a(free) * (z y) = (0 t)
	if the int argument modfyr  is true, the cholesky
	factorization of the projected hessian, r(t)*r, is updated also
	there are three separate cases to consider (although each case
	shares code with another)..

	(1)	a free variable becomes fixed on one of its bounds when there
		are already some general constraints in the working set
	(2)	a free variable becomes fixed on one of its bounds when there
		are only bound constraints in the working set
	(3)	a general constraint (corresponding to row  iadd  of  a) is
		added to the working set
	in cases (1) and (2), we assume that  kfree(ifix) = jadd
	in all cases,  jadd  is the index of the constraint being added
	if there are no general constraints in the working set,  the
	matrix  q = (z y)  is the identity and will not be touched
	if modfyr  is true and  ncolz is greater than one on entry,
	cslast and snlast contain the last of the sequence of givens
	rotations used to reduce the intermediate upper-hessenberg matrix
	to upper-triangular form.  these elements are needed by qpcore
	if  modfyg  is true on entry, the column transformations are
	applied to the vector  q(t)grad,  stored in  qtg
*/
short Base_Optimise::daddcon(int modfyg, int modfyr, int orthog, logical *unitq, integer *ifix, integer *iadd, integer *jadd, integer *nactiv, integer *ncolr, integer *ncolz, integer *nfree, dimen n, integer *Nq, integer *nrowa, integer *Nrowrt, short_vec kfree, real *condmx, real *cslast, real *snlast, real *a, real *qtg, real *rt, real *zy, real *wrk1, real *wrk2)
{

    const real zero = 0.;

    integer a_dim1, a_offset, rt_dim1, rt_offset, zy_dim1, zy_offset, i__1;

    real beta, cond;
    integer nelm, inct, nact1;
    real d;
    integer i, j, k;
    integer ldiag;
    int ifail;
    real delta;
    real dtnew;
    integer iswap;
    integer lrowr, nfree1= 0, ncolz1;
    real cs, condbd, sn;
    real tdtmin, tdtmax;
    integer itrans, kp1;

    --wrk2;
    --wrk1;
    zy_dim1 = *Nq;
    zy_offset = zy_dim1 + 1;
    zy -= zy_offset;
    rt_dim1 = *Nrowrt;
    rt_offset = rt_dim1 + 1;
    rt -= rt_offset;
    --qtg;
    a_dim1 = *nrowa;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --kfree;

	/*
	if the condition estimator of the updated factors is greater than
	condbd,  a warning message is printed
	*/
    condbd = pow(lm_eps, -0.9);
    ncolz1 = *ncolz - 1;
    if (*jadd > (integer) n) {
	goto L60;
    }
	/*
	     a simple bound has entered the working set.  iadd  is not used
	*/
    if (msg >= 80)
	lm_wmsg(
"\n//ADDCON//  SIMPLE BOUND ADDED.\n//ADDCON// NACTIV NCOLZ NFREE  IFIX  JADD UNITQ\n//ADDCON//%7ld%6ld%6ld%6ld%6ld%6ld", 
		CL(*nactiv), CL(*ncolz), CL(*nfree), CL(*ifix),
		CL(*jadd), CL(*unitq));
	/*
	     set  wrk1 = appropriate row of  q
	     reorder the elements of  kfree (this requires reordering the
	     corresponding rows of  q)
	*/
    nfree1 = *nfree - 1;
    nact1 = *nactiv;
    if (*unitq) {
	goto L20;
    }
	/*
	     q  is stored explicitly.  interchange components  ifix  and  nfree
	     of  kfree  and swap the corresponding rows of  q
	*/
    dcopy(*nfree, &zy[*ifix + zy_dim1], *Nq, &wrk1[1], 1);
    if (*ifix == *nfree) goto L180;
    kfree[*ifix] = kfree[*nfree];
    dcopy(*nfree, &zy[*nfree + zy_dim1], *Nq, &zy[*ifix + zy_dim1], *Nq);
    goto L180;
	/*
	     q  is not stored, but  kfree  defines an ordering of the columns
	     of the identity matrix that implicitly define  z
	     reorder  kfree  so that variables  ifix+1,...,nfree  are moved one
	     position to the left
	*/
L20:
    dzerovec(*nfree, &wrk1[1]);
    wrk1[*ifix] = 1.0;
    if (*ifix == *nfree) {
	goto L180;
    }
    i__1 = nfree1;
    for (i = *ifix; i <= i__1; ++i) {
	kfree[i] = kfree[i + 1];
/* L40: */
    }
    goto L180;
	/*
	     a general constraint has entered the working set
	     ifix is not used
	*/
L60:
    if(msg >= 80)
	lm_wmsg("\n//ADDCON//  GENERAL CONSTRAINT ADDED.\n//ADDCON// NACTIV NCOLZ NFREE  IADD  JADD UNITQ\n//ADDCON//%7ld%6ld%6ld%6ld%6ld%6ld",
		CL(*nactiv), CL(*ncolz), CL(*nfree), CL(*iadd), CL(*jadd), CL(*unitq));
    		nact1 = *nactiv + 1;
	/*
	     transform the incoming row of  a  by  q(t)
	*/
    dcopy(n, &a[*iadd + a_dim1], *nrowa, &wrk1[1], 1);
    dzyprod(8, n, *nactiv, *ncolz, *nfree, *Nq, *unitq, &kfree[1], &kfree[1], &
	    wrk1[1], &zy[zy_offset], &wrk2[1]);
    if (! (*unitq)) {
	goto L100;
    }
	/*
	     this is the first general constraint to be added  --  set  q = i.
	*/
    i__1 = *nfree;
    for (j = 1; j <= i__1; ++j) {
	dzerovec(*nfree, &zy[j * zy_dim1 + 1]);
	zy[j + j * zy_dim1] = 1.0;
    }
    *unitq = FALSE_;
	/*
	     check that the incoming row is not dependent upon those
	     already in the working set
	*/
L100:
    dtnew = dnrm2vec(*ncolz, &wrk1[1]);
    if (nact1 > 1) {
	goto L140;
    }
	/*
	     this is the only general constraint in the working set
	*/
    cond = dprotdiv(&asize, &dtnew, &ifail);
    if (ifail && asize == 0) {
	cond = lm_max;
    }
    if (cond >= *condmx) {
	goto L480;
    }
    if(cond >= condbd && msg >= 0)
	lm_wmsg("\n*** WARNING\n *** SERIOUS ILL-CONDITIONING IN THE WORKING SET AFTER ADDING CONSTRAINT %5ld\n *** OVERFLOW MAY OCCUR IN SUBSEQUENT ITERATIONS\n\n", CL(*jadd));
    dtmax = dtnew;
    dtmin = dtnew;
    goto L180;
	/*
	     there are already some general constraints in the working set
	     update the estimate of the condition number
	*/
L140:
    tdtmax = dmax(dtnew,dtmax);
    tdtmin = dmin(dtnew,dtmin);
    cond = dprotdiv(&tdtmax, &tdtmin, &ifail);
    if (ifail && tdtmax == 0) {
	cond = lm_max;
    }
    if (cond >= *condmx) {
	goto L480;
    }
    if (cond >= condbd && msg >= 0)
	lm_wmsg("\n*** WARNING\n *** SERIOUS ILL-CONDITIONING IN THE WORKING SET AFTER ADDING CONSTRAINT %5ld\n *** OVERFLOW MAY OCCUR IN SUBSEQUENT ITERATIONS\n\n",
	CL(*jadd));
    dtmax = tdtmax;
    dtmin = tdtmin;
	/*
	     use one or more column transformations to reduce the first  ncolz1
	     elements of  wrk1  to zero.  this affects  zy,  except if (unitq).
	     the transformations may also be applied to  qtg  and  r
	*/
L180:
    if (ncolz1 == 0) {
	goto L360;
    }
    if (modfyr || *unitq) {
	goto L320;
    }
	/*
	there is no  r.  use a single elimination or householder matrix
	*/
    if (orthog) {
	goto L240;
    }
	/*
	     elimination we use  elm( ..., zero, zero )   to perform an interchange
	*/
    detagen(CN(ncolz1), &wrk1[*ncolz], &wrk1[1], CI(1), &iswap, &itrans)
	    ;
    if (iswap > 0)
	delm(orthog, CN(*nfree), &zy[*ncolz * zy_dim1 + 1], 1, &zy[
		iswap * zy_dim1 + 1], 1, zero, zero);
    if (itrans == 0) {
	goto L220;
    }
    i__1 = ncolz1;
    for (j = 1; j <= i__1; ++j) {
	d = wrk1[j];
	if (d == 0) {
	    goto L200;
	}
	BITA_daxpy(CN(*nfree), d, &zy[*ncolz * zy_dim1 + 1], 1, &zy[j * zy_dim1 + 1],1);
L200:
	;
    }
L220:
    if (!modfyg) {
	goto L360;
    }
    if (iswap > 0)
	delm(orthog, 1, &qtg[*ncolz], 1, &qtg[iswap],1, zero, zero);
    if (itrans > 0) {
	BITA_daxpy(ncolz1, qtg[*ncolz], &wrk1[1], 1, &qtg[1], 1);
    }
    goto L360;

	/*
	orthogonal transformation
	we use a householder reflection,   i  -  1/beta  v v(t)
	there are two ways of applying the reflection.  the update to  z
	is done via   w  =  z * v,   z  =  z  -  1/beta  w v(t),
	where  v = wrk1 (from householder), and  w = wrk2 (workspace)
	the update to  qtg  is the more usual  d =  - qtg(t)*v / beta,
	qtg  =  qtg  +  d * v
	note that  delta  has to be stored after the reflection is used
	*/

L240:
    delta = wrk1[*ncolz];
    dhhrflctgen(&ncolz1, &delta, &wrk1[1], &c__1, &lm_eps, &beta);
    if (beta != 0) {
	wrk1[*ncolz] = beta;
    }
    if (beta <= 0) {
	goto L360;
    }
    dzerovec(*nfree, &wrk2[1]);
    i__1 = *ncolz;
    for (j = 1; j <= i__1; ++j) {
	d = wrk1[j];
	if (d == 0) {
	    goto L260;
	}
	BITA_daxpy(*nfree, d, &zy[j * zy_dim1 + 1], 1, &wrk2[1], 1);
L260:
	;
    }
    i__1 = *ncolz;
    for (j = 1; j <= i__1; ++j) {
	d = wrk1[j];
	if (d == 0) {
	    goto L280;
	}
	d = -d / beta;
	BITA_daxpy(*nfree, d, &wrk2[1], 1, &zy[j * zy_dim1 + 1], 1);
L280:
	;
    }
    if (!modfyg) {
	goto L300;
    }
    d = ddotvec(*ncolz, &wrk1[1],&qtg[1]);
    d = -d / beta;
    BITA_daxpy(*ncolz, d, &wrk1[1], 1, &qtg[1], 1);
L300:
    wrk1[*ncolz] = delta;
    goto L360;

	/*r  has to be modified.  use a sequence of 2*2 transformations*/
L320:
    lrowr = *ncolr;
    i__1 = ncolz1;
    for (k = 1; k <= i__1; ++k) {
	/*
	compute the transformation that reduces wrk1(k) to zero,
	then apply it to the relevant columns of  z  and  grad(t)q.
	*/
	kp1 = k + 1;
	delmgen(orthog, &wrk1[kp1], &wrk1[k], &cs, &sn);
	if (! (*unitq)) {
	    delm(orthog, CN(*nfree), &zy[kp1 * zy_dim1 + 1], 1, &zy[k * 
		    zy_dim1 + 1], 1, cs, sn);
	}
	if (modfyg)
	    delm(orthog, 1, &qtg[kp1], 1, &qtg[k], 1, cs, sn);
	/*
	apply the same transformation to the cols of  r  if relevant
	this generates a subdiagonal element in  r  which must be
	eliminated by a row rotation.  the last such row rotation
	is needed by  qpcore
	*/
	if (! (modfyr && k < *ncolr)) {
	    goto L340;
	}
	rt[kp1 + k * rt_dim1] = 0;
	delm(orthog, CN(kp1), &rt[kp1 * rt_dim1 + 1], 1, &rt[k * 
		rt_dim1 + 1], 1, cs, sn);
	BITA_drotg(&rt[k + k * rt_dim1], &rt[kp1 + k * rt_dim1], cslast, snlast);

	rt[kp1 + k * rt_dim1] = 0;
	--lrowr;
	dsymplanerotate(CN(lrowr), &rt[k + kp1 * rt_dim1],
			CI(*Nrowrt), &rt[kp1 + kp1 * rt_dim1],
			CI(*Nrowrt), *cslast, *snlast);
L340:
	;
    }
	/* if adding a general constraint, insert the new row of  t  and exit */
L360:
    if(*jadd > (integer) n){
    	dcopy(nact1, &wrk1[*ncolz], 1, &rt[nact1 + *ncolz * rt_dim1], *Nrowrt);
	return 0;
	}
	/*
	     we are adding a bound.  continue reducing the elements of  wrk1
	     to zero.  this affects  y,  t  and  qtg
	     first, set the super-diagonal elements of t to zero
	*/
    if (*nactiv == 0) {
	goto L440;
    }
    dzero(*nactiv, &rt[*nactiv + *ncolz * rt_dim1], *Nrowrt-1);
    nelm = 1;
    ldiag = *nactiv;
    i__1 = nfree1;
    for (k = *ncolz; k <= i__1; ++k) {
	delmgen(orthog, &wrk1[k + 1], &wrk1[k], &cs, &sn);
	delm(orthog, CN(*nfree), &zy[(k + 1) * zy_dim1 + 1], 1, &zy[k * 
		zy_dim1 + 1],1, cs, sn);
	delm(orthog, CN(nelm), &rt[ldiag + (k + 1) * rt_dim1], 1,
		&rt[ldiag + k * rt_dim1],1, cs, sn);
	if (modfyg)
	    delm(orthog, 1, &qtg[k + 1], 1, &qtg[k], 1, cs, sn);
	++nelm;
	--ldiag;
    }
	/*
	the diagonals of  t  have been altered.  recompute the largest and
	smallest values
	*/
    inct = *Nrowrt - 1;
    dxminmax(*nactiv, &rt[*nactiv + (ncolz1 + 1) * rt_dim1], inct, &dtmax, &
	    dtmin);
    if(dtmin / dtmax * *condmx < 1.0) goto L480;
    if (dtmin / dtmax * condbd < 1.0 && msg >= 0)
	lm_wmsg("\n*** WARNING\n *** SERIOUS ILL-CONDITIONING IN THE WORKING SET AFTER ADDING CONSTRAINT %5ld\n *** OVERFLOW MAY OCCUR IN SUBSEQUENT ITERATIONS\n\n",
	CL(*jadd));
	/*
	the last row of  zy  has been transformed to a multiple of the
	unit vector  e(nfree).  if orthogonal transformations have been
	used throughout, the last column of  zy  is the same.   we can
	therefore resurrect the gradient element of the newly fixed
	variable
	*/
L440:
    if (orthog && modfyg) {
	qtg[*nfree] /= wrk1[*nfree];
    }
	/*the factorization has been successfully updated*/
	return 0;

/*THE PROPOSED WORKING SET APPEARS TO BE LINEARLY DEPENDENT*/
L480:
	if(msg >= 80 ){
    		lm_wmsg("\n//ADDCON//  DEPENDENT CONSTRAINT REJECTED");
		if(*jadd <= (integer) n)
			lm_wmsg(
			"\n//ADDCON//     ASIZE     DTMAX     DTMIN\n//ADDCON//%10.2le%10.2le%10.2le",
				asize, dtmax, dtmin);
			else	lm_wmsg(
			"\n//ADDCON//     ASIZE     DTMAX     DTMIN     DTNEW\n//ADDCON//%10.2le%10.2le%10.2le",
				asize, dtmax, dtmin, dtnew);
		}
	return 1;
}
