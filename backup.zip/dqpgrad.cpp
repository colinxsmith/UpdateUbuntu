#include "baseoptimise.h"
/*
	qpgrad	computes or updates..
	(1)	objqp, the value of the quadratic objective function, and
	(2)	the vectors  q(free)(t)g(free)  and  g(fixed),  where  q(free)
		is the orthogonal factor of the	 a(free)  and  a  is the matrix
		of constraints in the working set.  these vectors are stored in
		elements  1,2,...,nfree	 and  nfree+1,...,n,  respectively,  of
		the array  qtg
	(3)	the component of the gradient vector corresponding to a bound
		constraint that has just been added to the working set
	*/
short Base_Optimise::dqpgrad(short mode, int unitq, dimen n, dimen nactiv, dimen nfree,
		dimen *nhess, dimen Nq, dimen nrowh, dimen ncolh, dimen jadd,
		short_vec kactiv, short_vec kfree, real alfa, real *objqp, real *gfixed, real gtp,
		vector	cvec, vector hess, vector p, vector qtg, vector scale, vector x, vector zy,
		vector wrk1, vector wrk2)
{

    real deltaf;
    dimen jthcol;

    --wrk2;
    --wrk1;
    --x;
    --scale;
    --qtg;
    --p;
    --cvec;
    --kfree;
    --kactiv;

    jthcol = 0;
    switch (mode){
	case 1:
/*
	MODE = 1  ---	COMPUTE THE OBJECTIVE FUNCTION AND GRADIENT FROM
			SCRATCH.  ALLOW FOR A DIAGONAL SCALING OF  X
*/
		dcopyvec(n, &x[1], &wrk1[1]);
		if (scldqp) ddmxmulv(n, &scale[1], 1, &wrk1[1], 1);
		qphess(n,nrowh,ncolh,CN(jthcol),hess,&wrk1[1],&qtg[1]);
		*objqp = 0.5 * ddotvec(n, &qtg[1], &wrk1[1])+ddotvec(n, &cvec[1], &wrk1[1]);
		BITA_daxpy(n, CR(1), &cvec[1], 1, &qtg[1], 1);
		if (scldqp) ddmxmulv(n, &scale[1], 1, &qtg[1], 1);
		/*COMPUTE Q(FREE)(T)(G(FREE) & G(FIXED).  discard ELEMENTS OF G(FREE)*/
		dzyprod(6,n,nactiv,0,nfree,Nq,unitq,kactiv+1,kfree+1,qtg+1, zy, wrk1+1);
		break;
	case 2:
/*
		IF THE QP OBJECTIVE FUNCTION IS REDUCED BY A POSITIVE
		STEP  ALFA,  OR  ALFA  IS NEGATIVE, UPDATE  OBJF
		Q(FREE)(T)G(FREE)  AND  G(FIXED)  CORRESPONDING TO
		THE CHANGE,  X = X + ALFA P
*/
		qphess(n, nrowh, ncolh, CN(jthcol), hess,&p[1], &wrk1[1]);
		if(scldqp) ddmxmulv(n, &scale[1], 1, &wrk1[1], 1);
		/*UPDATE  OBJQP. */
		deltaf = alfa * gtp + 0.5 * alfa * alfa*ddotvec(n,&p[1],&wrk1[1]);
		if (deltaf > lm_eps && alfa > lm_eps)
			/*THE STEP  ALFA  DOES NOT DECREASE THE OBJECTIVE FUNCTION. */
//			AddLog("Gone up by %-.10e baby\n",deltaf);
    			return -1;
		*objqp += deltaf;
		/*UPDATE QTG.  USE P  AS TEMPORARY WORK SPACE*/
		dzyprod(6, n,nactiv,0,nfree,Nq,unitq,kactiv+1,kfree+1,
		wrk1+1, zy, wrk2+1);
		BITA_daxpy(n, alfa, &wrk1[1], 1, &qtg[1], 1);
		break;
	case 3:
	/*COMPUTE THE  JADD-TH COMPONENT OF THE GRADIENT VECTOR.*/
		jthcol = jadd;
		dzerovec(n, &wrk2[1]);
		wrk2[jthcol] = 1;
		qphess(n,nrowh,ncolh,CN(jthcol),hess, &wrk2[1], &wrk1[1]);
		if(scldqp){
			ddmxmulv(n, &scale[1], 1, &wrk1[1], 1);
			*gfixed = scale[jadd] * (ddotvec(n, &wrk1[1], &x[1])+cvec[jadd]);
			}
		else *gfixed = ddotvec(n, &wrk1[1], &x[1]) + cvec[jadd];
    	}
	++(*nhess);
	return 0;
}
