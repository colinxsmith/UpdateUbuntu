#include "baseoptimise.h"
static integer c__1 = 1;
/*
	lpcrsh computes details associated with the working set at a point
	x.  the computation depends upon the value of the input parameter
	lcrash.	  as  follows ..

	lcrash = 0	means that lpcrsh should find (1) an initial working
			set, (2) the  tq  factors of the constraint coefficients
			for the working set, and (3) the point closest to  x
			that lies on the working set
	lcrash = 1	means that lpcrsh should compute (1) the tq
			factors of a working set specified by the integer array
			istate, and (2) the point closest to  x	 that satisfies
			the working set
	lcrash = 2	means that lpcrsh essentially does nothing but
			compute auxiliary information about the point  x  that
			lies on the constraints in the given working set

	values of istate(j)...
	- 2	    - 1		0	    1	       2	 3
	a*x < bl   a*x > bu	a*x free   a*x = bl   a*x = bu	 bl = bu
	istate(j) = 4  means that x(j) is on a temporary bound
*/
void Base_Optimise::dlpcrsh(	int orthog, logical *unitq, int vertex, byte lcrash, dimen n, integer *nclin, integer *nctotl,
		integer *Nq, integer *nrowa, integer *Nrowrt, integer *Ncolrt, integer *nactiv, integer *ncolz,
		integer *nfree, short_vec istate, short_vec kactiv, short_vec kfree, real *bigbnd, real *tolact,
		real *xnorm, real *a, real *anorm, real *ax, real *bl, real *bu, real *x, real *qtg, real *rt,
		real *zy, real *p, real *wrk1, real *wrk2)
{

    integer a_dim1, a_offset, rt_dim1, rt_offset, zy_dim1, zy_offset, i__1, 
	    i__2;
    real d__1;
	integer	n__ = n;


    integer iadd, jadd;
    real amin;
    integer imin=1000000000, jmin=1000000000, ifix;
    real resl, resu;
    integer nact1;
    integer i, j, k;
    integer idiag;
    real b1, b2;
    real rnorm;
    logical nolow, noupp;
    integer ncolz1, kb;
    integer is, nfixed;
    real colmin, toobig;
    integer nartif;
    real condmx, cslast;
    integer inform;
    real resmin, colsiz, snlast;
    integer idummy;
    real rowmax;
    real bnd, res;


    --wrk2;
    --wrk1;
    --p;
    zy_dim1 = *Nq;
    zy_offset = zy_dim1 + 1;
    zy -= zy_offset;
	i__1 = *Nrowrt* *Ncolrt;
	dzerovec(i__1,rt);
    rt_dim1 = *Nrowrt;
    rt_offset = rt_dim1 + 1;
    rt -= rt_offset;
    --qtg;
    --x;
    --bu;
    --bl;
    --ax;
    --anorm;
    a_dim1 = *nrowa;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --kfree;
    --kactiv;
    --istate;

	/*
	set the maximum allowable condition estimator of the constraints
	in the working set.  note that the conservative value used in
	lpcrsh is smaller than that used when a constraint is added to
	the working set during a typical iteration
	*/
    condmx = 1 / lm_rooteps;
    if (msg >= 80) {
	lm_wmsg((char*)"\n//LPCRSH//  LCRASH NCLIN NCTOTL\n//LPCRSH//%7d%7ld%7ld",
		lcrash,CL(*nclin),CL(*nctotl));
	lm_mdvwri((char*)"\nLP VARIABLES BEFORE CRASH...",n, &x[1]);
    	lm_mivwri((char*)"\nSTATUS OF THE LP BOUND   CONSTRAINTS",CN(*nctotl), &istate[1]);
    }
    nfixed = 0;
    *nactiv = 0;
    nartif = 0;
/*     IF A COLD START IS BEING MADE, INITIALIZE  ISTATE. */
/*     IF  BL(J) = BU(J),  SET  ISTATE(J)=3  FOR ALL VARIABLES AND LINEAR 
*/
/*     CONSTRAINTS. */
    if(lcrash > 0) goto L60;
    i__1 = *nctotl;
    for (j = 1; j <= i__1; ++j)
	istate[j] = bl[j] == bu[j] ? 3 : 0;
/* L40: */
/*     INITIALIZE  NFIXED,  NACTIV  AND  KACTIV. */
/*     ENSURE THAT THE NUMBER OF BOUNDS AND GENERAL CONSTRAINTS IN THE */
/*     WORKING SET DOES NOT EXCEED  N. */
L60:
    i__1 = *nctotl;
	for (j = 1; j <= i__1; ++j){
		if (nfixed + *nactiv ==  (integer)n || istate[j]==4 ) istate[j] = 0;
		if (istate[j] > 0){
			if(j <=  (integer)n){
				++nfixed;
				if(istate[j] == 1) x[j] = bl[j];
				if(istate[j] >= 2) x[j] = bu[j];
				}
			else	{
				++(*nactiv);
				if (lcrash < 2) kactiv[*nactiv] = j - n;
				}
			}
    		}
    *nfree = n - nfixed;
    *ncolz = *nfree - *nactiv;
    if (msg >= 80) {
	lm_mdvwri((char*)"\nLP VARIABLES AFTER CRASH INIT...",n, &x[1]);
    	lm_mivwri((char*)"\nSTATUS OF THE LP BOUND   CONSTRAINTS",CN(*nctotl), &istate[1]);
    	}
	/*if a hot start is required, the tq factorization is already known*/
    if (lcrash > 1) {
	goto L600;
    }
    dtmax = 1;
    dtmin = 1;
    *unitq = TRUE_;
/*     COMPUTE THE 2-NORMS OF THE CONSTRAINT ROWS. */
    asize = 1;
    if (*nclin == 0) {
	goto L140;
    }
    i__1 = *nclin;
    for (j = 1; j <= i__1; ++j) {
	anorm[j] = dnrm2(n, &a[j + a_dim1], *nrowa);
/* L120: */
    }
    dxminmax(*nclin, &anorm[1], 1, &asize, &amin);
L140:
    if (lcrash > 0) goto L320;
	/*
	---------------------------------------------------------------------
	if a cold start is required, an attempt is made to add as many
	constraints as possible to the working set
	---------------------------------------------------------------------
	*/
    if (nfixed + *nactiv ==  (integer)n) {
	goto L460;
    }
	/* see if any variables are outside their bounds */
    for (j = 1; j <=  (integer)n; ++j) {
	if (istate[j] != 0) goto L200;
	b1 = bl[j];
	b2 = bu[j];
	nolow = b1 <= -(*bigbnd);
	noupp = b2 >= *bigbnd;
	is = 0;
	if (nolow) {
	    goto L160;
	}
	if (x[j] - b1 <= (1 + fabs(b1)) * *tolact) {
	    is = 1;
	}
L160:
	if (noupp) {
	    goto L180;
	}
	if (b2 - x[j] <= (1 + fabs(b2)) * *tolact) {
	    is = 2;
	}
L180:
	if (is == 0) {
	    goto L200;
	}
/*        SET VARIABLE EQUAL TO ITS BOUND. */
	istate[j] = is;
	if (is == 1) x[j] = b1;
	if (is == 2) x[j] = b2;
	++nfixed;
	if(nfixed + *nactiv ==  (integer)n) goto L460;
L200:
	;
    }
/* --------------------------------------------------------------------- 
*/
/*     THE FOLLOWING LOOP FINDS THE LINEAR CONSTRAINT THAT IS CLOSEST */
/*     TO BEING SATISFIED.  IF IT IS SUFFICIENTLY CLOSE, IT WILL BE ADDED 
*/
/*     TO THE WORKING SET AND THE PROCESS WILL BE REPEATED. */
/* --------------------------------------------------------------------- 
*/
/*     FIRST, COMPUTE  AX  FOR INEQUALITY LINEAR CONSTRAINTS. */
    if(*nclin == 0) goto L320;
    i__1 = *nclin;
    for (i = 1; i <= i__1; ++i) {
	j = n + i;
	if (istate[j] > 0) {
	    goto L220;
	}
	ax[i] = BITA_ddot(n, &a[i + a_dim1], CI(*nrowa), &x[1], 1);
L220:
	;
    }
    toobig = *tolact + *tolact;
    i__1 = n;
    for (idummy = 1; idummy <= i__1; ++idummy) {
	resmin = toobig;
	is = 0;
	i__2 = *nclin;
	for (i = 1; i <= i__2; ++i) {
	    j = n + i;
	    if (istate[j] > 0) {
		goto L280;
	    }
	    b1 = bl[j];
	    b2 = bu[j];
	    nolow = b1 <= -(*bigbnd);
	    noupp = b2 >= *bigbnd;
	    resl = toobig;
	    resu = toobig;
	    if (nolow) {
		goto L240;
	    }
	    resl = (d__1 = ax[i] - b1, fabs(d__1)) / (1 + fabs(b1));
L240:
	    if (noupp) {
		goto L260;
	    }
	    resu = (d__1 = ax[i] - b2, fabs(d__1)) / (1 + fabs(b2));
L260:
	    res = min(resl,resu);
	    if (res >= *tolact) {
		goto L280;
	    }
	    if (res >= resmin) {
		goto L280;
	    }
	    resmin = res;
	    imin = i;
	    is = 1;
	    if (resl > resu) {
		is = 2;
	    }
L280:
	    ;
	}
	if (is == 0) {
	    goto L320;
	}
	++(*nactiv);
	kactiv[*nactiv] = imin;
	j = n + imin;
	istate[j] = is;
	if (nfixed + *nactiv ==  (integer)n) {
	    goto L460;
	}
/* L300: */
    }
/* --------------------------------------------------------------------- 
*/
/*     IF NECESSARY, ADD TEMPORARY BOUNDS TO MAKE A VERTEX. */
/* --------------------------------------------------------------------- 
*/
L320:
    *ncolz = n - nfixed - *nactiv;
    if (!vertex || *ncolz == 0) {
	goto L460;
    }
/*     COMPUTE LENGTHS OF COLUMNS OF SELECTED LINEAR CONSTRAINTS */
/*     (JUST THE ONES CORRESPONDING TO FREE VARIABLES). */
    i__1 = n;
    for (j = 1; j <= i__1; ++j) {
	if (istate[j] != 0) {
	    goto L380;
	}
	colsiz = 0;
	if (*nclin == 0) {
	    goto L360;
	}
	i__2 = *nclin;
	for (k = 1; k <= i__2; ++k) {
	    i = n + k;
	    if (istate[i] > 0) {
		colsiz += (d__1 = a[k + j * a_dim1], fabs(d__1));
	    }
/* L340: */
	}
L360:
	wrk1[j] = colsiz;
L380:
	;
    }
/*     FIND THE  NARTIF  SMALLEST SUCH COLUMNS. */
/*     THIS IS AN EXPENSIVE LOOP.  LATER WE CAN REPLACE IT */
/*     BY A 4-PASS PROCESS (SAY), ACCEPTING THE FIRST COL THAT */
/*     IS WITHIN  T  OF  COLMIN, WHERE  T = 0.0, 0.001, 0.01, 0.1 (SAY). 
*/
    i__1 = *ncolz;
    for (idummy = 1; idummy <= i__1; ++idummy) {
	colmin = lm_max;
	i__2 = n;
	for (j = 1; j <= i__2; ++j) {
	    if (istate[j] != 0) {
		goto L400;
	    }
	    if (*nclin == 0) {
		goto L420;
	    }
	    colsiz = wrk1[j];
	    if (colmin <= colsiz) {
		goto L400;
	    }
	    colmin = colsiz;
	    jmin = j;
L400:
	    ;
	}
	j = jmin;
L420:
	istate[j] = 4;
	++nartif;
/* L440: */
    }
/* --------------------------------------------------------------------- 
*/
/*     A TRIAL WORKING SET HAS NOW BEEN SELECTED. */
/* --------------------------------------------------------------------- 
*/
/*     SET  KFREE  TO POINT TO THE FREE VARIABLES. */
L460:
    *nfree = 0;
    i__1 = n;
    for (j = 1; j <= i__1; ++j) {
	if (istate[j] != 0) {
	    goto L480;
	}
	++(*nfree);
	kfree[*nfree] = j;
L480:
	;
    }
/*     COMPUTE THE TQ FACTORIZATION FOR THE SELECTED LINEAR CONSTRAINTS. 
*/
/*     FIRST, THE COLUMNS CORRESPONDING TO SIMPLE BOUNDS IN THE WORKING */

/*     SET ARE REMOVED. THE RESULTING  NACTIV BY NFREE  MATRIX (NACTIV */
/*     LE NFREE) IS FACTORIZED BY ADDING THE CONSTRAINTS ONE AT A TIME */
/*     AND UPDATING USING PLANE ROTATIONS OR STABILIZED ELIMINATIONS. */
/*     THE  NACTIV BY NACTIV  TRIANGULAR MATRIX  T  AND THE NFREE BY */
/*     NFREE MATRIX  Q  ARE STORED IN THE ARRAYS  RT  AND  ZY. */
    *ncolz = *nfree;
    if (*nactiv == 0) {
	goto L540;
    }
    nact1 = *nactiv;
    *nactiv = 0;
    dtqadd(orthog, unitq, &inform, &c__1, &nact1, nactiv, ncolz, nfree, &n__, 
	    Nq, nrowa, Nrowrt, Ncolrt, &istate[1], &kactiv[1], &kfree[
	    1], &condmx, &a[a_offset], &qtg[1], &rt[rt_offset], &zy[zy_offset]
	    , &wrk1[1], &wrk2[1]);
/*     IF A VERTEX IS REQUIRED BUT  TQADD  WAS UNABLE TO ADD ALL OF THE */

/*     SELECTED GENERAL CONSTRAINTS, ADD MORE TEMPORARY BOUNDS. */
    if (!vertex || *ncolz == 0) {
	goto L540;
    }
    ncolz1 = *ncolz;
    i__1 = ncolz1;
    for (idummy = 1; idummy <= i__1; ++idummy) {
	rowmax = 0;
	i__2 = *nfree;
	for (i = 1; i <= i__2; ++i) {
	    rnorm = dnrm2(*ncolz, &zy[i + zy_dim1], *Nq);
	    if (rowmax >= rnorm) {
		goto L500;
	    }
	    rowmax = rnorm;
	    ifix = i;
L500:
	    ;
	}
	jadd = kfree[ifix];
	inform = daddcon(0, 0, orthog, unitq, &ifix, &iadd, &jadd, 
		nactiv, ncolz, ncolz, nfree, n, Nq, nrowa, Nrowrt, &
		kfree[1], &condmx, &cslast, &snlast, &a[a_offset], &qtg[1], &
		rt[rt_offset], &zy[zy_offset], &wrk1[1], &wrk2[1]);
	--(*nfree);
	--(*ncolz);
	++nartif;
	istate[jadd] = 4;
/* L520: */
    }
/*     SET ELEMENTS  NACTIV + 1, ......, NACTIV + NFIXED  OF  KACTIV TO */

/*     POINT TO THE FIXED VARIABLES. */
L540:
    kb = *nactiv;
    i__1 = n;
    for (j = 1; j <= i__1; ++j) 
	{
		if (istate[j] == 0) continue;
		++kb;
		kactiv[kb] = j;
    }
/* --------------------------------------------------------------------- 
*/
/*     THE TQ FACTORIZATION HAS BEEN COMPUTED.  FIND THE POINT CLOSEST TO 
*/
/*     THE USER-SUPPLIED  X  THAT LIES ON THE INITIAL WORKING SET. */
/* --------------------------------------------------------------------- 
*/
/*     SET WRK1 = RESIDUALS FOR CONSTRAINTS IN THE WORKING SET. */
    if (*nactiv == 0) {
	goto L600;
    }
    i__1 = *nactiv;
    for (i = 1; i <= i__1; ++i) {
	k = kactiv[i];
	j = n + k;
	bnd = bl[j];
	if (istate[j] > 1) {
	    bnd = bu[j];
	}
	wrk1[i] = bnd - BITA_ddot(n, &a[k + a_dim1], CI(*nrowa), &x[1], 1);
/* L580: */
    }
/*     SOLVE FOR P, THE SMALLEST CORRECTION TO X THAT GIVES A POINT */
/*     ON THE CONSTRAINTS IN THE WORKING SET. */
/*     FIRST SOLVE  T*WRK1 = RESIDUALS, THEN GET  P = Y*WRK1. */
    idiag = 1;
    drtmxsolve(2, CN(*nactiv), &rt[(*ncolz + 1) * rt_dim1 + 1], CN(*Nrowrt), &wrk1[1], 
	    &idiag);
    dzerovec(n, &p[1]);
    dcopyvec(*nactiv, &wrk1[1], &p[*ncolz + 1]);
    dzyprod(2, n, *nactiv, *ncolz, *nfree, *Nq, *unitq, &kactiv[1], &kfree[1], 
	    &p[1], &zy[zy_offset], &wrk1[1]);
    BITA_daxpy(n, CR(1), &p[1], 1, &x[1], 1);
/* --------------------------------------------------------------------- 
*/
/*     COMPUTE THE 2-NORM OF  X. */
/*     INITIALIZE  AX  FOR ALL GENERAL CONSTRAINTS. */
/* --------------------------------------------------------------------- 
*/
L600:
    *xnorm = dnrm2vec(n, &x[1]);
    if (*nclin == 0) {
	goto L640;
    }
    dzerovec(*nclin, &ax[1]);
    i__1 = n;
    for (j = 1; j <= i__1; ++j) {
	if (x[j] != 0) {
	    BITA_daxpy(*nclin, x[j], &a[j * a_dim1 + 1], 1, &ax[1], 1);
	}
/* L620: */
    }
/*     A POINT THAT SATISFIES THE INITIAL WORKING SET HAS BEEN FOUND. */
L640:
    *ncolz = *nfree - *nactiv;
    nfixed = n - *nfree;
    if (msg >= 80) {
	lm_wmsg(
"\nLPCRSH. WORKING SET SELECTED ...\nBOUNDS = %ld TEMPORARY BOUNDS = %ld GENERAL LINEAR = %ld",
	CL(nfixed), CL(nartif),CL(*nactiv));
	lm_mdvwri((char*)"\nLP VARIABLES AFTER  CRASH...",n, &x[1]);
    }
}
