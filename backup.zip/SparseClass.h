/*
#include<cstdio>
#include<cmath>
#include<vector>
#include<valarray>
extern "C"
{
#include "ldl.h"
}
class DLLEXPORT SparseError
{
public:
    SparseError(short id){this->id=id;};
    ~SparseError(){};
    const char *ShowReason() const { return (id==0?"Exception in SparseLDL::Factor ERROR.\n":
	"Exception in SparseLDL::Factor ERROR in indices\n"); }
private:
	short id;
};
class DLLEXPORT SparseLDL
{
public:
	size_t n;
	size_t* Lp;
	size_t* Li;
	double*Lx;
	double*Diag;
	SparseLDL(size_t n=0,size_t* order=0);
	~SparseLDL();
	size_t Factor(double* AX=0,size_t*AP=0,size_t*AI=0);
	void Solve(double* g1);
	void CreateSparseIndices(double* Q);
	void SetOrder(size_t n=0,size_t* order=0);
private:
	std::valarray<size_t> *spaceI;
	std::valarray<double> *spaceD;
	std::vector<size_t> *indexAI;
	std::vector<double> *sparseAX;
	std::valarray<size_t> *indexAP;
	std::valarray<size_t> *invorder;
	size_t* order;
};
*/