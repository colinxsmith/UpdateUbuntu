#!/usr/bin/env python
#Colin Smith
#July 29th. 2005
#Maximise return subject to budget constraint and risk constraint using SOCP

from sys import stdin
from re import sub
from Opt import *
def getcov(file=stdin):
    Q=[]
    n=0
    while 1:
        line=file.readline()
        if not len(line):break
        line=sub(',*$','',line.strip())
        Q+=[float(i) for i in line.split(',')]
        n+=1
    return (n,Q)
        


"""
(n,Q)=getcov(open('testcov'))
#n=130
"""
n=1000
nfac=2
SV=[(i+1)*1e-5 for i in range(n)]
FL=[1]*n+[1]+[0]*(n-1)
FC=[1e-4,1e-5,2e-4]
Q=[0]*(n*(n+1)/2)
Factor2Cov(n,nfac,FC,FL,SV,Q)
#"""
#eigval=eigen(n,Q)[0]
#print 'Eigenvalues of the covariance matrix'
#for i in range(n):
#    print '%4d %20.8e'%(i+1,eigval[i])

opt=Opt()
opt.n=n
opt.kappa=0
opt.nfac=-1
opt.Q=Q
opt.m=1
opt.A=[1]*n
opt.L=[0]*n+[1]
opt.U=[1]*(n+1)
opt.gamma=.1
opt.alpha=[(i+1)*.01 for i in range(n)]
opt.bench=[float(1)/n for i in range(n)]
opt.SOCPquad()
keep=[i for i in opt.w]
opt.opt()
print '%6s %20s %20s'%(' ','From QP','From Cone Optimisation')
for i in range(len(keep)):
    print '%6d %20.12e %20.12e'%(i+1,opt.w[i],keep[i])
print 'Total %20.12e %20.12e'%(sum(opt.w),sum(keep))
opt.margutility()
print 'Utility\t\t%20.12e'%opt.utility
opt.w=[i for i in keep]
opt.names=[]
opt.margutility()
print 'SOCP Utility\t%20.12e'%opt.utility

