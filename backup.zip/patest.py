#! /bin/env python
from Opt import *
"""
extern "C" void PatternMin(unsigned long n,double *w_opt,double *step,
	double *f,double scale,pUtility calcfx,void*info,short iprint=1,unsigned long maxit=20,short icon=0)
"""

lab=[]
ns=0
pen=[]

def utility(c,Q,x,tt):
    n=len(x)
    imp=[0]*n
    tt(n,1,1,1,Q,x,imp)
    return dot(c,x)+0.5*dot(x,imp)
def patutil(n,x):
    return utility(patc,H,x,testmul)
def addvec(a,b,s=1):
    n=min(len(a),len(b))
    c=[0]*n
    for i in range(n):c[i]=a[i]+s*b[i]
    return c
def combine(x):
    n=len(x)/2
    xx=[0]*n
    for i in range(n):xx[i]=x[i]+x[i+n]
    return xx
def lscheck(a):
    L=0
    S=0
    N=0
    G=0
    for i in a:
        N+=i
        if i < 0:S+=i;G-=i
        else:L+=i;G+=i
    print 'Long %-.8e Short %-.8e Net %-.8e Gross %-.8e' % (L,S,N,G)
    return (L,S,N,G)
def x2print(x,name=''):
    if name != '':
        print name
    n=len(x)/2
    for i in range(n):print '%4d %20.8e %20.8e'%(i+1,x[i],x[i+n])
def xprint(x,name=''):
    if name != '':
        print name
    n=len(x)
    for i in range(n):print '%4d %20.8e'%(i+1,x[i])
def testmul(n,n1,n2,n3,H,x,y):
    ij = 0
    for i in range(n):
        y[i] = 0
        for j in range(i+1):
            y[i] += H[ij] * x[j]
            if i != j:
                y[j] += H[ij] * x[i]
            ij+=1
def lsmul(n,n1,n2,n3,H,x,y):
    w=[0]*ns
    j=0
    for i in range(ns):
        w[i]=x[i]
        if lab[j] == i:
            w[i]+=x[ns+j]
            j+=1
    testmul(ns,n1,n2,n3,H,w,y)
    j=0
    for i in range(ns):
        if lab[j] == i:
            y[ns+j]=y[i]
            y[i]-=x[ns+j]*pen[i]
            y[ns+j]-=x[i]*pen[i]
            j+=1
def makepen(n,pen,tt):
    x=[0]*n
    y=[0]*n
    for i in range(n):
        x[i]=1
        tt(n,n,n,n,H,x,y)
        pen[i]=2*y[i]
        x[i]=0
        
ns=10
H=[.1,
   1e-5,.2,
   1e-5,-1e-5,.3,
   1e-5,1e-5,1e-5,.4,
   1e-5,-1e-5,1e-5,1e-5,.5,
   1e-5,1e-5,1e-5,1e-5,1e-5,.6,
   1e-5,-1e-5,1e-5,-1e-5,1e-5,1e-5,.7,
   -1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.8,
   1e-5,1e-5,4e-5,-1e-5,2e-5,1e-5,1e-5,1e-5,.9,
   1e-5,1e-5,-1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,-1e-5,1]
A=[1,-1]*ns+[1,1]*ns
m=2
L=[-100]*ns+[0]*ns+[0]+[2]
U=[0]*ns+[100]*ns+[0]+[2]
lab=[i for i in range(ns)]
pen=[0]*ns
makepen(ns,pen,testmul)
x=[]
c=[.11,.12,.13,.14,.15,-.5,-.4,-.3,-.2,-.1]
CC=c+c
lp = 0
n=2*ns
print BasicQpOpt(n,m,A,L,U,x,CC,H,lp,lsmul,n) 
x2print(x,'balanced')
lscheck(x)
print 'Utility %20.8e'%utility(CC,H,x,lsmul)
xc=combine(x)
xprint(xc,'balanced')
print 'Utility %20.8e'%utility(c,H,xc,testmul)
A=[]
m=0
L=[-100]*ns+[0]*ns
U=[0]*ns+[100]*ns
print BasicQpOpt(n,m,A,L,U,x,CC,H,lp,lsmul,n) #x=-QinvCC
x2print(x,'Unconstrained')
lscheck(x)
print 'Utility %20.8e'%utility(CC,H,x,lsmul)
xb=[]
BB=[-1]*n
print BasicQpOpt(n,m,A,L,U,xb,BB,H,lp,lsmul,n)
x2print(xb,'Split weights from budget constraint vector')
lscheck(xb)
xp=[]
PP=[1]*ns+[-1]*ns
print BasicQpOpt(n,m,A,L,U,xp,PP,H,lp,lsmul,n)
x2print(xp,'Split weights from gross value constraint vector')
lscheck(xp)

m1=dot(xb,BB)
l1=dot(BB,x)/m1
modCC=addvec(CC,BB,-l1)
modx=[]
print BasicQpOpt(n,m,A,L,U,modx,modCC,H,lp,lsmul,n)
x2print(modx,'Split weights using linear term modified to make the net value 0')
lscheck(modx)
print 'Utility %20.8e'%utility(CC,H,modx,lsmul)
modxx=combine(modx)
xprint(modxx,'Weights using linear term modified to make the net value 0')
lscheck(modxx)
print 'Utility %20.8e'%utility(c,H,modxx,testmul)


l=[-100]*ns
u=[100]*ns
bb=[-1]*ns
y=[]
print BasicQpOpt(ns,m,A,l,u,y,c,H,lp,testmul,ns) #x=-QinvCC
xprint(y,'Unconstrained')
lscheck(y)
print 'Utility %20.8e'%utility(c,H,y,testmul)
yb=[]
print BasicQpOpt(ns,m,A,l,u,yb,bb,H,lp,testmul,ns)
xprint(yb,'Weights from budget constraint vector')
lscheck(yb)
yp=combine(xp)
pp=[0]*ns
testmul(ns,1,1,1,H,yp,pp)
xprint(yp,'Combined split weights from Gross value constraint')
xprint(pp,'Implied combined gross value constraint')
m1=dot(yb,bb)
l1=dot(bb,y)/m1
print 'Lagrange multiplier %-.8e'%l1
modc=addvec(c,bb,-l1)
xprint(modc,'Modified linear terms')
mody=[]
print BasicQpOpt(ns,m,A,l,u,mody,modc,H,lp,testmul,ns)
xprint(mody,'Optimal weights using modified linear terms')
lscheck(mody)
print 'Utility %20.8e'%utility(modc,H,mody,testmul)
print 'Utility %20.8e'%utility(c,H,mody,testmul)

A=[1,-1]*ns
l=[-100]*ns
u=[0]*ns
m=2
for i in range(ns):
    if mody[i]>0:A[2*i+1]=1;l[i]=0;u[i]=100
l+=[0]+[2]
u+=[0]+[2]
ybal=[]
print BasicQpOpt(ns,m,A,l,u,ybal,c,H,lp,testmul,ns)
xprint(ybal,'Balanced')
lscheck(ybal)
print 'Utility %20.8e'%utility(c,H,ybal,testmul)

print BasicQpOpt(ns,m,A,l,u,ybal,modc,H,lp,testmul,ns)
xprint(ybal,'Balanced')
lscheck(ybal)
print 'Utility %20.8e'%utility(c,H,ybal,testmul)

x2print(c+modc,'Original and changed linear terms')

wp=[]
step=[.01]*ns
f=[1]
scale=1
patc=modc
#PatternMin(ns,wp,step,f,scale,patutil,1,30,1)
if QuasiNewton(ns,wp,1,ns*20,f,patutil,1e-16,2,1):print 'Quasi-Newton step failed'
print 'Utility (pattern using modc)\t\t%20.10e'%utility(modc,H,wp,testmul)
print 'Check with value from PatternMin\t%20.10e'%f[0]
wqp=[]
m=1
A=[1]*ns
print BasicQpOpt(ns,m,A,l,u,wqp,c,H,lp,testmul,ns)
x2print(wp+wqp,'Comparison between pattern search and qp')
lscheck(wp)
lscheck(wqp)
print 'Utility (pattern using c)\t\t%20.10e'%utility(c,H,wp,testmul)
print 'Utility (qp)\t\t\t\t%20.10e'%utility(c,H,wqp,testmul)

