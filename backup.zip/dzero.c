/*
	set a general vector to zero
*/
#include "ldefns.h"


void dzero(dimen n, vector x, increment incx)
{
	dset(n,0.0,x,incx);
}
void szero(dimen n, float* x, increment incx)//single precision
{
	sset(n,0.0,x,incx);
}
