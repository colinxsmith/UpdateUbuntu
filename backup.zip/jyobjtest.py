import QuadMul
def qmul(n,n1,n2,n3,q,x,y):
	print 'qmul in jython'
	ij=0
	for i in range(n):
		y[i]=0
		for j in range(i+1):
			y[i]+=q[ij]*x[j]
			if i!=j:y[j]+=q[ij]*x[i]
			ij+=1
class PassIt(QuadMul):
	def __init__(self):print self
	def hmul(self,n,n1,n2,n3,q,x,y):qmul(n,n1,n2,n3,q,x,y)
from java.lang import *
from jarray import *
try:System.loadLibrary('safejavajy')
except:print 'Cannot load native code'
import Optimise
Q=[1,0,1]
x=[.55,.25]
y=array([0,0],Double)
tt=PassIt()
tt.hmul(2,1,1,1,Q,x,y)
print y
a=Optimise()
a.n=2
a.m=1
a.a=[1,1]
a.hmul=tt
a.lower=[0,0,1]
a.upper=[1,1,1]
a.c=[-1,1]
a.h=[1,.1,2]
a.OptSetup(2)
print a.x
