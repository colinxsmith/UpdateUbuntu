#!/usr/bin/env python
from Opt import *
from re import sub
from time import clock
r12=pow(12,.5)
badval=-1e20
def gendates():
    months='Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split()
    years='97 98 99 00 01 02 03 04 05'.split()
    back=[]
    for i in years:
        for j in months:
            back.append(j+i)
    del back[-1]    #no Dec05
    del back[-1]    #no Nov05
    return back
def turnover(w,wi):
    return 0.5*sum([abs(w[i]-wi[i]) for i in range(len(w))])
def var(x,Q):
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    """risk is sqrt(x'.Q.x); x is a list of length, Q is of length n*(n+1)/2"""
    return pow(var(x,Q),.5)
def meanerror(x,Q):
    """meanerror is sqrt(sum (xiQi)**2); x is a list of length, Q is of length n"""
    return pow(sum([x[i]*x[i]*Q[i]*Q[i] for i in range(len(x))]),.5)
def BITAutil(gamma,w,bench,alpha,Q):
    gamma/=(1-gamma)
    ret=-gamma*dot(w,alpha)
    return ret+0.5*var([w[i]-bench[i] for i in range(len(w))],Q)
def readcov(a):
    assets=[]
    COV=[]
    while(1):
        line=a.readline()
        if not len(line):break
        line=line.strip()
        if not len(line):continue
        line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
        try:
            r=float(line)
            COV.append(r)
        except:
            assets.append(line)
    return(assets,COV)
def readfore(a):
    assets=[]
    COVfe=[]
    MEANfe=[]
    alpha=[]
    real_alpha=[]
    while(1):
        line=a.readline()
        if not len(line):break
        line=line.strip()
        if not len(line):continue
        line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
        vals=line.split(',')
        if len(vals)>1:
            assets.append(vals[0])
            MEANfe.append(float(vals[1]))
            try:alpha.append(float(vals[2]))
            except:
                print vals[0]
                alpha.append(badval)
            try:real_alpha.append(float(vals[3]))
            except:
                print vals[0]
                real_alpha.append(badval)
        else:
            COVfe.append(float(vals[0]))
    return(assets,MEANfe,alpha,real_alpha,COVfe)
def getUniverse(badstocks,front,covfront,FEfront,dates):
    ASSETS={}
    tnumdel=0
    for date in dates:
        print date
        numdel=0
        file=front+covfront+date+'.csv'
        (assetsC,Q)=readcov(open(file))
        if ASSETS=={}:
            for stock in assetsC:
                ASSETS[stock]=1
        else:
            for stock in ASSETS.keys():
                if not stock in assetsC: del ASSETS[stock];numdel+=1
        file=front+FEfront+date+'.csv'
        (assetsF,MEANfe,alphaF,real_alpha,COVfe)=readfore(open(file))
        for stock in ASSETS.keys():
            if not stock in assetsF: del ASSETS[stock];numdel+=1
        print '%d removed'%numdel
        tnumdel+=numdel
    print 'Total number of stocks removed',tnumdel

    if badstocks!=[]:        
        for stock in ASSETS.keys():
            if stock in badstocks:del ASSETS[stock]
    return ASSETS.keys()
class RobOpt:
    def __init__(self):
        self.propsS='n,m,maxmeanFE,maxstderrorFE,gamma,maxRisk,mFE,rFE'.split(',')
        self.propsL='A,L,U,SV,FL,FC,alpha,alphafe,COVfe,bench,initial,real_alpha'.split(',')
        for i in self.propsS:
            setattr(self,i,0)
        for i in self.propsL:
            setattr(self,i,[])
        self.nf=-1
        self.two=2
    def Opt(self):
        for i in self.propsS:
            print i,getattr(self,i)
        for i in self.propsL:
            print i,getattr(self,i)[:5]
        w=[]
        t1=clock()
        back=SOCPRobust(self.n,self.m,w,self.A,self.L,self.U,self.nf,
                                     self.SV,self.FL,self.FC,self.alpha,self.alphafe,
                                     self.COVfe,self.maxmeanFE,self.maxstderrorFE,
                                     self.gamma,self.maxRisk,self.bench,
                                     self.initial,self.mFE,self.rFE)
        t2=clock()
        print 'Robust optimisation needed %d secs'%(t2-t1)
        setattr(self,'w',w)
        return back
    def Props(self):
        absret=dot(self.alpha,self.w)
        benchret=dot(self.alpha,self.bench)
        relret=absret-benchret
        real_return=dot(self.real_alpha,self.w)
        bench_return=dot(self.real_alpha,self.bench)
        relrisk=risk([self.w[i]-self.bench[i] for i in range(self.n)],self.FC)
        meanerr=meanerror([self.w[i]-self.mFE*self.initial[i] for i in range(self.n)],self.alphafe)
        stderr=risk([self.w[i]-self.rFE*self.initial[i] for i in range(self.n)],self.COVfe)
        utility=BITAutil(self.gamma,self.w,self.bench,self.alpha,self.FC)
        cret=absret-self.two*meanerr
        return (real_return,bench_return,relret,relrisk,meanerr,stderr,utility,cret)
class OutObj:
    def __init__(self,real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn,cret):
        self.attr='real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn,cret'.split(',')
        for i in self.attr:
            setattr(self,i,eval(i))
            print i,getattr(self,i)
front='z:/Omam/OMAM Robust/'
covfront='USDoptimisercovMatrix'
FEfront='USDforecastErrorMatrix'
#badstocksF=open('badstocks')
badstocks=[]
#while 1:
#    line=badstocksF.readline()
#    if not len(line):break
#    badstocks.append(line.strip())
#dates='Jan00 Feb00 Mar00 Apr00 May00 Jun00 Jul00 Aug00 Sep00 Oct00 Nov00 Dec00 Jan01 Feb01 Mar01 Apr01 May01 Jun01 Jul01 Aug01 Sep01 Oct01 Nov01 Dec01'.split()
universefile='universe'
dates=gendates()
#dates='Jan00 Feb00 Mar00 Apr00'.split()
try:
    univ=open(universefile)
    stocks=[]
    for i in univ.readlines():
        stocks.append(i.strip())
    univ.close()
except:
    stocks=getUniverse(badstocks,front,covfront,FEfront,dates)
    univ=open(universefile,'w')
    for i in stocks:univ.write(i+'\n')
    univ.close()
print stocks


initial=[]
w=[]
Optr=RobOpt()
Optr.n=n=len(stocks)
print n
Optr.m=1
Optr.A=[1]*n
Optr.L=[0]*n+[1]
Optr.U=[1]*n+[1]
Optr.bench=[1.0/n]*n
Optr.gamma=0.2
maxRisk=.0001/r12
maxmeanFE=-1e-3
maxstderrorFE=-1e-3
Optr.mFE=1
Optr.rFE=1
OUTPUT={}
OUTPUTt={}
Optq=Opt()
for i in 'n,m,A,L,U,alpha,bench,initial,gamma'.split(','):
    setattr(Optq,i,getattr(Optr,i))
Optq.nfac=-1
Optq.Q=Optr.FC
Optq.names=stocks
Optq.revise=1
Optq.gamma=1
Optq.minrisk=0
Optq.maxrisk=maxRisk
for date in dates:
    print '+++++++++++++ Date %s +++++++++++++++++++++'%date
    fileC=front+covfront+date+'.csv'
    print fileC
    (assetsC,Q)=readcov(open(fileC))

    nC=len(assetsC)
    print nC,(nC*(nC+1)/2),len(Q)

    fileF=front+FEfront+date+'.csv'
    print fileF

    (assetsF,MEANfe,alphaF,real_alphaF,COVfe)=readfore(open(fileF))
    na=len(assetsF)
    print na,(na*(na+1)/2),len(COVfe)

    ASSETS={}
    for i in assetsC:
        ASSETS[i]=1
        

    pickout(n,stocks,nC,assetsC,Q)
#    eigval=eigen(n,Q)[0]
#    print 'Eigenvalues of the covariance matrix'
#    for i in range(n):
#        print '%4d %20.8e'%(i+1,eigval[i])
    pickout(n,stocks,na,assetsF,COVfe)
#    eigval=eigen(n,COVfe)[0]
#    print 'Eigenvalues of the error matrix'
#    for i in range(n):
#        print '%4d %20.8e'%(i+1,eigval[i])

    ALPHA={}
    ALPHAFE={}
    REAL_ALPHA={}
    for i in range(na):
        ALPHAFE[assetsF[i]]=MEANfe[i]
        ALPHA[assetsF[i]]=alphaF[i]
        REAL_ALPHA[assetsF[i]]=real_alphaF[i]

    alpha=[]
    alphafe=[]
    real_alpha=[]
    for i in stocks:
        real_alpha.append(REAL_ALPHA[i])
        alpha.append(ALPHA[i])
        alphafe.append(ALPHAFE[i])

    Optr.FC=Q
    Optq.Q=Q
    if initial==[]:
        initial=[0]*n
        Optr.maxmeanFE=10
        Optr.maxstderrorFE=10
    else:
        initial=[i for i in w]
        Optr.maxmeanFE=maxmeanFE
        Optr.maxstderrorFE=maxstderrorFE
    Optr.maxRisk=maxRisk
    Optr.initial=initial
    Optq.initial=initial
    Optr.alpha=alpha
    Optq.alpha=alpha
    Optr.COVfe=COVfe
    Optr.alphafe=alphafe
    Optr.real_alpha=real_alpha
    tries=0
    while 1:
        retcode=Optr.Opt()
        print SOCPlstestMessage(retcode)
        (real_return,bench_return,relret,relrisk,meanerr,stderr,utility,cret)=Optr.Props()
        if retcode==0:break
        else:
#            Optr.maxRisk+=.01/r12;tries+=1
            Optr.maxmeanFE+=.001;tries+=1
            Optr.maxstderrorFE+=.001;tries+=1
            
    turn=turnover(Optr.w,Optr.initial)
    Optq.delta=turn
    Optq.maxrisk=relrisk
    for i in range(n):
        print '%20s\t%20.8f\t%20.8f%20.8f'%(stocks[i],Optr.alpha[i],Optr.w[i],Optr.initial[i])
    print real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn
    OUTPUT[date]=OutObj(real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn,cret)
    w=[i for i in Optr.w]
    Optq.opt()
    Optr.w=[i for i in Optq.w]
    turn=turnover(Optr.w,Optr.initial)
    (real_return,bench_return,relret,relrisk,meanerr,stderr,utility,cret)=Optr.Props()
    OUTPUTt[date]=OutObj(real_return,bench_return,relret,relrisk,meanerr,stderr,utility,turn,cret)

outfile=open('s:/robustoutbase1.csv','w')
#outfile=open('s:/robustout1.csv','w')
Labels={'date':',','bench_return':'Benchmark return,','real_return':'Real Ret,','relret':'Rel Ret,','relrisk':'Rel Risk,','meanerr':'Alpha Err,',
        'stderr':'Alpha Std,','utility':'Utility,','turn':'Turnover,','cret':'Cor Rel Return,'}
"""
outfile.write(',')
for date in dates:
    outfile.write('%s,'%date)
outfile.write('\n')
for i in 'real_return,bench_return,relret,relrisk,meanerr,stderr,turn'.split(','):
    outfile.write(Labels[i])
    for date in dates:
        outfile.write('%f,'%getattr(OUTPUT[date],i))
    outfile.write('\n')
outfile.write('\n')
outfile.write('\n')
for i in 'real_return,bench_return,relret,relrisk,meanerr,stderr,turn'.split(','):
    outfile.write(Labels[i])
    for date in dates:
        outfile.write('%f,'%getattr(OUTPUTt[date],i))
    outfile.write('\n')
"""

for i in 'date,real_return,bench_return,relret,relrisk,meanerr,stderr,turn,cret'.split(','):
    outfile.write(Labels[i])
outfile.write(',,')
for i in 'real_return,bench_return,relret,relrisk,meanerr,stderr,turn,cret'.split(','):
    outfile.write(Labels[i])
outfile.write('\n\n')
for date in dates:
    outfile.write('%s,'%date)
    for i in 'real_return,bench_return,relret,relrisk,meanerr,stderr,turn,cret'.split(','):
        outfile.write('%f,'%getattr(OUTPUT[date],i))
    outfile.write(',,')
    for i in 'real_return,bench_return,relret,relrisk,meanerr,stderr,turn,cret'.split(','):
        outfile.write('%f,'%getattr(OUTPUTt[date],i))
    outfile.write('\n')
