#!/bin/env python

import sys
sys.path.append('c:/users/colin/safeqp')

def countneg(a):
    back=0
    low=0
    for i in a:
        if i<=0:back+=1;low=min(low,i)
    return (back,low)
def testhere(n1,n2):
    if n1.find(n2)==0: return 1
    else: return 0
from Optn import *
def reportSpec(n,names,nsect,sectdef,SRisk,SBreak,type='Risk,'):
    print ',Specific,'
    ip=-1
    for k in range(1+nsect):#1 portfolio , nsect sectors
        print '%s%15.8e,'%(type,SRisk[k])
        if k==0:
            for i in range(n):
                ip+=1
                print '%s,%15.8e,'%(names[i],SBreak[ip])
        else:
            out=''
            for i in range(n):
                if sectdef[i+(k-1)*n]:
                    ip+=1
                    print 'Sector%d %s,%15.8e,'%(k,names[i],SBreak[ip])

def reportFactor(n,names,nf,fnames,nsect,sectdef,nfgroup,fgroupdef,TRisk,TBreak,type='Risk,'):
    stpS=[n]+[sum(sectdef[i*n:(i*n+n)]) for i in range(nsect)]#count the number of assets in each sector
    stpLF=[sum(fgroupdef[i*nf:(i*nf+nf)]) for i in range(nfgroup)]#count the number of factors in each factor group
    ssect=sum(sectdef)#Total number of assets in all sectors
    lsect=sum(fgroupdef)#Total number of factors in all factor groups
    out=',Total,'
    for i in range(nf):
        out+='%s,'%fnames[i]
    for i in range(nfgroup):
        out+='Total FacGroup%d,'%(i+1)
        for j in range(nf):
            if fgroupdef[j+i*nf]:
                out+='%s,'%fnames[j]
    print out
    start=0
    for k in range(1+nsect):#1 portfolio , nsect sectors
        out=type
        for i in range(1+nf+lsect+nfgroup):
            out+='%15.8e,'%(TRisk[i+k*(1+nf+lsect+nfgroup)])
        print out
        j=-1
        for jj in range(n):
            if k==0:
                out='%s,'%names[jj];j=jj
                ip=-1
                for i in range(1+nf):
                    ip+=1
                    out+='%15.8e,'%TBreak[j+ip*(n)]
                for ii in range(nfgroup):
                    ip+=1
                    out+='%15.8e,'%TBreak[j+ip*(n)]#the column below the factor sector total
                    for i in range(nf):
                        if fgroupdef[i+ii*nf]:
                            ip+=1
                            out+='%15.8e,'%TBreak[j+ip*(n)]
                print out
            else:
                if sectdef[jj+(k-1)*n]:
                    out='sector %d %s,'%(k,names[jj]);j+=1
                    ip=-1
                    for i in range(1+nf):
                        ip+=1
                        out+='%15.8e,'%TBreak[start+j+ip*(stpS[k])]
                    for ii in range(nfgroup):
                        ip+=1
                        out+='%15.8e,'%TBreak[start+j+ip*(stpS[k])]#the column below the factor sector total
                        for i in range(nf):
                            if fgroupdef[i+ii*nf]:
                                ip+=1
                                out+='%15.8e,'%TBreak[start+j+ip*(stpS[k])]
                    print out
        start+=stpS[k]*(1+nf+lsect+nfgroup)

#valsJPY={'JPNCGL1': 200000.0, 'JPNCMP1': -200000.0, 'JPNGNR1': 200000.0, 'JPNFWE1': 200000.0, 'JPNDFL1': 200000.0, 'JPNCPY1': 200000.0, 'JPNBGU1': 200000.0, 'JPNBUA1': -200000.0, 'JPNGRT1': 200000.0, 'JPNDHZ1': -200000.0, 'JPNDBB1': 200000.0, 'JPNDGP1': -200000.0, 'JPNFMX1': -200000.0, 'JPNFNP1': 200000.0, 'JPNCIH1': -200000.0, 'JPNBPW1': -200000.0, 'JPNDSB1': 200000.0, 'JPNDBU1': -200000.0, 'JPNBFM1': 200000.0, 'JPNGHW1': 200000.0, 'JPNDCK1': -200000.0, 'JPNDER1': -200000.0, 'JPNDBJ1': 200000.0, 'JPNGCI1': -200000.0, 'JPNDCR1': -200000.0, 'JPNBFT1': 200000.0, 'JPNDEC1': -200000.0, 'JPNCMA1': -200000.0, 'JPNDBE1': -200000.0, 'JPNDHJ1': -200000.0, 'JPNCVT1': 200000.0, 'JPNDCJ1': 200000.0, 'JPNBFN1': 200000.0, 'JPNDGB1': 200000.0, 'JPNESN1': -200000.0, 'JPNDCU1': -200000.0, 'JPNENQ1': -200000.0, 'JPNCFP1': 200000.0, 'JPNGGI1': -200000.0, 'JPNATJ1': -200000.0, 'JPNAJJ1': 200000.0, 'JPNBGK1': 200000.0, 'JPNGKI1': 200000.0, 'JPNFOR1': 200000.0, 'JPNADL1': -200000.0, 'JPNEJJ1': 200000.0, 'JPNDBH1': -200000.0, 'JPNDLM1': 200000.0, 'JPNGBU1': -200000.0, 'JPNDFX1': -200000.0, 'JPNAXG1': 200000.0, 'JPNFMU1': 200000.0, 'JPNCZN1': 200000.0, 'JPNDGE1': -200000.0, 'JPNDAH1': 200000.0, 'JPNDHL1': -200000.0, 'JPNCYI1': 200000.0, 'JPNGBA1': -200000.0, 'JPNDMF1': 200000.0, 'JPNCJB1': -200000.0, 'JPNCLZ1': -200000.0, 'JPNDBI1': -200000.0, 'JPNCJD1': 200000.0, 'JPNCDH1': -200000.0, 'JPNDGD1': -200000.0, 'JPNEXX1': 200000.0, 'JPNEMW1': -200000.0, 'JPNDJI1': 200000.0, 'JPNCDZ1': -200000.0, 'JPNAQX1': -200000.0, 'JPNBGI1': 200000.0, 'JPNGBQ1': -200000.0, 'JPNDJG1': 200000.0, 'JPNELG1': 200000.0, 'JPNDEV1': -200000.0, 'JPNDGG1': 200000.0, 'JPNECX1': 200000.0, 'JPNDKF1': -200000.0, 'JPNDAG1': 200000.0, 'JPNAON1': -200000.0, 'JPNCYS1': -200000.0, 'JPNGBP1': 200000.0, 'JPNBFQ1': -200000.0, 'JPNDAF1': 200000.0, 'JPNDME1': 200000.0, 'JPNEIS1': -200000.0, 'JPNDLX1': -200000.0, 'JPNFQN1': 200000.0, 'JPNCAN1': -200000.0, 'JPNBTO1': 200000.0, 'JPNEIX1': 200000.0, 'JPNGKB1': 200000.0, 'JPNGBR1': 200000.0, 'JPNCHC1': -200000.0, 'JPNFHQ1': 200000.0, 'JPY': 9400000.0, 'JPNEBF1': 200000.0, 'JPNEUS1': -200000.0}
#valsUSD={'USAALO1': 207144.0, 'USAHGP1': 226233.0, 'USAGMU1': 243880.0, 'USAHUU2': -350595.0, 'USAFVN1': 214914.0, 'USAWEF1': -118332.0, 'USANFE1': 81750.0, 'USA2US1': 105450.0, 'USAAGY1': -100650.0, 'USANOI1': -82566.0, 'USAK9H1': 221200.0, 'USAYNK1': -85624.0, 'USAMO51': 0.0, 'USAZQK1': -106524.0, 'USAQW51': -278460.0, 'USAMTI1': -107814.0, 'USAEMG1': -212124.0, 'USANNE1': -213638.0, 'USAQV81': 192546.0, 'USAL591': -101472.0, 'USAL6I1': 188700.0, 'USA3LD1': 223824.0, 'USAJGX1': -103051.0, 'USACXA1': -99291.0, 'USADFA1': 207459.0, 'USAXJP1': 123150.0, 'USA3X81': 190696.0, 'USAM8P1': -93439.0, 'USAPXB1': -219510.0, 'USAAPX1': -103610.0, 'USAHN41': -113152.0, 'USARB91': 193828.0, 'USAAUL1': 0.0, 'USAK1G1': -193991.0, 'USAKQY1': -197200.0, 'USAC1R2': -194145.0, 'USAPPT1': 101664.0, 'USA3LE1': -201662.0, 'USAIB11': 119886.0, 'USAISY1': 230310.0, 'USAFJ61': -96710.0, 'USAWJ41': -113148.0, 'USAXJJ1': 187000.0, 'USAPZ71': -210448.0, 'USAQGY1': -120995.0, 'USAKTU1': 109148.0, 'USANR51': -109800.0, 'USA4H51': -194130.0, 'USANS91': -126670.0, 'USAAG41': 92800.0, 'USAV8C1': -136940.0, 'USABBA1': -131490.0, 'USAW2I1': -107312.0, 'USAZKM1': 113390.0, 'USAHFL1': -189728.0, 'USAHWU2': -107776.0, 'USAKKX1': 248576.0, 'USABU71': 95760.0, 'USAB3F1': 154734.0, 'USAB211': 176946.0, 'USAOQJ1': -97686.0, 'USAD3D1': 268200.0, 'USAWG11': -236096.0, 'USAJ471': 193752.0, 'USABYW1': 172272.0, 'USAHC71': 207253.0, 'USALLX1': 222720.0, 'USAHML1': 157788.0, 'USAPEK2': 206424.0, 'USAWSP1': -87920.0, 'USAY461': 184175.0, 'USAOFA1': 118524.0, 'USAWYQ1': -251826.0, 'USAURY1': 112068.0, 'USAEE21': -246568.0, 'USADB51': -281487.0, 'USA16Q1': 213890.0, 'USAI951': -99270.0, 'USAM4M1': 110610.0, 'USA4XV1': -208820.0, 'USANCW1': 106650.0, 'USAS231': -223200.0, 'USA4BY1': -114180.0, 'USANY12': 99882.0, 'USABLB1': 200720.0, 'USD': 10421919, 'USAWL11': -202125.0, 'USAAGR1': -192720.0, 'USA4U81': -110998.0, 'USA4QD1': 45832.0, 'USAMP11': -128075.0, 'USA14R1': -93412.0, 'USAQ9J1': 358720.0, 'USAKPH1': -180856.0, 'USADJG1': 243530.0, 'USAAF51': -253750.0, 'USABMN1': 221923.0, 'USABTB1': 241620.0, 'USAW9M1': -109127.0, 'USAVAX1': -210090.0, 'USAVEH1': 142175.0, 'USAVGD1': 128526.0, 'USAR8K1': 114634.0, 'USAVHG1': 98568.0, 'USAP5Z1': -104752.0, 'USAA5F1': 106850.0, 'USA3VS1': 261840.0, 'USAN7G1': 108990.0, 'USAI4A1': -106559.0, 'USAMO61': -89400.0, 'USAKQV1': -136325.0, 'USAJUT1': -197743.0, 'USAX5T1': -209988.0, 'USA3GA1': -92950.0, 'USAKLC1': -133123.0}
valsJPY={'JPNCGL1': 200000.0, 'JPNCMP1': -200000.0, 'JPNGNR1': 200000.0}
valsUSD={'USAALO1': 207144.0, 'USAHGP1': 226233.0, 'USAGMU1': 243880.0}
print sum(valsJPY.values())
print sum(valsUSD.values())

#Change the next 6 lines to do single market examples
#totalValue=sum(valsJPY.values())
totalValue=sum(valsUSD.values())+sum(valsJPY.values())
port={}
for i in valsUSD.keys():
    port[i]=valsUSD[i]/totalValue
for i in valsJPY.keys():
    port[i]=valsJPY[i]/totalValue
    

pAssets =port.keys()

front='c:/users/colin/BIM/apr25/bimtest'
model=front+'/'+'testModel.csv'
Yfile=front+'/'+'BIMe_203_GLFac_Exposures.20041101'
Gfile=front+'/'+'BIMe_203_GLCovar.20041101'
Sfile=front+'/'+'BIMe_203_GLScaling.20041101'
YSfile=front+'/'+'YS.20041101'
#FGfile=front+'/'+'FG.20041101' # for testing
o=Opt()
print version()
o.getmodel(model,pAssets)

localnames=[i for i in o.mnames]



o.w = []
for i in o.names:
    o.w.append(port[i])

o.bench=[0]*(o.n)



gfnames={}   
getnames(open(Gfile),gfnames)
lnames={}
getnames(open(Sfile),lnames)
globalnames=gfnames.keys()


badnames=[i for i in o.fnames if not i in lnames.keys()]
if badnames!=[]:print 'These factor names are not compatible'
for i in badnames:
    print i

nl=len(o.fnames)
ng=len(globalnames)
localorder={}
globalorder={}

setorder(localorder,o.fnames)
setorder(globalorder,globalnames)

G=getsym(ng,open(Gfile),globalorder)
#FG=getsym(nl,open(FGfile),localorder)
S=getnonsym(nl,nl,open(Sfile),localorder,localorder)
Y=getnonsym(nl,ng,open(Yfile),localorder,globalorder)
YS=getnonsym(nl,ng,open(YSfile),localorder,globalorder)

#FCg=[0]*(nl*(nl+1)/2)
#getFSF(nl,ng,G,YS,FCg)
#ij=0
#for i in range(nl):
#    for j in range(i+1):
#        print '%d,%d,,%20.8e,%20.8e,%20.8e'%(i,j,FG[ij],FCg[ij],FG[ij]-FCg[ij]);ij+=1

"""
extern "C" void FriskAttribution(size_t n,size_t nl,vector FFC,vector FLOAD,vector x,
										   size_t nsect,
										   size_t* sectdef,size_t ng,vector G,vector YS,
										   size_t nfgroup,size_t* fgroupdef,
										   size_t nggroup,size_t* ggroupdef,
										   vector TotalRisks,vector GlobalRisks,vector LocalRisks,
										   vector TotalBreak,vector GlobalBreak,vector LocalBreak);
extern "C" void FvarianceAttribution(size_t n,size_t nl,vector FFC,vector FLOAD,vector x,
										   size_t nsect,
										   size_t* sectdef,size_t ng,vector G,vector YS,
										   size_t nfgroup,size_t* fgroupdef,
										   size_t nggroup,size_t* ggroupdef,
										   vector TotalRisks,vector GlobalRisks,vector LocalRisks,
										   vector TotalBreak,vector GlobalBreak,vector LocalBreak);
/*
	n			number of assets
	nl			number of local factors
	FC			Factor Covariances in lower triangle
	FL			Factor Loadings
	x			assets weights
	nsect		number of sectors
	sectdef		list of length n*nsect sectdef[i+j*n] = 1 if asset is in sector j, 0 otherwise
	ng			number of global factors
	G			global factor covariances in lower trinagle
	YS			exposures of local to global (scaled BARRA way)
	nfgroup		number of local factor sectors
	fgroupdef	list of length n*nfgroup fgroupdef[i+j*n] = 1 if factor i is in sector j, 0 otherwise
	nggroup		number of global factor sectors
	ggroupdef	list of length n*nggroup ggroupdef[i+j*n] = 1 if factor i is in sector j, 0 otherwise
	TotalRisks	array length (1+nsect)*(1+nl+nsl+nfgroup) where nsl is the number of 1s in fgroupdef 
				(i.e. the total number of factors in all the factor groups)
				TotalRisks holds the risks for
				Portfolio		1 element
					then nl factor risks
						then nfgroup groups of
							factor group total risk
							risk for each factor in the group
				Then nsect groups for each
					sector risk
						then nl factor risks
							then nsl groups of
								factor group total risk
								risk for each factor in the group
	GlobalRisks	similar to TotalRisks
	LocalRisks	similar to TotalRisks
	TotalBreak	array length ((n+nssect)*(1+nl+nsl)) where nssect is the total number of assets
				in all sectors
				TotalBreak holds the breakdown of the Totalrisks over the assets
				the first n give the asset contributions for total risk
				the next block of n*nl gives the asset breakdown for each of the nl factors
				then nfgroup blocks of factor group breakdowns
				then the breakdown of the Totalrisks over the assets in each sector (by sector)
					the first n give the asset contributions for total risk
					the next block of n*nl gives the asset breakdown for each of the nl factors
					then nfgroup blocks of factor group breakdowns

	GlobalBreak	similar to TotalBreak
	LocalBreak	similar to TotalBreak
*/
extern "C" void SriskAttribution(size_t n,vector SSV,vector x,size_t nsect,
										   size_t* sectdef,vector Rctr,vector TRctr);
extern "C" void SvarianceAttribution(size_t n,vector SSV,vector x,size_t nsect,
										   size_t* sectdef,vector Rctr,vector TRctr);
/*
	n		number of stocks
	SV		specific variances
	x		weights
	nsect	number of sectors
	sectdef	n*nsect array of 1s and 0s, ith sector weight for jth sector is sectdef[i+j*n]
	Rctr	output variances for stocks length n+sum(non-zeros in each sector)
	TRctr	output variances for sectors size nsect+1, the first total is for the portfolio
*/
"""
nsect=2
sectdef=[testhere(i,'US') for i in o.names]+[testhere(i,'JP') for i in o.names]
nfgroup=2
fgroupdef=[0,0,1,1]+[0]*(nl-4)+[0,1,0]+[0]*(nl-3)
nggroup=2
ggroupdef=[0,0,1]+[0]*(ng-3)+[0,0,1,1]+[0]*(ng-4)
ssect=sum(sectdef)
lsect=sum(fgroupdef)
gsect=sum(ggroupdef)
TRisk=[0]*((1+nl+lsect+nfgroup)*(1+nsect))
GRisk=[0]*((1+ng+gsect+nggroup)*(1+nsect))
LRisk=[0]*((1+nl+lsect+nfgroup)*(1+nsect))
TBreak=[0]*((1+nl+lsect+nfgroup)*(o.n+ssect))
GBreak=[0]*((1+ng+gsect+nggroup)*(o.n+ssect))
LBreak=[0]*((1+nl+lsect+nfgroup)*(o.n+ssect))
if jython:
    TRisk=jython_set(TRisk)
    GRisk=jython_set(GRisk)
    LRisk=jython_set(LRisk)
    TBreak=jython_set(TBreak)
    GBreak=jython_set(GBreak)
    LBreak=jython_set(LBreak)
FriskAttribution(o.n,nl,o.FC,o.FL,o.w,nsect,sectdef,ng,G,YS,nfgroup,fgroupdef,nggroup,ggroupdef,TRisk,GRisk,LRisk,TBreak,GBreak,LBreak)
print 'Total Risk'
reportFactor(o.n,o.names,nl,o.fnames,nsect,sectdef,nfgroup,fgroupdef,TRisk,TBreak)
print
print 'Local Risk'
reportFactor(o.n,o.names,nl,o.fnames,nsect,sectdef,nfgroup,fgroupdef,LRisk,LBreak)
print
print 'Global Risk'
reportFactor(o.n,o.names,ng,globalnames,nsect,sectdef,nggroup,ggroupdef,GRisk,GBreak)
print

TVar=[0]*((1+nl+lsect+nfgroup)*(1+nsect))
GVar=[0]*((1+ng+gsect+nggroup)*(1+nsect))
LVar=[0]*((1+nl+lsect+nfgroup)*(1+nsect))
TVBreak=[0]*((1+nl+lsect+nfgroup)*(o.n+ssect))
GVBreak=[0]*((1+ng+gsect+nggroup)*(o.n+ssect))
LVBreak=[0]*((1+nl+lsect+nfgroup)*(o.n+ssect))
if jython:
    TVar=jython_set(TVar)
    GVar=jython_set(GVar)
    LVar=jython_set(LVar)
    TVBreak=jython_set(TVBreak)
    GVBreak=jython_set(GVBreak)
    LVBreak=jython_set(LVBreak)

Mineg=[0.0]
if jython:
    Mineg=Convert(Mineg)
print 'back ',FvarianceAttribution(o.n,nl,o.FC,o.FL,o.w,nsect,sectdef,ng,G,YS,nfgroup,fgroupdef,nggroup,ggroupdef,TVar,GVar,LVar,TVBreak,GVBreak,LVBreak,0,Mineg)
print Mineg[0]
num=0
low=0
back=countneg(TVar);print back
num+=back[0]
low=min(back[1],low)
back=countneg(GVar);print back
num+=back[0]
low=min(back[1],low)
back=countneg(LVar);print back
num+=back[0]
low=min(back[1],low)
back=countneg(TVBreak);print back
num+=back[0]
low=min(back[1],low)
back=countneg(GVBreak);print back
num+=back[0]
low=min(back[1],low)
back=countneg(LVBreak);print back
num+=back[0]
low=min(back[1],low)
print num
print low
print 'Total Variance'
reportFactor(o.n,o.names,nl,o.fnames,nsect,sectdef,nfgroup,fgroupdef,TVar,TVBreak,type='Variance,')
print
print 'Local Variance'
reportFactor(o.n,o.names,nl,o.fnames,nsect,sectdef,nfgroup,fgroupdef,LVar,LVBreak,type='Variance,')
print
print 'Global Variance'
reportFactor(o.n,o.names,ng,globalnames,nsect,sectdef,nggroup,ggroupdef,GVar,GVBreak,type='Variance,')
print

SRisk=[0]*(1+nsect)
SBreak=[0]*(o.n+ssect)
if jython:
    SRisk=jython_set(SRisk)
    SBreak=jython_set(SBreak)
SriskAttribution(o.n,o.SV,o.w,nsect,sectdef,SBreak,SRisk)
print 'Specific Risk'
reportSpec(o.n,o.names,nsect,sectdef,SRisk,SBreak)
print

SVar=[0]*(1+nsect)
SVBreak=[0]*(o.n+ssect)
if jython:
    SVar=jython_set(SVar)
    SVBreak=jython_set(SVBreak)
print 'Specific Variance'
SvarianceAttribution(o.n,o.SV,o.w,nsect,sectdef,SVBreak,SVar)
reportSpec(o.n,o.names,nsect,sectdef,SVar,SVBreak,type='Variance,')
