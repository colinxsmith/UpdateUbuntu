#Copyright 2004 Colin Smith, COR-FS
#Python version of the Properties methods in the COR-FS Risk Engine (C++ code in safeqp.dll)


def Symmult(n,S,x,Sx):
    """Multiply a symmetric matrix S by a vector x to get Sx.
    S is a list of length n*(n+1)/2 containing the lower triangle of a symmetric
    matrix stored in the order [00,10,11,20,21,22,.......]
    x and Sx are lists of length n
    """
    if len(x)<n:raise 'x is not long enough'
    if len(Sx)<n:raise 'Sx is not long enough'
    if len(S)<n*(n+1)/2:raise 'S is not long enough'
    ij=0
    for i in range(n):
        Sx[i]=0
        for j in range(i+1):
            Sx[i]+=S[ij]*x[j]
            if i!=j:Sx[j]+=S[ij]*x[i]
            ij+=1

def Dot(n,x,y,nother=1,index=0):
    """General scalar product of vectors x and y with jump in index for y."""
    s=0
    for i in range(n):s+=x[i]*y[i*nother+index]
    return s

rootsquaresum=lambda a,b:pow(a*a+b*b,0.5) #returns squareroot(a*a+b*b)
rootsquaredif=lambda a,b:pow(a*a-b*b,0.5) #returns squareroot(a*a-b*b)

class Properties:
    def __init__(self):
        self.bench=[]
        self.w=[]
        self.n=0
        self.nfac=0
        self.SV=[]
        self.FC=[]
        self.FL=[]
    def expose(self,w):
        """Find the factor exposures for weights w"""
        fx=[0]*self.nfac
        for i in range(self.nfac):
            FXi=[self.FL[j+i*self.n] for j in range(self.n)]
            fx[i]=Dot(self.n,FXi,w)
        return fx
    def FMC(self,fx):
        """Find marginal derivatives for the factor part for exposures fx,
        (fmc is a list of implied factor alphas)"""
        Cfx=[0]*self.nfac
        Symmult(self.nfac,self.FC,fx,Cfx)
        fmc=[0]*self.n
        for i in range(self.n):fmc[i]=Dot(self.nfac,Cfx,self.FL,self.n,i)
        fvar=Dot(self.nfac,Cfx,fx)
        frisk=pow(fvar,0.5)
        if frisk>1e-15:Cfx=[i/frisk for i in Cfx]
        else:Cfx=[0]*self.nfac
        return (fmc,Cfx)
    def SMC(self,w):
        """Find marginal derivatives for the non-factor part for weights w,
        (smc is a list of implied non-factor alphas)"""
        smc= [self.SV[i]*w[i] for i in range(self.n)]
        svar=Dot(self.n,smc,w)
        srisk=pow(svar,0.5)
        if srisk>1e-15:return (smc,[i/srisk for i in smc])
        else:return (smc,[0]*(self.n))
    def MC(self,w,fmc,smc):
        """Find marginal derivatives for the weights w using the implied alphas from FMC and SMC,
        mc is a list of implied alphas i.e. product of stock level covariance matrix and w"""
        mc= [fmc[i] + smc[i] for i in range(self.n)]
        var=Dot(self.n,mc,w)
        risk=pow(var,0.5)
        if risk > 1e-15:return [i/risk for i in mc]
        else:return [0]*self.n
    def props(self):
        if self.w==[]:return
        if self.FL==[]:return
        if self.FC==[]:return
        if self.SV==[]:return
        if self.n==0:return
        if self.nfac==0:return
        #Absolute properties
        self.FX=self.expose(self.w)
        (fmc,fmctr)=self.FMC(self.FX)
        (smc,smctr)=self.SMC(self.w)
        self.FMCTR=[i for i in fmctr]
        self.FMCTR+=smctr
        self.MCTR=self.MC(self.w,fmc,smc)
        self.arisk=Dot(self.n,self.w,self.MCTR)
        if self.bench==[]:return
        #Active Properties
        active=[self.w[i]-self.bench[i] for i in range(self.n)]
        self.AFX=self.expose(active)
        (afmc,fmcar)=self.FMC(self.AFX)
        (asmc,smcar)=self.SMC(active)
        self.FMCAR=[i for i in fmcar]
        self.FMCAR+=smcar
        self.MCAR=self.MC(active,afmc,asmc)
        self.risk=Dot(self.n,active,self.MCAR)
        #Benchmark Properties
        self.BFX=[self.FX[i]-self.AFX[i] for i in range(self.nfac)]        
        (bfmc,fmcbr)=self.FMC(self.BFX)
        (bsmc,smcbr)=self.SMC(self.bench)
        self.FMCBR=[i for i in fmcbr]
        self.FMCBR+=smcbr
        self.MCBR=self.MC(self.bench,bfmc,bsmc)
        self.brisk=Dot(self.n,self.bench,self.MCBR)
        self.beta=[i/self.brisk for i in self.MCBR]
        self.pbeta=Dot(self.n,self.beta,self.w)
        #Residual Properties
        residual=[self.w[i]-self.pbeta*self.bench[i] for i in range(self.n)]
        self.RFX=self.expose(residual)
        (rfmc,fmcrr)=self.FMC(self.RFX)
        (rsmc,smcrr)=self.SMC(residual)
        self.FMCRR=[i for i in fmcrr]
        self.FMCRR+=smcrr
        self.MCRR=self.MC(residual,rfmc,rsmc)
        self.Rrisk=Dot(self.n,residual,self.MCRR)
        #Systematic Properties
        self.SFX=[self.AFX[i]-self.RFX[i] for i in range(self.nfac)]
        self.srisk=rootsquaredif(self.arisk,self.Rrisk)
        
        
if __name__=='__main__':
    """Example test program"""
    O=Properties()
    O.n=4
    O.nfac=2
    O.w=[.25]*4
    O.bench=[.24]*3+[.3]
    O.FC=[1,0.1,2]
    O.SV=[2,3,4,5]
    O.FL=[1,1,1,1,1,-1,-1,1]
    O.props()
    for i in O.__dict__.keys():
        print 'Attribute ',i,' ',getattr(O,i)

    from Opt import *
    P=Opt()
    P.n=4
    P.nfac=2
    P.w=[.25]*4
    P.bench=[.24]*3+[.3]
    P.FC=[1,0.1,2]
    P.SV=[2,3,4,5]
    P.FL=[1,1,1,1,1,-1,-1,1]
    P.props()
    for i in O.__dict__.keys():
        try:print 'Attribute ',i,' ',getattr(P,i)
        except: print 'no ',i

            


       
        
    