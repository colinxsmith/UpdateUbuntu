#include "baseoptimise.h"
short Base_Optimise::dchkdat(ulong liwork, ulong lwork, ulong litotl, ulong lwtotl, dimen nrowa, dimen n, dimen nclin, dimen nctotl, short_vec istate, short_vec kactiv, int lcrash, real *bigbnd, real *a, real *bl, real *bu, real *featol, real *x)
{

    static char *id =(char*)"VARBL LNCON NLCON ";

	short	nerror;
	dimen	nplin = n + nclin;

    real ftol;
    real test;
    integer j, k;
    real b1, b2;
    integer l1;
    logical ok;
    integer is;

/*     CHKDAT  CHECKS THE DATA INPUT TO THE VARIOUS OPTIMIZERS. */
/*     THE FOLLOWING QUANTITIES ARE NOT CHECKED... */
/*     NROWA, N, NCLIN, NCTOTL */
/*     KACTIV */
/*     A, X */
    --x;
    --featol;
    --bu;
    --bl;
    --kactiv;
    --istate;

    nerror = 0;
/* --------------------------------------------------------------------- 
*/
/*     CHECK THAT THERE IS ENOUGH WORKSPACE TO SOLVE THE PROBLEM. */
/* --------------------------------------------------------------------- 
*/
    ok=litotl<=liwork&&lwtotl<=lwork;
    if (ok && msg <= 0) {
	goto L20;
    }
    if (msg >= 0)
	lm_wmsg(
"\nWORKSPACE PROVIDED IS     IW(%6ld),  W(%6ld).\nTO SOLVE PROBLEM WE NEED  IW(%6ld),  W(%6ld).",
		CL(liwork), CL(lwork), CL(litotl), CL(lwtotl));
    if (ok)
	goto L20;
    ++nerror;
    if (msg >= 0)
	lm_wmsg("\nXXX  NOT ENOUGH WORKSPACE TO SOLVE PROBLEM.");
/* --------------------------------------------------------------------- 
*/
/*     CHECK THE BOUNDS ON ALL VARIABLES AND CONSTRAINTS. */
/* --------------------------------------------------------------------- 
*/
L20:
    for (j = 1; j <= (integer)nctotl; ++j) {
	b1 = bl[j];
	b2 = bu[j];
	ok = b1 <= b2;
	if (ok) {
	    goto L40;
	}
	++nerror;
	k = j;
	l1 = 1;
	if (j >  (integer) n) {
	    k = j - n;
	}
	if (j >  (integer) n) {
	    l1 = 4;
	}
	if (j >  (integer) nplin) {
	    k -= nclin;
	}
	if (j >  (integer) nplin) {
	    l1 = 7;
	}
	if( msg >= 0)
	    lm_wmsg(
"\nXXX THE BOUNDS ON %.2s%.2s%.1s%3ld ARE INCONSISTENT BL =%16.7lg BU =%16.7lg",
		id, id + 2, id + 4, CL(k), b1,
		    b2);
L40:
	;
    }
/* --------------------------------------------------------------------- 
*/
/*     CHECK  BIGBND  AND  FEATOL. */
/* --------------------------------------------------------------------- 
*/
    ok = *bigbnd > 0;
    if (ok) goto L60;
    ++nerror;
    if (msg >= 0)
	lm_wmsg("\nXXX BIGBND IS NOT POSITIVE...%20.9lg",*bigbnd);
L60:
    for (j = 1; j <=  (integer) nctotl; ++j) {
	ftol = featol[j];
	test = 1 + ftol;
	ok = test > 1;
	if (!ok && msg>=0)
	    lm_wmsg(
"\n*** WARNING -- FEATOL(%4ld) IS LESS THAN MACHINE PRECISION...%16.6lg",
		CL(j), ftol);
    }
/* --------------------------------------------------------------------- 
*/
/*     IF WARM START, CHECK  ISTATE. */
/* --------------------------------------------------------------------- 
*/
/* L100: */
    if (lcrash){
    for (j = 1; j <=  (integer) nplin; ++j) {
	is = istate[j];
	ok = is >= -2 && is <= 4;
	if(!ok){
		++nerror;
		if (msg >= 0)
	    		lm_wmsg(
			"\nXXX COMPONENT%5ld OF ISTATE IS OUT OF RANGE...%10ld", 
		    CL(j), CL(is));
	}
    }
    }
	return nerror;
}
