#ifndef _BASEOPT_H
#define _BASEOPT_H
#include<vector>
#include<map>
#include<cstring>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<sstream>
#include<fstream>
#include<stdexcept>
#include<algorithm>
#include<valarray>
#include<iostream>
#include<cstdarg>
#include "ldefns.h"
#include "constant.h"
#include "validate.h"
typedef void		(*pHmul)_PROTO((dimen /*n*/, dimen /*nrh*/, dimen /*nc*/, dimen /*jc*/, vector /*H*/, vector /*x*/, vector /*hx*/,void* info));
typedef double (*pUtility)_PROTO((dimen nvab,vector x,void* info));
typedef void (*pModC)_PROTO((dimen nvab,vector x,vector c,void* info));
typedef void (*pConstraintFunc)_PROTO((dimen n,dimen m,vector x,vector y,vector J,vector H,vector g,void* info));
typedef void (*pModQ)_PROTO((dimen nvab,vector x,vector Qmod,void* info));
typedef	double	(*p1DFunc)(double kappa,void* info);
extern void FiniteDiffGrad(dimen n,vector x,vector g,void*info);
extern "C" void SharpHess(dimen n,vector x,vector g,void*info);
extern "C" void SharpHessI(dimen n,vector x,vector g,void*info);
extern void BFGSHess(dimen n,vector x,vector h,void*info);
extern "C" void ParityHessUV(dimen n,vector x,vector h,void*info);
extern "C" void ParityHessU(dimen n,vector x,vector h,void*info);

#define rooteps 1.490116119384766e-008
//#define MEMORYTEST //Don't forget to add perf1.cpp to the project
#ifdef __cplusplus
enum TimeOptType {GainLossType,CVarType,SemiVarType};
class DLLEXPORT TimeOptExtra
{
public:
	bool usethis;
	vector Lst,Ust,Ast,cst,initialst;
	vector L,U,A,c,initial,x;
	void SetLog(void* logprint);
	void AddLog(const char* mess,...);
	void PrintLog(char*name=0);
	double*DATA,*meanDATA;
	size_t tlen,n,nextra;
	bool opt;
	TimeOptType OptType;
	TimeOptExtra();
	~TimeOptExtra();
	void* logprint;
	vector benchmark;
	void*costinfo;
};
class DLLEXPORT ForUpdates
{
public:
	vector xnow,xpast,gnow,gpast,hnow;
	size_t count;
	pUtility Util;
	pModC ModDeriv;
	void*gradinfo;
	void*Uinfo;
	bool BFGS;//Use Hessian updates instead of true Hessian if true
};
//Class for Cvar properties
class DLLEXPORT MVCvar:public TimeOptExtra
{
public:
	size_t nn;
	size_t number_included;
	double* Q;
	double* mean;
	bool cvarConstraintdata;
	double cvarL,cvarU;
	bool* I;
	void getI(double*w);
	void getMeans();
	void make_cov_matrix();
	double CVar(double*w);
	double CVar(double*w,double base);
	double CVarn(double*w,double base);
	double cvar_averse;
	float tail_divisor;
	float tail_factor;
	double VAR;
	void DCVar(double*w,double*grad,double step);
	void DCVar(double*w,double*grad);
	MVCvar(size_t n,size_t tlen,double*DATA,size_t number_included);
	~MVCvar();
private:
	std::valarray<bool>*pI;
	std::valarray<double>*pm;
	std::valarray<double>*pQ;
};
class DLLEXPORT GainLossVar:public TimeOptExtra
{
public:
	double gpower;
	double lpower;
	vector r;	//target
	double*mean;
	bool*I;
	double Gain;
	double Loss;
	double*MGain;
	double*MLoss;
	double Variance;
	double*MVar;
	char**names;
	double pGain,pRGain,pRLoss;;
	long nf;
	double*SV;
	double*FL;
	double*FC;
	double*Q;
	GainLossVar(size_t len,size_t nstocks,double*D,vector r0,char**names=0,long nf=-1,double*SV=0,double*FC=0,double*FL=0);
	~GainLossVar();
	void getI(double*w);
	void getMeans();
	double GainCLoss(double*w,double C,double*grad,double*hess);
	double Var(double*w,double*benchmark=0);
	void factor_model_process();
	void make_cov_matrix();
	double losslambda;
	double utility_multiplier;
private:
	std::valarray<bool>*pI;
	std::valarray<double>*pm;
	std::valarray<double>*pQ;
};
extern "C"
{
#endif
DLLEXPORT void simplex(dimen n,double* start,double* xmin,double* ynewlo,
		double reqmin,double* step,dimen konvge,dimen kcount,dimen* icount,dimen* numres,
		dimen* ifault,pUtility fn,void* info);
DLLEXPORT extern	double	Solve1D(p1DFunc RiskE,double gammabot,double gammatop,
									double tol,void* info);
DLLEXPORT extern	double PathMin(p1DFunc RiskE,double gammabot=0,
							   double gammatop=1-rooteps,double tol=rooteps,void* info=0,
							   int stopifpos=0);
DLLEXPORT extern	void	NaiveRound(size_t n,vector w,vector initial,
				   vector minlot,vector sizelot,vector roundw);
DLLEXPORT extern void digitise(size_t n,vector w,vector initial,vector minlot,vector sizelot,vector digit);
DLLEXPORT extern double digit2w(double w,double initial,double d,double minl,double sizl,double minlb=0);
DLLEXPORT extern double digitisei(double w,double initial,double minl,double sizl,double minlb=0);
DLLEXPORT extern double round_weight(double x,double initial,double minl,double sizel,double minlb=0);
DLLEXPORT extern size_t roundcount(size_t n,vector w,vector initial,vector minl,vector sizl,double *trw,vector naive);
DLLEXPORT extern  short QuasiNewton(size_t n,vector x,int print,size_t maxiter,
								  double *f,pUtility func,void*info,double conv=1e-12,int method=1,int twosided=0,double stoplimit=1e+8);
DLLEXPORT double  CVarValue(size_t n,size_t tlen,double*DATA,size_t number_included,vector w);
DLLEXPORT double  CVarValueO(size_t n,size_t tlen,double*DATA,size_t number_included,vector w);

#ifdef __cplusplus
}
#endif

#define istart	(DAS_Sol_istart)
#define scldqp	(DAS_Sol_scldqp)
#define nrowrt	(DAS_Sol_nrowrt)
#define ncolrt	(DAS_Sol_ncolrt)
#define nq	(DAS_Sol_nq)
#define locnp	(DAS_Sol_locnp)
#define nrowqp	(DAS_Sol_nrowqp)
#define loclc	(DAS_Sol_loclc)
#define msg	(DAS_Sol_msg)
#define parm	(DAS_Sol_parm)
#define nout	(DAS_Sol_nout)
#define asize	(DAS_Sol_asize)
#define dtmax	(DAS_Sol_dtmax)
#define dtmin	(DAS_Sol_dtmin)
#define pKACTV	((stride*)(DAS_Sol_ploc[0]))
#define pKFREE	((stride*)(DAS_Sol_ploc[1]))
#define pANORM	((real*)(DAS_Sol_ploc[2]))
#define pAP	((real*)(DAS_Sol_ploc[3]))
#define pPX	((real*)(DAS_Sol_ploc[4]))
#define pQTG	((real*)(DAS_Sol_ploc[5]))
#define fpQTG	(pQTG - 1)
#define pRLAM	((real*)(DAS_Sol_ploc[6]))
#define pRT	((real*)(DAS_Sol_ploc[7]))
#define pZY	((real*)(DAS_Sol_ploc[8]))
#define pWRK	((real*)(DAS_Sol_ploc[9]))

#ifndef NOCLASS
class DLLEXPORT Base_Optimise
{
public:
//Inputs
	real featol;		//Feasible tolerance for constraint bounds
	dimen n;			//Number of variables	(>0)
	dimen m;			//Number of constraints (>0)
	vector A;			//Constraint array
	vector firstw;
	vector soft_A;
	vector soft_b;
	vector soft_l;
	dimen soft_m;
	bool use_soft_in_hessmult;
	vector lower;		//Lower bounds of variables and constraints
	vector upper;		//Upper bounds of variables and constraints
	unsigned char lp;	//For qp or lp, the objective function is set up internally
	vector H;			//Hessian Matrix (fixed if qp, not used at all if lp)
	vector c;			//The linear cost vector (lp and qp only)
	vector H_from_higher_terms;
	virtual void update_with_higher(size_t n,vector Higher,vector Q,short plus=0);
	std::valarray<double>			*extraH;
	size_t*	optimiseorder;
	std::valarray<double>*ExtraQx;
	double scale_utility_external_terms;
	unsigned char DoExtraIterations;
	unsigned char use_higher_H;
	Validate*	checker;//For the licencing stuff
	int licenced;
	bool lp_really;
	short round_result;	//Round the result in interior point
	short CONJ;			//Use conjugate gradients in interior point
	short useInteriorPoint;
	size_t mem_kbytes;
	bool no_interior_ever;
	TimeOptExtra *TimeOptData;

//Output
	vector x;			//Variables

	unsigned char higher_reset;
//Constructor/ destructor
	Base_Optimise();
	std::stringstream *logprint;
	void SetLog();
	void PrintLog();
//	void AddLog(const char* mm);
	void AddLog(const char *mm,...); 


#ifndef MYNOVIRT
	virtual 
#endif
		~Base_Optimise();

	pHmul	hmul;
	pUtility Util;
	pModC ModDeriv;
	pModQ ModHessian;
	void* HmulObjectInfo;
	void* UtilObjectInfo;
	void* ModCObjectInfo;
	void* ModQObjectInfo;
	char* Version;
	double	clocker(int start=0);

	short NaiveNonlinearMin(size_t n,size_t m,vector x,vector c,vector Q,vector A,
									   vector L,vector U,vector work);
	virtual void qphess(dimen nvab,dimen n1,dimen n2,dimen n3,vector Q,vector x,vector y)=0;
	virtual real shortcost(dimen n,vector x)=0;
	virtual real utility(dimen nvab,vector x,vector c,vector Q)=0;
	virtual void ModifyC(dimen nvab,vector Q,vector x,vector newc,unsigned char all=1)=0;
	virtual void ResetInitial(unsigned char forward=1)=0;

	virtual void qphess_base(dimen nvab,dimen n1,dimen n2,dimen n3,vector Q,vector x,vector y);
	virtual real utility_base(dimen nvab,vector x,vector c,vector Q);
	short Opt(dimen nvab,dimen m,vector x,vector A,vector lower,vector upper,vector c);
	short OptInterior(dimen nvab,dimen m,vector x,vector A,vector lower,vector upper,vector c);
	real PathMin(dimen n,vector wstart,vector wchange,vector c,vector Q,
		double tol=rooteps);
	virtual void ModifyC_base(dimen nvab,vector Q,vector x,vector newc);
	short OptAdvanced(dimen nvab,dimen m,vector x,vector A,vector lower,vector upper,vector c,vector lambda);
	void TimeOptSetC(size_t Nvab,vector L,vector U,vector A,vector c,vector initial);
	double gamma_for_eps;
protected:
	short qpsol_ifail;
	double objective;
	std::valarray<double> *keep_last_C;
integer		DAS_Sol_nout;//=0;
integer		DAS_Sol_msg;//=0;
integer		DAS_Sol_istart;//=0;
real		DAS_Sol_parm[10];//{0.0};
real		DAS_Sol_asize;//=0.0;
real		DAS_Sol_dtmax;//=0.0;
real		DAS_Sol_dtmin;//=0.0;
integer		DAS_Sol_nrowrt;//=0;
integer		DAS_Sol_ncolrt;//=0;
integer		DAS_Sol_nq;//=0;
void		*DAS_Sol_ploc[15];//={0};
integer		DAS_Sol_locnp[30];//={0};
integer		DAS_Sol_loclc[15];//={0};
integer		DAS_Sol_ncqp;//=0;
integer		DAS_Sol_nrowqp;//=0;
logical		DAS_Sol_scldqp;//=0;
real		DAS_Sol_zgfacc;//=-1.0;
	

	short dqpsol(short itmax, short msglvl, dimen n, dimen nclin, dimen nctotl, 
		dimen nrowa, dimen nrowh, dimen ncolh, real *bigbnd, vector A, vector bl,
		vector bu, vector cvec, vector featol, vector hess, 
		int cold, int lp, int orthog, vector x, short_vec istate, short *iter,
		real *obj, vector lambda, short_vec iw, ulong leniw, 
		vector work, ulong lenw, short ifail);
	void dqpprt(int orthog, integer isdel, integer iter, integer jadd, 
		integer jdel, dimen nactiv, dimen ncolz, dimen nfree, dimen n, 
		dimen nclin, dimen nrowa, dimen Nrowrt, dimen nhess, short_vec istate, 
		short_vec kfree, real alfa, real condh, real condt, real obj, 
		real gfnorm, real ztgnrm, real emax, matrix a, matrix rt, 
		vector x, vector wrk1, vector wrk2);
	void dqpcore(int orthog, logical *unitq, integer *inform, integer *iter, 
		integer *itmax, dimen n, integer *nclin, integer *nctotl, integer *nrowa, 
		integer *nrowh, integer *ncolh, integer *nactiv, integer *nfree,
		short_vec istate, short_vec kactiv, short_vec kfree, 
		real *objqp, real *xnorm, real *a, real *ax, real *bl, real *bu, 
		real *clamda, real *cvec, real *featol, real *hess, real *scale, 
		real *x, short_vec iw, real *w);
	short dqpgrad(short mode, int unitq, dimen n, dimen nactiv,
		dimen nfree,
		dimen *nhess, dimen Nq, dimen nrowh, dimen ncolh, dimen jadd,
		short_vec kactiv, short_vec kfree, real alfa, real *objqp, real *gfixed,
		real gtp,
		vector	cvec, vector hess, vector p, vector qtg, vector scale, vector x,
		vector zy,
		vector wrk1, vector wrk2);
	dimen dqpcrsh(int unitq, dimen n, dimen ncolz, dimen nfree, 
		dimen *nhess, dimen Nq, dimen nrowh, dimen ncolh, dimen Nrowrt, 
		short_vec kfree, real *hsize, real *hess, matrix rt, vector scale,
		matrix zy,
 vector hz1,
 vector wrk);
	void dqpcolr(logical *nocurv, logical *posdef, logical *renewr, logical *unitq,
		dimen n, integer *ncolr, integer *nfree, integer *Nq,
		integer *nrowh, integer *ncolh, integer *Nrowrt, integer *nhess,
		short_vec kfree, real *cslast, real *snlast, real *drmax, real *emax,
		real *hsize, real *rdlast, real *hess, real *rt, real *scale, real *zy,
		real *hz1, real *wrk);
	void dqpchkp( dimen n, dimen nclin, dimen issave, dimen jdsave, vector ap, vector p);
	void	dprtsol(	dimen nfree, dimen nrowa, dimen n, dimen nclin, dimen ncnln,
		dimen nctotl,
			real bigbnd, dimen nactiv, short_vec istate, short_vec kactiv,
			matrix a, vector bl, vector bu, vector c, vector clamda, vector rlamda, 
			vector x);
	void dlpcrsh(	int orthog, logical *unitq, int vertex, byte lcrash, dimen n,
		integer *nclin, integer *nctotl,
		integer *Nq, integer *nrowa, integer *Nrowrt, integer *Ncolrt, integer *nactiv,
		integer *ncolz,
		integer *nfree, short_vec istate, short_vec kactiv, short_vec kfree, real *bigbnd,
		real *tolact,
		real *xnorm, real *a, real *anorm, real *ax, real *bl, real *bu, real *x, real *qtg, real *rt,
		real *zy, real *p, real *wrk1, real *wrk2);
	void dlpcore(	int lp, int minsum, int orthog, logical *unitq, int vertex, 
		integer *inform, integer *iter,
		integer *itmax, byte lcrash, dimen n, integer *nclin, integer *nctotl, 
		integer *nrowa, integer *nactiv,
		integer *nfree, integer *numinf, short_vec istate, short_vec kactiv, 
		short_vec kfree, real *obj, real *xnorm,
		real *a, real *ax, real *bl, real *bu, real *clamda, real *cvec, real *featol, 
		real *x, short_vec iw, real *w);
	void dlpbgst(	dimen n, dimen nactiv, dimen nfree, integer *jbigst, integer *kbigst,
		short_vec istate, short_vec kactiv, real dinky, real feamin, real *trulam, vector featol, vector rlamda);
	void dgetlamd(char *lprob, dimen n, dimen nactiv, dimen ncolz, dimen nfree, dimen nrowa, dimen Nrowrt, dimen *jsmlst, dimen *ksmlst, 
		real *smllst, short_vec istate, short_vec kactiv, real *a, real *anorm, real *qtg, real *rlamda, real *rt);
	void ddelcon(int modfyg, int orthog, int unitq, dimen jdel, 
		dimen kdel, dimen nactiv, dimen ncolz, dimen nfree, dimen n, dimen Nq,
		dimen nrowa, dimen Nrowrt, short_vec kactiv, short_vec kfree, matrix a, 
		vector qtg, matrix rt, matrix zy);
	short daddcon(int modfyg, int modfyr, int orthog, logical *unitq, 
		integer *ifix, integer *iadd, integer *jadd, integer *nactiv, integer *ncolr, 
		integer *ncolz, integer *nfree, dimen n, integer *Nq, integer *nrowa, 
		integer *Nrowrt, short_vec kfree, real *condmx, real *cslast, real *snlast,
		real *a, real *qtg, real *rt, real *zy, real *wrk1, real *wrk2);
	void dalloc(byte nalg, dimen n, dimen nclin, dimen ncnln, dimen nctotl, 
		short_vec iw, vector w, ulong *litotl, ulong *lwtotl);
	void dbdpert(int firstv, int negstp, real *bigalf, real *bigbnd, real *pnorm, 
		integer *jadd1, integer *jadd2, real *palfa1, real *palfa2, short_vec istate, 
		dimen n, dimen nctotl, real *anorm, real *ap, real *ax, real *bl, real *bu, 
		real *featol, real *p, real *x);
	short dbndalf(int firstv, int *hitlow, short_vec istate, integer *jadd, dimen n,
		dimen nctotl, dimen numinf, real *alfa, real *palfa, real *atphit, real *bigalf, 
		real *bigbnd, real *pnorm, real *anorm, real *ap, real *ax, real *bl, real *bu, 
		real *featol, real *p, real *x);
	short dchkdat(ulong liwork, ulong lwork, ulong litotl, ulong lwtotl, dimen nrowa, 
		dimen n, dimen nclin, dimen nctotl, short_vec istate, short_vec kactiv, 
		int lcrash, real *bigbnd, real *a, real *bl, real *bu, real *featol, real *x);
	void dtqadd(int orthog, logical *unitq, integer *inform, integer *k1, integer *k2,
		integer *nactiv, integer *ncolz, integer *nfree, integer *n, integer *nq, 
		integer *nrowa, integer *nrowrt, integer *ncolrt, short_vec istate,
		short_vec kactiv, short_vec kfree, real *condmx, real *a, real *qtg, real *rt, 
		real *zy, real *wrk1, real *wrk2);
	void dfindp(logical *nullr, logical *unitpg, logical *unitq, dimen n, integer *nclin,
		integer *Nq, integer *nrowa, integer *Nrowrt, integer *ncolr, integer *ncolz,
		integer *nfree, short_vec istate, short_vec kfree, int negligible, real *gtp,
		real *pnorm, real *rdlast, real *a, real *ap, real *p, real *qtg, real *rt,
		real *v, real *zy, real *work);
	void dlpprt(	int lp, dimen nrowa, dimen Nrowrt, dimen n, dimen nclin, dimen nfree, dimen isdel, dimen nactiv,
		dimen ncolz, dimen iter, dimen jadd, dimen jdel, real alfa, real condt,
		dimen numinf, real suminf, real objlp, short_vec istate, short_vec kfree, matrix a,
		matrix rt, vector x, vector wrk1, vector wrk2);
	void dqpdump(dimen n, dimen nrowh, dimen ncolh, vector cvec, real *hess, vector wrk, 
		vector hx);
private:
#ifndef _OPENMP
	clock_t	timebase;
#else
	double	timebase;
#endif
	double timeaquired;
	std::string *vers;


};

class MemProb
{
public:
	MemProb(std::string mess,dimen amount,dimen n);
	std::string mess;
	dimen amount;
	dimen n;
};
#endif

class SparseChol
{
public:
	Integer n,nn,n1;
	double tolpiv;
	Integer i,j,mua,jumax,flag,lenju,lenu,pivot_nzp,pivot_nju;
	double*M,*D,*U,*sign;
	Integer*iju,*ju,*iu,*p,*ip,*im,*jm,*zrank;
	SparseChol(Integer n=0,double*M=0);
	~SparseChol();
	Integer Factor();
	void SetPermutation();
	void Solve(double* b);
	void CreateSparseIndices();
	Integer Symbolic();
	void SetOrder();
	void SetM(double*M);
private:
	std::valarray<Integer>*IJM;
	std::valarray<double>*DU;
	std::valarray<Integer>*IP;
};

#endif
