#include "ldefns.h"
/*
	DAS version of BLAS routine ddot for computing the inner product
	of two real general vectors x and y
*/
//#define MULTI_P
float BITA_sdot(dimen n, float *x, increment incx, float *y, increment incy)//single precision
{
	float sum;

	sum = 0;
	while(n--){
		sum += *x * *y;
		x += incx;
		y += incy;
		}
	return sum;
}
#ifdef MULTI_P
real ddot_old(dimen n, real *x, increment incx, real *y, increment incy)
#else
real BITA_ddot(dimen n, real *x, increment incx, real *y, increment incy)
#endif
{
	real sum;

	sum = 0;
	while(n--){
		sum += *x * *y;
		x += incx;
		y += incy;
		}
	return sum;
}



#ifdef MULTI_P
#define nthreads 2
#define OLD ddot_old
HANDLE handles[nthreads];
CRITICAL_SECTION mutex;
struct arginfo
{
	double*sum;dimen n;vector x;increment incx;vector y;increment incy;
	size_t id;
};
static void work_here(void *arg)
{
	struct arginfo*Info=(struct arginfo*)arg;
	double sumh;
	size_t nn=Info->n/nthreads,extra=0;
	if(Info->id==nthreads-1) extra=Info->n-nthreads*nn;
	sumh=OLD(nn+extra,Info->x+Info->id*nn*Info->incx,Info->incx,Info->y+Info->id*nn*Info->incy,Info->incy);
	EnterCriticalSection(&mutex);
	*(Info->sum)+=sumh;
	LeaveCriticalSection(&mutex);
}
double BITA_ddot(dimen n,vector x, increment incx,vector y, increment incy)
{
	if(n>=3000)
	{
		size_t threadID,i;
		struct arginfo Info[nthreads];
		double sum=0;
		for(i=0;i<nthreads;i++)
		{
			Info[i].id=i;
			Info[i].n=n;
			Info[i].x=x;
			Info[i].y=y;
			Info[i].incx=incx;
			Info[i].incy=incy;
			Info[i].sum=&sum;
		}
		InitializeCriticalSection(&mutex);
		for(i=0;i<nthreads;++i)
		{
			handles[i]=CreateThread(0,0,(LPTHREAD_START_ROUTINE)work_here,&Info[i],0,&threadID);
		}
		WaitForMultipleObjects(nthreads,handles,TRUE,INFINITE);
		for(i=0;i<nthreads;i++)
		{
			CloseHandle(handles[i]);
		}
		return sum;
	}
	else
		return OLD(n,x,incx,y,incy);
}
#endif
