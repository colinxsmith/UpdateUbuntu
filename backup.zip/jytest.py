from safejava import *
from jarray import *
import Optimise,FOptimise
from java.lang import System,Object,Double

"""
Helper functions
"""
def sumlist(a):
    s=0
    for i in a:s+=i
    return s
def dot(a,b):
    s=0
    for i in range(len(a)):s+=a[i]*b[i]
    return s
def utilityhere(n,x,c,Q):
    implied=[0]*n
    testmul(n,1,1,1,Q,x,implied)
    s=dot(c,x) + 0.5*dot(implied,x)
    return s
def listadd(a,b):
    c=[]
    for i in range(len(a)):c.append(a[i]+b[i])
    return c
def listsub(a,b):
    c=[]
    for i in range(len(a)):c.append(a[i]-b[i])
    return c
def scallistadd(gamma,a,c):
    b=[]
    for i in range(len(a)):b.append(a[i]*gamma+c[i])
    return b
def scallistsub(gamma,a,c):
    b=[]
    for i in range(len(a)):b.append(a[i]*gamma-c[i])
    return b
"""
The optimisation problem
"""

#_________________________________________________________________________________________________
class FUNCS(Object):
    def hmul(self,n,n1,n2,n3,H,x,y):
        """Define the Hessian times vector routine here in Python instead of the optimiser dll"""
        ij = 0
        for i in range(n):
            y[i] = 0
            for j in range(i+1):
                y[i] += H[ij] * x[j]
                if i != j:y[j] += H[ij] * x[i]
                ij+=1

System.loadLibrary('safejava')

print dir()

opt=Optimise()

print opt.getVersion()
opt.delete()
del opt
opt=Optimise()
print opt.getVersion()

n=5
opt.n=n
opt.m=1
A=[1]*n
opt.a=A
lower=[0]*n+[1]
opt.lower=lower
upper=[1]*n+[1]
opt.upper=upper
alpha=[-.2,-.1,.1,.2,.3]
bench=[.2,.2,.2,.2,.2]

H=[1,
   -.1,1,
   .1,-.1,1,
   .1,.1,-.1,1,
   .1,.1,.1,-.1,1]
opt.h=H
testmul=FUNCS()
print testmul
#opt.hmul = testmul #This does not work!


implied=[0]*n

testmul.hmul(n,1,1,1,opt.h,bench,implied)
print implied
store=[0]*n
store1=[0]*n
def variance(gamma):
    """
    Do a relative variance optimisation for this value of gamma and return the
    the absolute variance
    """
    scale=-gamma/(1-gamma)
    opt.c=scallistsub(scale,alpha,implied)
    opt.OptSetup(n)
    x=opt.x
    print x
    testmul.hmul(n,1,1,1,H,x,store)
    return dot(x,store)

print variance(.1)