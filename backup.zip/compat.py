#! /bin/env python

try:
    from java.lang import *
    #System.loadLibrary("safejavajy")#Now this is done in safejavajy.java
    from jarray import *
    from safejavajy import FrontierCVPA,FrontierCVPAextcosts,FrontierCVPA,FrontierCVPAF,Optimise_internalCVPAextcosts,Optimise_internalCVPA,Optimise_internalCVPAFb,factor_model_process
except:from safe import FrontierCVPA,FrontierCVPAextcosts,FrontierCVPA,FrontierCVPAF,Optimise_internalCVPAextcosts,Optimise_internalCVPA,Optimise_internalCVPAFb,factor_model_process
def turnover(a,b):
    n=len(a)
    if len(b)!=n:raise 'length error in turnover'
    s=0
    for i in range(n):s+=abs(a[i]-b[i])
    return s*.5
def lscheck(w):
    sp=0
    sn=0
    g=0
    for i in w:
        if i < 0:sn+=i
        if i > 0:sp+=i
        g+=abs(i)
    return (sp,sn,g,-sn/sp)
class testopt:
    def __init__(self):
        self.n=0
        self.nfac=0
        self.names=[]
        self.FC=[]
        self.FL=[]
        self.SV=[]
        self.m=0
        self.bench=[]
        self.alpha=[]
        self.A=[]
        self.L=[]
        self.U=[]
        self.gamma=0
        self.kappa=.5
        self.costs=0
        self.initial=[]
        self.mask=[]
        self.delta=2
        self.buy=[]
        self.sell=[]
        self.basket=-1
        self.tradenum=-1
        self.revise=0
        self.min_holding=-1
        self.min_trade=-1
        self.ls=0
        self.full=1
        self.rmin=1
        self.rmax=1
        self.round=0
        self.min_lot=[]
        self.size_lot=[]
        self.shake=[]
        self.ncomp=0
        self.Composites=[]
        self.value=1
        self.npiece=0
        self.hpiece=[]
        self.pgrad=[]
        self.nabs=0
        self.A_abs=[]
        self.mabs=0
        self.I_A=[]
        self.Abs_U=[]
        self.Q=[]
        self.riskc=0
        self.maxrisk=0
        self.minrisk=0
        self.shake=[]
        self.w=[]
        self.costgrad=None
        self.costfunc=None
        self.costhess=None
        self.SV=[]
        self.FC=[]
        self.FL=[]
        self.npoints=0
        self.risk=[]
        self.arisk=[]
        self.areturn=[]
        self.rreturn=[]
        self.minrisk=-1
        self.maxrisk=-1
        self.take_out_costs=0
        self.log=1
        self.logfile=""
    def opt(self):
        c=0
        for i in self.__dict__.keys():
            print '%4d\t%20s'%(c+1,i),self.__dict__[i]
            c+=1
        try:
            w=array([0]*self.n,Double)          #Need java objects for returned variables
            shake=array([-1]*self.n,Integer)
            if getattr(self,'Q') == []:
                if getattr(self,'nfac')>-1:
                    Q=array([0]*(self.n*(self.nfac+1)),Double)
            else:
                Q=array(self.Q,Double)
        except:
            w=[]
            shake=[]
            Q=self.Q
        try:ogamma=array([0],Double)
        except:ogamma=[]
        if self.costfunc == None or self.costgrad == None:
            if self.FL==[] and self.FC==[] and self.SV==[]:
                ret = Optimise_internalCVPA(self.n,self.nfac,self.names,w,self.m,self.A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.gamma,self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.mask,self.log,self.logfile)
            else:
                ret = Optimise_internalCVPAFb(self.n,self.nfac,self.names,w,self.m,self.A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.gamma,self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                        self.minrisk,self.maxrisk,ogamma,self.mask,self.log,self.logfile,0,0,-1,-1,-1,-1,1,1)
        else:
            ret = Optimise_internalCVPAextcosts(self.n,self.nfac,self.names,w,self.m,self.A,
                                    self.L,self.U,self.alpha,self.bench,Q,
                                    self.gamma,self.initial,self.delta,self.kappa,
                                    self.basket,self.tradenum,
                                    self.revise,self.min_holding,
                                    self.min_trade,self.ls,self.full,self.rmin,
                                    self.rmax,self.round,self.min_lot,self.size_lot,
                                    shake,self.ncomp,self.Composites,self.value,
                                    self.nabs,self.A_abs,
                                    self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                    self.costfunc,self.costgrad,self.costhess,self.minrisk,self.maxrisk,ogamma,
                                    self.take_out_costs,self.mask,self.log,self.logfile,1,0,0,-1,-1,-1,-1,1,1)
        print '@*'*10,' ',ret,' ','*@'*10
        if getattr(self,'Q')==[]:
            setattr(self,'Q',map(lambda t:t,Q))
        for i in ['w','shake']:setattr(self,i,map(lambda t:t,eval(i)))
    def front(self):
        """The method for getting frontier points"""
        c=0
        for i in self.__dict__.keys():
            print '%4d\t%20s'%(c+1,i),self.__dict__[i]
            c+=1
        try:
            w=array([0]*self.n*self.npoints,Double)          #Need java objects for returned variables
            shake=array([-1]*self.n,Integer)
            risk=array([0]*self.npoints,Double)
            arisk=array([0]*self.npoints,Double)
            rreturn=array([0]*self.npoints,Double)
            areturn=array([0]*self.npoints,Double)
            if getattr(self,'Q') == []:
                if getattr(self,'nfac')>-1:
                    Q=array([0]*(self.n*(self.nfac+1)),Double)
            else:
                Q=array(self.Q,Double)
        except:
            Q=self.Q
            w=[]
            shake=[]
            risk=[]
            arisk=[]
            rreturn=[]
            areturn=[]
        if self.costfunc == None or self.costgrad == None:
            if self.FL==[] and self.FC==[] and self.SV==[]:
                ret = FrontierCVPA(self.npoints,risk,arisk,rreturn,areturn,self.n,self.nfac,self.names,w,self.m,self.A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.mask)
            else:
                ret = FrontierCVPAF(self.npoints,risk,arisk,rreturn,areturn,self.n,self.nfac,self.names,w,self.m,self.A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,self.mask)
        else:
            ret = FrontierCVPAextcosts(self.npoints,risk,arisk,rreturn,areturn,self.n,self.nfac,self.names,w,self.m,self.A,
                                    self.L,self.U,self.alpha,self.bench,Q,
                                    self.initial,self.delta,self.kappa,
                                    self.basket,self.tradenum,
                                    self.revise,self.min_holding,
                                    self.min_trade,self.ls,self.full,self.rmin,
                                    self.rmax,self.round,self.min_lot,self.size_lot,
                                    shake,self.ncomp,self.Composites,self.value,
                                    self.nabs,self.A_abs,
                                    self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                    self.costfunc,self.costgrad,self.costhess,self.take_out_costs,self.mask)
        print '@*'*10,' ',ret,' ','*@'*10
        if getattr(self,'Q')==[]:
            setattr(self,'Q',map(lambda t:t,Q))
        for i in ['w','shake','risk','arisk','rreturn','areturn']:setattr(self,i,map(lambda t:t,eval(i)))
n=10
opt=testopt()
opt.n=n
opt.m=1
opt.A=[1]*n
opt.names=map(lambda t:'Stock %d'%(t+1),range(n))
opt.alpha=map(lambda t:float(t-n/2)/n,range(n))
opt.bench=map(lambda t:1.0/n,range(n))
opt.L=[0]*n+[1]
opt.U=[1]*n+[1]
opt.nfac=-1
Q=[0]*(n*(n+1)/2)
ij=0
for i in range(n):
    for j in range(i+1):
        if i==j:Q[ij]=float(i+1)*1e-2
        ij+=1
opt.Q=Q
opt.gamma=0
opt.opt()
print opt.w

print opt.tradenum
opt.basket=8
opt.gamma=1e-3
opt.opt()
print opt.w
opt.basket=9
opt.initial=map(lambda t:(opt.w[t]+opt.bench[t])*.5,range(n))
opt.revise=1
opt.opt()
print opt.w
turn=turnover(opt.w,opt.initial)
print 'delta %-.8e turnover %-.8e'%(opt.delta,turn)
opt.delta=turn*.95
opt.opt()
print opt.w
turn=turnover(opt.w,opt.initial)
print 'delta %-.8e turnover %-.8e'%(opt.delta,turn)
opt.delta=.6
opt.min_holding=.111
opt.opt()
print opt.w
turn=turnover(opt.w,opt.initial)
print 'delta %-.8e turnover %-.8e'%(opt.delta,turn)
opt.costs=1
opt.kappa=1e-6
opt.delta=2
opt.basket=-1
opt.min_holding=-1
opt.buy=map(lambda t:2e-3,range(n))
opt.sell=map(lambda t:2e-3,range(n))
opt.opt()
print opt.w
turn=turnover(opt.w,opt.initial)
print 'delta %-.8e turnover %-.8e'%(opt.delta,turn)
opt.buy=[]
opt.sell=[]
opt.npiece=2
opt.hpiece=[-1,1]*n
opt.pgrad=[-2e-3,2e-3]*n
opt.opt()
print opt.w
turn=turnover(opt.w,opt.initial)
print 'delta %-.8e turnover %-.8e'%(opt.delta,turn)
opt.round=1
opt.min_trade=1
opt.min_lot=[.111]*n
opt.opt()
print opt.w
turn=turnover(opt.w,opt.initial)
print map(lambda i:opt.w[i]-opt.initial[i],range(n))
print 'delta %-.8e turnover %-.8e'%(opt.delta,turn)
print opt.shake

print 'Long short gross abs'
opt.round=0
opt.min_trade=-1
opt.costs=0
opt.revise=1
opt.ls=2
opt.bench=[]
opt.L=[-1]*n+[-0.1]
opt.U=[1]*n+[0.1]
opt.full=1
opt.mabs=1
opt.I_A=[0]
opt.Abs_U=[.91e-1]
opt.rmin=.816
opt.rmax=-1.1
opt.delta=4.95389862e-01
opt.tradenum=n-1
opt.opt()
print opt.w
print 'Long short totals %-.8e %-.8e gross %-.8e ratio %-.8e'%(lscheck(opt.w))

turn=turnover(opt.w,opt.initial)
print 'delta %-.8e turnover %-.8e'%(opt.delta,turn)
print 'trades ',map(lambda t:opt.w[t]-opt.initial[t],range(n))

#opt.npoints=10
#opt.front()

#print opt.risk
#print opt.rreturn
#print 'The frontier portfolio weights',opt.w

