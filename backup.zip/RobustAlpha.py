#!/usr/bin/env python
from Opt import *
from re import sub
import sys
from time import clock
r12=pow(12,.5)
badval=-1e20
class BIM:
    """For reading in a BARRA integrated risk model assembled by my stuff"""
    def __init__(self,filename='model.csv'):
        print filename
        file=open(filename)
        nstocks=0
        FX=[]
        FC=[]
        SV=[]
        NAMES=[]
        while(1):
            line=file.readline()
            if len(line)==0:break
            line=line.strip()
            line=sub('[\s\[\]]','',line) # change Compx [name] to Compxname
            line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
            data=line.split(',')
            if line.find('SpecVar')>-1:
                ff=[i for i in data]
                del ff[0]
                del ff[-1]
                setattr(self,'FACTORNAMES',ff)
            elif not (data[0] in self.FACTORNAMES):
                NAMES.append(data[0])
                del data[0]
                SV.append(float(data[-1]))
                del data[-1]
                FX+=[float(i) for i in data]
                nstocks+=1
            else:
                del data[0]
                FC+=[float(i) for i in data]
        setattr(self,'nfac',len(self.FACTORNAMES))
        transpose(self.nfac,nstocks,FX)
        print 'Number of Factors ',self.nfac
        print 'Number of Stocks ',nstocks
        for i in ['FX','FC','nstocks','SV','NAMES']:
            setattr(self,i,eval(i))
def newW(p,p1,w):
    """Get new weights due to price change"""
    n=len(w)
    w1=[w[i]*p1[i]/p[i] for i in range(n)]
    tot=sum(w1)
    return [i/tot for i in w1]
def newWr(r,w):
    """Get new weights due to price change from returns"""
    n=len(w)
    w1=[w[i]*(1+r[i]) for i in range(n)]
    tot=sum(w1)
    return [i/tot for i in w1]
def newB(n,mcap):
    """Get mcap weighted portfolio weights"""
    tot=sum(mcap[:n])
    return [i/tot for i in mcap[:n]]
def gendates():
    """Generate a list of consequtive datas from Jan97 to Nov05"""
    months='Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split()
    years='97 98 99 00 01 02 03 04 05'.split()
    back=[]
    for i in years:
        for j in months:
            back.append(j+i)
    del back[-1]    #no Dec05
    #del back[-1]    #no Nov05
    return back
def turnover(w,wi):
    """Get turnover as half sum of absolute differences"""
    return 0.5*sum([abs(w[i]-wi[i]) for i in range(len(w))])
def var(x,Q):
    """x'.Q.x"""
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    """risk is sqrt(x'.Q.x); x is a list of length, Q is of length n*(n+1)/2"""
    return pow(var(x,Q),.5)
def meanerror(x,Q):
    """meanerror is sqrt(sum (xiQi)**2); x is a list of length, Q is of length n"""
    return pow(sum([x[i]*x[i]*Q[i]*Q[i] for i in range(len(x))]),.5)
def BITAutil(gamma,w,bench,alpha,Q):
    """The value of the BITA plus utility function"""
    gamma/=(1-gamma)
    ret=-gamma*dot(w,alpha)
    return ret+0.5*var([w[i]-bench[i] for i in range(len(w))],Q)


def readcov(a):
    """Read a covariance risk model file"""
    assets=[]
    COV=[]
    while(1):
        line=a.readline()
        if not len(line):break
        line=line.strip()
        if not len(line):continue
        line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
        try:
            r=float(line)
            COV.append(r)
        except:
            assets.append(line)
    return(assets,COV)
def readfore(a):
    """Read data in a forecast error data file"""
    bads=[]
    assets=[]
    COVfe=[]
    MEANfe=[]
    alpha=[]
    real_alpha=[]
    mcap=[]
    price=[]
    sect=[]
    types=[]
    while(1):
        line=a.readline()
        if not len(line):break
        line=line.strip()
        if not len(line):continue
        line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
        vals=line.split(',')
        if types==[]:
            types=vals
            continue
        if len(vals)>1:
            assets.append(vals[0])
            rem=0
            try:MEANfe.append(float(vals[1]))
            except:
                print vals[0],'Meanfe',vals[1]
                alpha.append(badval)
                rem=1
            try:alpha.append(float(vals[2]))
            except:
                print vals[0],'alpha',vals[2]
                alpha.append(badval)
                rem=1
            try:real_alpha.append(float(vals[3]))
            except:
                print vals[0],'real_alpha',vals[3]
                real_alpha.append(badval)
                rem=1
            try:mcap.append(float(vals[4]))
            except:
                print vals[0],'mcap',vals[4]
                mcap.append(badval)
                rem=1
            try:price.append(float(vals[5]))
            except:
                print vals[0],'price',vals[5]
                price.append(badval)
                rem=1
            try:sect.append(float(vals[6]))
            except:
                print vals[0],'sect',vals[6]
                sect.append(badval)
                rem=1
            if rem:
                print 'remove',vals[0],'due to bad float'
                bads.append(vals[0])
                del assets[-1]
                del MEANfe[-1]
                del alpha[-1]
                del real_alpha[-1]
                del mcap[-1]
                del sect[-1]
                del price[-1]
        else:
            COVfe.append(float(vals[0]))
    for i in bads:
        if i in assets:raise 'bad value problem'
    return(assets,MEANfe,alpha,real_alpha,mcap,price,sect,COVfe)
class RobOpt:
    """Class for holding Robust optimsation data and doing the robust optimisation and calculation
    of the reported stuff"""
    def __init__(self):
        self.propsS='n,m,M,full,rmin,rmax,val,nabs,gamma,maxRisk,mFE,S'.split(',')
        self.propsL='A,L,U,Q,alpha,dalpha,covalpha,Aabs,Uabs,bench,initial,real_alpha,mcap,price,sect'.split(',')
        for i in self.propsS:
            setattr(self,i,0)
        for i in self.propsL:
            setattr(self,i,[])
        self.nf=-1
        self.rmin=-1
        self.rmax=-1
        self.maxRisk=-1
        self.M=-1
        self.S=-1
    def Opt(self):
        """Do the robust optimisation"""
        for i in self.propsS:
            print i,getattr(self,i)
        for i in self.propsL:
            print i,getattr(self,i)[:5]
        w=[]
        nf=-1
        SV=[]
        FL=[]
        t1=clock()
        back=SOCPlsRobust(self.n,self.m,w,self.A,nf,SV,FL,self.Q,self.alpha,self.full,self.rmin,self.rmax,
                          self.L,self.U,self.val,self.maxRisk,self.dalpha,self.M,self.covalpha,
                          self.S,self.nabs,self.Aabs,self.Uabs,self.bench,self.initial)
        t2=clock()
        print 'Robust optimisation needed %d secs'%(t2-t1)
        setattr(self,'w',w)
        return back
    def Props(self):
        """Get return and risk numbers and the robust numbers"""
        if self.bench==[]:bench=[0]*self.n
        else:bench=self.bench
        if self.initial==[]:initial=[0]*self.n
        else:initial=self.initial
        absret=dot(self.w,self.alpha)
        benchret=dot(bench,self.alpha)
        relret=absret-benchret
        #real_return=dot(self.w,self.real_alpha)
        #bench_return=dot(bench,self.real_alpha)
        relrisk=risk([self.w[i]-bench[i] for i in range(self.n)],self.Q)
        meanerr=meanerror([self.w[i]-self.mFE*initial[i] for i in range(self.n)],self.dalpha)
        stderr=risk([self.w[i]-self.mFE*initial[i] for i in range(self.n)],self.covalpha)
        return (relret,relrisk,meanerr,stderr)

if __name__=='__main__':
    front='z:/Omam/OMAM Robust/'
    covfront='risk models/USDoptimisercovMatrix'
    FEfront='MktCap_FEDeMeaned_Strategy/USDforecastErrorMatrix'
    date = 'Jan97'
    print '+++++++++++++ Date %s +++++++++++++++++++++'%date
    fileC=front+covfront+date+'.csv'
    print fileC
    (assetsC,Q)=readcov(open(fileC))
    nC=len(assetsC)
    print nC,(nC*(nC+1)/2),len(Q)
    fileF=front+FEfront+date+'.csv'
    print fileF
    (assetsF,MEANfe,alphaF,real_alphaF,mcap,price,sect,COVfe)=readfore(open(fileF))


    Opt=RobOpt()
    Opt.n=len(assetsF)
    Opt.alpha=alphaF
    Opt.dalpha=[pow(Q[i*(i+3)/2],.5) for i in range(Opt.n)]
    Opt.M=.03
    Opt.maxRisk=.05/r12
    Opt.Q=Q
    Opt.covalpha=Q
    Opt.S=.02
    #0<= Sum of weights <=1
    Opt.m=1
    Opt.A=[1]*Opt.n
    Opt.L=[-1]*Opt.n+[0]
    Opt.U=[1]*Opt.n+[1]
    #GROSS VALUE <=2
    Opt.Aabs=[1]*Opt.n
    Opt.Uabs=[2]
    Opt.nabs=1
    #.45 <= -S/L <= .55
    Opt.rmax=.55
    Opt.rmin=.45
    Opt.initial=[1.0/Opt.n]*Opt.n
    Opt.mFE=1

    back=Opt.Opt()
    print SOCPlstestMessage(back)
    if back==2:print 'infeasible '*5
    else:
        (relret,relrisk,meanerr,stderr)=Opt.Props()
        for i in ['relret','relrisk','meanerr','stderr']:
            print i
            exec 'print %s'%i
        print longshortgross(Opt.w)
        for i in range(Opt.n):
            if Opt.w[i]<0:Opt.U[i]=0
            elif Opt.w[i]>0:Opt.L[i]=0
        back=Opt.Opt()
        print SOCPlstestMessage(back)
        if back==2:print 'infeasible '*5
        else:
            (relret,relrisk,meanerr,stderr)=Opt.Props()
            for i in ['relret','relrisk','meanerr','stderr']:
                print i
                exec 'print %s'%i
            print longshortgross(Opt.w)