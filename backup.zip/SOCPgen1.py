#!/usr/bin/env python

from Opt import *
"""
extern "C" int SOCPgenopt(size_t n,size_t m,size_t *md,vector c,vector A,vector b,
									vector w,size_t nb,vector z,double delt=1e-2,double nu=1.1);
"""
norm=lambda x:pow(dot(x,x),.5)
sqr=lambda x:x*x
n=10
errs=[(i+4)*.01 for i in range(n)]
m=2+n
md=[1]*(n+1)+[n+1]
c=[-(i+1) for i in range(n)]
A=[-1]*n
for i in range(n):#to get positive w[i]
    s=[0]*n
    s[i]=1
    A+=s
for i in range(n):
    s=[0]*n
    s[i]=errs[i]
    A+=s
A+=[0]*n
b=[1]+[0]*n+[0]*n+[.1]
w=[.9/n]*n

nb=0
nb=sum(md)
z=[0]*nb
tot=0
for i in range(m-1):
    z[tot+md[i]-1]=10
    tot+=md[i]
start=nb-md[-1]
nn=0
for i in range(n):
    tot=0
    z[start+i]=c[i]
    for j in range(m-1):
        for k in range(md[j]):
            z[start+i]-=A[i+(tot+k)*n]*z[tot+k]
        tot+=md[j]
    z[start+i]/=A[i+(start+i)*n]
    nn+=z[start+i]*z[start+i]
z[-1]=pow(nn,.5)+1.1

for i in range(n):
    tot=0
    for j in range(nb):tot+=A[i+j*n]*z[j]
    print c[i],tot
        
SOCPgenopt(n,m,md,c,A,b,w,nb,z,1e-2,10000,200)
SOCPgenopt(n,m,md,c,A,b,w,nb,z,1e-2,10,200)
SOCPgenopt(n,m,md,c,A,b,w,nb,z,1e-2,1.1,2000)

for i in range(n):
    tot=0
    for j in range(nb):tot+=A[i+j*n]*z[j]
    print c[i],tot

print w,sum(w),norm([errs[i]*w[i] for i in range(n)])
print z

print '%3s %20s %20s %20s'%('','Weight','alpha','alpha error')
for i in range(n):
    print '%5d %20.12e %20.12e %20.12e'%((i+1),w[i],-c[i],errs[i])
print '%5s %20.12e %20.12e %20.12e'%('Total',sum(w),-dot(w,c),norm([errs[i]*w[i] for i in range(n)]))