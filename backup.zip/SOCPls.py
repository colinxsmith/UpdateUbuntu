#!/usr/bin/env python
from SOCPsetup import *

n=1000
m=1
nfac=2
SV=[(i+1)*1e-5 for i in range(n)]
FL=[1]*n+[1]+[0]*(n-1)
FC=[1e-4,1e-5,2e-4]
alpha=[(i+1) for i in range(n)]
bench=[0 for i in range(n)]

Opt=SOCPOPT()
Opt.BITAconvertModel(n,nfac,SV,FC,FL)
Opt.FactoriseQ(n)

alphat=[0]*n
a=[1]*n
at=[0]*n
for i in range(n):alphat[i]=dot(alpha,Opt.rQm1[i*n:(i+1)*n])
for i in range(n):at[i]=dot(a,Opt.rQm1[i*n:(i+1)*n])

Opt.n=1
Opt.nd=[n+1]
Opt.m=2
Opt.A=at+[0]+[0]*n+[1]
Opt.b=[0,1e-3]
Opt.c=[-i for i in alphat]+[0]
nn=sum(Opt.nd)
Opt.Opt()

w=[0]*n
for i in range(n):
    w[i]=0
    for j in range(n):
        w[i]+=Opt.rQm1[i+j*n]*Opt.x[j]
        
print w,sum(w)

implied=[]
Sym_mult(n,Opt.Q,w,implied)
for i in range(n):
    print alpha[i],implied[i]

sl=sum([i for i in w if i>0])
w=[i/sl for i in w]
print w
implied=[]
Sym_mult(n,Opt.Q,w,implied)
for i in range(n):
    print alpha[i],implied[i]

alpha=[i for i in implied]
for i in range(n):alphat[i]=dot(alpha,Opt.rQm1[i*n:(i+1)*n])
Opt.c=[-i for i in alphat]+[0]
Opt.Opt()

w=[0]*n
for i in range(n):
    w[i]=0
    for j in range(n):
        w[i]+=Opt.rQm1[i+j*n]*Opt.x[j]
        
print w,sum(w)
