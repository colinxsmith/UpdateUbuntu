/*
	mxtranspose( n, m, a, b )

	sets b(m,n) = transpose(a(n,m));
*/
#include "ldefns.h"
void dmx_transpose(dimen n, dimen m, matrix a, matrix b)
{
	undex	size = m*n;
	if(b!=a){
		real	*bmn, *aij, *anm;
		bmn = b + size;	/*b+n*m*/
		anm = a + size;
		while(b<bmn) for(aij=a++;aij<anm; aij+=n ) *b++ = *aij;
		}
	else if(size>3){
		undex i,row,column,current;
		for(i=1, size -= 2;i<size;i++){
			current = i;
			do	{
				/*current = row+n*column*/
				column = current/m;
				row = current%m;
				current = n*row +  column;
				} while(current < i);

			if (current >i) {
				real temp = a[i];
				a[i] = a[current];
				a[current] = temp;
				}
			}
		}
}
