#include "ldefns.h"
#include "constant.h"
/*
	dsmxasrt( n, F, P, mode, b )	applies the sqrt of a factorised matrix made by dsmxfac
					to the vector b. If mode is SMXFAC_LEFT_ROOT then we apply
					root(D)U' to b otherwise we apply U root(D) to b
*/

void	dsmxasrt( dimen n, ldl_matrix F, short_vec P, int mode, vector v )
{
#	define	LDEBUGPR( A )
	dimen	i;
	vector	f;
	real	R[4], a, b;
	if(mode&SMXFAC_LEFT_ROOT)dsmxaupt(n, F, P, SMXFAC_TRANSPOSE, v );
	for(f=F,i=0;i<n;f+=i+1){
		if(P[i]>0){
			/*1x1 block*/
			v[i] *= (f[0]<lm_rooteps ? lm_eps : sqrt(f[0]));
			i++;
			}
		else	{
			/*2x2 block; find the square root of the block*/
			a = *f;
			f += i+1;
			b = *f++;
			dsmx22sqrt( a, b, *f, R );
			a = R[0]*v[i] + R[2]*v[i+1];
			v[i+1] = R[1]*v[i] + R[3]*v[i+1];
			v[i] = a;
			i += 2;
			}
		}
	if(!(mode&SMXFAC_LEFT_ROOT))dsmxaupt(n, F, P, SMXFAC_NORMAL, v );
}
