/*
	copy vector x to vector y
*/
#include "ldefns.h"

void dcopyvec(dimen n, vector x, vector y)
{
	memmove(y,x,n*sizeof(real));
}
void scopyvec(dimen n, float* x, float* y)//single precision
{
	memmove(y,x,n*sizeof(float));
}
