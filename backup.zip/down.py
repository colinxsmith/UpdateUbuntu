#! /bin/env python
from sys import path
path.append('./')
from Opt import *
if jython:
    import CostFunc
def lscheck(w):
    sp=0
    sn=0
    g=0
    for i in w:
        if i < 0:sn+=i
        if i > 0:sp+=i
        g+=abs(i)
    return (sp,sn,g,-sn/sp)
#_____________________________________________________________________________________________________________
n=10
opt=Opt()
opt.n=n
opt.m=1
opt.A=[1]*n
opt.names=map(lambda t:'Stock %d'%(t+1),range(n))
opt.alpha=map(lambda t:float(t-n/2)/n,range(n))
opt.bench=map(lambda t:1.0/n,range(n))
opt.L=[0]*n+[1]
opt.U=[1]*n+[1]
opt.nfac=-1
opt.initial=map(lambda t:t,opt.bench)
Q=[0]*(n*(n+1)/2)
ij=0
for i in range(n):
    for j in range(i+1):
        if i==j:Q[ij]=float(i+1)*1e-2
        ij+=1
opt.Q=Q
#___________________________________________________________________________________________________________
opt.gamma=0.1
opt.log=0
bret=dot(opt.bench,opt.alpha)
def sharpe(gamma):
    opt.gamma=gamma
    if opt.opt() > 1:raise 'Optimisation failed'
    opt.risks()
    ret=dot(opt.w,opt.alpha)-bret
    sharp=ret/opt.risk
#    print 'risk return sharpe',opt.risk,ret,sharp
    return -sharp
downset=0
def downf(gamma):
    opt.gamma=gamma
    if opt.opt() > 1:raise 'Optimisation failed'
    opt.risks()
    ret=dot(opt.w,opt.alpha)-bret
    sharp=ret/opt.risk
    down=ret-3*opt.risk
    print 'gamma %e sharpe %e down %e'%(gamma,sharp,down)
    return down-downset
if jython:
    class SetFuncSharpe(CostFunc):
        def f1d(self,g):return sharpe(g)
    class SetFuncDown(CostFunc):
        def f1d(self,g):return downf(g)
    SHARPE=SetFuncSharpe()
    DOWN=SetFuncDown()
    gamma1=PathMin(SHARPE,1e-5,1,1e-8,0)
    sharpemax=-sharpe(gamma1)
    downsharpe=downf(gamma1)
    print 'Down at optimal sharpe gamma %e'%downsharpe
    downset=downsharpe*.5#try to find gamma which halves the value of downf and also reduces risk
    ogamma=Solve1D(DOWN,gamma1,1e-5,1e-8)
else:
    gamma1=PathMin(sharpe,1e-5,1,1e-8,0)
    sharpemax=-sharpe(gamma1)
    downsharpe=downf(gamma1)
    print 'Down at optimal sharpe gamma %e'%downsharpe
    downset=downsharpe*.5#try to find gamma which halves the value of downf and also reduces risk
    ogamma=Solve1D(downf,1e-5,gamma1,1e-8)
    downset*=1.01
    ogamma=Solve1D(downf,ogamma,.05,1e-8)
wopt=map(lambda t:t,opt.w)
risk=opt.risk

downset=0
dsharp=-sharpe(ogamma)
print 'Down at gamma = %e %e'%(ogamma,downf(ogamma))
print 'Down at optimal sharpe gamma %e'%downsharpe
print 'Maximum Sharpe Ratio is %e at gamma= %e'%(sharpemax,gamma1)
print 'Sharpe Ratio is %e at gamma= %e'%(dsharp,ogamma)
print 
print wopt
