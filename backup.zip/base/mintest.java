class	OptimiserFunctions
{
	public double[] c;//This array defines the extra utility and its 1st and 2nd derivatives
	public double	f1d(double x)
	{
	//	This has a minimum at x=.2 with function value -10
	//	It has a zero at around x=3.36
		System.out.println("f1d: x = "+x);
		return (x-.2)*(x-.2)-10;
	}
	public void hmul(long n,long n1,long n2,long n3,double[] H,double[] x,double[] y)
	{
		int i,j,ij;
		for(i=0,ij=0;i<n;++i)
		{
			y[i] = 0;
			for(j=0;j<=i;++j)
			{
				y[i]+=H[ij]*x[j];
				if(i!=j)
					y[j]+=H[ij]*x[i];
				ij++;
			}
		}
	}
	public void modc(long n,double[] x,double[] C)
	{
//		System.out.println("function MODC");
		int i,j,k;
		double prod;
		for (i=0;i<n;++i)
		{
			for (j=0;j<=i;++j)
			{
				for (k=0;k<=j;++k)
				{
					prod=c[i]*c[j]*c[k];
					if (j!=k && j!=i && i!=k)
					{
						C[i]+=prod*x[j]*x[k]*2;
						C[j]+=prod*x[i]*x[k]*2;
						C[k]+=prod*x[i]*x[j]*2;
					}
					else if (i==j && j!=k)
					{
						C[i]+=prod*x[j]*x[k]*2;
						C[k]+=prod*x[i]*x[j];
					}
					else if (j==k && i!=k)
					{
						C[i]+=prod*x[j]*x[k];
						C[j]+=prod*x[i]*x[k]*2;
					}
					else if (i==k && j==k)
					{
						C[i]+=prod*x[j]*x[k];
					}
				}
			}
		}
	}
	public void modq(long n,double[] x,double[] C)
	{
//		System.out.println("function MODQ");
		int i,j,k,ij,jk,ik;
		double prod;
		ij=0;
		for (i=0;i<n;++i)
		{
			jk=0;
			for (j=0;j<=i;++j)
			{
				for (k=0;k<=j;++k)
				{
					ik=i*(i+1)/2+k;
					prod=c[i]*c[j]*c[k];
					if (j!=k && j!=i && i!=k)
					{
						C[ij]+=prod*x[k];
						C[jk]+=prod*x[i];
						C[ik]+=prod*x[j];
					}
					else if (i==j && j!=k)
					{
						C[ij]+=prod*x[k]*2;
						C[ik]+=prod*x[i]*2;
					}
					else if (j==k && i!=k)
					{
						C[jk]+=prod*x[i]*2;
						C[ij]+=prod*x[j]*2;
					}
					else if (i==k && j==k)
					{
						C[ij]+=prod*x[i]*6;
					}
					jk+=1;
				}
				ij+=1;
			}
		}
	}
    
	public double util(long n,double[] x)
	{
//		System.out.println("function UTIL");
		double s=0,prod;
		int i,j,k;
		for (i=0;i<n;++i)
		{
			for (j=0;j<=i;++j)
			{
				for (k=0;k<=j;++k)
				{
					prod=c[i]*c[j]*c[k]*x[i]*x[j]*x[k];
					if (j!=k && j!=i && i!=k)
					{
						s+=prod*6;
					}
					else if (i==j && j!=k)
					{
						s+=prod*3;
					}
					else if (j==k && i!=k)
					{
						s+=prod*3;
					}
					else if (i==k && j==k)
					{
						s+=prod;
					}
				}
			}
		}
		return s;
	}
}

public class mintest
{
/*	static 
	{
		try
		{
			System.loadLibrary("safejava");
		}
		catch (UnsatisfiedLinkError e)
		{
			System.err.println("Native code library failed to load.\n" + e);
			System.exit(1);
		}
	}*/
	public static void main(String args[])
	{
		OptimiserFunctions OF=new OptimiserFunctions();
		double x=0;

		//Find the minimum of Testmin.f1d()

		x=safejava.PathMin(OF,-10,10,1e-8,0);
		System.out.println("Min is at "+x+", value; "+OF.f1d(x));
		//Solve tTestmin.f1d()=0 on range 0,100
		x=safejava.Solve1D(OF,0,100,1e-8);
		System.out.println("Value at "+x+" is "+OF.f1d(x));

		//Now do an optimisation of absolute variance

		double [] H = {1,-.1,1,.1,-.1,1,.1,.1,-.1,1,.1,.1,.1,-.1,1};
		long n=5,m=1;
		short lp=0;
		double [] A={1,1,1,1,1};
		double [] cdata={.1,.2,.3,.4,.5};
		OF.c=cdata;
		double [] L={0,0,0,0,0,1};
		double [] U={1,1,1,1,1,1};
		double [] c={-.02,-.01,.01,.02,.03};
		double [] xx = new double[(int)n];
  		System.out.println(safejava.BasicQpOpt(n, m, A, L, U, xx, c, H, lp, null, -1, 0, 
		null, -1, null, null, 0, 1, 1, null, null, null, null));
		double sum=0;
		int i;
		for(i=0;i<n;++i)
		{
			sum+=xx[i];
			System.out.println(i+" "+xx[i]);
		}
		System.out.println("Total "+sum);
		System.out.println("Repeat but define the Hessian multiplication function here in java");
  		System.out.println(safejava.BasicQpOpt(n, m, A, L, U, xx, c, H, lp, OF, -1, 0, 
		null, -1, null, null, 0, 1, 1, null, null, null, null));
		sum=0;
		for(i=0;i<n;++i)
		{
			sum+=xx[i];
			System.out.println(i+" "+xx[i]);
		}
		System.out.println("Total "+sum);
		System.out.println("Now use cubic terms in the utility");
  		System.out.println(safejava.BasicQpOpt(n, m, A, L, U, xx, c, H, lp, OF, -1, 0, 
		null, -1, null, null, 0, 1, 1, cdata, OF, OF, OF));
		sum=0;
		for(i=0;i<n;++i)
		{
			sum+=xx[i];
			System.out.println(i+" "+xx[i]);
		}
		System.out.println("Total "+sum);
/*		This doesn't work if the safejavajy class has defined Optimise. Not worth
		tidying up at present
		Optimise OO=new Optimise();
		System.out.println(OO.getVersion());
		System.out.println(OO.getN());
		OO.setN(5);
		System.out.println(OO.getN());*/
	}
}
