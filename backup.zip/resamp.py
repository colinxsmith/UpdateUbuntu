#! env python
"""
Colin 30-8-2002
Python program for running an optimisation/risk report using a COR-RS Curve output trace log
as input

Run this by typing:
python runtest.py logfile1 logfile2 .......
for as many logs as you like (don't put the trailing dots in!)

Modified for Tkinter 29-01-2003
"""
from Opt import *
from random import random
import getf,sys

def oxprintmat(a,name):
    """Generate a file containing a float list in Ox matrix format for list a"""
    name=name+'.mat'
    length=len(a)
    if length<=0:return
    file=open(name,'w')
    file.write('%d 1\n' % length)
    for i in a:file.write('%-.16e\n' % i)
    file.close()
def change_alpha(a,b,step=1e-1):
    n=b.n
    if step == 0:
        for i in range(n):b.alpha[i]=a.alphas[i]
    else:
        #for i in range(n):b.alpha[i]=a.alphas[i]*(1.0+step*(random()-0.5))
        for i in range(n):b.alpha[i]=a.alphas[i]*(1.0+gausspdf(0,step))
def copylist(a):
    b=[]
    for i in a:
        b.append(i)
    return b

del sys.argv[0] #This will be the string runtest.py
OxPrint=0
for arg in sys.argv:
    if arg == '-ox':OxPrint=1;continue
    print arg
    a=getf.datin()
    a.getBITA5(arg)
    #for i in dir(a):print i,getattr(a,i)
    print version()
    relrisk=Opt()

    relrisk.n=n=a.numAssets
    relrisk.nfac=a.numFactors
    if relrisk.nfac == -1:
        try:relrisk.Q=a.Q
        except:relrisk.Q=[0]*(n*(n+1)/2)
        if OxPrint:oxprintmat(relrisk.Q,'Q')
    else:
        relrisk.FC=a.FC
        if OxPrint:oxprintmat(relrisk.FC,'FC')
    ncomp = 0
    try:
        relrisk.ncomp=ncomp=a.numCompositeAssets
        Comp=[]
        if a.numCompositeAssets > 0:
            stockcount=0
            for name in a.assetNames:
                if stockcount>=(relrisk.n-relrisk.ncomp):
                    ccc=getattr(a,name)
                    #exec 'ccc = a.%s' % name
                    for i in range(ncomp):
                        del ccc[-1]
                    Comp += ccc
                stockcount+=1
        relrisk.Composites=Comp
        if OxPrint:oxprintmat(relrisk.Composites,'Composites')
    except:pass
    if OxPrint:
        oxf=open('names','w')
        for name in a.assetNames:oxf.write('%s\n'%name)
        oxf.close()
    if relrisk.nfac!=-1:
        FL=[]
        for i in a.FACNAMES:
            FFL=getattr(a,i)
            for i in range(ncomp):
                del FFL[-1]
            FL+=FFL
        SV=a.specificVariance
        for i in range(ncomp):
            del SV[-1]
        relrisk.SV=SV
        if OxPrint:oxprintmat(relrisk.SV,'SV')
        relrisk.FL=FL
        if OxPrint:oxprintmat(relrisk.FL,'FL')
    relrisk.bench=a.benchmarkPortfolio
    if OxPrint:oxprintmat(relrisk.bench,'benchmark')
    relrisk.alpha=map(lambda d:d,a.alphas)
    if OxPrint:oxprintmat(relrisk.alpha,'alpha')
    relrisk.names=a.assetNames
    relrisk.initial=a.initialPortfolio
    if OxPrint:oxprintmat(relrisk.initial,'initial')
    relrisk.buy=a.buyCost
    if OxPrint:oxprintmat(relrisk.buy,'buy')
    relrisk.sell=a.sellCost
    if OxPrint:oxprintmat(relrisk.sell,'sell')
    relrisk.m=m=a.numLinearConstraints
    A=[0]*n*m
    L=a.lowerBoundAssetWeight
    U=a.upperBoundAssetWeight
    for cc in range(m):
        aa=getattr(a,'linearConstraint'+str(cc+1))
        #exec 'aa = a.%s' % 'linearConstraint'+str(cc+1)
        for i in range(n):
            A[cc+m*i] = aa[i]
        L.append(a.lower['linearConstraint'+str(cc+1)])
        U.append(a.upper['linearConstraint'+str(cc+1)])
    relrisk.L=L
    if OxPrint:oxprintmat(relrisk.L,'L')
    relrisk.U=U
    if OxPrint:oxprintmat(relrisk.U,'U')
    relrisk.A=A
    if OxPrint:oxprintmat(relrisk.A,'A')

       
    relrisk.gamma=a.returnParameter
    relrisk.kappa=a.costParameter
    relrisk.costs=a.costsOnOff
    relrisk.delta=a.turnoverConstraint
    relrisk.basket=a.maxNumAssetsInOptimisedPortfolio
    relrisk.tradenum=a.maxNumTradesInOptimisedPortfolio
    relrisk.revise=a.reviseOnOff
    relrisk.min_holding=a.minAssetWeight
    relrisk.min_trade=a.minAssetTrade
    relrisk.ls=a.longShortOnOff
    relrisk.full=a.fullyInvested
    relrisk.rmin=a.minShortLongRatio                      
    relrisk.rmax=a.maxShortLongRatio                        
    relrisk.round=a.roundLotsOnOff
    relrisk.npoints=a.numFrontierIncrements
    relrisk.Nlong=-1
    relrisk.Nshort=-1


    if a.isRiskConstrained == 'false':
        relrisk.riskc=0
    elif a.isRiskConstrained == 'true':
        relrisk.riskc=1
    else:
        raise 'isRiskConstrained is neither false nor true: %s'%a.isRiskConstrained

    relrisk.riskc=0
    if relrisk.riskc:    
        relrisk.maxrisk = a.maxRisk
        relrisk.minrisk = a.minRisk
#    relrisk.downrisk=1
    relrisk.downfactor=2.0/pow(12,0.5)
#    relrisk.minrisk=-.0316667
#    relrisk.maxrisk=6.1e-2

    relrisk.min_lot=a.minLot
    if OxPrint:oxprintmat(relrisk.min_lot,'min_lot')
    relrisk.size_lot=a.sizeLot
    if OxPrint:oxprintmat(relrisk.size_lot,'size_lot')
    root=None
    if a.optimisationTechnique>-1:
        from scrolled import *
        class Info(Frame):
            def __init__(self,root,name,cnf={},**kw):
                """Associate a text entry with a lable"""
                for i in kw.keys():
                    cnf[i]=kw[i]
                Frame.__init__(self,root,cnf)
                l=Label(self,bg='#33ee22',text=name,justify=LEFT,anchor=W)
                l.config(width=4,relief=SUNKEN)
                l.pack(side=LEFT)
                ents=Entry(self,bg='#dddd22')
                ents.config(width=8,relief=SUNKEN)
                ents.pack(side=LEFT)
                self.ents=ents
        class FrontGraph(Frame):
            def __init__(self,root,relrisk,gammas,cnf={},**kw):
                for i in kw.keys():
                    cnf[i]=kw[i]
                Frame.__init__(self,root,cnf)
                frame=ScrolledCanvas(root)
                frame.canvas.config(width=800,height=600,bg='#ffff55')
                frameb=Frame(root)
                gammat=''
                for gamma in gammas:
                    gammat+=str(gamma)+' '
                def front():
                    frame.canvas.delete(ALL)
                    x=[]
                    y=[]
                    for gamma in gammas:
                        relrisk.gamma=gamma
                        relrisk.opt()
                        relrisk.props()
                        (r1,ret1)=(relrisk.risk,relrisk.rreturn)
                        x.append(r1)
                        y.append(ret1)
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,len(gammas))
                    frame.plot(fill='green',title='Return vs Risk')
                    for i in range(len(gammas)):
                        frame.point(x[i],y[i],fill='brown',crossize=10)
                    for i in range(1000):
                        change_alpha(a,relrisk)
                        for gamma in gammas:
                            relrisk.gamma=gamma
                            relrisk.opt()
                            relrisk.props()
                            (r1,ret1)=(relrisk.risk,relrisk.rreturn)
                            retp=dot(relrisk.w,a.alphas)-dot(relrisk.bench,a.alphas)
                            frame.point(r1,ret1,fill='blue',crossize=1)
                            frame.point(r1,retp,fill='red',crossize=1)
                    frame.canvas.postscript(file='graph.ps')
                button=Button(frameb,bg='#ffddaa',command=front,text='frontier at these gammas: '+gammat)
                frame.pack(expand=1,fill=BOTH)
                frameb.pack(expand=1,fill=X)
                button.pack(expand=1,fill=X,side=LEFT)
        root=Tk()
        root.title('Resampling from Curve data in file %s; optimiser version %s, expires %s, keys %s'%(arg,version(),expire_date(),
                                                                                     component_key()))
        scalarnamesF='gamma kappa delta min_holding min_trade rmin rmax maxrisk minrisk value zetaS zetaF ShortCostScale downfactor'
        scalarnamesI='npoints ncomp nfac npiece nabs m mabs costs basket shortbasket longbasket tradenum tradebuy tradesell revise ls full round riskc DoByRisks downrisk '
        scalarframes={}
        vals=Frame(root,relief=SUNKEN)
        vals.pack(side=LEFT)
        vals1=Frame(vals,relief=SUNKEN)
        vals2=Frame(vals,relief=SUNKEN)
        vv=Label(vals,text='Scalar values',font='-*-Arial-Bold-R-Bold--*-200-*-*-*-*-*-*')
        vv.pack(side=TOP,fill=X)
        vals2.pack(side=BOTTOM,expand=1,fill=X)
        vals1.pack(side=RIGHT,expand=1,fill=BOTH)
        retmes=Entry(vals2,bg='#ff33ee')
        riskval=Entry(vals2,bg='#33eeff')
        retval=Entry(vals2,bg='#33eeff')
        utilval=Entry(vals2,bg='#33eeff')
        def GetValues():
            for i in scalarnamesI.split():
                setattr(relrisk,i,int(scalarframes[i].ents.get()))
            for i in scalarnamesF.split():
                setattr(relrisk,i,float(scalarframes[i].ents.get()))
            relrisk.alpha=copylist(a.alphas)

            relrisk.opt()
            relrisk.props()

            (r1,ret1)=(relrisk.risk,relrisk.rreturn)
            riskval.delete(0,END)
            riskval.insert(END,'risk\t%20.15e'%r1)
            retval.delete(0,END)
            retval.insert(END,'return\t%20.15e'%ret1)
            scalarframes['gamma'].ents.delete(0,END)
            scalarframes['gamma'].ents.insert(END,str(relrisk.gamma))
            relrisk.margutility()
            u=relrisk.utility
            utilval.delete(0,END)
            utilval.insert(END,'utility\t%20.15e'%u)
            print 'Utility %-.8e' % u
            retmes.delete(0,END)
            retmes.insert(END,relrisk.returnmessage)
            
        optcom=Button(vals2,bg='#ffaadd',command=GetValues,text='Accept scalars and Optimise')
        for i in scalarnamesI.split():
            scalarframes[i]=Info(vals,i,relief=SUNKEN)
            scalarframes[i].ents.insert(END,str(getattr(relrisk,i)))
            scalarframes[i].pack(side=TOP)
        for i in scalarnamesF.split():
            scalarframes[i]=Info(vals1,i,relief=SUNKEN)
            scalarframes[i].ents.insert(END,str(getattr(relrisk,i)))
            scalarframes[i].pack(side=TOP)
        optcom.pack(side=TOP,expand=1,fill=X)
        retmes.pack(side=TOP,expand=1,fill=X)
        riskval.pack(side=TOP,expand=1,fill=X)
        retval.pack(side=TOP,expand=1,fill=X)
        utilval.pack(side=TOP,expand=1,fill=X)
        frameg=FrontGraph(root,relrisk,[.2,.3,.4,.5])
        frameg.pack(side=LEFT)
        finish=Button(root,bg='#eeff33',command=root.destroy,text='Finish')
        finish.pack(side=RIGHT,expand=1,fill=X)
        root.mainloop()

