#include "ldefns.h"

void BITA_drotg(real *a, real *b, real *c, real *s)
{
    int fail;
    real t;

/*
DROTG BLAS,  except that c is always returned as non-negative and  b
is overwritten by the tangent of the angle that defines the plane rotation.
c and s are given as c = 1.0/sqrt( 1.0 + t**2 ),   s = c*t   where   t = b/a.
When  abs( b ) <= eps*abs( a ),  where  eps is the relative machine 
precision,  then  c and s  are always returned as c = 1.0  and  s = 0.0
and when  abs( a ) <  eps*abs( b ) then c and s are always returned 
as c = 0.0  and  s = sign( t ).

Note that t is always returned as  b/a, unless this would overflow in 
which  case the value  sign( t )/lm_min is returned.
*/
	if(*b == 0){
		*c = 1;
		*s = 0;
		}
	else	{
		t = dprotdiv(b, a, &fail);
		*c = dcossint(t, s);
		*a = *c * *a + *s * *b;
		*b = t;
		}
}
