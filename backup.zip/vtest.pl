use safepl;
package safepl;
$\="\n";
$,="\t";
print component_key();
$a=[];
print days_left($a),@$a;
print version();
print expire_date();
