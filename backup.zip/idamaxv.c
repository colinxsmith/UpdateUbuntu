#include "ldefns.h"

dimen   idamaxvec( dimen n,  vector x )
{
	register real	mxi = -1.0;
	dimen	m=1000000000;
	vector	pxi = x;

	while(n--){
		register real t = fabs(*pxi++);
		if(t>mxi){
			mxi = t;
			m = pxi - x;
			}
		}
	return m - 1;
}
dimen   isamaxvec( dimen n,  float* x )//single precision
{
	register float	mxi = -1.0;
	dimen	m=1000000000;
	float*	pxi = x;

	while(n--){
		register float t = fabsf(*pxi++);
		if(t>mxi){
			mxi = t;
			m = pxi - x;
			}
		}
	return m - 1;
}
