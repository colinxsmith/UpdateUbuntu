#Colin 16-12-2005
#Solving Sparse linear equations
from Opt import *

n=4
order=[1,0,2,3]
S=SparseLDL(n)
S.SetOrder(n,order)

Q=[1,0.1,2,0.1,0.1,3,0.1,0.1,0.1,4]

S.CreateSparseIndices(Q)
print S.Factor()
b=[1,4,9,16]
S.Solve(b)
print b

#Second working out the sparse arrays here
S=SparseLDL(n,order)
AP=[0]
AI=[]
AX=[]
ij=0
tot=0
for i in range(n):
    for j in range(n):
        if j<=i:
            if Q[ij]!=0:
                AX.append(Q[ij])
                AI.append(j)
                tot+=1
            ij+=1
        else:
            if Q[j*(j+1)/2+i]!=0:
                AX.append(Q[j*(j+1)/2+i])
                AI.append(j)
                tot+=1
    AP.append(tot)
S.Factor(AX,AP,AI)
b=[1,4,9,16]
S.Solve(b)
print b