#!/bin/env python
from re import sub
from sys import stdin,argv
def comprocess(Cfunc='DLLEXPORT void	factor_model_process(dimen n,dimen nfac,vector FL,vector FC,vector SV,vector Q);',
               COMfunc='HRESULT __stdcall Optimiser::FactorModelProcess(int n,int nfac,VARIANT FL,VARIANT FC,VARIANT SV,VARIANT *Q)'):
    linesep = '// '+'='*40
    Cfunc=sub('DLLEXPORT','extern "C"',Cfunc)
    print Cfunc
    print COMfunc+'\n{'
    print '\tHRESULT hh;'
    print '\tsize_t NNN;'
    print linesep
    for ff in COMfunc.split(','):
        if ff.find('VARIANT')>-1:
            FL=sub('^.* ','',ff)
            FL=sub('\)$','',FL)
            cFL='c'+sub('\*','',FL)
            if Cfunc.find('vector '+FL.replace('*',''))>-1:
                print '\tvector %s;'%cFL
            elif Cfunc.find('real* '+FL.replace('*',''))>-1:
                print '\treal* %s;'%cFL
            elif Cfunc.find('real*'+FL.replace('*',''))>-1:
                print '\treal* %s;'%cFL
            elif Cfunc.find('real *'+FL.replace('*',''))>-1:
                print '\treal* %s;'%cFL
            elif Cfunc.find('double* '+FL.replace('*',''))>-1:
                print '\tdouble* %s;'%cFL
            elif Cfunc.find('double*'+FL.replace('*',''))>-1:
                print '\tdouble* %s;'%cFL
            elif Cfunc.find('double *'+FL.replace('*',''))>-1:
                print '\tdouble* %s;'%cFL
            elif Cfunc.find('dimen* '+FL.replace('*',''))>-1:
                print '\tdimen* %s;'%cFL
            elif Cfunc.find('dimen*'+FL.replace('*',''))>-1:
                print '\tdimen* %s;'%cFL
            elif Cfunc.find('dimen *'+FL.replace('*',''))>-1:
                print '\tdimen* %s;'%cFL
            elif Cfunc.find('int* '+FL.replace('*',''))>-1:
                print '\tint* %s;'%cFL
            elif Cfunc.find('int*'+FL.replace('*',''))>-1:
                print '\tint* %s;'%cFL
            elif Cfunc.find('int *'+FL.replace('*',''))>-1:
                print '\tint* %s;'%cFL
            print '\thh = Variant2Vector(NNN,%s,&%s,"%s:%s");'%(FL,cFL,sub('\*','',FL),comname)
            print '\tif(hh == S_FALSE)'
            print '\t\treturn S_FALSE;'
        elif ff.find('::')>-1:
            comname=sub('^.*::','',ff)
            comname=sub('\(.*$','',comname)
    print linesep

    ccf=sub('extern "C"\W\w*\W','',Cfunc)
    ccf=sub('vector\W','\1c',ccf)
    ccf=sub('dimen\*\W','\1c',ccf)
    ccf=sub('int \*\W','\1c',ccf)
    ccf=sub('double \*\W','\1c',ccf)
    ccf=sub('real \*\W','\1c',ccf)
    ccf=sub('dimen \*\W','\1c',ccf)
    ccf=sub('int\*\W','\1c',ccf)
    ccf=sub('double\*\W','\1c',ccf)
    ccf=sub('real\*\W','\1c',ccf)
    ccf=sub('\(\w*\W','(',ccf)
    ccf=sub(',\w*\W',',',ccf)

    print '\t'+ccf
    print linesep
    for ff in COMfunc.split(','):
        if ff.find('VARIANT')>-1:
            FL=sub('^.* ','',ff)
            FL=sub('\)$','',FL)
            cFL='c'+sub('\*','',FL)
            print '\tSafeArrayRelease(%s,%s,NNN);'%(FL,cFL)
    print linesep
    print '\treturn S_OK;\n}'

del argv[0]
if len(argv):ff=open(argv[0])
else:ff=stdin

while 1:
    Cfunc=ff.readline()
    if not Cfunc:break
    Cfunc=Cfunc.strip()
    if len(Cfunc)==0:continue
    while Cfunc.find(';')==-1:Cfunc+=ff.readline().strip()
    COMfunc=ff.readline().strip()
    while COMfunc.find(')')==-1:COMfunc+=ff.readline().strip()
    comprocess(Cfunc,COMfunc)
