/*
	x = y + z for simple vectors (all unit stride)
*/
#include "ldefns.h"
void daddvec(dimen n, vector y, vector z, vector x)
{
	dadd(n,y,1,z,1,x,1);
}
