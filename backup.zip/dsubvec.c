/*
	x = y - z for simple vectors
*/
#include "ldefns.h"
void dsubvec(dimen n, vector y, vector z, vector x)
{
	dsub(n,y,1,z,1,x,1);
}
