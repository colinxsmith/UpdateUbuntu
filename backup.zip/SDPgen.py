#!/bin/env python
from SDP import *
"""
extern "C" int OptSDP(int N,int M,double* Q,double* c,double* A,double*L,double*U,double* w_opt,
					  double* bench=0,double* implied=0,double* alpha=0,double Rmin=0,double Rmax=0)
"""
def Symmult(n,S,x,Sx):
    """Multiply a symmetric matrix S by a vector x to get Sx.
    S is a list of length n*(n+1)/2 containing the lower triangle of a symmetric
    matrix stored in the order [00,10,11,20,21,22,.......]
    x and Sx are lists of length n
    """
    if len(x)<n:raise 'x is not long enough'
    if len(Sx)<n:raise 'Sx is not long enough'
    if len(S)<n*(n+1)/2:raise 'S is not long enough'
    ij=0
    for i in range(n):
        Sx[i]=0
        for j in range(i+1):
            Sx[i]+=S[ij]*x[j]
            if i!=j:Sx[j]+=S[ij]*x[i]
            ij+=1
def dot(a,b):
    n=len(a)
    if n!=len(b):raise 'Length error in dot'
    res=0
    for i in range(n):res+=a[i]*b[i]
    return res
def util(n,Q,c,w):
    if Q==[]:
        return dot(c,w)
    implied=[0]*n
    Symmult(n,Q,w,implied)
    return 0.5*dot(w,implied)+dot(c,w)
def var(n,Q,w):
    implied=[0]*n
    Symmult(n,Q,w,implied)
    return dot(w,implied)
def g(l):
    """Turn the Lagrangian multiplyer of the risk constraint to gamma"""
    k=0.5/l
    return k/(1+k)
def Opt(n,m,w,L,U,alpha,bench,gamma,A,cov,basket,R=0):
    implied=[0]*n
    Symmult(n,cov,bench,implied)
    c=[gamma/(1-gamma)*(-alpha[i])-implied[i] for i in range(n)]
    Rmax=Rmin=R
    if R==0:impliedh=[]
    else:impliedh=implied
    print 'Return code ',OptSDP(n,m,cov,c,A,L,U,w,bench,impliedh,alpha,Rmin,Rmax,basket)
    print dot(A,w)
    print 'Return ',dot(alpha,w)
    print 'Utility ',util(n,cov,c,w)
    print 'Abs Variance ',var(n,cov,w)
    if implied!=[]:
        print 'Rel Variance ',var(n,cov,w)-2*dot(implied,w)+dot(implied,bench)
        
if __name__ == '__main__':
    n=4
    m=1
    cov=[0.082413214985258054, 0.0085237134681903914, 0.089070270882033536, 0.0052971882656530911, -0.010020600571815669, 0.079791663443914862, 0.016249612103159561, -0.012009661280024869, -0.0056633461502720861, 0.092481531373906162]
    alpha=[.1,.2,.3,.4]
    bench=[1.0/n]*n
    implied=[0]*n
    Symmult(n,cov,bench,implied)
    gamma=g(1.33249665e+000)
    gamma=0
    print gamma
    c=[gamma/(1-gamma)*(-alpha[i])-implied[i] for i in range(n)]

    A=[1]*n
    L=[0]*n+[1-1e-6]
    U=[1]*n+[1]
    w=[]

    Rmin=.06
    Rmax=Rmin
    basket=2

    print Opt(n,m,w,L,U,alpha,bench,gamma,A,cov,basket,0)
    print OptSDP(n,m,cov,c,A,L,U,w,bench,[],alpha,Rmin,Rmax,basket)
    print w
    print dot(A,w)
    print 'Return ',dot(alpha,w)
    print 'Utility ',util(n,cov,c,w)
    print 'Abs Variance ',var(n,cov,w)
    print 'Rel Variance ',var(n,cov,w)-2*dot(implied,w)+dot(implied,bench)

    varmin=0.01892
    varmax=0.06873
    np=1
    vars=[varmin+((varmax-varmin)*i)/np for i in range(np)]
    ret=[]
    actvar=[]
    for R in vars:
        Rmin=Rmax=R
        print OptSDP(n,m,cov,c,A,L,U,w,bench,implied,alpha,Rmin,Rmax,basket)
        print w
        print dot(A,w)
        print 'Return ',dot(alpha,w)
        print 'Utility ',util(n,cov,c,w)
        print 'Abs Variance ',var(n,cov,w)
        print 'Rel Variance ',var(n,cov,w)-2*dot(implied,w)+dot(implied,bench)
        ret.append(dot(alpha,w))
        actvar.append(var(n,cov,w)-2*dot(implied,w)+dot(implied,bench))

    for i in range(np):
        print '%20.10f %20.10f %20.10f'%(vars[i],actvar[i],ret[i])
