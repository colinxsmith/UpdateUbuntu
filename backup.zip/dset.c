/*
	set a general vector to a constant
*/
#include "ldefns.h"


void dset(dimen n, real alpha, vector x, increment incx)
{
	if(n>0){
		if(incx<0) incx = -incx;	/*cannot matter which order*/
		while(n--){ *x = alpha; x += incx; }
		}
}
void sset(dimen n, float alpha, float* x, increment incx)//single precision
{
	if(n>0){
		if(incx<0) incx = -incx;	/*cannot matter which order*/
		while(n--){ *x = alpha; x += incx; }
		}
}
