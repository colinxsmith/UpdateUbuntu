#include "baseoptimise.h"
/* FIND THE BIGGEST SCALED MULTIPLIER LARGER THAN UNITY. */
void Base_Optimise::dlpbgst(	dimen n, dimen nactiv, dimen nfree, integer *jbigst, integer *kbigst,
		short_vec istate, short_vec kactiv, real dinky, real feamin, real *trulam, vector featol, vector rlamda)
{
	real	rlam, biggst;
	dimen 	nlam, j, k, is, nfixed;

	--rlamda;
	--featol;
	--kactiv;
	--istate;

	*jbigst = 0;
	nfixed = n - nfree;
	nlam = nfixed + nactiv;
	if (nlam == 0) return;
	biggst = 1 + dinky;
	for (k = 1; k <= nlam; ++k) {
		j = kactiv[k];
		if (k <= nactiv) j += n;
		is = istate[j];
		if(is >= 1) {
			rlam = rlamda[k];
			if (is == 2) rlam = -rlam;
			if (is == 3) rlam = fabs(rlam);
			rlam = featol[j] / feamin * rlam;
			if (biggst < rlam) {
				biggst = rlam;
				*trulam = rlamda[k];
				*jbigst = j;
				*kbigst = k;
				}
			}
		}
	if (msg >= 80) lm_wmsg((char*)"\n//LPBGST// JBIGST         BIGGST\n//LPBGST//%7ld%15.4lg", CL(*jbigst), biggst);
}
