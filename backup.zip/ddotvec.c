#include "ldefns.h"
/*
	DAS version of BLAS routine ddot for computing the inner product
	of two simple real vectors x and y
*/
//#define MULTI_P
float sdotvec(dimen n, float *x, float *y)//single precision
{
	register float sum;

	sum = 0;
	while(n--) sum += *x++ * *y++;
	return sum;
}
#ifdef MULTI_P
real ddotvec_old(dimen n, real *x, real *y)
#else
real ddotvec(dimen n, real *x, real *y)
#endif
{
	register real sum;

	sum = 0;
	while(n--) sum += *x++ * *y++;
	return sum;
}

#ifdef MULTI_P
#define nthreads 2
#define OLD ddotvec_old
HANDLE handles[nthreads];
CRITICAL_SECTION mutex;
struct arginfo
{
	double*sum;size_t n;vector x;vector y;
	size_t id;
};
static void work_here(void *arg)
{
	struct arginfo*Info=(struct arginfo*)arg;
	double sumh;
	size_t nn=Info->n/nthreads,extra=0;
	if(Info->id==nthreads-1) extra=Info->n-nthreads*nn;
	sumh=OLD(nn+extra,Info->x+Info->id*nn,Info->y+Info->id*nn);
	EnterCriticalSection(&mutex);
	*(Info->sum)+=sumh;
	LeaveCriticalSection(&mutex);
}
double ddotvec(dimen n,vector x,vector y)
{
	if(n>=3000)
	{
		size_t threadID,i;
		struct arginfo Info[nthreads];
		double sum=0;
		for(i=0;i<nthreads;i++)
		{
			Info[i].id=i;
			Info[i].n=n;
			Info[i].x=x;
			Info[i].y=y;
			Info[i].sum=&sum;
		}
		InitializeCriticalSection(&mutex);
		for(i=0;i<nthreads;++i)
		{
			handles[i]=CreateThread(0,0,(LPTHREAD_START_ROUTINE)work_here,Info+i,0,&threadID);
		}
		WaitForMultipleObjects(nthreads,handles,TRUE,INFINITE);
		for(i=0;i<nthreads;i++)
		{
			CloseHandle(handles[i]);
		}
		return sum;
	}
	else
		return OLD(n,x,y);
}
#endif


double lmod(dimen n,vector a)
{
	register double back;
	back=0;
	while(n--)
		back+=fabs(*a++);
	return back;
}
double linfinity(dimen n,vector a)
{
	register double back;
	back=0;
	while(n--)
	{
		back=dmax(back,fabs(*a));a++;
	}
	return back;
}
double linfinityj(dimen n,vector a,dimen jump)
{
	register double back;
	back=0;
	while(n--)
	{
		back=dmax(back,fabs(*a));a+=jump;
	}
	return back;
}
