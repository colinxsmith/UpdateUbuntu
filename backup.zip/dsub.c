/*
	x = y - z for general vectors
*/
#include "ldefns.h"
void dsub(dimen n, vector y, increment incy, vector z, increment incz, vector x, increment incx)
{
	while(n--){
		*x = *y - *z;
		y += incy;
		z += incz;
		x += incx;
		}
}
