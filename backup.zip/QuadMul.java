public class QuadMul	
{
	public void hmul(long n,long n1,long n2,long n3,double[] H,double[] x,double[] y)
	{
		int i,j,ij;
		for(i=0,ij=0;i<n;++i)
		{
			y[i]=0;
			for(j=0;j<=i;++j)
			{
				y[i]+=H[ij]*x[j];
				if(i!=j)y[j]+=H[ij]*x[i];
				ij++;
			}
		}
	}
	public void hmul(long n,long n1,long n2,long n3,double[] H,double[] x,Double[] y1)
	{
		int i,j,ij;
		double []y=new double[(int)n];
		for(i=0,ij=0;i<n;++i)
		{
			y[i]=0;
			for(j=0;j<=i;++j)
			{
				y[i]+=H[ij]*x[j];
				if(i!=j)y[j]+=H[ij]*x[i];
				ij++;
			}
			y1[i]=new Double(y[i]);
		}
	}
}
