#include "baseoptimise.h"
/*
     dqpprt  prints various levels of output for  qpcore
           msg    cumulative result
           ---    -----------------
        <=   0    no output
        ==   1    nothing now (but full output later)
        ==   5    one terse line of output
        >=  10    same as 5 (but full output later)
        >=  15    nothing more if  iter < istart
                  otherwise,  x,  istate  and  kfree
        >=  20    multipliers (printed outside qpprt)
                  the array  ax
        >=  30    diagonals of  t  and  r
        >=  80    debug output
        ==  99    cvec  and  hess  (called from qpdump)
*/
void Base_Optimise::dqpprt(int orthog, integer isdel, integer iter, integer jadd, integer jdel, dimen nactiv, dimen ncolz, dimen nfree, dimen n, dimen nclin, dimen nrowa, dimen Nrowrt, dimen nhess, short_vec istate, short_vec kfree, real alfa, real condh, real condt, real obj, real gfnorm, real ztgnrm, real emax, matrix a, matrix rt, vector x, vector wrk1, vector wrk2)
{

	static char *lstate =(char*)" LUETV";
	static char *hdrfmt=(char*)"\n\n  ITN JDEL  JADD       STEP NHESS   OBJECTIVE NCOLZ %s NORM ZTG   COND T COND ZHZ  HESS MOD";
	static char *hdrfmt2=(char*)"%5ld%5ld%c%5ld%c%10.2lg%6ld%12.4lg%6ld%11.2lg%10.2lg%9.1lg%9.1lg%10.2lg";

	char ladd[1], ldel[1];
	integer k, laddi, ldeli;
	--x;
	--kfree;
	--istate;
	
	if (msg < 5) return;
	ldeli = 0;
	laddi = 0;
	if (jdel > 0) ldeli = isdel;
	if (jdel < 0){
		ldeli = 5;
		jdel = -jdel;
		}
	if (jadd > 0) laddi = istate[jadd];
	*ldel = lstate[ldeli];
	*ladd = lstate[laddi];
	if (msg < 15) {
		/*print heading (possibly) and terse line*/
		if(iter == 0 && jdel == 0)
			lm_wmsg(hdrfmt,(orthog?"NORM GFREE":"  NORM QTG"));
			lm_wmsg(hdrfmt2, CL(iter), CL(jdel), *ldel, CL(jadd),
				*ladd, alfa, CL(nhess), obj,
				CL(ncolz), gfnorm, ztgnrm, condt, condh, emax);
			return;
			}
	/*print terse line,  x,  istate,  kfree*/
	itrwri("QP", iter);
	lm_wmsg(hdrfmt,(orthog?"NORM GFREE":"  NORM QTG"));
	lm_wmsg(hdrfmt2, CL(iter), CL(jdel), *ldel, CL(jadd),
		*ladd, alfa, CL(nhess), obj, CL(ncolz), gfnorm, ztgnrm, condt, condh, emax);
	lm_mdvwri("\nQP VARIABLES", n, &x[1]);
	lm_mivwri("\nSTATUS OF THE QP BOUND CONSTRAINTS", n, &istate[1]);
	if (nclin > 0) lm_mivwri("\nSTATUS OF THE QP GENERAL CONSTRAINTS",nclin,&istate[n+1]);
	if(nfree > 0) lm_mivwri("\nLIST OF FREE QP VARIABLES",nfree, &kfree[1]);
	/*compute and print  ax.  use  work  to avoid side effects*/
	if (msg < 20) return;
	if (nclin > 0) {
		for (k = 0; k <  (integer)nclin; ++k) wrk2[k] = BITA_ddot(n, a+k, nrowa, &x[1], 1);
		lm_mdvwri("\nVALUES OF QP GENERAL LINEAR CONSTRAINTS",nclin,wrk2);
		}
	/*print all the diagonals of  t  and  r*/
	if (msg < 30) return;
	if (nactiv > 0) {
		dcopy(nactiv,rt+nactiv+ncolz*Nrowrt-1, Nrowrt-1, wrk1,1);
		lm_mdvwri("\nDIAGONALS OF QP WORKING SET FACTOR  T",nactiv, wrk1);
		}
	if(ncolz > 0) {
		lm_wmsg("\nDIAGONALS OF QP PRJ. HESSIAN FACTOR  R");
		lm_gdvwri(ncolz, rt, CI(Nrowrt+1));
		}
}
