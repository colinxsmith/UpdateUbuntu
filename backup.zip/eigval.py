try:
    from java.lang import *
    from jarray import *
    from safejavajy import *
    jython=1
except:
    from safe import *
    jython=0
def eigen(n,M):
    """
    n is the dimension of the problem and M is a square symmetric matrix.
    eigen returns a tuple (eigval,eigvec)
    the order of the eigenvectors in
    eigenvector i is eigvec[j+i*n]

    
    Uses routine eigendecomp in safe optimiser
    eigendecomp(dimen n, matrix S, vector eigval, dimen itmax);
    """
    if jython:
        S=array(M,Double)
        eigval=array([0]*n,Double)
    else:
        S=map(lambda t:t,M)
        eigval=[]
    itmax=3000
    r=eigendecomp(n,S,eigval,itmax)
    if r != 0:
        raise 'Eigenvalues not found properly'
    if jython:
        for k in ['S','eigval']:#Probably inefficient but shows how it can be done
            k=eval(k)
            k=map(lambda t:t,k)
    return (eigval,S)
def printeig(n,eigval,eigvec):
    """
    n is the order of the matrix
    eigval is the vector of size n of eigenvalues
    eigvec contains the n eigenvectors end to end
    """
    
    print '______________________________'
    for i in range(n):
        print 'Eigenvalue %d %12.5f\nEigenvector %d' % (i+1,eigval[i],i+1)
        for j in range(n):
            print '%12.5f' % eigvec[j+i*n]
        print '______________________________'

if __name__=='__main__':
    
    M=[1,0.1,0,
       0.1,2,0,
       0,0,3]
    n=3
    (eigval,eigvec)=eigen(n,M)

    printeig(n,eigval,eigvec)

    """
EIGENVECTORS and EIGENVALUES of M are:
 ______________________________
Eigenvalue 1      3.00000
Eigenvector 1
     0.00000
     0.00000
     1.00000
______________________________
Eigenvalue 2      2.00990
Eigenvector 2
     0.09854
     0.99513
     0.00000
______________________________
Eigenvalue 3      0.99010
Eigenvector 3
     0.99513
    -0.09854
     0.00000
______________________________
    """

