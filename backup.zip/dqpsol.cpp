#include "baseoptimise.h"
extern	char	version_str[];
/*
	dqpsol solves quadratic programming (QP) problems of the form 
	minimize     c'*x  +  1/2 x'*H*X 
	subject to		(  x  ) 
			BL  <=  (     ) <=  BU 
				( A*x ) 

	where ' denotes the transpose of a column vector. 
	The symmetric matrix  H  may be positive-definite, positive 
	semi-definite, or indefinite. 
	n  is the number of variables (dimension of  x). 
	nclin  is the number of general linear constraints (rows of  a). 
	(nclin may be zero.) 

	The matrix   H  is defined by the subroutine  qphess, which 
	must compute the matrix-vector product  H*x  for any vector  x. 
	the vector  c  is entered in the one-dimensional array  cvec. 
	the first  n  components of  bl  and   bu  are lower and upper 
	bounds on the variables.  the next  nclin  components are 
	lower and upper bounds on the general linear constraints. 
	the matrix  a  of coefficients in the general linear constraints 
	is entered as the two-dimensional array a (of dimension 
	nrowa  by  n). if nclin = 0,  a  is not accessed. 
	the vector  x  must contain an initial estimate of the solution, 
	and will contain the computed solution on output. 
*/
short Base_Optimise::dqpsol(short itmax, short msglvl, dimen n, dimen nclin, dimen nctotl, dimen nrowa, dimen nrowh, dimen ncolh, real *bigbnd, real *a, real *bl, real *bu, real *cvec, real *featol, real *hess, int cold, int lp, int orthog, real *x, short_vec istate, short *iter, real *obj, real *clamda, short_vec iw, ulong leniw, vector w, ulong lenw, short ifail)
{

	integer itmx;
	char	*l= (char*)(lp?((lp&2)?"FP":"LP"):"QP");

	//real bigdx;
	integer nfree, ncnln;
	logical unitq;
	real xnorm;// epspt9;
	integer lscale, maxact, minact;
	byte	lcrash;
	//real tolact;
	integer minfxd, inform, mxfree, nactiv, numinf;
	ulong litotl;
	short nerror;
	int	minsum;
	integer mxcolz;
	int	vertex;
	ulong	lwtotl;
	integer lax;

#define NCLIN &nclin_
	integer	nclin_=nclin;
#define NCTOTL &nctotl_
	integer	nctotl_=nctotl;
#define NROWA &nrowa_
	integer	nrowa_=nrowa;
	integer	iter_;
#define NROWH &nrowh_
	integer	nrowh_=nrowh;
#define NCOLH &ncolh_
	integer	ncolh_=ncolh;
	--w;
	--iw;
	--clamda;
	--istate;
	--x;
	--featol;
	--cvec;
	--bu;
	--bl;

	/*IF ITMAX IS NOT POSITIVE ON ENTRY SET IT TO 50*/
	itmx = itmax;
	if (itmx <= 0) itmx = 50;

	/*
	IF THERE IS NO FEASIBLE POINT FOR THE LINEAR CONSTRAINTS AND
	BOUNDS, COMPUTE THE MINIMUM SUM OF INFEASIBILITIES
	IT IS NOT NECESSARY TO START THE QP PHASE AT A VERTEX
	*/
	minsum = (lp&2)?0:1;
	vertex = 0;
	/*
	ANY CHANGE IN X THAT IS GREATER THAN  BIGDX  WILL BE REGARDED
	AS AN INFINITE STEP
	*/
	//bigdx = 1e20;

	/*
	DURING SELECTION OF THE INITIAL WORKING SET (BY CRASH),
	CONSTRAINTS WITH RESIDUALS LESS THAN  TOLACT  WILL BE MADE ACTIVE. 
	*/
	//tolact = .01;
	//epspt9 = pow(lm_eps, 0.9);
/*	parm[0] = *bigbnd;
	parm[1] = bigdx;
	parm[2] = tolact;
	parm[3] = epspt9;*/

	/*
	assign the dimensions of arrays in the parameter list of qpcore
	economies of storage are possible if the minimum number of active
	constraints and the minimum number of fixed variables are known in
	advance.  the expert user should alter  minact  and  minfxd
	accordingly
	if a linear program is being solved and the matrix of general
	constraints is fat,  i.e.,  nclin < n,  a non-zero value is
	known for  minfxd.  note that in this case,  vertex  must be 1
	*/
	minact = 0;
	minfxd = 0;
/*	Vadim Moroz's data showed that this can lead to errors!  Colin 19-7-2000
	if (lp && nclin < n)
	{
		minfxd = n - nclin - 1;
		vertex = 1;
	}*/
	mxfree = n - minfxd;
	maxact = min(n,nclin);
	maxact = max(1,maxact);
	mxcolz = n - (minfxd + minact);
	nq = max(1,mxfree);
	nrowrt = max(mxcolz,maxact);
	ncolrt = max(1,mxfree);
	ncnln = 0;

	/*allocate certain arrays that are not done in  alloc*/
	litotl = 0;
	lax = 1;
	lwtotl = lax + nrowa - 1;
	/*allocate remaining work arrays*/
	dalloc(2, n, nclin, ncnln, nctotl, iw, w, &litotl, &lwtotl);
	/*set the message level for  lpdump, qpdump, chkdat  and  lpcore*/
	msg = 0;
	if (msglvl >= 5) msg = 5;
	if (lp || msglvl >= 15) msg = msglvl;
	/*
	*** the following statement must be executed if  istart   ***
	*** is not set in the calling routine.                    ***
	*/
	istart = 0;
	lcrash = 1;
	if (cold) lcrash = 0;
	/*check input parameters and storage limits*/
	if (msglvl == 99)
		dlpdump(n, nclin, nctotl, nrowa, lcrash, lp, minsum,
		vertex, &istate[1], a, &w[lax], &bl[1], &bu[1],
		&cvec[1], &x[1]);
	if(msglvl == 99)
		dqpdump(n, nrowh, ncolh, &cvec[1], hess, pWRK, pPX);

	nerror = dchkdat(leniw, lenw, litotl, lwtotl, nrowa, n, nclin,
			nctotl, &istate[1], pKACTV, lcrash,
			bigbnd, a, &bl[1], &bu[1], &featol[1], &x[1]);
	*iter = 0;
	if(nerror) {
	if (msglvl > 0)
		lm_wmsg(
" EXIT QPSOL-%6ld ERRORS FOUND IN THE INPUT PARAMETERS.  PROBLEM ABANDONED.",
		CL(nerror));
		return lm_check_fail((short)CS(ifail), CS(9), "QPSOL");
		}

	/*
	no scaling is provided by this version of  dqpsol
	give a fake value for the start of the scale array
	*/
	scldqp = FALSE_;
	lscale = 1;

	/*
	---------------------------------------------------------------------
	call  lpcore  to obtain a feasible point, or solve a linear
	problem
	---------------------------------------------------------------------
	*/
	dlpcore(lp&1, minsum, orthog, &unitq, vertex, &inform,&iter_,
	&itmx, lcrash, n, NCLIN, NCTOTL, NROWA, &nactiv, &nfree, &numinf, 
	    &istate[1], pKACTV, pKFREE, obj, &xnorm, a, &
	    w[lax], &bl[1], &bu[1], &clamda[1], &cvec[1], &featol[1], &x[1], &
	    iw[1], &w[1]);
	*iter = (short)iter_;
	if (lp){
		/*THE PROBLEM WAS AN LP, NOT A QP*/
		if (inform > 2)  inform += 4;
		if (inform == 1)  inform = 6;
		}
	else if (inform == 0){
		/*
		---------------------------------------------------------------------
		call  qpcore  to solve a quadratic problem
		---------------------------------------------------------------------
		*/
		msg = msglvl;
		/*
		*** the following statement must be executed if  istart   ***
		*** is not set in the calling routine.                    ***
		*/
		istart = 0;
		dqpcore(orthog, &unitq, &inform, &iter_,&itmx, n, NCLIN, NCTOTL, 
	    		NROWA, NROWH, NCOLH, &nactiv, &nfree, &istate[1],
	    		pKACTV, pKFREE, obj, &xnorm, a, &w[lax], &bl[1], &bu[1], &clamda[1], &cvec[1], &featol[1], hess, 
	    		&w[lscale], &x[1], &iw[1], &w[1]);
		*iter = (short)iter_;
		}
	else	{
		/*
		trouble in  lpcore
		inform cannot be given the value  2  when finding a feasible
		point, so it is necessary to decrement all the values of  inform
		that are greater than  2
		*/
		if (inform > 2) --inform;
		inform += 5;
		}
	/*print messages if required*/
	if(msglvl > 0){
		switch(inform){
			case 0: lm_wmsg("\nEXIT QPSOL- OPTIMAL %.2s SOLUTION.",l);
				break;
			case 1: wqpexi((char*)"WEAK LOCAL MINIMUM.");
				break;
			case 2: lm_wmsg("\nEXIT dqpsol- %.2s SOLUTION IS UNBOUNDED.", l);
				break;
			case 3: wqpexi((char*)"ZERO MULTIPLIERS.");
				break;
			case 4: wqpexi((char*)"TOO MANY ITERATIONS WITHOUT CHANGING X.");
				break;
			case 5: wqpexi((char*)"TOO MANY ITERATIONS.");
				break;
			case 6: wqpexi((char*)"CANNOT SATISFY THE LINEAR CONSTRAINTS.");
				break;
			case 7: wqpexi((char*)"TOO MANY ITERATIONS WITHOUT CHANGING X IN THE LP PHASE.");
				break;
			case 8: wqpexi((char*)"TOO MANY ITERATIONS DURING THE LP PHASE.");
				break;
			}
		if(numinf == 0) lm_wmsg("\n FINAL %.2s OBJECTIVE VALUE =%20.9lg", l, *obj );
		else lm_wmsg("\n FINAL SUM OF INFEASIBILITIES =%20.9lg", *obj);
		}

	return (short)(inform==0? 0 : lm_check_fail((short)CS(ifail), (short)CS(inform), "QPSOL"));
}
