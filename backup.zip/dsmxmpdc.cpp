#include "ldefns.h"
/*
	This routine creates a temporary Sdecomp which should be removed as soon as possible
*/
int	dsmxmpd_check( dimen n, sym_matrix F, short msglvl, sym_matrix *pSdecomp )
{
	int		c_hi = msglvl>=20, res;
	dimen		nn = ((n*(n+1))>>1);
	short_vec	P;
	dimen		l_u= nn+(n*sizeof(*P)+sizeof(real)/*-1*/)/sizeof(real);
//	dimen		i;
	sym_matrix	S, Sdecomp;

	Sdecomp = new double[ l_u ];
	if(c_hi){
		S = new double [nn];
		dcopyvec(nn, F, S);
		}
	else	S = 0;
	res = _dsmxmpd_check(n, F, Sdecomp, (P=(short_vec)(Sdecomp+nn)), S, msglvl );
/*	for(i = 0;i < n;++i)
		lm_wmsg("%d      %d",i+1,P[i]);
	for(i = 0;i < nn;++i)
		lm_wmsg("%d      %20.10e",i+1,Sdecomp[i]);*/
	if(S) delete[] S;
	if(pSdecomp) *pSdecomp = Sdecomp;
	else delete[] Sdecomp;
	return res;
}
