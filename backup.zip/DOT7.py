#!/bin/env python
#Colin 13-1-2005
#Semi-definite optimisation interior point algorithm
#Dropping and positive variables
from safe import OptSemiGen,vec2symm,DOT,combineS,Amake,vecvec2symmat
snn=lambda x:x*(x+1)/2
def Symmult(n,S,x,Sx):
    """Multiply a symmetric matrix S by a vector x to get Sx.
    S is a list of length n*(n+1)/2 containing the lower triangle of a symmetric
    matrix stored in the order [00,10,11,20,21,22,.......]
    x and Sx are lists of length n
    """
    if len(x)<n:raise 'x is not long enough'
    if len(Sx)<n:raise 'Sx is not long enough'
    if len(S)<n*(n+1)/2:raise 'S is not long enough'
    ij=0
    for i in range(n):
        Sx[i]=0
        for j in range(i+1):
            Sx[i]+=S[ij]*x[j]
            if i!=j:Sx[j]+=S[ij]*x[i]
            ij+=1
def Amake1(n,base,a,b,c):#Now in C++
    """Set up a quadratic constraint which is met when a*x+b=0
    The constraint matrix is:
    
    basei*aj+basej*ai   (B*aj+b*basej)/2
    (B*ai+b*basei)/2     B*b

    Here the last element of basis must be chosen large enough
    to ensure that a false solution is avoided (i.e must not get
    base*x=-B)

    We choose a large number for B  (large is defined by the problem)  
    """
    basis=[i for i in base]
    a2=[i for i in a]
    basis+=[10]
    a2+=[b]
    ij=0
    for i in range(n+1):
        for j in range(i+1):
            c[ij]=0.5*(basis[i]*a2[j]+a2[i]*basis[j])
            ij+=1
n=4
basket=2
cov=[0.082413214985258054, 0.0085237134681903914, 0.089070270882033536, 0.0052971882656530911, -0.010020600571815669, 0.079791663443914862, 0.016249612103159561, -0.012009661280024869, -0.0056633461502720861, 0.092481531373906162]
g=[.01,.02,.03,.04]
#g=[1]*n
slack=n
pm=n
C=[0]*(snn(n+slack+pm+1))
for i in range(len(cov)):C[i]=cov[i]
for i in range(n):C[snn(n+slack+pm+1)-n-slack-pm-1+i]=g[i]

nb=4
m=nb+2+slack+2*pm+1
A=[]
basis=[0]*(n+slack+pm)
a=[1]*n+[0]*slack+[0]*pm
aa=[1]*n+[0]*slack+[0]*pm
ap=[0]*n+[0]*slack+[1]*pm
aap=[0]*n+[0]*slack+[1]*pm

"""Return constraint
for i in range(n):
    Ahere=[0]*(snn(n+1))
    basis[i]=1
    print a
    Ahere=Amake(n,a,g,.0796)
    dot=sum([a[j]*basis[j] for j in range(n)])
    a=[a[j]-dot*basis[j] for j in range(n)]
    basis[i]=0
    A+=Ahere
"""

for i in range(nb):
    Ahere=[0]*(snn(n+1+slack+pm))
    basis[i]=1
    print a
    Amake(n+slack+pm,a,aa,-1,Ahere,1e5)
    dot=sum([a[j]*basis[j] for j in range(n+slack+pm)])
    a=[a[j]-dot*basis[j] for j in range(n+slack+pm)]
    basis[i]=0
    A+=Ahere
Ahere=[0]*(snn(n+1+slack+pm))
for i in range(nb):
    Ahere[snn(n+slack+pm)+n+slack+i]=.5
Ahere[-1]=-basket
A+=Ahere
Ahere=[0]*(snn(n+1+slack+pm))
for i in range(nb):
    Ahere[snn(n+slack+i)+n+slack+i]=1
Ahere[-1]=-(basket)
A+=Ahere
for i in range(slack):
    Ahere=[0]*(snn(n+1+slack+pm))
    Ahere[snn(n+slack+pm)+i]=1
    Ahere[snn(n+i)+n+i]=-1
    A+=Ahere
for i in range(pm):
    Ahere=[0]*(snn(n+1+slack+pm))
    Ahere[snn(n+slack+pm)+n+slack+i]=-.5
    Ahere[snn(n+i+slack)+n+i+slack]=1
    A+=Ahere
    Ahere=[0]*(snn(n+1+slack+pm))
    Ahere[snn(n+i+slack)+i]=-1
    Ahere[snn(n+slack+pm)+i]=1
    A+=Ahere

A2=[0]*(snn(n+slack+pm+1)-1)+[1]
b=[0]*(nb)+[0,0]+[0]*(slack+2*pm)+[1]
A+=A2

X=[0]*(snn(n+slack+pm+1))
print OptSemiGen(n+slack+pm+1,m,X,C,A,b,200)
print 'Variance (matrix)',DOT(n,X,cov)
x=X[snn(n+slack+pm+1)-n-slack-pm-1:snn(n+slack+pm+1)-slack-pm-1]
implied=[0]*n
Symmult(n,cov,x,implied)
print 'Variance (vector)',sum([x[i]*implied[i] for i in range(n)])
print 'Return ',sum([x[i]*g[i] for i in range(n)])
print 'Utility ',DOT(n,X,cov)+2*sum([x[i]*g[i] for i in range(n)])

print x,sum([x[i]*aa[i] for i in range(n)])
XX=[0]*(snn(n+slack+pm+1))
vecvec2symmat(n+slack+pm+1,X[snn(n+slack+pm+1)-n-slack-pm-1:snn(n+slack+pm+1)],X[snn(n+slack+pm+1)-n-slack-pm-1:snn(n+slack+pm+1)],XX)
diff=[XX[i]-X[i] for i in range(len(X))]
print diff,sum(diff)
I=[0]*(snn(n+slack+pm+1))
for i in range(n+slack+pm+1):I[i*(i+3)/2]=1
print DOT(n+slack+pm+1,I,X),DOT(n+slack+pm+1,I,XX)

