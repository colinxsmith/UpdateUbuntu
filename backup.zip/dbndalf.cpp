#include "baseoptimise.h"
/*
	dbndalf finds a step  alfa  such that the point  x + alfa*p
	reaches one of the linear constraints (including bounds).
	Two possible steps are defined as follows...
	alfa1	is the maximum step that can be taken without violating
		one of the linear constraints that is currently satisfied.
	alfa2	reaches a linear constraint that is currently violated.
		usually this will be the furthest such constraint along  p,
		but if  firstv = 1 it will be the first one along  p.
		this is used only by dlpcore when the problem has been
		determined to be infeasible, and we are now minimizing the
		sum of infeasibilities. (alfa2 is not defined if numinf==0)

	alfa will usually be the minimum of  alfa1  and  alfa2.

	alfa could be negative (since we allow inactive constraints
	to be violated by as much as  featol).  in such cases, a
	third possible step is computed, to find the nearest satisfied
	constraint (perturbed by  featol) along the direction  - p.
	alfa  will be reset to this step if it is shorter.  this is the
	only case for which the final step  alfa  does not move  x
	exactly onto a constraint (the one denoted by  jadd).
	constraints in the working set are ignored  (istate(j) ge 1).

	jadd	denotes which linear constraint is reached.
	hitlow	indicates whether it is the lower or upper bound that
		has restricted  alfa.

	values of istate(j)....
		-2         -1         0           1           2          3
	    a*x < bl   a*x > bu   a*x free   a*x == bl   a*x == bu   bl == bu

	the values -2 and -1 do not occur once lpcore finds a feasible point.
*/
short Base_Optimise::dbndalf(int firstv, int *hitlow, short_vec istate, integer *jadd, dimen n, dimen nctotl, dimen numinf, real *alfa, real *palfa, real *atphit, real *bigalf, real *bigbnd, real *pnorm, real *anorm, real *ap, real *ax, real *bl, real *bu, real *featol, real *p, real *x)
{
#define FMT2 \
"\n//BNDALF//  NEGATIVE STEP.\n//BNDALF//           ALFA          PALFA\n//BNDALF//%15.5lg%15.5lg"
	short	inform;

	real d__1;


	integer jadd1;
	real alfa1, alfa2;
	integer jadd2;
	int	hlow1, hlow2, lastv;
	dimen	i, j;
	real palfa1, palfa2, apmax1, apmax2;
	integer jsave1, jsave2;
	real epspt9;
	integer js;
	real absatp;
	real rownrm, atp, res, atx, atp1, atp2;
	--x;
	--p;
	--featol;
	--bu;
	--bl;
	--ax;
	--ap;
	--anorm;
	--istate;

	epspt9 = parm[3];
	inform = 0;

	/*
	FIRST PASS -- FIND STEPS TO PERTURBED CONSTRAINTS, SO THAT
	PALFA1  WILL BE SLIGHTLY LARGER THAN THE TRUE STEP, AND
	PALFA2  WILL BE SLIGHTLY SMALLER THAN IT SHOULD BE.  IN DEGENERATE 
	CASES, THIS STRATEGY GIVES US SOME FREEDOM IN THE SECOND PASS.
	THE GENERAL IDEA FOLLOWS THAT DESCRIBED BY P.M.J. HARRIS, P.21 OF 
	MATHEMATICAL PROGRAMMING 5, 1 (1973), 1--28.
	*/
	dbdpert(firstv, 0, bigalf, bigbnd, pnorm, &jadd1, &jadd2, &palfa1, &
		palfa2, &istate[1], n, nctotl, &anorm[1], &ap[1], &
		ax[1], &bl[1], &bu[1], &featol[1], &p[1], &x[1]);
	jsave1 = jadd1;
	jsave2 = jadd2;

	/*
	SECOND PASS -- RECOMPUTE STEP-LENGTHS WITHOUT PERTURBATION
	AMONGST CONSTRAINTS THAT ARE CLOSE TO THE PERTURBED STEPS
	CHOOSE THE ONE (OF EACH TYPE) THAT MAKES THE LARGEST ANGLE
	WITH THE SEARCH DIRECTION
	*/
	if (msg == 99) lm_wmsg(
"BNDALF ENTERED\n    J  JS         FEATOL         AX             AP     JADD1        ALFA1     JADD2        ALFA2");
	alfa1 = *bigalf;
	alfa2 = 0.0;
	if (firstv) alfa2 = *bigalf;
	apmax1 = 0.0;
	apmax2 = 0.0;
	atp1 = 0.0;
	atp2 = 0.0;
	hlow1 = FALSE_;
	hlow2 = FALSE_;
	lastv = !firstv;
	for (j = 1; j <= nctotl; ++j) {
		js = istate[j];
		if (js > 0) continue;
		if (j > n) {
			/*GENERAL LINEAR CONSTRAINT. */
			i = j - n;
			atx = ax[i];
			atp = ap[i];
/*			lm_wmsg((char*)"atx %e  atp %e  istate[%d]=%d",atx,atp,j,js); */
			rownrm = anorm[i] + 1.0;
			}
		else	{
			/*BOUND CONSTRAINT. */
			atx = x[j];
			atp = p[j];
			rownrm = 1.0;
			}
		if (fabs(atp) <= epspt9 * rownrm * *pnorm) res = -1.0;
		else if (atp > lm_eps) {
			/*ATX IS INCREASING. */
			/*TEST FOR SMALLER ALFA1 IF UPPER BOUND IS SATISFIED. */
			if (js != -1) {
				if(bu[j] < *bigbnd) {
					res = bu[j] - atx;
					if(((integer) j == jsave1 || palfa1 * atp >= res )
						&& apmax1 * rownrm * *pnorm < atp) {
						apmax1 = atp / (rownrm * *pnorm);
						alfa1 = res / atp;
						jadd1 = j;
						atp1 = atp;
						hlow1 = FALSE_;
						}
					}
				/*TEST FOR BIGGER ALFA2 IF LOWER BOUND IS VIOLATED. */
				if (js == -2) {
					res = bl[j] - atx;
					if((firstv || (integer) j == jsave2 || palfa2 * atp <= res)
						&& (lastv || (integer) j == jsave2 || palfa2 * atp >= res)
						&& (apmax2 * rownrm * *pnorm < atp)){
						apmax2 = atp / (rownrm * *pnorm);
						if (atp >= 1.0) alfa2 = res / atp;
						else if(res < *bigalf * atp) alfa2 = res / atp;
						else alfa2 = *bigalf;
						jadd2 = j;
						atp2 = atp;
						hlow2 = TRUE_;
						}
					}
				}
			}
		else if (js != -2) {
			/*ATX IS DECREASING. */
			/*TEST FOR SMALLER ALFA1 IF LOWER BOUND IS SATISFIED*/
			absatp = -atp;
			if (bl[j] > -(*bigbnd)) {
				res = atx - bl[j];
				if(((integer) j == jsave1 || palfa1 * absatp >= res)
					&& (apmax1 * rownrm * *pnorm < absatp)){
					apmax1 = absatp / (rownrm * *pnorm);
					alfa1 = res / absatp;
					jadd1 = j;
					atp1 = atp;
					hlow1 = TRUE_;
					}
				}
			/*TEST FOR BIGGER ALFA2 IF UPPER BOUND IS VIOLATED*/
			if (js == -1) {
				res = atx - bu[j];
				if((firstv ||(integer)  j == jsave2 || palfa2 * absatp <= res)
					&& (lastv ||(integer)  j == jsave2 || palfa2 * absatp >= res)
					&& (apmax2 * rownrm * *pnorm < absatp)){
					apmax2 = absatp / (rownrm * *pnorm);
					if (absatp >= 1.0) alfa2 = res / absatp;
					else if (res < *bigalf * absatp) alfa2 = res / absatp;
					else alfa2 = *bigalf;
					jadd2 = j;
					atp2 = atp;
					hlow2 = FALSE_;
					}
				}
		}
		if(msg == 99)
			lm_wmsg((char*)"%5ld%4ld%15.5lg%15.5lg%15.5lg%6ld%17.7lg%6ld%17.7lg",
				CL(j), CL(js), featol[j], atx, atp, CL(jadd1), alfa1,
				CL(jadd2), alfa2);
	}

	/*IF FEASIBLE, ONLY ALFA1 WILL HAVE BEEN SET. */
	*alfa = alfa1;
	*palfa = palfa1;
	*jadd = jadd1;
	*atphit = atp1;
	*hitlow = hlow1;
	if(numinf!=0 && jadd2!=0 && (alfa2 < alfa1 || (alfa2 <= palfa1 && apmax2 >= apmax1))){
		/*
		INFEASIBLE -- SEE IF WE STEP TO THE FURTHEST VIOLATED CONSTRAINT. 
		BE PREPARED TO STEP IN THE RANGE  (ALFA1, PALFA1)  IF THE VIOLATED 
		CONSTRAINT HAS A LARGER VALUE OF  AP
		*/
		*alfa = alfa2;
		*jadd = jadd2;
		*atphit = atp2;
		*hitlow = hlow2;
		}
	else if(*alfa < -lm_eps ) {
		/*
		NEGATIVE STEP
		JADD  WILL RETAIN ITS CURRENT VALUE, BUT WE MAY SHORTEN  ALFA
		TO BE  - PALFA1,  THE STEP TO THE NEAREST PERTURBED SATISFIED
		CONSTRAINT ALONG THE DIRECTION -P
		*/
		dbdpert(firstv, 1, bigalf, bigbnd, pnorm, &jadd1, &jadd2, &palfa1, &
			palfa2, &istate[1], n, nctotl, &anorm[1], &ap[1], &
			ax[1], &bl[1], &bu[1], &featol[1], &p[1], &x[1]);
		if (msg >= 80) lm_wmsg( FMT2, *alfa, palfa1);
		d__1 = fabs(*alfa);
		*alfa = -min(d__1,palfa1);
		}

	/*
	TEST FOR UNDEFINED OR INFINITE STEP.  THIS SHOULD MEAN THAT THE
	SOLUTION IS UNBOUNDED
	*/
	if (*jadd == 0){
		*alfa = *bigalf;
		*palfa = *bigalf;
		inform = 2;
		}
	if(*alfa >= *bigalf) inform = 3;
	if (msg >= 80 && inform > 0) lm_wmsg(
"\n//BNDALF//  UNBOUNDED STEP.\n//BNDALF//  JADD          ALFA\n//BNDALF//  %4ld%15.5lg",
		CL(*jadd), *alfa);
	return inform;
}
