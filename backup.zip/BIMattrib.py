#!/bin/env python
from Opt import *
"""
basic_factor_global_local_attribution(
				n,		Number of stocks
				nl,		Number of factors (= number of local factors)
				ng,		Number of global factors
				FL,		Factor loadings
				w,		Portfolio weights
				Y,		Exposures of local to global factors (rectangular length nl*ng)
				G,		Global factor covariances (lower triangle length ng*(ng+1)/2)
				S,		Scaling matrix (non-symetric length nl*nl)
				FC,		Factor covariances
				SV,		Specific variances
				XMCTR,	Asset level factor mctr (output)
				FMCTR,	Factor level factor mctr (output)
				SMCTR,	Asset level non-factor mctr (output)
				IsFVar,	Isolated Factor variance (output)
				IsXVar,	Isolated Asset variance (output)
				IsFVarpg,	Isolated Global factor variance (output)
				GFX,	Isolated Global factor exposures (output)
				FMCTRpg,Factor level pure global factor mctr (output)
				FX,		Factor exposures (output)
				facrisk	factor risk (output)
				print	log output set to [] for nothing
				FCgl	global FC is returned if FCgl!=[] and G!=[] S!=[] Y!=[]
)
This expects either 1) FC=[] and S,G and Y given OR 2) FC to be given and S=[], G=[] and Y=[]
but NOT both 1) and 2)
In case 1) the outputs FMCTR and XFMCTR are for attributation of global factor variance.
In case 2) the outputs FMCTR and XFMCTR are for attribution of total factor variance.
If XMCTR=[] then no asset level factor attribution is performed.
If FMCTR=[] then no factor level factor attribution is performed.
If SV=[] and SMCTR=[] then no Asset level non-factor attribution is performed.

IsVar outputs are isolated asset or factor values. 
IsXVar gives the diagonal elements of the asset covariance matrix
IsFVar gives the diagonal elements of the factor covariance matrix, 
pg refers to the pure global covariance matrix G

Typically this would be called twice; once with FC=[] and S,G and Y given and then with FC given
and S=[], G=[] and Y=[].

For risks total factor squared=global squared + local squared



"""
def localglobal(n,nl,ng,FL,FC,SV,Y,G,S):
    """To calculate only Asset level terms set FMCTR and FMCTRg both to []
    and to omit non-factor terms set SMCTR to [].
    Similarly to omit asset level factor terms set XMCTR and XMCTRg to [].
    """
    XMCTR=[0]*n     #Asset level total factor mctr
    SMCTR=[0]*n     #Aseet level non-factor mctr
    FMCTR=[0]*nl    #Factor level total factor mctr
    XMCTRg=[0]*n    #Asset level global factor mctr
    FMCTRg=[0]*nl   #Factor level global factor mctr
    FMCTRpg=[0]*ng   #Factor level pure global factor mctr
    GFX=[0]*ng
    FX=[0]*nl
    facrisk=[0]
    facriskg=[0]
    FCgl=[]#[0]*(nl*(nl+1)/2) we don't need this here anymore
    IsFVar=[0]*nl
    IsXVar=[0]*n
    IsFVarg=[0]*nl
    IsFVarpg=[0]*ng
    IsXVarg=[0]*n
    IsXVarga=[0]*(n*ng)
    if jython:
        XMCTR=array(XMCTR,Double)
        FMCTR=array(FMCTR,Double)
        SMCTR=array(SMCTR,Double)
        IsFVar=array(IsFVar,Double)
        IsXVar=array(IsXVar,Double)
        FX=array(FX,Double)
        facrisk=array(facrisk,Double)
        facriskg=array(facriskg,Double)
    basic_factor_global_local_attribution(n,nl,ng,FL,w,[],[],[],[],FC,SV,XMCTR,FMCTR,SMCTR,IsFVar,IsXVar,[],[],[],[],FX,facrisk,1,[])
    if jython:
        XMCTR=[i for i in XMCTR]
        FMCTR=[i for i in FMCTR]
        SMCTR=[i for i in SMCTR]
        IsFVar=[i for i in IsFVar]
        IsXVar=[i for i in IsXVar]
        FX=[i for i in FX]


    if jython:
        XMCTRg=array(XMCTRg,Double)
        FMCTRg=array(FMCTRg,Double)
        FMCTRpg=array(FMCTRpg,Double)
        GFX=array(GFX,Double)
        FX=array(FX,Double)
        FCgl=array(FCgl,Double)
        IsFVarg=array(IsFVarg,Double)
        IsFVarpg=array(IsFVarpg,Double)
        IsXVarg=array(IsXVarg,Double)
        IsXVarga=array(IsXVarga,Double)
        facrisk=array(facrisk,Double)
        facriskg=array(facriskg,Double)
    basic_factor_global_local_attribution(n,nl,ng,FL,w,Y,G,S,[],[],[],XMCTRg,FMCTRg,[],IsFVarg,IsXVarg,IsFVarpg,GFX,FMCTRpg,IsXVarga,FX,facriskg,1,FCgl)
    #basic_factor_global_local_attribution1(n,nl,ng,FL,w,Y,G,S,[],XMCTRg,FMCTRg,IsFVarg,IsXVarg,IsFVarpg,GFX,FMCTRpg,IsXVarga,FX,facriskg,1)
    if jython:
        FCgl=[i for i in FCgl]
        XMCTRg=[i for i in XMCTRg]
        FMCTRg=[i for i in FMCTRg]
        FMCTRpg=[i for i in FMCTRpg]
        IsFVarg=[i for i in IsFVarg]
        IsFVarpg=[i for i in IsFVarpg]
        IsXVarg=[i for i in IsXVarg]
        IsXVarga=[i for i in IsXVarga]
        FX=[i for i in FX]
        GFX=[i for i in GFX]

    facrisk=facrisk[0]
    facriskg=facriskg[0]

#   Get local parts from total factor squared = local factor squared + global factor squared    
    facriskl=pow(sqr(facrisk)-sqr(facriskg),0.5)
    
    XMCTRl=[(facrisk*XMCTR[i]-facriskg*XMCTRg[i])/facriskl for i in range(len(XMCTR))]
    FMCTRl=[(facrisk*FMCTR[i]-facriskg*FMCTRg[i])/facriskl for i in range(len(FMCTR))]
    IsFVarl=[IsFVar[i]-IsFVarg[i] for i in range(len(IsFVar))]
    IsXVarl=[IsXVar[i]-IsXVarg[i] for i in range(len(IsXVar))]
    return(XMCTR,FMCTR,SMCTR,XMCTRg,FMCTRg,XMCTRl,FMCTRl,FX,FCgl,IsFVar,IsFVarg,IsFVarl,IsXVar,IsXVarg,IsXVarl,IsFVarpg,GFX,FMCTRpg,IsXVarga)
def getnames(fl,dic,sep='|'):
    """Read just the first column to get the factor names"""
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        dic[line.split(sep)[0]]=1
def getsym(n,fl,dic,sep='|'):
    """Read symmetric data from file fl"""
    M=[0]*(n*(n+1)/2)
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        data=line.split(sep)
        try:
            i=dic[data[0].strip()]-1
            j=dic[data[1].strip()]-1
            I=max(i,j)
            J=min(i,j)
            M[I*(I+1)/2+J]=float(data[2].strip())
        except:pass
    return M
def getnonsym(nl,ng,fl,dic1,dic2,sep='|'):
    """Read non-symmetric data from file fl"""
    M=[0]*(nl*ng)
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        data=line.split(sep)
        try:
            i=dic1[data[0].strip()]-1
            j=dic2[data[1].strip()]-1
            M[i+j*nl]=float(data[2].strip())
        except:pass
    return M
def setorder(dic,names):
    i=1
    for name in names:
        dic[name]=i
        i+=1
"""
Need proper data to go in here
"""
front='.'
model=front+'/'+'model1.csv'
Yfile=front+'/'+'BIMe_203_GLFac_Exposures.20041101'
Gfile=front+'/'+'BIMe_203_GLCovar.20041101'
Sfile=front+'/'+'BIMe_203_GLScaling.20041101'
o=Opt()
print version()
o.getmodel(model,[])

"""
Need to choose the names of the stocks somehow,
here I use all of the stocks in the model
"""
localnames=[i for i in o.mnames]

o.getmodel(model,localnames)

gfnames={}   
getnames(open(Gfile),gfnames)
lnames={}
getnames(open(Sfile),lnames)
globalnames=gfnames.keys()

#"""
#Here's a fix to make some factor names compatible
for i in range(len(o.fnames)):
    o.fnames[i]=o.fnames[i].replace('USE3','USE3L')
#"""

badnames=[i for i in o.fnames if not i in lnames.keys()]
if badnames!=[]:print 'These factor names are not compatible'
for i in badnames:
    print i

nl=len(o.fnames)
ng=len(globalnames)
localorder={}
globalorder={}

setorder(localorder,o.fnames)
setorder(globalorder,globalnames)

G=getsym(ng,open(Gfile),globalorder)
S=getnonsym(nl,nl,open(Sfile),localorder,localorder)
Y=getnonsym(nl,ng,open(Yfile),localorder,globalorder)

w=[1.0/o.n]*(o.n)   #Portfolio weights



(XMCTR,FMCTR,SMCTR,XMCTRg,FMCTRg,XMCTRl,FMCTRl,FX,FCgl,IsFVar,IsFVarg,IsFVarl,IsXVar,IsXVarg,IsXVarl,IsFVarpg,GFX,FMCTRpg,IsXVarga)=localglobal(o.n,nl,ng,o.FL,o.FC,o.SV,Y,G,S)

print o.n,nl,ng

facriskpg=0
print '%20s %20s %20s %20s'%('Global Factor','Pure Global factor MCTR','Pure Global Exposure','Total Pure Global factor CTR')
for i in range(ng):
    print '%20s %20.8e %20.8e %20.8e'%(globalnames[i],FMCTRpg[i],GFX[i],GFX[i]*FMCTRpg[i])
    facriskpg+=FMCTRpg[i]*GFX[i]

print 'total factor global risk %-.8e, variance %-.8e'%(facriskpg,sqr(facriskpg))  
facrisk=0
facriskg=0
facriskl=0
print '%20s %20s %20s %20s %20s %20s %20s %20s '%('Factor','Total factor MCTR','Global factor MCTR','Local factor MCTR','Exposure','Total factor CTR','Global factor CTR','Local factor CTR')
for i in range(nl):
    print '%20s %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e'%(o.fnames[i],FMCTR[i],FMCTRg[i],FMCTRl[i],FX[i],FX[i]*FMCTR[i],FX[i]*FMCTRg[i],FX[i]*FMCTRl[i])
    facrisk+=FMCTR[i]*FX[i]
    facriskg+=FMCTRg[i]*FX[i]
    facriskl+=FMCTRl[i]*FX[i]

print 'Checks'
print facrisk,facriskg,facriskl
print sqr(facrisk),sqr(facriskg),sqr(facriskl),(sqr(facriskg)+sqr(facriskl))

facrisk=0
facriskg=0
facriskl=0
print '%20s %20s %20s %20s %20s %20s %20s %20s '%('Asset','Total factor MCTR','Global factor MCTR','Local factor MCTR','Weight','Total factor CTR','Global factor CTR','Local factor CTR')
for i in range(o.n):
    print '%20s %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e'%(o.names[i],XMCTR[i],XMCTRg[i],XMCTRl[i],w[i],w[i]*XMCTR[i],w[i]*XMCTRg[i],w[i]*XMCTRl[i])
    facrisk+=XMCTR[i]*w[i]
    facriskg+=XMCTRg[i]*w[i]
    facriskl+=XMCTRl[i]*w[i]

print 'Checks'
print facrisk,facriskg,facriskl
print sqr(facrisk),sqr(facriskg),sqr(facriskl),(sqr(facriskg)+sqr(facriskl))

specrisk=0
print '%20s %20s %20s %20s'%('Asset','Non-factor MCTR','Non-factor CTR','weight')
for i in range(o.n):
    print '%20s %20.8e %20.8e %20.8e'%(o.names[i],SMCTR[i],w[i]*SMCTR[i],w[i])
    specrisk+=SMCTR[i]*w[i]
print specrisk
print sqr(specrisk)


#Phuc type reports. Here we find the total, global and local variance for each factor
totalg=0
print '%20s %20s '%('Factor','pure global part')
for i in range(ng):
    print '%20s %20.8e'%(globalnames[i],IsFVarpg[i])
    totalg+=IsFVarpg[i]
facvarg=sqr(facriskg)
interact=facvarg-totalg
print 'Total Global Variance \t\t\t\t%20.8e'%facvarg
print 'Total Variance for each global factor isolated \t%20.8e'%totalg
print 'Variance due to global factor interaction \t%20.8e'%interact
total=0
totalg=0
totall=0
print '%20s %20s %20s %20s'%('Factor','variance','global part','local part')
for i in range(nl):
    print '%20s %20.8e %20.8e %20.8e'%(o.fnames[i],IsFVar[i],IsFVarg[i],IsFVarl[i])
    total+=IsFVar[i]
    totalg+=IsFVarg[i]
    totall+=IsFVarl[i]

facvar=sqr(facrisk)
interact=facvar-total
print 'Total Variance \t\t\t\t\t%20.8e'%facvar
print 'Total Variance for each factor isolated \t%20.8e'%total
print 'Variance due to factor interaction \t\t%20.8e'%interact
facvarg=sqr(facriskg)
interact=facvarg-totalg
print 'Total Global Variance \t\t\t\t%20.8e'%facvarg
print 'Total Global Variance for each factor isolated \t%20.8e'%totalg
print 'Global Variance due to factor interaction \t%20.8e'%interact
facvarl=sqr(facriskl)
interact=facvarl-totall
print 'Total Local Variance \t\t\t\t%20.8e'%facvarl
print 'Total Local Variance for each factor isolated \t%20.8e'%totall
print 'Local Variance due to factor interaction \t%20.8e'%interact

total=0
totalg=0
totall=0
print '%20s %20s %20s %20s'%('Asset','variance','global part','local part')
for i in range(o.n):
    print '%20s %20.8e %20.8e %20.8e'%(o.names[i],IsXVar[i],IsXVarg[i],IsXVarl[i])
    total+=IsXVar[i]
    totalg+=IsXVarg[i]
    totall+=IsXVarl[i]

interact=facvar-total
print 'Total Variance \t\t\t\t\t%20.8e'%facvar
print 'Total Variance for each stock isolated \t\t%20.8e'%total
print 'Variance due to stock interaction \t\t%20.8e'%interact
interact=facvarg-totalg
print 'Total Global Variance \t\t\t\t%20.8e'%facvarg
print 'Total Global Variance for each stock isolated \t%20.8e'%totalg
print 'Global Variance due to stock interaction \t%20.8e'%interact
interact=facvarl-totall
print 'Total Local Variance \t\t\t\t%20.8e'%facvarl
print 'Total Local Variance for each stock isolated \t%20.8e'%totall
print 'Local Variance due to stock interaction \t%20.8e'%interact

print 'Breakdown of the global part of variance of each asset over the global factors'
out='%20s '%'Asset'
for i in range(ng):out+='%20s '%globalnames[i]
print out
for i in range(o.n):
    out='%20s '%o.names[i]
    total=0
    for j in range(ng):
        out+='%20.8e '%IsXVarga[j+i*ng]
        total+=IsXVarga[j+i*ng]
    print out
    print 'total %20.8e'%total

print 'Total global factor variance %20.8e'%xCx(ng,G,GFX)
