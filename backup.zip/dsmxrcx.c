/*
	dsmxrcx( undex n, sym_matrix S, undex p, undex q )

	exchanges rows p and q and columns p and q of the symmetric
	matrix S which is of dimension n. The matrix S is stored
	compactly by row. ie element S(i,j) 0<=j<=i<n is held in
	element S[i*(i+1)/2+j]

	R. G. Becker March 1992
*/
#include "ldefns.h"
#define	SWAP(X,Y,T) { T = X; X = Y; Y = T; }
void dsmxrcx(dimen n, sym_matrix S, dimen p, dimen q)
{
	real	*Sp;
	real	*Sq;
	real	t;
	undex	i;
	short	j;
	if(!n || p==q) return;	/*trivial cases*/

	/*ensure p<q*/
	if(++p>++q) SWAP( p, q, i );

	/*swap rows p and q columns 1..p-1*/
	Sp = S+(p*(i=(p-1)))/2;		/*Sp points to S(p,1)*/
	Sq = S+(q*(j=((short) q-1)))/2;		/*Sq points to S(q,1)*/
	dswap( i, Sp, 1, Sq, 1);

	/*swap columns p and q rows q+1 .. n*/
	Sp += i;			/*Sp points to S(p,p)*/
	Sq += j;			/*Sq points to S(q,q)*/
	j = (short)p - (short)q;	/*negative*/
	for(i=q, S=Sq; i<n; i++){
		S += i;			/*S points to S(i+1,q)*/
		SWAP(S[0],S[j],t);
		}

	SWAP( *Sp, *Sq, t );		/*diagonal elements*/

	/*now swap elements (p+i,p) with elements (q,q-i) i=1,..,q-p-1*/
	Sp = Sq-- +j;
	while( --q > p ){
		Sp -= q;
		SWAP(*Sp,*Sq,t);
		Sq--;
		}
}
