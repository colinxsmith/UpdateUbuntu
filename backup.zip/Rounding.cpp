#include "optimise.h"
#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#endif

#define unround 1e60
#define rounderror lm_eps8
#define score_test_first lm_eps
#define round_eps lm_eps8
template <typename XX> void set_repeat(size_t n,XX p,XX*a)
{
	while(n--){*a++ = p;}
}
double small_test(double xx)
{
	return xx - (double)3.0 * ((xx*(double)4.0)/(double)3.0 - xx);
}
bool treestart(class OptParamRound*info,bool passedfromthresh,vector initial,vector minlot,
						vector sizelot,vector roundw,vector thresh=0);
void violation_test(Optimise*Opt,char*mess=0,size_t Nvab=0)
{
#ifdef _DEBUG
	if(mess)Opt->AddLog("%s\n",mess);
	Opt->AddLog("back %d\n",Opt->back);
	size_t i,j;
	if(Nvab==0)Nvab=Opt->n;
	for(i=0;i<Nvab;++i)
		Opt->AddLog("S %d %20.8f %20.8f %20.8f \n",i+1,Opt->lower[i],Opt->x[i],Opt->upper[i]);
	for(i=0;i<Opt->m;++i)
		Opt->AddLog("C %d %20.8f %20.8f %20.8f \n",i+1,Opt->lower[Nvab+i],BITA_ddot(Nvab,Opt->A+i,Opt->m,Opt->x,1),Opt->upper[Nvab+i]);
	for(i=0;i<(Opt->n-Nvab);++i)
	{
		Opt->AddLog("S Fixed weight %d %20.8f\n",Nvab+i+1,Opt->x[Nvab+i]);
		for(j=0;j<Opt->m;++j)
			Opt->AddLog("Fixed part for contraint %d %20.8f\n",j+1,Opt->A[(Nvab+i)*Opt->m+j]);
	}
#endif
}

size_t zeros_in_initial(size_t n,vector initial)
{
	size_t z=0;
	while(n--)
	{
		if(*initial==0)
			z++;
		initial++;
	}
	return z;
}

size_t reset_bad_drop(size_t n,vector w,vector initial,unsigned char* bad)
{
	size_t i,b=0;
	double init;
	for(i=0;i<n;++i,bad++,w++)
	{
		init=initial?initial[i]:0;
		if(*bad&&fabs(*w-init)<=lm_eps8)
		{
			b++;*bad=(unsigned char)0;
		}
	}
	return b;
}
template <typename T> void printorder(size_t n,T*order)
{
	while(n--)
	{
		std::cout << *order++ << "  ";
	}
	std::cout << std::endl;
}

inline bool order_diff(size_t n,size_t*a,size_t*b)
{
	while(n--)
	{
		if(*a++ != *b++) return true;
	}
	return false;
}
inline size_t bad_sum(size_t n,unsigned char*a,unsigned char*b=0)
{
	size_t back=0;
	if(b)
	{
		while(n--)
		{
			back+=(size_t)((bool)(*a++)||(bool)(*b++));
		}
	}
	else
	{
		while(n--)
		{
			back+=(size_t)(*a++);
		}
	}
	return back;
}
inline size_t thresh_check(size_t n,vector w,vector initial,vector L,vector U,vector min_trade,vector min_hold=0,double eps=lm_rooteps)
{
	size_t i,bad;
	bool badi;
	double init;
	for(i=0,bad=0;i<n;++i)
	{
		init=initial?initial[i]:0;
		badi=false;
		if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,min_trade[i],0))) > eps && fabs(fabs(w[i]-init)-min_trade[i])>eps)
		{
			badi=true;
		}
		if(min_hold&&fabs(fabs(w[i])-fabs(round_weight(w[i],0,min_hold[i],0))) > eps && fabs(fabs(w[i])-min_hold[i])>eps)
		{
			badi=true;
		}
		if(w[i]<L[i]-lm_eps8||w[i]>U[i]+lm_eps8)
		{
			badi=true;
		}
		if(badi)bad++;
	}
	return n-bad;
}
inline size_t round_check(size_t n,vector w,vector initial,vector L,vector U,vector minlot,vector sizelot,double eps=lm_rooteps)
{
	size_t i,bad;
	bool badi;
	double init;
	long kk;
	for(i=0,bad=0;i<n;++i)
	{
		init=initial?initial[i]:0;
		badi=false;
		if(fabs(fabs(w[i])-fabs(round_weight(w[i],init,minlot[i],sizelot?sizelot[i]:0))) > eps)
		{
			if(fabs(fabs(w[i]-init)-minlot[i])>eps)
			{
				if(sizelot&&sizelot[i]>lm_eps)
				{
					kk=(long)((fabs(w[i]-init)-minlot[i])/sizelot[i]);
					if(fabs(kk*sizelot[i]+minlot[i]-fabs(w[i]-init))>eps)
					{
						badi=true;
					}
				}
				else if(fabs(w[i]-init)-fabs(minlot[i])<-eps && fabs(w[i]-init)>eps)
					badi=true;
			}
		}
		if(w[i]<L[i]-lm_eps8||w[i]>U[i]+lm_eps8)
		{
			badi=true;
		}
		if(badi)bad++;
	}
	return n-bad;
}
inline void setbadness(size_t n,vector lower,vector upper,unsigned char*dropbadb,unsigned char*dropbadt,vector initial,real equalbounds)
{
	size_t i;
	for(i=0;i<n;++i)
	{
		if(fabs(lower[i]-upper[i])<=equalbounds+lm_eps)
		{
			if(fabs(lower[i])>equalbounds+lm_eps)
				dropbadb[i]=1;
			if(fabs(lower[i]-(initial?initial[i]:0))>equalbounds+lm_eps)
				dropbadt[i]=1;
		}
	}
	for(i=0;i<n;++i)
	{
		if(lower[i]>lm_eps8 || upper[i]<-lm_eps8)
			dropbadb[i]=1;
		if(lower[i]>(initial?initial[i]:0)+lm_eps8 || upper[i]<(initial?initial[i]:0)-lm_eps8)
			dropbadt[i]=1;
	}
}
inline void GradientDropOrder(void *info,vector x,vector grad)
{
//This just gets the gradient of the utility function now it should go into Optimise class sometime.
    Optimise* Opt=(Optimise*)info;
    Opt->qphess_base(Opt->n,1,1,1,Opt->H,x,grad);
    daddvec(Opt->n,grad,Opt->c,grad);
    if(Opt->ModCObjectInfo)
    {
    	vector cc=&(*Opt->buysell)[0];
        Opt->ResetInitial(0);
        Opt->ModDeriv(Opt->n,x,cc,Opt->ModCObjectInfo);
        Opt->ResetInitial();
        daxpyvec(Opt->n,Opt->scale_utility_external_terms,cc,grad);
    }
}
inline void movefixed(size_t n,vector w,size_t* order,vector lower,vector upper,double equalbounds,unsigned char*bad,
					  long plus=-1,long minus=-1)
{
/*	Move any variables with fixed bounds to the top of the list. If plus and minus are both not -1, then 
	make sure that the fixtures corresponding to the lower of them are at the top.	*/
	size_t low,i,ib;
	for(i=0,low=0;(i<n)&&(low<n-i-1);++i)
	{
		while(low<(n-i-1)&&(upper[order[low]]-lower[order[low]]<=equalbounds||bad[order[low]]))//&&((plus<minus && w[order[low]]>lm_eps) || 
			//(minus<plus && w[order[low]]<-lm_eps)))
			low++;
		ib=order[n-i-1];
		if(upper[ib]-lower[ib]<=equalbounds&&!bad[order[low]]&&!bad[ib])
		{
			if((plus<minus && w[ib]>lm_eps) || 
				(minus<plus && w[ib]<-lm_eps) ||(plus==-1&&minus==-1&&fabs(w[ib])>lm_eps))
			{
				std::swap(order[n-i-1],order[low]);
				low++;
			}
		}
	}
}
inline void lplsdropord(size_t n,size_t* order)
{
/*
In python 

	order[n-1]=n/2
	for i in range(n/2):
		order[2*i]=i
		order[2*i+1]=n-1-i

[0, 1, 2, 3, 4, 5, 6, 7, 8, 9] becomes
[0, 9, 1, 8, 2, 7, 3, 6, 4, 5]

and

[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10] becomes
[0, 10, 1, 9, 2, 8, 3, 7, 4, 6, 5]
*/
	size_t i=0,n2=n>>1;
	order[--n]=n2;
	while(i<n2)
	{
		*order++=i++;
		*order++=n--;
	}
}
inline void modifyorder(size_t n,vector w,size_t* order,unsigned char* bad,long nl=-1,long ns=-1,void*info=0,bool add_initial=false)
{
	size_t nn,i,ni,j;
	if(info)
	{
		Optimise* oo=(Optimise*)info;
		std::valarray<size_t> lsord(n);
		lplsdropord(n,&lsord[0]);
		if(oo->lp)//For lp it's better to
		{
			std::valarray<double>neww(n);
			for(i=0;i<n;++i){neww[i]=oo->c[i]*fabs(w[i]);}
			getordereig(n,&neww[0],order,bad);
			Reorder_gen(n,&lsord[0],order,1);
		}
		else
		{
			std::valarray<double>neww(n),grad(n);
			if(add_initial&&oo->initial)daddvec(n,w,oo->initial,w);
			GradientDropOrder(oo,w,&grad[0]);
			if(add_initial&&oo->initial)dsubvec(n,w,oo->initial,w);
			for(i=0;i<n;++i)//gradient near 0, contribution to utility otherwise
			{
				neww[i]=!w[i]?grad[i]:lm_max/**grad[i]*/*w[i];
			}
			getorder(n,&neww[0],order,bad);
			//getordereig(n,&neww[0],order,bad);
			//Reorder_gen(n,&lsord[0],order,1);
/*			for(j=0;j<n;++j)
			{
				i=order[j];
				oo->AddLog("%4d %e %e %e %d\n",i,w[i],grad[i],neww[i],bad[i]);
			}
			oo->AddLog("_________________________________________________________________\n");*/
		}
	}
	else
		getorder(n,w,order,bad);
	if(nl==-1 && ns==-1)return;
/*	If we are doing signed dropping, then the basket must be re-ordered so that variables
	with the same sign occur together in the list of dropable variables.	*/
	
	if(nl==-1)nl=n;
	if(ns==-1)ns=n;
	short sign;
	if(ns<nl)
	{
		sign=1;
		nn=ns;
	}
	else
	{
		sign=-1;
		nn=nl;
	}
//	Find the smallest i such that all of the free signs are included in the first i
	for(i=0,ni=0;i<n;++i)
	{
		if(fabs(w[order[i]])>lm_eps && ni<nn)
		{
			if(w[order[i]]*sign<-lm_eps)++ni;
		}
		else{break;}
	}
//	Swap to put the free signs at the top
	j=i;
	for(i=0;i<ni;i++)
	{
		if(w[order[i]]*sign > lm_eps)
		{
			while(j>0&&(w[order[j-1]]*sign>lm_eps))
			{
				j--;
			}
			if(i!=(j-1))std::swap(order[i],order[j-1]);
		}
	}
//	Count the number set
    size_t ib=0;
    for(i=0;i<nn;++i)
	{
        if(w[order[i]]*sign < -lm_eps){++ib;}
	}
//	Get the order for the top signs correct. (It may be better to use quick sort for this one day.)
    while(ib>1)
	{
		--ib;
        for(i=0;i<ib;++i)
		{
            if(w[order[ib]]*sign < w[order[i]]*sign){std::swap(order[i],order[ib]);}
		}
	}
}
inline void modifyorder2(size_t n,vector w,size_t* order,unsigned char* bad,long nl=-1,long ns=-1,void*info=0,bool add_initial=false)
{
	size_t nn,i,ni,j;
	if(info)
	{
		OptParamRound*OP=(OptParamRound*)info;
//		Optimise* oo=(Optimise*)OP->MoreInfo;
		std::valarray<size_t> lsord(n);
		lplsdropord(n,&lsord[0]);//need to have an lp member
		if(OP->lp)//For lp it's better to
		{
			std::valarray<double>neww(n);
			for(i=0;i<n;++i){neww[i]=OP->c[i]*fabs(w[i]);}
			getordereig(n,&neww[0],order,bad);
			Reorder_gen(n,&lsord[0],order,1);
		}
		else
		{
			vector keepx=OP->x;
			std::valarray<double>neww(n),grad(n);
			if(add_initial&&OP->initial)daddvec(n,w,OP->initial,w);
			OP->grad=&grad[0];
			OP->x=w;
			OP->GradFunc(info);
			OP->x=keepx;
			//GradientDropOrder(oo,w,&grad[0]);
			if(add_initial&&OP->initial)dsubvec(n,w,OP->initial,w);
			double gtest=ddotvec(n,&grad[0],&grad[0]);
			for(i=0;i<n;++i)//gradient near 0, contribution to utility otherwise
			{
				neww[i]=!w[i]?grad[i]:lm_max/**grad[i]*/*w[i];
			}
			getorder(n,&neww[0],order,bad);
			//getordereig(n,&neww[0],order,bad);
			//Reorder_gen(n,&lsord[0],order,1);
/*			for(j=0;j<n;++j)
			{
				i=order[j];
				oo->AddLog("%4d %e %e %e %d\n",i,w[i],grad[i],neww[i],bad[i]);
			}
			oo->AddLog("_________________________________________________________________\n");*/
		}
	}
	else
		getorder(n,w,order,bad);
	if(nl==-1 && ns==-1)return;
/*	If we are doing signed dropping, then the basket must be re-ordered so that variables
	with the same sign occur together in the list of dropable variables.	*/
	
	if(nl==-1)nl=n;
	if(ns==-1)ns=n;
	short sign;
	if(ns<nl)
	{
		sign=1;
		nn=ns;
	}
	else
	{
		sign=-1;
		nn=nl;
	}
//	Find the smallest i such that all of the free signs are included in the first i
	for(i=0,ni=0;i<n;++i)
	{
		if(fabs(w[order[i]])>lm_eps && ni<nn)
		{
			if(w[order[i]]*sign<-lm_eps)++ni;
		}
		else{break;}
	}
//	Swap to put the free signs at the top
	j=i;
	for(i=0;i<ni;i++)
	{
		if(w[order[i]]*sign > lm_eps)
		{
			while(j>0&&(w[order[j-1]]*sign>lm_eps))
			{
				j--;
			}
			if(i!=(j-1))std::swap(order[i],order[j-1]);
		}
	}
//	Count the number set
    size_t ib=0;
    for(i=0;i<nn;++i)
	{
        if(w[order[i]]*sign < -lm_eps){++ib;}
	}
//	Get the order for the top signs correct. (It may be better to use quick sort for this one day.)
    while(ib>1)
	{
		--ib;
        for(i=0;i<ib;++i)
		{
            if(w[order[ib]]*sign < w[order[i]]*sign){std::swap(order[i],order[ib]);}
		}
	}
}
extern "C" short dropopt(void*info,size_t ndrop,vector w,unsigned char*bad,size_t* order1=0)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
/*	
	Try to get a dropping order by optimisation.....
	1) find the optimal portfolio for n
	2) drop the worst n-basket stocks from 1)
	3) optimise all n stocks but with the last n-basket stocks constrained to sum to a around the weight of 
		the smallest non-zero stock in 2) there are many ways to do this
	4) drop the worst n-basket stocks from 3)
	5) play around a bit to try to get a better result than we got in 2) if possible

	When compared to the results from SDP, we find this can hit the true global minimum 
		often when the other dropping methods don't. 

    To use for trades, which can be + or -, the extra constraint would be an absolute type constraint. The method 
	is not so attractive for this kind of case.
*/
	OptParamRound*GET=(OptParamRound*)info;
	short back;bool isLS=false;
	size_t i,j;
	for(i=0;i<GET->n;++i)
	{
		if(((Optimise*)(GET->MoreInfo))->lower[i]<-lm_eps){isLS=true;break;}
	}
	if(isLS)return 0;
	size_t n=GET->n;
	size_t m=GET->m;
	std::valarray<double>ss(n);
	vector startw=&ss[0];
	vector L=((Optimise*)(GET->MoreInfo))->lower;
	vector U=((Optimise*)(GET->MoreInfo))->upper;
	vector AA=((Optimise*)(GET->MoreInfo))->A;
	dcopyvec(n,w,startw);dcopyvec(n,startw,GET->x);
	double utility_start=GET->UtilityFunc(info),utility;
	m++;//set up extra constraint for last n-basket variables
	double lastw=1,endw=0;
	std::valarray<double>lower(n+m),upper(n+m),A(n*m);
	for(i=0;i<m-1;++i)
		dcopy(n,AA+i,m-1,&A[i],m);
	std::valarray<size_t> order(n);
	if(!order1)modifyorder2(n,GET->x,&order[0],bad,-1,-1,info);
	else memcpy(&order[0],order1,n*sizeof(size_t));
	for(i=0;i<n;++i)
	{
		j=order[i];
		if(i<(ndrop-1))
			A[m-1+j*m]=0;
		else
			A[m-1+j*m]=1;
	}
	dcopyvec(n,L,&lower[0]);
	dcopyvec(n,U,&upper[0]);
	dcopyvec(m-1,L+n,&lower[n]);
	dcopyvec(m-1,U+n,&upper[n]);
	lower[n+m-1]=0;
	((Optimise*)(GET->MoreInfo))->lower=&lower[0];
	((Optimise*)(GET->MoreInfo))->upper=&upper[0];
	
	size_t inner=0;//bool difforder;
	while(lastw>lm_eps)
	{
		((Optimise*)(GET->MoreInfo))->m=GET->m=m;
		((Optimise*)(GET->MoreInfo))->A=&A[0];
		upper[n+m-1]=isLS?0:lastw;
		back=GET->OptFunc(info);
		utility=GET->UtilityFunc(info);for(i=ndrop-1,endw=0;i<n;++i){endw+=GET->x[order[i]];}
		modifyorder2(n,GET->x,&order[0],bad,-1,-1,info);
		((Optimise*)(GET->MoreInfo))->A=AA;
		GET->m-=1;
		((Optimise*)(GET->MoreInfo))->m=GET->m;
		for(i=ndrop;i<n;++i)
		{
			j=order[i];
			upper[j]=0;
			lower[j]=0;
		}
		GET->OptFunc(info);
		utility=GET->UtilityFunc(info);
		for(i=ndrop;i<n;++i)
		{
			j=order[i];
			upper[j]=U[j];
			lower[j]=L[j];
		}
		if(back==6||back==9||(inner>3&&(utility>=utility_start)))break;
		if(utility<utility_start) 
		{
			dcopyvec(n,GET->x,startw);
			utility_start=utility;
			inner=1;	lastw=fabs(endw)*.5;
		}
		else
		{
			inner++;
			lastw = dmin((lastw),(fabs(endw)))*.5;
		}
		for(i=0;i<n;++i)
		{
			j=order[i];
			if(i<(ndrop-1))
				A[m-1+j*m]=0;
			else
				A[m-1+j*m]=1;
		}
	}
	((Optimise*)(GET->MoreInfo))->A=AA;
	((Optimise*)(GET->MoreInfo))->lower=L;
	((Optimise*)(GET->MoreInfo))->upper=U;
	if(utility>=utility_start||back==6)
	{
		dcopyvec(n,startw,w);back=0;
	}
	else
	{
		if(GET->x!=w)dcopyvec(n,GET->x,w);
	}
	return back;
}
KeepBest::KeepBest(size_t n,short back,size_t nround,double utility,size_t stage)
{
	this->back=back;
	this->nround=nround;
	this->utility=utility;
	this->n=n;
	this->stage=stage;
	w=new double[n];
	oldw=new double[n];
	first=new double[n];
	stuck=0;
	printstream=0;
}
KeepBest::~KeepBest()
{
	delete [] w;
	delete [] oldw;
	delete [] first;
}
void KeepBest::Setw(vector w,short back,size_t nround,double utility,size_t stage)
{
	dcopyvec(n,w,this->w);
	this->back=back;
	this->utility=utility;
	this->nround=nround;
	this->stage=stage;
}
void KeepBest::Message()
{
	if(printstream)
	{
		char mess[100];
		sprintf(mess,"code %d, utility %-.16e, number rounded %d\n",back,utility,nround);
		*printstream<<mess;
	}
}
void RoundOrder(size_t n,vector score,size_t* ovec,unsigned char* dropbad)
{
	getorder(n,score,ovec,dropbad);
}
size_t roundcount(size_t n,vector w,vector initial,vector minl,vector sizl,double *trw,vector naive)
{
	size_t c=0;
	double rw;
	*trw=0;
	while(n--)
	{
		*naive++=rw=round_weight(*w,initial?*initial++:0,*minl++,sizl?*sizl++:0);
		(*trw)+=*w-rw;
		if(fabs(fabs(*w)-fabs(rw))<=rounderror)
			c++;
		w++;
	}
	return c;
}
short RoundInnerOpt(void*info)
{
	OptParamRound*OP=(OptParamRound*)info;
	Optimise*Opt=(Optimise*)OP->MoreInfo;
	vector minholdlot=OP->minholdlot;
	vector mintradelot=OP->mintradelot;
	OP->minholdlot=0;
	OP->mintradelot=0;
	if(minholdlot&&mintradelot)
	{
		std::valarray<double>w(Opt->n);
		Thresh(OP,Opt->initial,mintradelot,&w[0],minholdlot);Opt->back=(OP->back==2?6:OP->back);
		dcopyvec(Opt->n,&w[0],Opt->x);
	}
	else if(minholdlot)
	{
		std::valarray<double>w(Opt->n);
		Thresh(OP,0,minholdlot,&w[0]);Opt->back=(OP->back==2?6:OP->back);
		dcopyvec(Opt->n,&w[0],Opt->x);
	}
	else if(mintradelot)
	{
		std::valarray<double>w(Opt->n);
		Thresh(OP,Opt->initial,mintradelot,&w[0]);Opt->back=(OP->back==2?6:OP->back);
		dcopyvec(Opt->n,&w[0],Opt->x);
	}
	else Opt->AccumOpt(OP->basket,OP->trades);
	{
		Opt->AddLog("back %d\n",Opt->back);//violation_test(Opt);
	}
	if(Opt->back == 0)
	{
		size_t i;
		for(i=0;i<Opt->n;++i)
		{
			if(fabs(Opt->x[i]-Opt->lower[i])<1e-7)
				Opt->x[i]=Opt->lower[i];
			else if(fabs(Opt->x[i]-Opt->upper[i])<1e-7)
				Opt->x[i]=Opt->upper[i];
		}
	}
	OP->minholdlot=minholdlot;
	OP->mintradelot=mintradelot;
	OP->back=Opt->back;
	return Opt->back;
}
extern double BaskUtility(void*info);
void Optimise::Rounding(size_t basket,size_t trades,vector initial,vector minlot,
						vector sizelot,vector roundw,vector minholdlot,vector mintradelot)
{
	if(true)
	{
		OptParamRound Op;
		Op.basket=basket;
		Op.trades=trades;
		Op.lower=lower;
		Op.back=this->back;
		Op.m=m;
		Op.MoreInfo=this;
		Op.n=n;
		Op.OptFunc=RoundInnerOpt;
		Op.upper=upper;
		Op.UtilityFunc=BaskUtility;
		Op.x=x;
		Op.logprint=this->logprint;
		Op.minholdlot=minholdlot;
		Op.mintradelot=mintradelot;
		if(treestart(&Op,false,initial,minlot,sizelot,roundw)){back=0;}
		Op.logprint=0;
	}
	else
	{
		std::valarray<double>Lkeep(n+m),Ukeep(n+m),naive(n);
		class KeepBest KB(n);
		KB.printstream=logprint;
		dcopyvec(n+m,lower,&Lkeep[0]);
		dcopyvec(n+m,upper,&Ukeep[0]);
		bool changed=0;
		size_t i;
		for(i=0;i<n;++i)
		{
			double init=initial?initial[i]:0;
			if(upper[i] < minlot[i]+init) 
			{
				if(init<=upper[i]){upper[i]=dmax(init,lower[i]);changed=1;}
				else{upper[i]=dmax(init-minlot[i],lower[i]);changed=1;}
			}
			if(lower[i] > init-minlot[i]) 
			{
				if(init>=lower[i]){lower[i]=dmin(init,upper[i]);changed=1;}
				else{lower[i]=dmin(init+minlot[i],upper[i]);changed=1;}
			}
		}
		if(changed)
		{
			AddLog("Changed bounds due to high minlot and reoptimise\n");
			this->AccumOpt(basket,trades);
		}
		roundopt(KB,basket,trades,lower,upper,&Lkeep[0],&Ukeep[0],initial,minlot,sizelot,0,&naive[0]);
		dcopyvec(n+m,&Lkeep[0],lower);
		dcopyvec(n+m,&Ukeep[0],upper);
		KB.Message();
		dcopyvec(n,KB.w,roundw);
		double diff,init;
		for(i=0;i<n;++i)
		{
			if(sizelot && (sizelot[i]>lm_eps))
			{
				init=initial?initial[i]:0;
				diff=digitisei(KB.w[i],init,minlot[i],sizelot[i]) -
					digitisei(KB.first[i],init,minlot[i],sizelot[i]);
				if(fabs(diff) > 3) 
				{
					AddLog("Stock %d moved more than 3 lots(%f)\n",i+1,diff);
				}
			}
		}
		if(this->back==25)this->back=0;
	}
}
void Optimise::Thresh(size_t basket,size_t trades,vector initial,vector minlot,
						vector roundw)
{
	std::valarray<double>Lkeep(n+m),Ukeep(n+m),naive(n);
	class KeepBest KB(n);
	KB.printstream=logprint;
	dcopyvec(n+m,lower,&Lkeep[0]);
	dcopyvec(n+m,upper,&Ukeep[0]);
	bool changed=0;
	size_t i;
	short back=0;
	for(i=0;i<n;++i)
	{
		double init=initial?initial[i]:0;
		if(upper[i] < minlot[i]+init) 
		{
			if(init<=upper[i]){upper[i]=dmin(upper[i],dmax(init,lower[i]));changed=1;}
			else{upper[i]=dmin(upper[i],dmax(init-minlot[i],lower[i]));changed=1;}
		}
		if(lower[i] > init-minlot[i]) 
		{
			if(init>=lower[i]){lower[i]=dmax(lower[i],dmin(init,upper[i]));changed=1;}
			else{lower[i]=dmax(lower[i],dmin(init+minlot[i],upper[i]));changed=1;}
		}
	}
	if(changed)
	{
		AddLog("Changed bounds due to high threshold and reoptimise\n");
		this->AccumOpt(basket,trades);
		back=this->back;
	}
	if(back<2)
		roundopt(KB,basket,trades,lower,upper,&Lkeep[0],&Ukeep[0],initial,minlot,0,0,&naive[0]);
	dcopyvec(n+m,&Lkeep[0],lower);
	dcopyvec(n+m,&Ukeep[0],upper);
	KB.Message();
	dcopyvec(n,KB.w,roundw);
	if(this->back==25)this->back=0;
}
void Optimise::Thresh(size_t basket,size_t trades,vector initial,vector wminlot,vector tminlot,
						vector roundw,vector minhold,vector mintrade)
{
	std::valarray<double>Lkeep(n+m),Ukeep(n+m),naive(n);
	double top,bot;
	class KeepBest KB(n);
	KB.printstream=logprint;
	dcopyvec(n+m,lower,&Lkeep[0]);
	dcopyvec(n+m,upper,&Ukeep[0]);
	bool changed=0;
	size_t i;
	for(i=0;i<n;++i)
	{
		double init=initial?initial[i]:0;
		if(upper[i] < tminlot[i]+init) 
		{
			if(init<=upper[i]){upper[i]=dmin(upper[i],dmax(init,lower[i]));changed=1;}
			else{upper[i]=dmin(upper[i],dmax(init-tminlot[i],lower[i]));changed=1;}
		}
		if(lower[i] > init-tminlot[i]) 
		{
			if(init>=lower[i]){lower[i]=dmax(lower[i],dmin(init,upper[i]));changed=1;}
			else{lower[i]=dmax(lower[i],dmin(init+tminlot[i],upper[i]));changed=1;}
		}
	}
	if(wminlot)
	{
		for(i=0;i<n;++i)
		{
			double init=initial?initial[i]:0;
			if(upper[i] < wminlot[i]) 
			{
				if(0<=upper[i]){upper[i]=dmin(upper[i],dmax(0,lower[i]));changed=1;}
				else{upper[i]=dmin(upper[i],dmax(-wminlot[i],lower[i]));changed=1;}
			}
			if(lower[i] > -wminlot[i]) 
			{
				if(0>=lower[i]){lower[i]=dmax(lower[i],dmin(0,upper[i]));changed=1;}
				else{lower[i]=dmax(lower[i],dmin(wminlot[i],upper[i]));changed=1;}
			}
			if(init!=0&&init-tminlot[i] < wminlot[i]&&lower[i]>dmin(init-tminlot[i],-wminlot[i]))
			{
				if(wminlot[i]>init){lower[i]=dmax(lower[i],dmax(init+tminlot[i],wminlot[i]));changed=1;}
				else{lower[i]=dmax(lower[i],init);changed=1;}
			}
			if(init!=0&&init-tminlot[i] < wminlot[i]&&upper[i]<dmax(init+tminlot[i],wminlot[i]))
			{
				if(-wminlot[i]<init){upper[i]=dmin(upper[i],dmin(init-tminlot[i],-wminlot[i]));changed=1;}
				else{upper[i]=dmin(upper[i],init);changed=1;}
			}
		}
	}
	if(changed)
	{
		AddLog("Changed bounds due to high threshold and reoptimise\n");
		this->AccumOpt(basket,trades);
	}
	for(i=0;i<n;++i)
	{
		if((initial[i]+tminlot[i]) < -wminlot[i] || (wminlot[i] < initial[i]-tminlot[i]))
		{
			wminlot[i]=0;
			tminlot[i]=0;
		}
		else
		{
			top=dmax(initial[i]+tminlot[i],wminlot[i]);
			bot=dmin(initial[i]-tminlot[i],-wminlot[i]);
			wminlot[i]=top;
			tminlot[i]=bot;
		}
	}
	roundopt(KB,basket,trades,lower,upper,&Lkeep[0],&Ukeep[0],initial,wminlot,0,0,&naive[0],
		0,tminlot,lm_max,0,minhold,mintrade);
	dcopyvec(n+m,&Lkeep[0],lower);
	dcopyvec(n+m,&Ukeep[0],upper);
	KB.Message();
	dcopyvec(n,KB.w,roundw);
	if(this->back==25)this->back=0;
}
short Optimise::roundopt(class KeepBest &KB,size_t basket,size_t trades,vector L,
						vector U,vector Lfirst,vector Ufirst,vector initial,
						vector minlot,vector sizelot,size_t stage,vector naive,
						size_t rounded,vector minlot1,double oldutil,bool nopt,
						vector minhold,vector mintrade)
{
	std::valarray<double>updowntest;
	std::valarray<size_t>updownorder;
	std::valarray<unsigned char>updownbad;
	double score_test=score_test_first;
//	if(stage>5)score_test*=1.0/stage;
	if(back>1)return back;
	bool firsttime=(L==lower);
	double utility;
	size_t nround=0;
	std::valarray<double>LUnext;

	if(firsttime)
	{
		LUnext.resize(2*(n+m));
		L=&LUnext[0];
		U=&LUnext[n+m];
		dcopyvec(n+m,lower,L);
		dcopyvec(n+m,upper,U);
		utility=this->utility_base(n,x,c,H);
	}
	else
	{
		dcopyvec(n+m,L,lower);
		dcopyvec(n+m,U,upper);
		if(!nopt){AccumOpt(basket,trades);}
		else{AddLog("Did not need to optimise here\n");}
		utility=this->utility_base(n,x,c,H);
	}

	size_t kbranch,kk;
	double dd=-1,init,nw,sizl,minl1,minl3,minl4;
#ifdef USEGETENV
	double breakpoint=(!getenv("BPOINT")?1:atof(getenv("BPOINT")));
	double breduce=(!getenv("BREDUCE")?.8:atof(getenv("BREDUCE")));
	int doit=0,maxset=(!getenv("MSET")?20:atoi(getenv("MSET")));
#else
	double breakpoint=1;
	double breduce=.8;
	int doit=0,maxset=20;
#endif
	bool doreorder=0;

	bool ok=0;
	if(back <= 1)
	{
		nround=0;
		ok=1;
		dcopyvec(n,x,KB.oldw);
//		std::valarray<size_t>ovec(n);
//		std::valarray<unsigned char>dropbad(n);
		std::valarray<double>score(n);
		score=lm_max;
//		dropbad=(unsigned char) 0;
		if(!minlot1)
		{
			for(kk=0;kk<n;++kk)
			{
				init=initial?initial[kk]:0;
				score[kk]=fabs(fabs(x[kk]-init)-minlot[kk])/minlot[kk];
			}
		}
		else
		{
			for(kk=0;kk<n;++kk)
			{
				init=initial?initial[kk]:0;
				if(fabs(minlot[kk]) > lm_eps)
				{
					score[kk]=fabs(x[kk]-minlot[kk])/fabs(minlot[kk]);
				}
				if(fabs(minlot1[kk])>lm_eps&&score[kk]>=score_test)
				{
					score[kk]=fabs(x[kk]-minlot1[kk])/fabs(minlot1[kk]);
				}
				if(fabs(minlot[kk]) <= lm_eps&&fabs(minlot1[kk]) <= lm_eps)
				{
					score[kk]=fabs(x[kk]-minhold[kk])/fabs(minhold[kk]);
					if(score[kk]>=score_test)
						score[kk]=fabs(x[kk]-init-mintrade[kk])/fabs(mintrade[kk]);
				}
			}
		}
//		RoundOrder(n,&score[0],&ovec[0],&dropbad[0]);

		for(kk=0;kk<n;++kk)
		{
//			kbranch=ovec[kk];
			kbranch=kk;dd=-1;
			init=initial?initial[kbranch]:0;
			sizl=sizelot?sizelot[kbranch]:0;
			minl1=minlot1?minlot1[kbranch]:0;
			minl3=minhold?minhold[kbranch]:0;
			minl4=mintrade?mintrade[kbranch]:0;
			if(!minlot1)
			{
				if(score[kbranch]<score_test&&(fabs(x[kbranch]-init)<minlot[kbranch]))
				{
//					printf("Discarding %-.8e %-.8e score %-.8e this time\n",x[kbranch]-init,minlot[kbranch],score[kbranch]);
					if(score[kbranch]<1e-15)nround++;
					continue;
				}
			}
			else
			{
				if(score[kbranch]<score_test)
				{
					if(fabs(minlot[kbranch]) > lm_eps && fabs(minlot1[kbranch]) > lm_eps 
						&& (x[kbranch])<minlot[kbranch] && (x[kbranch])>minlot1[kbranch])
					{
//						printf("Discarding %-.8e %-.8e score %-.8e this time\n",x[kbranch],minlot[kbranch],score[kbranch]);
						if(score[kbranch]<1e-15)nround++;
						continue;
					}
					else if(minhold&&(fabs(x[kbranch])<minhold[kbranch] || fabs(x[kbranch]-init)<mintrade[kbranch]))
					{
//						printf("Discarding %-.8e %-.8e score %-.8e this time\n",x[kbranch],minhold[kbranch],score[kbranch]);
						if(score[kbranch]<1e-15)nround++;
						continue;
					}
				}
			}
			if(sizl>lm_eps)
			{
				dd=digitisei(x[kbranch],init,minlot[kbranch],sizl,minl1);
				nw=naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],sizl,minl1);
			}
			else if(!minlot1&&fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror)
			{
				dd=digitisei(x[kbranch],init,minlot[kbranch],sizl,minl1);
				nw=naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],sizl,minl1);
			}
			else if(minlot1&&fabs(minlot[kbranch])<=lm_eps && fabs(minlot1[kbranch])<=lm_eps)
			{
				if(fabs(x[kbranch]-init) < mintrade[kbranch])
				{
					nw=naive[kbranch]=init;
				}
				else if(fabs(x[kbranch]) < minhold[kbranch])
				{
					nw=naive[kbranch]=0;
				}
				else
				{
					nw=naive[kbranch]=x[kbranch];
				}
			}
			else if(minlot1&&fabs(minlot[kbranch])>lm_eps&&fabs(minlot1[kbranch])>lm_eps)
			{
				double init_check=(minlot[kbranch]+minl1)*.5;
				if((x[kbranch]>=minlot[kbranch]) || (x[kbranch]<=minl1))
				{
					naive[kbranch]=x[kbranch];
				}
				else
				{
					if(fabs(init_check-init) < 1e-15 && 
						(fabs(init) >= minhold[kbranch] || fabs(init)<lm_eps))
					{
						naive[kbranch]=init;
					}
					else if(fabs(init_check) < 1e-15 && 
						(fabs(init) >= mintrade[kbranch] || fabs(init)<lm_eps))
					{
						naive[kbranch]=0;
					}
					else if(fabs(x[kbranch]-minlot[kbranch]) < fabs(x[kbranch]-minl1))
					{
						naive[kbranch]=minlot[kbranch];
						AddLog("Go to upper %d\n",kbranch);
						if(naive[kbranch]>Ufirst[kbranch])
						{
							naive[kbranch]=minl1;
							AddLog("Change to lower %d\n",kbranch);
						}
					}
					else
					{
						naive[kbranch]=minl1;
						AddLog("Go to lower %d\n",kbranch);
						if(naive[kbranch]<Lfirst[kbranch])
						{
							naive[kbranch]=minlot[kbranch];
							AddLog("Change to upper %d\n",kbranch);
						}
					}
				}
				nw=naive[kbranch];
			}
			else
			{
				nw=naive[kbranch]=x[kbranch];
			}

			if(nw < Lfirst[kbranch] -lm_eps && !minlot1)
			{
				naive[kbranch]=digit2w(x[kbranch],init,dd+1,minlot[kbranch],sizl,0);
				AddLog("Rounded weight increased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
			}
			else if(nw < Lfirst[kbranch] -lm_eps)
			{
				if(fabs(minlot[kbranch]) > lm_eps && fabs(minlot1[kbranch]) > lm_eps 
					&& fabs(naive[kbranch]-minlot1[kbranch]) < 1e-15)
				{
					naive[kbranch]=minlot[kbranch];
				}
				else if(fabs(minlot[kbranch]) <= lm_eps && fabs(minlot1[kbranch]) <= lm_eps)
				{
					if(fabs(x[kbranch]-init) <= mintrade[kbranch])
						naive[kbranch]=mintrade[kbranch]+init;
					else if(fabs(x[kbranch]) <= minhold[kbranch])
						naive[kbranch]=minhold[kbranch];
				}
				AddLog("Rounded weight increased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
			}
			else if(nw > Ufirst[kbranch] +lm_eps&& !minlot1)
			{
				naive[kbranch]=digit2w(x[kbranch],init,dd-1,minlot[kbranch],sizl,0.0);
				AddLog("Rounded weight decreased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
			}
			else if(nw > Ufirst[kbranch] + lm_eps)
			{
				if(fabs(minlot[kbranch]) > lm_eps && fabs(minlot1[kbranch]) > lm_eps 
					&& fabs(naive[kbranch]-minlot[kbranch]) < 1e-15)
				{
					naive[kbranch]=minlot1[kbranch];
				}
				else if(fabs(minlot[kbranch]) <= lm_eps && fabs(minlot1[kbranch]) <= lm_eps)
				{
					if(fabs(x[kbranch]-init) <= mintrade[kbranch])
						naive[kbranch]=-mintrade[kbranch]+init;
					else if(fabs(x[kbranch]) <= minhold[kbranch])
						naive[kbranch]=-minhold[kbranch];
				}
				AddLog("Rounded weight decreased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
			}
			
			if(x[kbranch]<(naive[kbranch]-rounderror))
			{
				ok=0;
				if(naive[kbranch]!=Lfirst[kbranch])
				{
					L[kbranch]=naive[kbranch];
//					U[kbranch]=Ufirst[kbranch];
				}
				else
					U[kbranch]=dmin(Ufirst[kbranch],naive[kbranch]);
			}
			else if(x[kbranch]>(naive[kbranch]+rounderror))
			{
				ok=0;
				if(naive[kbranch]!=Ufirst[kbranch])
				{
					U[kbranch]=naive[kbranch];
//					L[kbranch]=Lfirst[kbranch];
				}
				else
					L[kbranch]=dmax(Lfirst[kbranch],naive[kbranch]);
			}
//			else if(stage > 15){nround++;L[kbranch]=U[kbranch]=x[kbranch];}//Not sure about this
			else {nround++;}

			if(dd==unround||dd==-unround)
			{
				AddLog("minlot---- kbranch %d UNROUND \tLUxn %-.8e %-.8e %-.8e %-.8e\n",kbranch,L[kbranch],U[kbranch],x[kbranch],naive[kbranch]);
			}
			else if(fabs(fabs(dd-(long)(dd))-1)<lm_rooteps)
			{
				AddLog("minlot---- kbranch %d %f %ld\tLUxn %-.8e %-.8e %-.8e %-.8e\n",kbranch,dd,(long)(dd),L[kbranch],U[kbranch],x[kbranch],naive[kbranch]);
			}

			if(L[kbranch]>U[kbranch])
			{
				if(L[kbranch]<=Ufirst[kbranch])U[kbranch]=Ufirst[kbranch];
				else if(U[kbranch]>=Lfirst[kbranch])L[kbranch]=Lfirst[kbranch];
				else
				{
					U[kbranch]=Ufirst[kbranch];
					L[kbranch]=Lfirst[kbranch];
				}
			}
/*			if(sizl<=lm_eps && fabs(x[kbranch]-init) >= minlot[kbranch]+rounderror)
			{
				if(x[kbranch]-init > rounderror)
				{
					L[kbranch]=max(minlot[kbranch]+init,Lfirst[kbranch]);
					U[kbranch]=Ufirst[kbranch];
				}
				else if(x[kbranch]-init < -rounderror)
				{
					U[kbranch]=min(-minlot[kbranch]+init,Ufirst[kbranch]);
					L[kbranch]=Lfirst[kbranch];
				}
			}*/
		}
		AddLog("%d rounded at stage %d (out of %d) utility %-.16e\n",nround,stage,n,utility);
		if(firsttime)dcopyvec(n,x,KB.first);

		if(nround==KB.nround && fabs(utility-KB.utility)<=lm_eps)
			KB.stuck++;
		if(KB.nround < nround)
		{
			KB.Setw(x,back,nround,utility,stage);
			KB.Message();KB.stuck=0;
		}
		else if(KB.nround==nround && utility < KB.utility)
		{
			KB.Setw(x,back,nround,utility,stage);
			KB.Message();KB.stuck=0;
		}

		if(nround==rounded && fabs(utility-oldutil)<=lm_eps)
			ok=1;
		if(KB.stuck>0)ok=1;
		if(!ok && stage<KB.stage+20)
			roundopt(KB,basket,trades,L,U,Lfirst,Ufirst,initial,minlot,sizelot,
			stage+1,naive,nround,minlot1,utility,0,minhold,mintrade);
		else if(ok && stage<KB.stage+20 && nround<n)
		{
			AddLog("End of branch; stage %d\n",stage);
			bool doopt=0;
			double dw;
			for(kbranch=0;kbranch<n;++kbranch)
			{
				init=initial?initial[kbranch]:0;dd=-1;
				sizl=sizelot?sizelot[kbranch]:0;
				minl1=minlot1?minlot1[kbranch]:0;
				if(sizl>lm_eps)
				{
					dd=digitisei(x[kbranch],init,minlot[kbranch],sizl,minl1);
					naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],sizl,minl1);

					if(x[kbranch] <= naive[kbranch]-rounderror && 
						(dw=digit2w(x[kbranch],init,dd-1,minlot[kbranch],sizl,minl1))>=
						Lfirst[kbranch])
					{
						L[kbranch]=Lfirst[kbranch];
						U[kbranch]=dmin(Ufirst[kbranch],dw);
						doopt=1;
					}
					else if(x[kbranch] >= naive[kbranch]+rounderror && 
						(dw=digit2w(x[kbranch],init,dd+1,minlot[kbranch],sizl,minl1))<=
						Ufirst[kbranch])
					{
						U[kbranch]=Ufirst[kbranch];
						L[kbranch]=dmax(Lfirst[kbranch],dw);
						doopt=1;
					}
				}
				else if(!minlot1 && fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror)
				{
					dd=digitisei(x[kbranch],init,minlot[kbranch],sizl,minl1);
					naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],sizl,minl1);

					L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
					U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
					doopt=1;
				}
				else if(minlot1&&fabs(minlot[kbranch])<=lm_eps&&fabs(minlot1[kbranch])<=lm_eps)
				{
					if(fabs(x[kbranch]-init) < mintrade[kbranch])
					{
						L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
					}
					else if(fabs(x[kbranch]) < minhold[kbranch])
					{
						L[kbranch]=dmax(dmin(Ufirst[kbranch],0.0),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],0.0),Ufirst[kbranch]);
					}
					doopt=1;
				}
				else if(minlot1 && fabs(minlot[kbranch])>lm_eps&&fabs(minlot1[kbranch])>lm_eps&&
					x[kbranch] <= minlot[kbranch]+rounderror 
					&& x[kbranch] >= minlot1[kbranch]-rounderror)
				{
					double init_check=(minlot[kbranch]+minlot1[kbranch])*.5;
					if(fabs(init_check-init)<1e-15)
					{
						naive[kbranch]=init;
						L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
					}
					else if(fabs(init_check)<1e-15)
					{
						naive[kbranch]=0;
						L[kbranch]=dmax(dmin(Ufirst[kbranch],0.0),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],0.0),Ufirst[kbranch]);
					}
					else
					{
						if(fabs(init) > mintrade[kbranch] && mintrade[kbranch] >= minhold[kbranch])
						{
							naive[kbranch]=0;
						}
						else if(fabs(init) > minhold[kbranch] && minhold[kbranch] >= mintrade[kbranch])
						{
							naive[kbranch]=init;
						}
						else if(fabs(x[kbranch]-minlot[kbranch]) < fabs(x[kbranch]-minlot1[kbranch]))
						{
							naive[kbranch]=minlot[kbranch];
						}
						else
						{
							naive[kbranch]=minlot1[kbranch];
						}
						L[kbranch]=dmax(dmin(Ufirst[kbranch],naive[kbranch]),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],naive[kbranch]),Ufirst[kbranch]);
					}
					doopt=1;
				}
				else
					naive[kbranch]=x[kbranch];
			}
			if(doopt)
				roundopt(KB,basket,trades,L,U,Lfirst,Ufirst,initial,minlot,sizelot,stage+1,
				naive,nround,minlot1,utility,0,minhold,mintrade);
			else
			{
				AddLog("No re-opt stage %d\n",stage);
			}
		}
	}

	if(back==9 || back==6 || back==16)
	{
		int moretop=n<100?10:1,more=moretop,breakno=0,breakmax=10;
		bool bad=1;
		while(bad==1 && (more>0||breakno<breakmax))
		{
			AddLog("Stage %d New start after infeasibility with %d step%s\n",stage,more,more==1?".":"s.");
			bad=0;
			for(kbranch=0;kbranch<n;++kbranch)
			{
				if(x[kbranch] > U[kbranch])
				{
					AddLog("bounds on %d %-.8e (%-.8e,%-.8e)\n",kbranch,x[kbranch],L[kbranch],U[kbranch]);
				}
				else if(x[kbranch] < L[kbranch] || x[kbranch] > U[kbranch])
				{
					AddLog("bounds on %d %-.8e (%-.8e,%-.8e)\n",kbranch,x[kbranch],L[kbranch],U[kbranch]);
				}
				if(L[kbranch]==U[kbranch])
				{
					L[kbranch]=Lfirst[kbranch];
					U[kbranch]=Ufirst[kbranch];
				}
			}
			updowntest.resize(n);
			updownorder.resize(n);
			updownbad.resize(n);

			updownbad=(unsigned char)0;
			doreorder=0;
			doit=0;
			for(kbranch=0;kbranch<n;++kbranch)
			{
				init=initial?initial[kbranch]:0;
				sizl=sizelot?sizelot[kbranch]:0;
				minl1=minlot1?minlot1[kbranch]:0;
				if(sizl<=lm_eps && (!minlot1 && fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]+rounderror))
				{
					updowntest[kbranch]=fabs(KB.oldw[kbranch]-init)/minlot[kbranch];
					doreorder=1;
				}
				else
					updowntest[kbranch]=0;
			}

/*			if(doreorder)
			{
				getorder(n,&updowntest[0],&updownorder[0],&updownbad[0],0);breakno++;
			}
			else*/
				breakno=breakmax;
			for(kk=0;kk<n;++kk)
			{
				kbranch=kk;//doreorder?updownorder[kk]:kk;
				init=initial?initial[kbranch]:0;dd=-1;
				sizl=sizelot?sizelot[kbranch]:0;
				minl1=minlot1?minlot1[kbranch]:0;
				if(sizl>lm_eps || (!minlot1 && fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]+rounderror))
				{
					dd=digitisei(KB.oldw[kbranch],init,minlot[kbranch],sizl,minl1);
					naive[kbranch]=digit2w(KB.oldw[kbranch],init,dd,minlot[kbranch],sizl,minl1);
					if(sizl>lm_eps)
					{//if(stage<3&&(x[kk]<=U[kk] && x[kk]>=L[kk]))continue;
						if(naive[kbranch]<KB.oldw[kbranch]&&(dd-(int)dd<((double)(moretop-more))/moretop))
						{
							U[kbranch]=Ufirst[kbranch];
							L[kbranch]=dmin(
								digit2w(KB.oldw[kbranch],init,dd+more,minlot[kbranch],sizl,minl1),
								Ufirst[kbranch]);
						}
						else if(naive[kbranch]>KB.oldw[kbranch]&&(dd-(int)dd>((double)(more))/moretop))
						{
							L[kbranch]=Lfirst[kbranch];
							U[kbranch]=dmax(
								digit2w(KB.oldw[kbranch],init,dd-more,minlot[kbranch],sizl,minl1),
								Lfirst[kbranch]);
						}
					}
					else if(Ufirst[kbranch] <= minlot[kbranch])
					{
						L[kbranch]=dmax(init,Lfirst[kbranch]);
						U[kbranch]=dmin(init,Ufirst[kbranch]);
					}
					else if(Lfirst[kbranch] >= minlot[kbranch])
					{
						L[kbranch]=dmax(init,Lfirst[kbranch]);
						U[kbranch]=dmin(init,Ufirst[kbranch]);
					}
					else if(fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]*breakpoint)
					{
						L[kbranch]=dmax(init,Lfirst[kbranch]);
						U[kbranch]=dmin(init,Ufirst[kbranch]);doit++;
					}
					else if(KB.oldw[kbranch]-init > minlot[kbranch]*breakpoint)
					{
						L[kbranch]=dmax(init+minlot[kbranch],Lfirst[kbranch]);
						U[kbranch]=Ufirst[kbranch];doit++;
					}
					else if(KB.oldw[kbranch]-init < -minlot[kbranch]*breakpoint)
					{
						L[kbranch]=Lfirst[kbranch];doit++;
						U[kbranch]=dmin(init-minlot[kbranch],Ufirst[kbranch]);
					}
					if(doit>maxset)
					{
					//	AddLog("Enough resets %d\n",doit);
						continue;
					}
					if(L[kbranch]>U[kbranch])
					{
						bad=1;break;
					}
				}
				else if(minlot1)
				{
					if(fabs(minlot[kbranch])>lm_eps&&fabs(minlot1[kbranch])>lm_eps)
					{
						if(fabs(KB.oldw[kbranch]-minlot[kbranch]) < fabs(KB.oldw[kbranch]-minlot1[kbranch]))
						{
							if(KB.oldw[kbranch]>=minlot[kbranch])
							{
								L[kbranch]=dmax(minlot[kbranch],Lfirst[kbranch]);
								U[kbranch]=Ufirst[kbranch];
							}
							else if(fabs(init)<lm_eps)
							{
								L[kbranch]=dmax(0,Lfirst[kbranch]);
								U[kbranch]=dmin(0,Ufirst[kbranch]);
							}
							else if(fabs(init)>minhold[kbranch])
							{
								L[kbranch]=dmax(init,Lfirst[kbranch]);
								U[kbranch]=dmin(init,Ufirst[kbranch]);
							}
							else if(fabs(init)>mintrade[kbranch])
							{
								L[kbranch]=dmax(0,Lfirst[kbranch]);
								U[kbranch]=dmin(0,Ufirst[kbranch]);
							}
							else
							{
								L[kbranch]=Lfirst[kbranch];
								U[kbranch]=dmin(minlot1[kbranch],Ufirst[kbranch]);
							}
						}
						else
						{
							if(KB.oldw[kbranch]<=minlot1[kbranch])
							{
								U[kbranch]=dmin(minlot1[kbranch],Ufirst[kbranch]);
								L[kbranch]=Lfirst[kbranch];
							}
							else if(fabs(init)<lm_eps)
							{
								L[kbranch]=dmax(0,Lfirst[kbranch]);
								U[kbranch]=dmin(0,Ufirst[kbranch]);
							}
							else if(fabs(init)>minhold[kbranch])
							{
								L[kbranch]=dmax(init,Lfirst[kbranch]);
								U[kbranch]=dmin(init,Ufirst[kbranch]);
							}
							else if(fabs(init)>mintrade[kbranch])
							{
								L[kbranch]=dmax(0,Lfirst[kbranch]);
								U[kbranch]=dmin(0,Ufirst[kbranch]);
							}
							else
							{
								U[kbranch]=Ufirst[kbranch];
								L[kbranch]=dmax(minlot[kbranch],Lfirst[kbranch]);
							}
						}
					}
					else
					{
						if(fabs(KB.oldw[kbranch]) < minhold[kbranch]*.5)
						{
							L[kbranch]=dmax(0,Lfirst[kbranch]);
							U[kbranch]=dmin(0,Ufirst[kbranch]);
						}
						else if(fabs(KB.oldw[kbranch]) < minhold[kbranch] && KB.oldw[kbranch]>0)
						{
							L[kbranch]=dmax(dmin(Ufirst[kbranch],minhold[kbranch]),Lfirst[kbranch]);
							U[kbranch]=Ufirst[kbranch];
						}
						else if(fabs(KB.oldw[kbranch]) < minhold[kbranch] && KB.oldw[kbranch]<0)
						{
							U[kbranch]=dmin(dmax(Lfirst[kbranch],-minhold[kbranch]),Ufirst[kbranch]);
							L[kbranch]=Lfirst[kbranch];
						}

						if(fabs(KB.oldw[kbranch]-init) < mintrade[kbranch]*.5)
						{
							L[kbranch]=dmax(init,Lfirst[kbranch]);
							U[kbranch]=dmin(init,Ufirst[kbranch]);
						}
						else if(fabs(KB.oldw[kbranch]-init) < mintrade[kbranch] && KB.oldw[kbranch]>0)
						{
							L[kbranch]=dmax(dmin(Ufirst[kbranch],init+mintrade[kbranch]),Lfirst[kbranch]);
							U[kbranch]=Ufirst[kbranch];
						}
						else if(fabs(KB.oldw[kbranch]-init) < mintrade[kbranch] && KB.oldw[kbranch]<0)
						{
							U[kbranch]=dmin(dmax(Lfirst[kbranch],init-mintrade[kbranch]),Ufirst[kbranch]);
							L[kbranch]=Lfirst[kbranch];
						}
					}
				}
				else
					naive[kbranch]=KB.oldw[kbranch];
			}
			more--;
			if(bad) break;
			dcopyvec(n+m,L,lower);
			dcopyvec(n+m,U,upper);
			AccumOpt(basket,trades);
			if(back>1) 
			{
				bad=1;
				if(doreorder)
				{
					breakpoint*=breduce;
					AddLog("\t\t*** %d Breakpoint now %f ***\n",breakno,breakpoint);
					if(breakno<breakmax)more++;
				}
			}
		}
		if(back<=1)
		{
			AddLog("Successful new start found for stage %d\n",stage);
			back=roundopt(KB,basket,trades,L,U,Lfirst,Ufirst,initial,minlot,sizelot,stage,
				naive,nround,minlot1,utility,1,minhold,mintrade);
		}
		else {AddLog("Could not find new start\n");back=25;}
	}
	return back;
}
inline size_t sizenow(size_t n,vector x,double thresh,long&pos,long&neg)
{
	size_t k=0;
	pos=0;
	neg=0;
	while(n--)
	{
		if(fabs(*x)>thresh)k++;
		if(*x>thresh)pos++;
		if(*x<-thresh)neg++;
		x++;
	}
	return k;
}
inline void checkbound(size_t n,vector initial,vector l,vector u,vector x=0)
{
	size_t nz=0,ni=0,no=0,i;
	for(i=0;i<n;++i)
	{
		if(l[i]==u[i])
		{
			if(x)
			{
				std::cout.width(10);
				std::cout << l[i];
				std::cout.width(10);
				std::cout << x[i];
				std::cout << std::endl;
			}
			if(l[i]==0)nz++;
			if(l[i]==initial[i])ni++;
			no++;
		}
	}
	std::cout << "Number zero "<<nz<<std::endl;
	std::cout << "Number initial "<<ni<<std::endl;
	std::cout << "Number fixed "<<no<<std::endl;
}
class DropResult
{
public:
	long basket;
	long trades;
	double u;
};
short Optimise::Drop2(dimen nvab/*we don't need this*/,dimen basket,dimen trades,bool onlyfast)
{
	if((long) trades<0)trades=n;
	if((long) basket<0)basket=n;
	size_t basketnow,tradesnow,basket1,trades1,makez,ib,blow=0,tlow=0,tdone=0,bdone=0,tpdone=0,bpdone=0;
        bool first_time_to_optimise=false;
        double uquick=lm_max,u,init;
	DropResult OldResults;
	bool onesided=1;
	size_t basketnow1,tradesnow1;
	if(basket<=n && longbasket>-1 && shortbasket==(long)n)shortbasket=max(0,(long)basket-longbasket);
	else if(basket<n && longbasket==(long)n && shortbasket>-1)longbasket=max(0,(long)basket-shortbasket);
	if(trades<=n && tradebuy>-1 && tradesell==(long)n)tradesell=max(0,(long)trades-tradebuy);
	else if(trades<n && tradebuy==(long)n && tradesell>-1)tradebuy=max(0,(long)trades-tradesell);
	short back=0;
	bool nogood=false;
	size_t i,way;
	std::valarray<unsigned char> dropbadb(n),dropbadt(n);
	dropbadb=(unsigned char)0;
	dropbadt=(unsigned char)0;
	std::valarray<double> keept(n);
	if(initial)
		dsubvec(n,x,initial,&keept[0]);
	else
		dcopyvec(n,x,&keept[0]);
	long Nlong,Nshort,Nlong1,Nshort1;
	long Nbuy,Nsell,Nbuy1,Nsell1;
	basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
	tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);
	if(longbasket==-1&&shortbasket==-1&&tradebuy==-1&&tradesell==-1)
	{
		if(basketnow<=basket && tradesnow <= trades)
			return this->back;
	}
	else if(Nlong<=longbasket&&Nshort<=shortbasket&&tradebuy==-1&&tradesell==-1)
			return this->back;
	else if(longbasket==-1&&shortbasket==-1&&Nbuy<tradebuy&&Nsell<=tradesell)
			return this->back;
	setbadness(n,lower,upper,&dropbadb[0],&dropbadt[0],initial,equalbounds);
/*	for(i=0;i<n;++i)
	{
		if(fabs(lower[i]-upper[i])<=equalbounds)
		{
			if(fabs(lower[i])>equalbounds+lm_eps)
				dropbadb[i]=1;
			if(fabs(lower[i]-(initial?initial[i]:0))>equalbounds+lm_eps)
				dropbadt[i]=1;
		}
	}

	for(i=0;i<n;++i)
	{
		if(lower[i]>lm_eps || upper[i]<-lm_eps)
			dropbadb[i]=1;
		if(lower[i]>(initial?initial[i]:0)+lm_eps || upper[i]<(initial?initial[i]:0)-lm_eps)
			dropbadt[i]=1;
	}*/
	std::valarray<double> first(n);
	std::valarray<double> keepx(n);
	std::valarray<double> quick(n);
	std::valarray<double> keepL(n+m);
	std::valarray<double> keepU(n+m);

	std::valarray<size_t> basketorder(n);
	std::valarray<size_t> tradeorder(n);

	dcopyvec(n,x,&keepx[0]);
	dcopyvec(n,x,&first[0]);//Use for fast double drop only
	if(initial)
		dsubvec(n,x,initial,&keept[0]);
	else
		dcopyvec(n,x,&keept[0]);
	dcopyvec(n+m,lower,&keepL[0]);
	dcopyvec(n+m,upper,&keepU[0]);

	if(mabs)
	{
		modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0],-1,-1,this);
		modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0],-1,-1,this,true);
	}
	else
	{
		modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0],longbasket,shortbasket,this);
		modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0],tradebuy,tradesell,this,true);
	}

	basketnow1=basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
	Nlong1=Nlong;Nshort1=Nshort;
	tradesnow1=tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);
	Nbuy1=Nbuy;Nsell1=Nsell;

	if(initial&&tradesnow1<=trades)
	{
		long ibask=sizenow(n,initial,lm_eps,Nlong,Nshort),idiff;
		idiff=((long)basket-ibask);
		if(idiff<2&&idiff>-2)
			modifyorder(n,initial,&basketorder[0],&dropbadb[0],-1,-1,lp?this:0);
	}
	long buyset=-1,longset=-1;
	size_t kp,kn,itop;
	long sellset=-1,shortset=-1;
	short doingbasketsortrades=0;

	if((Nbuy>tradebuy || Nsell>tradesell) && tradebuy!=-1&& tradesell!=-1)
	{
		buyset=tradebuy;
		sellset=tradesell;
		for(i=0,kp=0,kn=0;i<n;++i)
		{
			ib=tradeorder[i];
			if(keept[ib]>lm_eps && kp<(size_t)buyset){kp++;continue;}
			if(keept[ib]<-lm_eps && kn<(size_t)sellset){kn++;continue;}
			break;
		}
		itop=n-i;
		for(i=0,makez=0;i<itop&&makez<n;++i)
		{
			ib=tradeorder[n-i-1];
			init=(initial?initial[ib]:0);
			if(dropbadt[ib])
			{
				AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
			}
			else if(upper[ib]-lower[ib]>equalbounds&& 
				(init<=upper[ib]) && (init>=lower[ib]))
			{
				lower[ib]=upper[ib]=init;makez++;
			}
			else if(fabs(keept[ib])<=lm_eps)
				makez++;
		}
		if(nogood && makez==n)
			nogood=false;
		if(nogood)back=6;

//		checkbound(n,initial,lower,upper);
		AccumOpt(n);
//		checkbound(n,initial,lower,upper,x);
		back=this->back;
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(back==6||back==16) 
		{
			dcopyvec(n,&keepx[0],x);
//			if(!mabs)return back;
			if((tradesnow-trades) > 10)dropfac=.2;
			else dropfac=.99;
			AddLog("basketnow %d (%d) line %d tradesnow %d (%d) dropfac set to %f\n",basketnow,basket,__LINE__,tradesnow,trades,dropfac);
                }
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);

		basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);
		if(!mabs&&(Nbuy<=tradebuy) && (Nsell<=tradesell) && basketnow <= basket 
			&& longbasket==-1 && shortbasket==-1)
		{
			dcopyvec(n,x,&quick[0]);
			uquick=utility_base(n,x,c,H);
			AddLog("Keep weights with u=%20.10e\n",uquick);
		}
		else if((Nbuy<=tradebuy) && (Nsell<=tradesell) && basketnow <= basket 
			&& Nlong<=longbasket && Nshort<=shortbasket)
		{
			dcopyvec(n,x,&quick[0]);
			uquick=utility_base(n,x,c,H);
			AddLog("Keep weights with u=%20.10e\n",uquick);
		}
		basketnow=basketnow1;
		tradesnow=tradesnow1;
		Nbuy=Nbuy1;
		Nsell=Nsell1;
		Nlong=Nlong1;
		Nshort=Nshort1;
	}
	else if(tradesnow > trades)
	{
		trades1=trades;
		for(i=0,makez=0;i<n&&makez<(n-trades1);++i)
		{
			ib=tradeorder[n-i-1];
			init=(initial?initial[ib]:0);
			if(dropbadt[ib])
			{
				AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
			}
			else if(upper[ib]-lower[ib]>equalbounds&& 
				(init<=upper[ib]) && (init>=lower[ib]))
			{
				lower[ib]=upper[ib]=init;makez++;
			}
			else if(fabs(keept[ib])<lm_eps)
				makez++;
		}
		if(nogood && makez==(n-trades1))
			nogood=false;
		if(nogood)back=6;

//		checkbound(n,initial,lower,upper);
		AccumOpt(n);
//		checkbound(n,initial,lower,upper,x);
		back=this->back;
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(back==6||back==16) 
		{
			dcopyvec(n,&keepx[0],x);
		//	if(!mabs)return back;
			if((tradesnow-trades) > 10)dropfac=.1;
			else dropfac=.99;
			AddLog("basketnow %d (%d) line %d tradesnow %d (%d) dropfac set to %f\n",basketnow,basket,__LINE__,tradesnow,trades,dropfac);
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);

		basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);
		if((basketnow<=basket) && (tradesnow<=trades)
			&& longbasket==-1 && shortbasket==-1)
		{
			dcopyvec(n,x,&quick[0]);
			uquick=utility_base(n,x,c,H);
			AddLog("Keep weights with u=%20.10e\n",uquick);
		}
		else if((basketnow<=basket) && (tradesnow<=trades)
			&& Nlong<=longbasket && Nshort<=shortbasket)
		{
			dcopyvec(n,x,&quick[0]);
			uquick=utility_base(n,x,c,H);
			AddLog("Keep weights with u=%20.10e\n",uquick);
		}
		basketnow=basketnow1;
		tradesnow=tradesnow1;
		Nbuy=Nbuy1;
		Nsell=Nsell1;
		Nlong=Nlong1;
		Nshort=Nshort1;
	}
	if(!mabs&&(Nlong > longbasket || Nshort > shortbasket) && longbasket!=-1 && shortbasket!=-1)
	{
		longset=longbasket;
		shortset=shortbasket;
		dcopyvec(n,&keepx[0],x);
		basket1=basket;
		for(i=0,kp=0,kn=0;i<n;++i)
		{
			ib=basketorder[i];
			if(keepx[ib]>lm_eps && kp<(size_t)longset){kp++;continue;}
			if(keepx[ib]<-lm_eps && kn<(size_t)shortset){kn++;continue;}
			break;
		}
		itop=n-i;
		for(i=0,makez=0;i<itop&&makez<n;++i)
		{
			ib=basketorder[n-i-1];
			if(dropbadb[ib])
			{
				AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
			}
			else if(upper[ib]-lower[ib]>equalbounds&& 
				0<=upper[ib] && 0>=lower[ib])
			{
				lower[ib]=upper[ib]=0;makez++;
			}
			else if(fabs(x[ib])<=lm_eps)
				makez++;
		}
		if(nogood && makez==n)
			nogood=false;
		if(nogood)back=6;

//		checkbound(n,initial,lower,upper);
		AccumOpt(n);
//		checkbound(n,initial,lower,upper,x);
		back=this->back;
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(back==6||back==16) 
		{
			dcopyvec(n,&keepx[0],x);
//			if(!mabs)return back;
			if((basketnow-basket) > 10)dropfac=.1;
			else dropfac=.99;
			AddLog("basketnow %d (%d) line %d tradesnow %d (%d) dropfac set to %f\n",basketnow,basket,__LINE__,tradesnow,trades,dropfac);
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);

		basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);
		if((Nlong<=longbasket) &&(Nshort<=shortbasket) && (tradesnow<=trades)&&
			tradebuy==-1&&tradesell==-1)
		{
			if(uquick>(u=utility_base(n,x,c,H)))
			{
				dcopyvec(n,x,&quick[0]);
				uquick=u;
				AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		else if((Nlong<=longbasket) &&(Nshort<=shortbasket) && (tradesnow<=trades)&&
			Nbuy<=tradebuy&&Nsell<=tradesell)
		{
			if(uquick>(u=utility_base(n,x,c,H)))
			{
				dcopyvec(n,x,&quick[0]);
				uquick=u;
				AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		basketnow=basketnow1;
		tradesnow=tradesnow1;
		Nbuy=Nbuy1;
		Nsell=Nsell1;
		Nlong=Nlong1;
		Nshort=Nshort1;
		dcopyvec(n,x,&first[0]);//Use for fast double drop only
	}
	else if(basketnow > basket)
	{
		dcopyvec(n,&keepx[0],x);
		basket1=basket;
		for(i=0,makez=0;i<n&&makez<(n-basket1);++i)
		{
			ib=basketorder[n-i-1];
			if(dropbadb[ib])
			{
				AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
			}
			else if(upper[ib]-lower[ib]>equalbounds&&
				(0<=upper[ib]) && (0>=lower[ib]))
			{
				lower[ib]=upper[ib]=0;makez++;
			}
			else if(fabs(x[ib])<lm_eps)
				makez++;
		}
		if(nogood && makez==(n-basket1))
			nogood=false;
		if(nogood)back=6;

//		checkbound(n,initial,lower,upper);
		AccumOpt(n);
//		checkbound(n,initial,lower,upper,x);
		back=this->back;
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(back==6||back==16) 
		{
			dcopyvec(n,&keepx[0],x);
//			if(!mabs)return back;
			if((basketnow-basket) > 10)dropfac=.1;
			else dropfac=.99;
			AddLog("basketnow %d (%d) line %d tradesnow %d (%d) dropfac set to %f\n",basketnow,basket,__LINE__,tradesnow,trades,dropfac);
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);

		basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);
		u=utility_base(n,x,c,H);
		if((basketnow<=basket) && (tradesnow<=trades) && tradebuy==-1&&tradesell==-1)
		{
			int kkkk=0;
			std::valarray<double>kpx(n);
			dcopyvec(n,x,&kpx[0]);
			while(basketnow<basket)
			{

				//Use the gradient to give the order of stocks to add back in
				std::valarray<double>xhere(n),buysell,grad(n);
				if(ModCObjectInfo) buysell.resize(n);
				qphess_base(n,1,1,1,H,x,&grad[0]);
				daddvec(n,&grad[0],c,&grad[0]);
				if(ModCObjectInfo)
				{
					buysell=0;
					ResetInitial(0);
					ModDeriv(n,x,&buysell[0],ModCObjectInfo);
					ResetInitial();
					daxpyvec(n,scale_utility_external_terms,&buysell[0],&grad[0]);
				}
				modifyorder(n,&grad[0],&basketorder[0],&dropbadb[0],-1,-1,lp?this:0);
				dcopyvec(n+m,&keepL[0],lower);
				dcopyvec(n+m,&keepU[0],upper);
				for(i=0,makez=kkkk;i<n&&makez<(n-basket1);++i)
				{
					ib=basketorder[n-i-1];
					if(x[ib]!=0)continue;
					if(dropbadb[ib])
					{
						AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
					}
					else if(upper[ib]-lower[ib]>equalbounds&&
						(0<=upper[ib]) && (0>=lower[ib]))
					{
						lower[ib]=upper[ib]=0;makez++;
					}
					else if(fabs(x[ib])<lm_eps)
						makez++;
				}
				if(nogood && makez==(n-basket1))
					nogood=false;
				if(nogood)back=6;
				
				//		checkbound(n,initial,lower,upper);
				AccumOpt(n);
				//		checkbound(n,initial,lower,upper,x);
				back=this->back;
				if(back==6||back==16) 
				{
					for(i=0;i<n;++i)
					{
						if(fabs(kpx[i])>0)grad[i]*=kpx[i];
					}
					modifyorder(n,&grad[0],&basketorder[0],&dropbadb[0],-1,-1,lp?this:0);
					dcopyvec(n+m,&keepL[0],lower);
					dcopyvec(n+m,&keepU[0],upper);
					for(i=0,makez=0;i<n&&makez<(n-basket1);++i)
					{
						ib=basketorder[n-i-1];
						if(x[ib]!=0)continue;
						if(dropbadb[ib])
						{
							AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
						}
						else if(upper[ib]-lower[ib]>equalbounds&&
							(0<=upper[ib]) && (0>=lower[ib]))
						{
							lower[ib]=upper[ib]=0;makez++;
						}
						else if(fabs(x[ib])<lm_eps)
							makez++;
					}
					if(nogood && makez==(n-basket1))
						nogood=false;
					if(nogood)back=6;
					
					//		checkbound(n,initial,lower,upper);
					AccumOpt(n);
					//		checkbound(n,initial,lower,upper,x);
					back=this->back;
				}
				if(initial)
					dsubvec(n,x,initial,&keept[0]);
				else
					dcopyvec(n,x,&keept[0]);
				
				basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
				tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);
				if(basketnow<=basket)
				{
					dcopyvec(n,x,&kpx[0]);
				}
				kkkk++;
			}
			dcopyvec(n,&kpx[0],x);
			if(uquick>(u=utility_base(n,x,c,H)))
			{
				dcopyvec(n,x,&quick[0]);
				uquick=u;
				AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		if((basketnow<=basket) && (tradesnow<=trades) && Nbuy<=tradebuy&&Nsell<=tradesell)
		{
			if(uquick>(u=utility_base(n,x,c,H)))
			{
				dcopyvec(n,x,&quick[0]);
				uquick=u;
				AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		basketnow=basketnow1;
		tradesnow=tradesnow1;
		Nbuy=Nbuy1;
		Nsell=Nsell1;
		Nlong=Nlong1;
		Nshort=Nshort1;
		dcopyvec(n,x,&first[0]);//Use for fast double drop only
	}


	dcopyvec(n,&first[0],x);//This start is just for fast double drop
	dcopyvec(n,&keepx[0],&first[0]);//Now this really is the first non dropping solution
	if(initial)
		dsubvec(n,x,initial,&keept[0]);
	else
		dcopyvec(n,x,&keept[0]);

	if(mabs)
	{
		modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0],-1,-1,this);
		modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0],-1,-1,this,true);
	}
	else
	{
		modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0],longbasket,shortbasket,this);
		modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0],tradebuy,tradesell,this,true);
	}

	basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
	tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);

	dcopyvec(n+m,&keepL[0],lower);
	dcopyvec(n+m,&keepU[0],upper);


	size_t fast=1;
//	if(lp&&basketnow<=basket&&tradesnow<=trades&&back<=2)fast=0;
	OldResults.basket=basketnow;
	OldResults.trades=tradesnow;
	size_t stuck=0,loopc=0;
	while(fast||
		(basketnow>basket&&longbasket==-1&&shortbasket==-1) || 
		(/*basketnow>basket&&*/longbasket>-1&&shortbasket>-1&&(Nlong>longbasket||Nshort>shortbasket)) || 
		(tradesnow>trades&&tradebuy==-1&&tradesell==-1) ||
		(/*tradesnow>trades&&*/tradebuy>-1&&tradesell>-1&&(Nbuy>tradebuy||Nsell>tradesell))
		)
	{
		if(mabs||(longbasket==-1&&shortbasket==-1))
		{
			if(fast){basket1=basket;}
		/*	else if(back==6)
			{
				AddLog("Reset dropbads b and t\n");
				dropbadb=(unsigned char)0;
				dropbadt=(unsigned char)0;
				setbadness(n,lower,upper,&dropbadb[0],&dropbadt[0],initial,equalbounds);
				basket1=basketnow-1;
			}*/
			else 
			{
				/*if(back==6)
				{
					AddLog("Reset dropbads b and t\n");
					dropbadb=(unsigned char)0;
					dropbadt=(unsigned char)0;
					setbadness(n,lower,upper,&dropbadb[0],&dropbadt[0],initial,equalbounds);
				}*/
				basket1=(size_t)dmax((double)basket,basketnow*(1.0-dropfac) + dropfac*basket);
			}
			AddLog("basket1 %d\n",basket1);
		}
		else
		{
			if(fast)
			{
				longset=longbasket;
				shortset=shortbasket;
			}
			else
			{
				longset=(long)dmax((double)longbasket,Nlong*(1.0-dropfac)+dropfac*longbasket);
				shortset=(long)dmax((double)shortbasket,Nshort*(1.0-dropfac)+dropfac*shortbasket);
			}
			AddLog("longset %d shortset %d\n",longset,shortset);
		}
		if(mabs||(tradebuy==-1&&tradesell==-1))
		{
			if(fast)trades1=trades;
			else trades1=(size_t)dmax((double)trades,tradesnow*(1.0-dropfac) + dropfac*trades);
			AddLog("trades1 %d\n",trades1);
		}
		else
		{
			if(fast)
			{
				buyset=tradebuy;
				sellset=tradesell;
			}
			else
			{
				buyset=(long)dmax((double)tradebuy,Nbuy*(1.0-dropfac)+dropfac*tradebuy);
				sellset=(long)dmax((double)tradesell,Nsell*(1.0-dropfac)+dropfac*tradesell);
			}
			AddLog("buyset %d sellset %d\n",buyset,sellset);
		}
		modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0],longset,shortset,this);
		modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0],buyset,sellset,this,true);

		blow=tlow=0;
		if((longbasket==-1||longbasket==(long)n)&&(shortbasket==-1||shortbasket==(long)n)
			&&(tradebuy==-1||tradebuy==(long)n)&&(tradesell==-1||tradesell==(long)n))
		{
			if(basketnow<=basket || tradesnow<=trades)
				onesided=1;
			else
				onesided=0;
		}
		else if((tradebuy==-1||tradebuy==(long)n)&&(tradesell==-1||tradesell==(long)n))
		{
			if((Nlong<=longbasket && Nshort<=shortbasket) || tradesnow<=trades)
				onesided=1;
			else
				onesided=0;
		}
		else if((longbasket==-1||longbasket==(long)n)&&(shortbasket==-1||shortbasket==(long)n))
		{
			if((Nbuy<=tradebuy && Nsell<=tradesell) || basketnow<=basket)
				onesided=1;
			else
				onesided=0;
		}
		else
		{
			if((Nlong<=longbasket && Nshort<=shortbasket) || (Nbuy<=tradebuy && Nsell<=tradesell))
				onesided=1;
			else
				onesided=0;
		}
//		onesided=1;
		for(way=0;way<2;++way)
		{
			if((way==0))
			{
				if(mabs||(longbasket==-1&&shortbasket==-1))
				{
					if(basketnow<=basket)blow=bdone;
					movefixed(n,x,&basketorder[0],lower,upper,equalbounds,&dropbadb[0]);
					for(i=0,makez=blow,tdone=0;i<n&&makez<(n-basket1);++i)
					{
						doingbasketsortrades=1;
						ib=basketorder[n-i-1];
						if(dropbadb[ib])
						{
							AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
						}
						else if((upper[ib]-lower[ib]>equalbounds) &&
							(0<=upper[ib]) && (0>=lower[ib]) &&
							(((!onesided&&(fabs(x[ib])<=fabs(keept[ib])))||onesided)))
						{
							lower[ib]=upper[ib]=0;makez++;
							if(fabs(keept[ib])<lm_eps)tdone++;
						}
						else if(fabs(x[ib])<lm_eps)
							makez++;
					}
					AddLog("basket -- %d dropped %d trades done by default (prev %d)\n",makez,tdone,tpdone);
					if(nogood && makez==(n-basket1))
						nogood=false;
	//				tlow=tdone;
				}
				else
				{
					if(Nlong<=longbasket && Nshort<=shortbasket)blow=bdone;
					movefixed(n,x,&basketorder[0],lower,upper,equalbounds,&dropbadb[0],longset,shortset);
					for(i=0,kp=0,kn=0;i<n;++i)
					{
						ib=basketorder[i];
						if(x[ib]>lm_eps && kp<(size_t)longset){kp++;continue;}
						if(x[ib]<-lm_eps && kn<(size_t)shortset){kn++;continue;}
						break;
					}
					itop=n-i;
					for(i=0,makez=blow,tdone=0;i<itop&&makez<n;++i)
					{
						doingbasketsortrades=1;
						ib=basketorder[n-i-1];
						if(dropbadb[ib])
						{
							AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
						}
						else if(upper[ib]-lower[ib]>equalbounds&& 
							(0<=upper[ib]) && (0>=lower[ib]) &&
							(((!onesided&&(fabs(x[ib])<=fabs(keept[ib])))||onesided)))
						{
							lower[ib]=upper[ib]=0;makez++;
							if(fabs(keept[ib])<lm_eps)tdone++;
						}
						else if(fabs(x[ib])<=lm_eps)
							makez++;
					}
					AddLog("lsbasket -- %d dropped %d trades done by default (prev %d)\n",makez,tdone,tpdone);
					if(nogood && makez==n)
						nogood=false;
				}
			}
			else
			{
				if(mabs||(tradebuy==-1&&tradesell==-1))
				{
					if(tradesnow<=trades)tlow=tdone;
					movefixed(n,&keept[0],&tradeorder[0],lower,upper,equalbounds,&dropbadt[0]);
					for(i=0,makez=tlow,bdone=0;i<n&&makez<(n-trades1);++i)
					{
						doingbasketsortrades=2;
						ib=tradeorder[n-i-1];
						init=(initial?initial[ib]:0);
						if(dropbadt[ib])
						{
							AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
						}
						else if(upper[ib]-lower[ib]>equalbounds&& 
							(init<=upper[ib]) && (init>=lower[ib]) &&
							(((!onesided&&(fabs(x[ib])>=fabs(keept[ib])))||onesided)))
						{
							lower[ib]=upper[ib]=init;makez++;
							if(fabs(x[ib])<lm_eps)bdone++;
						}
						else if(fabs(keept[ib])<lm_eps)
							makez++;
					}
					AddLog("trades -- %d dropped %d basket done by default (prev %d)\n",makez,bdone,bpdone);
					if(nogood && makez==(n-trades1))
						nogood=false;
	//				blow=bdone;
				}
				else
				{
//					size_t low;
					if(Nbuy<=tradebuy&&Nsell<=tradesell)tlow=tdone;
					movefixed(n,&keept[0],&tradeorder[0],lower,upper,equalbounds,&dropbadt[0],buyset,sellset);
					for(i=0,kp=0,kn=0;i<n;++i)
					{
						ib=tradeorder[i];
						if(keept[ib]>lm_eps && kp<(size_t)buyset){kp++;continue;}
						if(keept[ib]<-lm_eps && kn<(size_t)sellset){kn++;continue;}
						break;
					}
					itop=n-i;
					for(i=0,makez=tlow,bdone=0;i<itop&&makez<n;++i)
					{
						doingbasketsortrades=2;
						ib=tradeorder[n-i-1];
						init=(initial?initial[ib]:0);
						if(dropbadt[ib])
						{
							AddLog("ERROR in Drop2 %d",__LINE__);nogood=true;
						}
						else if(upper[ib]-lower[ib]>equalbounds&& 
							(init<=upper[ib]) && (init>=lower[ib]) &&
							(((!onesided&&(fabs(x[ib])>=fabs(keept[ib])))||onesided)))
						{
							lower[ib]=upper[ib]=init;makez++;
							if(fabs(x[ib])<lm_eps)bdone++;
						}
						else if(fabs(keept[ib])<=lm_eps)
							makez++;
					}
					AddLog("bsbasket -- %d dropped %d trades done by default (prev %d)\n",makez,tdone,tpdone);
					if(nogood && makez==n)
						nogood=false;
				}
			}
		}
		if(nogood){back=6;break;}

//		checkbound(n,initial,lower,upper);
		AccumOpt(n);
//		checkbound(n,initial,lower,upper,x);
		back=this->back;
		if(back<=1)
		{
			dcopyvec(n,x,&keepx[0]);
			first_time_to_optimise=false;
/*			for(i=0;i<n;++i)
			{
				if(dropbadb[i]&&!x[i])
				{
					dropbadb[i]=0;
					AddLog("stock %d unmarked for no drop\n",i+1);
				}
				if(dropbadt[i]&&!(x[i]==initial[i]))
				{
					dropbadt[i]=0;
					AddLog("trade %d unmarked for no drop\n",i+1);
				}
			}*/
		}
		else
		{
			bool done=0;
			if(!onesided) doingbasketsortrades=0;
			dcopyvec(n,&keepx[0],x);
			if(initial)
				dsubvec(n,x,initial,&keept[0]);
			else
				dcopyvec(n,x,&keept[0]);
			basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
			tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);
//			modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0],longset,sellset);
//			modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0],buyset,sellset);
			while(basketnow<n)
			{
				if(doingbasketsortrades==2&&!first_time_to_optimise)break;
				if(lower[basketorder[basketnow]]!=upper[basketorder[basketnow]])
				{
					basketnow++;continue;
				}
				if(fabs(lower[basketorder[basketnow]])<=lm_eps&&!dropbadb[basketorder[basketnow]])
				{
					dropbadb[basketorder[basketnow]]=1;done=1;break;
				}
				basketnow++;
			}
			while(!done&&(tradesnow<n))
			{
				if(doingbasketsortrades==1&&!first_time_to_optimise)break;
				if(lower[tradeorder[tradesnow]]!=upper[tradeorder[tradesnow]])
				{
					tradesnow++;continue;
				}
				if(initial)
				{
					if(fabs(lower[tradeorder[tradesnow]]-initial[tradeorder[tradesnow]])<=lm_eps&&!dropbadt[tradeorder[tradesnow]])
					{
						dropbadt[tradeorder[tradesnow]]=1;done=1;break;
					}
				}
				else
				{
					if(fabs(lower[tradeorder[tradesnow]]-0)<=lm_eps&&!dropbadt[tradeorder[tradesnow]])
					{
						dropbadt[tradeorder[tradesnow]]=1;done=1;break;
					}
				}
				tradesnow++;
			}
                        if(first_time_to_optimise)
                        {
                            dcopyvec(n+m,&keepL[0],lower);
                            dcopyvec(n+m,&keepU[0],upper);
                        }
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);
//		modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0]);
//		modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0]);
		basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);bpdone=bdone;tpdone=tdone;
		if(longbasket!=-1 && shortbasket!=-1)
		{
			if(basketnow<=basket)
			{
				if(Nlong>longbasket)basket-=(Nlong-longbasket);
				else if(Nshort>shortbasket)basket-=(Nshort-shortbasket);
				if((long)basket < 0)basket=0;
				AddLog("basket reduced to %d\n",basket);
			}
		}
		if(tradebuy!=-1 && tradesell!=-1)
		{
			if(tradesnow<=trades)
			{
				if(Nbuy>tradebuy)trades-=(Nbuy-tradebuy);
				else if(Nsell>tradesell)trades-=(Nsell-tradesell);
				if((long)trades < 0)trades=0;
				AddLog("trades reduced to %d\n",trades);
			}
		}
		AddLog("basket now %d trades now %d\n",basketnow,tradesnow);
		AddLog("long now %d short now %d\n",Nlong,Nshort);
		AddLog("buy now %d sell now %d\n",Nbuy,Nsell);
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(!fast && (basketnow==(size_t)OldResults.basket) && (tradesnow==(size_t)OldResults.trades))
		{
			stuck++;
			AddLog("STUCK %d\n",stuck);
			if(basketnow<=basket&&tradesnow<trades)break;
			if(stuck > 50)
			{
				back=6;
				break;
			}
		}
		else
		{
			OldResults.basket=basketnow;
			OldResults.trades=tradesnow;
			stuck=0;
		}
		if(fast&&!onlyfast)
		{
			if(longbasket==-1&&shortbasket==-1&&tradebuy==-1&&tradesell==-1)
			{
				if(uquick>(u=utility_base(n,x,c,H))&&basketnow<=basket&&tradesnow<=trades)
				{
					dcopyvec(n,x,&quick[0]);uquick=u;
					AddLog("Keep fast weights u=%20.10e\n",uquick);
				}
			}
			else if(Nlong<=longbasket&&Nshort<=shortbasket&&tradebuy==-1&&tradesell==-1)
			{
				if(uquick>(u=utility_base(n,x,c,H))&&basketnow<=basket&&tradesnow<=trades)
				{
					dcopyvec(n,x,&quick[0]);uquick=u;
					AddLog("Keep fast weights u=%20.10e\n",uquick);
				}
			}
			else if(Nsell<=tradesell&&Nbuy<=tradebuy&&shortbasket==-1&&longbasket==-1)
			{
				if(uquick>(u=utility_base(n,x,c,H))&&basketnow<=basket&&tradesnow<=trades)
				{
					dcopyvec(n,x,&quick[0]);uquick=u;
					AddLog("Keep fast weights u=%20.10e\n",uquick);
				}
			}
			else if(Nsell<=tradesell&&Nbuy<=tradebuy&&Nlong<=longbasket&&Nshort<=shortbasket)
			{
				if(uquick>(u=utility_base(n,x,c,H))&&basketnow<=basket&&tradesnow<=trades)
				{
					dcopyvec(n,x,&quick[0]);uquick=u;
					AddLog("Keep fast weights u=%20.10e\n",uquick);
				}
			}
			dcopyvec(n,&first[0],x);//First non dropping solution
			if(initial)
				dsubvec(n,x,initial,&keept[0]);
			else
				dcopyvec(n,x,&keept[0]);
//			modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0]);
//			modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0]);
			basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
			tradesnow=sizenow(n,&keept[0],lm_eps,Nbuy,Nsell);bpdone=bdone;tpdone=tdone;
		}

		fast=0;
		if(loopc++>10*n)
		{
			AddLog("Dropping is not converging in under %d iterations\n",loopc);
			back=6;
			break;
		}
	}
	if(!mabs&&(uquick<(u=utility_base(n,x,c,H)) || (uquick!=lm_max&&(back==6||back==16))))
	{
		AddLog("last u=%20.10e\n",u);
		dcopyvec(n,&quick[0],x);back=0;
		u=utility_base(n,x,c,H);
		AddLog("Copy fast weights at end u=%20.10e\n",u);
	}
	if(shortbasket!=-1&&longbasket!=-1&&(tradebuy==-1&&tradesell==-1))
	{
		basket=shortbasket+longbasket;
		double unow;
		basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
		std::valarray<double>xhere(n),buysell;
		if(ModCObjectInfo) buysell.resize(n);
		dcopyvec(n,x,&xhere[0]);
		if(Nlong<longbasket || Nshort<shortbasket)
		{
			for(i=0;i<n;++i)
			{
				if(x[i]>0)
				{
					lower[i]=0;upper[i]=keepU[i];
				}
				else if(x[i]<0)
				{
					lower[i]=keepL[i];upper[i]=0;
				}
				else
				{
					lower[i]=0;upper[i]=0;
				}
			}
			size_t ig;
			std::valarray<double>grad(n);
			int icount=0;
			if(Nshort<shortbasket)
				icount+=shortbasket-Nshort;
			if(Nlong<longbasket)
				icount+=longbasket-Nlong;
			icount*=5;
			size_t nochange=0,added;
			while((Nshort<shortbasket || Nlong<longbasket)&&icount--)
			{
				bool tryonce=true;
				AddLog("Increase icount = %d\n",icount);
				qphess_base(n,1,1,1,H,x,&grad[0]);
				daddvec(n,&grad[0],c,&grad[0]);
				if(ModCObjectInfo)
				{
					buysell=0;
					ResetInitial(0);
					ModDeriv(n,x,&buysell[0],ModCObjectInfo);
					ResetInitial();
					daxpyvec(n,scale_utility_external_terms,&buysell[0],&grad[0]);
				}
				modifyorder(n,&grad[0],&basketorder[0],&dropbadb[0],-1,-1,lp?this:0);
				for(i=0,added=0;i<n;++i)
				{
					ig=basketorder[n-i-1];
					if(x[ig]==0&&grad[ig]>0 && Nshort<shortbasket)
					{
						lower[ig]=keepL[ig];
						AddLog("Added %d\n",ig);
						if(added++>=nochange)break;
					}
					else if(x[ig]==0&&grad[ig]<0 && Nlong<longbasket)
					{
						upper[ig]=keepU[ig];
						AddLog("Added %d\n",ig);
						if(added++>=nochange)break;
					}
				}
				AccumOpt(n);
				back=this->back;
				if(back<2)
				{
					basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
 					unow=utility_base(n,x,c,H);
					AddLog("Utility %20.8e Nlong %d Nshort %d\n",unow,Nlong,Nshort);
					if(Nlong<=longbasket  &&Nshort<=shortbasket)
						dcopyvec(n,x,&xhere[0]);
					nochange++;
				}
				if(tryonce && i<n)
				{
					int j=n;
					if(Nshort>shortbasket)
					{
						while(Nshort>shortbasket&&j)
						{
							tryonce=false;
							for(j=i;j>=0;--j)
							{
								ig=basketorder[n-j-1];
								if(x[ig]<0)
								{
									lower[ig]=0;Nshort--;break;
								}
							}
							AccumOpt(n);
							back=this->back;
							if(back<2)
							{
								basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
								unow=utility_base(n,x,c,H);
								AddLog("Utility %20.8e Nlong %d Nshort %d\n",unow,Nlong,Nshort);
								if(Nlong<=longbasket  &&Nshort<=shortbasket)
									dcopyvec(n,x,&xhere[0]);
							}
						}
					}
					else if(Nlong>longbasket)
					{
						while(Nlong>longbasket&&j)
						{
							tryonce=false;
							for(j=i;j>=0;--j)
							{
								ig=basketorder[n-j-1];
								if(x[ig]>0)
								{
									upper[ig]=0;Nshort--;break;
								}
							}
							AccumOpt(n);
							back=this->back;
							if(back<2)
							{
								basketnow=sizenow(n,x,lm_eps,Nlong,Nshort);
								unow=utility_base(n,x,c,H);
								AddLog("Utility %20.8e Nlong %d Nshort %d\n",unow,Nlong,Nshort);
								if(Nlong<=longbasket  &&Nshort<=shortbasket)
									dcopyvec(n,x,&xhere[0]);
							}
						}
					}
				}
			}
		}
		dcopyvec(n,&xhere[0],x);
	}
	else if((shortbasket==-1&&longbasket==-1)&&(tradebuy!=-1&&tradesell!=-1))
	{
		std::valarray<double>xhere(n),buysell;
		dcopyvec(n,x,&xhere[0]);
		double unow;
		dsubvec(n,x,initial,x);
		tradesnow=sizenow(n,x,lm_eps,Nbuy,Nsell);
		daddvec(n,x,initial,x);
		if(ModCObjectInfo) buysell.resize(n);
		if(Nbuy<tradebuy || Nsell<tradesell)
		{
			for(i=0;i<n;++i)
			{
				if(x[i]>initial[i])
				{
					lower[i]=initial[i];upper[i]=keepU[i];
				}
				else if(x[i]<initial[i])
				{
					lower[i]=keepL[i];upper[i]=initial[i];
				}
				else
				{
					lower[i]=initial[i];upper[i]=initial[i];
				}
			}
			size_t ig;
			std::valarray<double>grad(n);
			int icount=0;
			if(Nsell<tradesell)
				icount+=tradesell-Nsell;
			if(Nbuy<tradebuy)
				icount+=tradebuy-Nbuy;
			icount*=3;
			size_t nochange=0,added;
			while((Nsell<tradesell || Nbuy<tradebuy)&&icount--)
			{
				bool tryonce=true;
				AddLog("Increase icount = %d\n",icount);
				qphess_base(n,1,1,1,H,x,&grad[0]);
				daddvec(n,&grad[0],c,&grad[0]);
				if(ModCObjectInfo)
				{
					buysell=0;
					ResetInitial(0);
					ModDeriv(n,x,&buysell[0],ModCObjectInfo);
					ResetInitial();
					daxpyvec(n,scale_utility_external_terms,&buysell[0],&grad[0]);
				}
				modifyorder(n,&grad[0],&basketorder[0],&dropbadb[0],buyset,sellset,lp?this:0);
				for(i=0,added=0;i<n;++i)
				{
					ig=basketorder[n-i-1];
					if(x[ig]==initial[ig]&&grad[ig]>0 && Nshort<tradesell)
					{
						lower[ig]=keepL[ig];
						AddLog("Added %d\n",ig);
						if(added++>nochange)break;
					}
					else if(x[ig]==initial[ig]&&grad[ig]<0 && Nlong<tradebuy)
					{
						upper[ig]=keepU[ig];
						AddLog("Added %d\n",ig);
						if(added++>nochange)break;
					}
				}
				AccumOpt(n);
				back=this->back;
				if(back<2)
				{
					dsubvec(n,x,initial,x);
					tradesnow=sizenow(n,x,lm_eps,Nbuy,Nsell);
					daddvec(n,x,initial,x);
					unow=utility_base(n,x,c,H);
					AddLog("Utility %20.8e Nlong %d Nshort %d\n",unow,Nbuy,Nsell);
					if(Nbuy<=tradebuy  &&Nsell<=tradesell)
						dcopyvec(n,x,&xhere[0]);
					nochange++;
				}
				if(tryonce&&i<n)
				{
					int j=n;
					if(Nsell>tradesell)
					{
						while(Nsell>tradesell&&j)
						{
							tryonce=false;
							for(j=i;j>=0;--j)
							{
								ig=tradeorder[n-j-1];
								if(x[ig]<initial[ig])
								{
									lower[ig]=initial[ig];Nshort--;break;
								}
							}
							AccumOpt(n);
							back=this->back;
							if(back<2)
							{
								dsubvec(n,x,initial,x);
								tradesnow=sizenow(n,x,lm_eps,Nbuy,Nsell);
								daddvec(n,x,initial,x);
								unow=utility_base(n,x,c,H);
								AddLog("Utility %20.8e Nbuy %d Nsell %d\n",unow,Nbuy,Nsell);
								if(Nbuy<=tradebuy  &&Nsell<=tradesell)
									dcopyvec(n,x,&xhere[0]);
							}
						}
					}
					else if(Nbuy>tradebuy)
					{
						while(Nbuy>tradebuy&&j)
						{
							tryonce=false;
							for(j=i;j>=0;--j)
							{
								ig=basketorder[n-j-1];
								if(x[ig]>initial[ig])


								{
									upper[ig]=initial[ig];Nshort--;break;
								}
							}
							AccumOpt(n);
							back=this->back;
							if(back<2)
							{
								dsubvec(n,x,initial,x);
								tradesnow=sizenow(n,x,lm_eps,Nbuy,Nsell);
								daddvec(n,x,initial,x);
								unow=utility_base(n,x,c,H);
								AddLog("Utility %20.8e Nbuy %d Nsell %d\n",unow,Nbuy,Nsell);
								if(Nbuy<=tradebuy  &&Nsell<=tradesell)
									dcopyvec(n,x,&xhere[0]);
							}
						}
					}
				}
			}
		}
		dcopyvec(n,&xhere[0],x);
	}
	dcopyvec(n+m,&keepL[0],lower);
	dcopyvec(n+m,&keepU[0],upper);
	return back;
}

OptParamRound::OptParamRound()
{
	logprint=0;
	logprint_check=0;
	minholdlot=0;
	mintradelot=0;
	MoreInfo=0;
	TimeOptData=0;
}
OptParamRound::~OptParamRound()
{
	if(logprint_check)delete logprint_check;
}
std::stringstream* OptParamRound::Getlogprint()
{
	return logprint;
}
void OptParamRound::SetLog()
{
	logprint_check=logprint=new std::stringstream;
}
void OptParamRound::PrintLog()
{
	if(logprint)
		std::cout<<(*logprint).str();
}
void OptParamRound::AddLog(const char *mess, ...)
{
	if(!logprint) return;
	char mm[200];
	va_list ttt;
	va_start(ttt,mess);
	int i = vsprintf(mm, mess, ttt);
	if(i>0)
	{
		*logprint<<"\x1b[1;31m"<<mm<<"\x1b[0;m";
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
		std::cout<<"\x1b[1;31m"<<mm<<"\x1b[0;m";std::cout.flush();
#endif
	}
	va_end(ttt);
}

short roundopt(void*info,class KeepBest &KB,vector L,
						vector U,vector Lfirst,vector Ufirst,vector initial,
						vector minlot,vector sizelot,size_t stage,vector naive,
						size_t rounded,vector minlot1,double oldutil,bool nopt,
						vector minhold,vector mintrade)
{
	OptParamRound* OP=(OptParamRound*)info;
	size_t n=OP->n;
	size_t m=OP->m;
	vector lower=OP->lower;
	vector upper=OP->upper;
	vector x=OP->x;
	std::valarray<double>updowntest;
	std::valarray<size_t>updownorder;
	std::valarray<unsigned char>updownbad;
	double score_test=score_test_first;
//	if(stage>5)score_test*=1.0/stage;
	if(OP->back>1)return OP->back;
	bool firsttime=(L==lower);
	double utility;
	size_t nround=0;
	std::valarray<double>LUnext;

	if(firsttime)
	{
		LUnext.resize(2*(n+m));
		L=&LUnext[0];
		U=&LUnext[n+m];
		dcopyvec(n+m,lower,L);
		dcopyvec(n+m,upper,U);
		utility=OP->UtilityFunc(info);
	}
	else
	{
		dcopyvec(n+m,L,lower);
		dcopyvec(n+m,U,upper);
		if(!nopt){OP->OptFunc(info);}
		else{OP->AddLog("Did not need to optimise here\n");}
		utility=OP->UtilityFunc(info);
	}

	size_t kbranch,kk;
	double dd=-1,init,nw,sizl,minl1,minl3,minl4;
#ifdef USEGETENV
	double breakpoint=(!getenv("BPOINT")?1:atof(getenv("BPOINT")));
	double breduce=(!getenv("BREDUCE")?.8:atof(getenv("BREDUCE")));
	int doit=0,maxset=(!getenv("MSET")?20:atoi(getenv("MSET")));
#else
	double breakpoint=1;
	double breduce=.8;
	int doit=0,maxset=20;
#endif
	bool doreorder=0;

	bool ok=0;
	if(OP->back <= 1)
	{
		nround=0;
		ok=1;
		dcopyvec(n,x,KB.oldw);
//		std::valarray<size_t>ovec(n);
//		std::valarray<unsigned char>dropbad(n);
		std::valarray<double>score(n);
		score=lm_max;
//		dropbad=(unsigned char) 0;
		if(!minlot1)
		{
			for(kk=0;kk<n;++kk)
			{
				init=initial?initial[kk]:0;
				score[kk]=fabs(fabs(x[kk]-init)-minlot[kk])/minlot[kk];
			}
		}
		else
		{
			for(kk=0;kk<n;++kk)
			{
				init=initial?initial[kk]:0;
				if(fabs(minlot[kk]) > lm_eps8)
				{
					score[kk]=fabs(x[kk]-minlot[kk])/fabs(minlot[kk]);
				}
				if(fabs(minlot1[kk])>lm_eps8&&score[kk]>=score_test)
				{
					score[kk]=fabs(x[kk]-minlot1[kk])/fabs(minlot1[kk]);
				}
				if(fabs(minlot[kk]) <= lm_eps8&&fabs(minlot1[kk]) <= lm_eps8)
				{
					score[kk]=fabs(x[kk]-minhold[kk])/fabs(minhold[kk]);
					if(score[kk]>=score_test)
						score[kk]=fabs(x[kk]-init-mintrade[kk])/fabs(mintrade[kk]);
				}
			}
		}
//		RoundOrder(n,&score[0],&ovec[0],&dropbad[0]);
		for(kk=0;kk<n;++kk)
		{
//			kbranch=ovec[kk];
			kbranch=kk;dd=-1;
			init=initial?initial[kbranch]:0;
			sizl=sizelot?sizelot[kbranch]:0;
			minl1=minlot1?minlot1[kbranch]:0;
			minl3=minhold?minhold[kbranch]:0;
			minl4=mintrade?mintrade[kbranch]:0;
			if(!minlot1)
			{
				if(score[kbranch]<score_test&&(fabs(x[kbranch]-init)<minlot[kbranch]))
				{
//					printf("Discarding %-.8e %-.8e score %-.8e this time\n",x[kbranch]-init,minlot[kbranch],score[kbranch]);
					if(score[kbranch]<1e-15)nround++;
					continue;
				}
			}
			else
			{
				if(score[kbranch]<score_test)
				{
					if(fabs(minlot[kbranch]) > lm_eps && fabs(minlot1[kbranch]) > lm_eps 
						&& (x[kbranch])<minlot[kbranch] && (x[kbranch])>minlot1[kbranch])
					{
//						printf("Discarding %-.8e %-.8e score %-.8e this time\n",x[kbranch],minlot[kbranch],score[kbranch]);
						if(score[kbranch]<1e-15)nround++;
						continue;
					}
					else if(minhold&&(fabs(x[kbranch])<minhold[kbranch] || fabs(x[kbranch]-init)<mintrade[kbranch]))
					{
//						printf("Discarding %-.8e %-.8e score %-.8e this time\n",x[kbranch],minhold[kbranch],score[kbranch]);
						if(score[kbranch]<1e-15)nround++;
						continue;
					}
				}
			}
			if(sizl>lm_eps)
			{
				dd=digitisei(x[kbranch],init,minlot[kbranch],sizl,minl1);
				nw=naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],sizl,minl1);
			}
			else if(!minlot1&&fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror)
			{
				dd=digitisei(x[kbranch],init,minlot[kbranch],sizl,minl1);
				nw=naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],sizl,minl1);
			}
			else if(minlot1&&fabs(minlot[kbranch])<=lm_eps && fabs(minlot1[kbranch])<=lm_eps)
			{
				if(fabs(x[kbranch]-init) < mintrade[kbranch])
				{
					nw=naive[kbranch]=init;
				}
				else if(fabs(x[kbranch]) < minhold[kbranch])
				{
					nw=naive[kbranch]=0;
				}
				else
				{
					nw=naive[kbranch]=x[kbranch];
				}
			}
			else if(minlot1&&fabs(minlot[kbranch])>lm_eps&&fabs(minlot1[kbranch])>lm_eps)
			{
				double init_check=(minlot[kbranch]+minl1)*.5;
				if((x[kbranch]>=minlot[kbranch]) || (x[kbranch]<=minl1))
				{
					naive[kbranch]=x[kbranch];
				}
				else
				{
					if(fabs(init_check-init) < 1e-15 && 
						(fabs(init) >= minhold[kbranch] || fabs(init)<lm_eps))
					{
						naive[kbranch]=init;
					}
					else if(fabs(init_check) < 1e-15 && 
						(fabs(init) >= mintrade[kbranch] || fabs(init)<lm_eps))
					{
						naive[kbranch]=0;
					}
					else if(fabs(x[kbranch]-minlot[kbranch]) < fabs(x[kbranch]-minl1))
					{
						naive[kbranch]=minlot[kbranch];
						OP->AddLog("Go to upper %d\n",kbranch);
						if(naive[kbranch]>Ufirst[kbranch])
						{
							naive[kbranch]=minl1;
							OP->AddLog("Change to lower %d\n",kbranch);
						}
					}
					else
					{
						naive[kbranch]=minl1;
						OP->AddLog("Go to lower %d\n",kbranch);
						if(naive[kbranch]<Lfirst[kbranch])
						{
							naive[kbranch]=minlot[kbranch];
							OP->AddLog("Change to upper %d\n",kbranch);
						}
					}
				}
				nw=naive[kbranch];
			}
			else
			{
				nw=naive[kbranch]=x[kbranch];
			}

			if(nw < Lfirst[kbranch] -lm_eps && !minlot1)
			{
				naive[kbranch]=digit2w(x[kbranch],init,dd+1,minlot[kbranch],sizl,0);
				OP->AddLog("Rounded weight increased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
			}
			else if(nw < Lfirst[kbranch]-lm_eps)
			{
				if(fabs(minlot[kbranch]) > lm_eps && fabs(minlot1[kbranch]) > lm_eps 
					&& fabs(naive[kbranch]-minlot1[kbranch]) < 1e-15)
				{
					naive[kbranch]=minlot[kbranch];
				}
				else if(fabs(minlot[kbranch]) <= lm_eps && fabs(minlot1[kbranch]) <= lm_eps)
				{
					if(fabs(x[kbranch]-init) <= mintrade[kbranch])
						naive[kbranch]=mintrade[kbranch]+init;
					else if(fabs(x[kbranch]) <= minhold[kbranch])
						naive[kbranch]=minhold[kbranch];
				}
				OP->AddLog("Rounded weight increased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
			}
			else if(nw > Ufirst[kbranch] +lm_eps&& !minlot1)
			{
				naive[kbranch]=digit2w(x[kbranch],init,dd-1,minlot[kbranch],sizl,0.0);
				OP->AddLog("Rounded weight decreased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
			}
			else if(nw > Ufirst[kbranch]+lm_eps)
			{
				if(fabs(minlot[kbranch]) > lm_eps && fabs(minlot1[kbranch]) > lm_eps 
					&& fabs(naive[kbranch]-minlot[kbranch]) < 1e-15)
				{
					naive[kbranch]=minlot1[kbranch];
				}
				else if(fabs(minlot[kbranch]) <= lm_eps && fabs(minlot1[kbranch]) <= lm_eps)
				{
					if(fabs(x[kbranch]-init) <= mintrade[kbranch])
						naive[kbranch]=-mintrade[kbranch]+init;
					else if(fabs(x[kbranch]) <= minhold[kbranch])
						naive[kbranch]=-minhold[kbranch];
				}
				OP->AddLog("Rounded weight decreased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
			}
			
			if(x[kbranch]<(naive[kbranch]-rounderror))
			{
				ok=0;
				if(naive[kbranch]!=Lfirst[kbranch])
				{
					L[kbranch]=naive[kbranch];
//					U[kbranch]=Ufirst[kbranch];
				}
				else
					U[kbranch]=dmin(Ufirst[kbranch],naive[kbranch]);
				if(fabs(minlot[kbranch])>fabs(init))
				{
					if(init>0)
					{
						L[kbranch]=dmin(Ufirst[kbranch],dmax(Lfirst[kbranch],naive[kbranch]));
					}
					else
					{
						U[kbranch]=dmax(Lfirst[kbranch],dmin(Ufirst[kbranch],naive[kbranch]));
					}
				}
			}
			else if(x[kbranch]>(naive[kbranch]+rounderror))
			{
				ok=0;
				if(naive[kbranch]!=Ufirst[kbranch])
				{
					U[kbranch]=naive[kbranch];
//					L[kbranch]=Lfirst[kbranch];
				}
				else
					L[kbranch]=dmax(Lfirst[kbranch],naive[kbranch]);
				if(fabs(minlot[kbranch])>fabs(init))
				{
					if(init>0)
					{
						L[kbranch]=dmin(Ufirst[kbranch],dmax(Lfirst[kbranch],naive[kbranch]));
					}
					else
					{
						U[kbranch]=dmax(Lfirst[kbranch],dmin(Ufirst[kbranch],naive[kbranch]));
					}
				}
			}
			else nround++;

			if(fabs(fabs(dd-(long)(dd))-1)<lm_rooteps)
			{
				OP->AddLog("minlot---- kbranch %d %f %ld\tLUxn %-.8e %-.8e %-.8e %-.8e\n",kbranch,dd,(long)(dd),L[kbranch],U[kbranch],x[kbranch],naive[kbranch]);
			}

			if(L[kbranch]>U[kbranch])
			{
				if(L[kbranch]<=Ufirst[kbranch])U[kbranch]=Ufirst[kbranch];
				else if(U[kbranch]>=Lfirst[kbranch])L[kbranch]=Lfirst[kbranch];
				else
				{
					U[kbranch]=Ufirst[kbranch];
					L[kbranch]=Lfirst[kbranch];
				}
			}
/*			if(sizl<=lm_eps && fabs(x[kbranch]-init) >= minlot[kbranch]+rounderror)
			{
				if(x[kbranch]-init > rounderror)
				{
					L[kbranch]=max(minlot[kbranch]+init,Lfirst[kbranch]);
					U[kbranch]=Ufirst[kbranch];
				}
				else if(x[kbranch]-init < -rounderror)
				{
					U[kbranch]=min(-minlot[kbranch]+init,Ufirst[kbranch]);
					L[kbranch]=Lfirst[kbranch];
				}
			}*/
		}
		OP->AddLog("%d rounded at stage %d (out of %d) utility %-.16e\n",nround,stage,n,utility);
		if(firsttime)dcopyvec(n,x,KB.first);

		if(nround==KB.nround && fabs(utility-KB.utility)<=lm_eps)
			KB.stuck++;
		if(KB.nround < nround)
		{
			KB.Setw(x,OP->back,nround,utility,stage);
			KB.Message();KB.stuck=0;
		}
		else if(KB.nround==nround && utility < KB.utility)
		{
			KB.Setw(x,OP->back,nround,utility,stage);
			KB.Message();KB.stuck=0;
		}

		if(nround==rounded && fabs(utility-oldutil)<=lm_eps)
			ok=1;
		if(KB.stuck>0)ok=1;
		if(!ok && stage<KB.stage+20)
			roundopt(info,KB,L,U,Lfirst,Ufirst,initial,minlot,sizelot,
			stage+1,naive,nround,minlot1,utility,0,minhold,mintrade);
		else if(ok && stage<KB.stage+20 && nround<n)
		{
			OP->AddLog("End of branch; stage %d\n",stage);
			bool doopt=0;
			double dw;
			for(kbranch=0;kbranch<n;++kbranch)
			{
				init=initial?initial[kbranch]:0;dd=-1;
				sizl=sizelot?sizelot[kbranch]:0;
				minl1=minlot1?minlot1[kbranch]:0;
				if(sizl>lm_eps)
				{
					dd=digitisei(x[kbranch],init,minlot[kbranch],sizl,minl1);
					naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],sizl,minl1);

					if(x[kbranch] <= naive[kbranch]-rounderror && 
						(dw=digit2w(x[kbranch],init,dd-1,minlot[kbranch],sizl,minl1))>=
						Lfirst[kbranch])
					{
						L[kbranch]=Lfirst[kbranch];
						U[kbranch]=dmin(Ufirst[kbranch],dw);
						doopt=1;
					}
					else if(x[kbranch] >= naive[kbranch]+rounderror && 
						(dw=digit2w(x[kbranch],init,dd+1,minlot[kbranch],sizl,minl1))<=
						Ufirst[kbranch])
					{
						U[kbranch]=Ufirst[kbranch];
						L[kbranch]=dmax(Lfirst[kbranch],dw);
						doopt=1;
					}
				}
				else if(!minlot1 && fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror)
				{
					dd=digitisei(x[kbranch],init,minlot[kbranch],sizl,minl1);
					naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],sizl,minl1);

					L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
					U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
					doopt=1;
				}
				else if(minlot1&&fabs(minlot[kbranch])<=lm_eps&&fabs(minlot1[kbranch])<=lm_eps)
				{
					if(fabs(x[kbranch]-init) < mintrade[kbranch])
					{
						L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
					}
					else if(fabs(x[kbranch]) < minhold[kbranch])
					{
						L[kbranch]=dmax(dmin(Ufirst[kbranch],0.0),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],0.0),Ufirst[kbranch]);
					}
					doopt=1;
				}
				else if(minlot1 && fabs(minlot[kbranch])>lm_eps&&fabs(minlot1[kbranch])>lm_eps&&
					x[kbranch] <= minlot[kbranch]+rounderror 
					&& x[kbranch] >= minlot1[kbranch]-rounderror)
				{
					double init_check=(minlot[kbranch]+minlot1[kbranch])*.5;
					if(fabs(init_check-init)<1e-15)
					{
						naive[kbranch]=init;
						L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
					}
					else if(fabs(init_check)<1e-15)
					{
						naive[kbranch]=0;
						L[kbranch]=dmax(dmin(Ufirst[kbranch],0.0),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],0.0),Ufirst[kbranch]);
					}
					else
					{
						if(fabs(init) > mintrade[kbranch] && mintrade[kbranch] >= minhold[kbranch])
						{
							naive[kbranch]=0;
						}
						else if(fabs(init) > minhold[kbranch] && minhold[kbranch] >= mintrade[kbranch])
						{
							naive[kbranch]=init;
						}
						else if(fabs(x[kbranch]-minlot[kbranch]) < fabs(x[kbranch]-minlot1[kbranch]))
						{
							naive[kbranch]=minlot[kbranch];
						}
						else
						{
							naive[kbranch]=minlot1[kbranch];
						}
						L[kbranch]=dmax(dmin(Ufirst[kbranch],naive[kbranch]),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],naive[kbranch]),Ufirst[kbranch]);
					}
					doopt=1;
				}
				else
					naive[kbranch]=x[kbranch];
			}
			if(doopt)
				roundopt(info,KB,L,U,Lfirst,Ufirst,initial,minlot,sizelot,stage+1,
				naive,nround,minlot1,utility,0,minhold,mintrade);
			else
			{
				OP->AddLog("No re-opt stage %d\n",stage);
			}
		}
	}

	if(OP->back>1)
	{
		int more=1,breakno=0,breakmax=10;
		bool bad=1;
		while(bad==1 && (more>0||breakno<breakmax))
		{
			OP->AddLog("Stage %d New start after infeasibility with %d step%s\n",stage,more,more==1?".":"s.");
			bad=0;
			for(kbranch=0;kbranch<n;++kbranch)
			{
				if(x[kbranch] > U[kbranch])
				{
					OP->AddLog("bounds on %d %-.8e (%-.8e,%-.8e)\n",kbranch,x[kbranch],L[kbranch],U[kbranch]);
				}
				else if(x[kbranch] < L[kbranch] || x[kbranch] > U[kbranch])
				{
					OP->AddLog("bounds on %d %-.8e (%-.8e,%-.8e)\n",kbranch,x[kbranch],L[kbranch],U[kbranch]);
				}
				if(L[kbranch]==U[kbranch])
				{
					L[kbranch]=Lfirst[kbranch];
					U[kbranch]=Ufirst[kbranch];
				}
			}
			updowntest.resize(n);
			updownorder.resize(n);
			updownbad.resize(n);

			updownbad=(unsigned char)0;
			doreorder=0;
			doit=0;
			for(kbranch=0;kbranch<n;++kbranch)
			{
				init=initial?initial[kbranch]:0;
				sizl=sizelot?sizelot[kbranch]:0;
				minl1=minlot1?minlot1[kbranch]:0;
				if(sizl<=lm_eps && (!minlot1 && fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]+rounderror))
				{
					updowntest[kbranch]=fabs(KB.oldw[kbranch]-init)/minlot[kbranch];
					doreorder=1;
				}
				else
					updowntest[kbranch]=0;
			}

			if(doreorder)
			{
				getorder(n,&updowntest[0],&updownorder[0],&updownbad[0],0);breakno++;
			}
			else
				breakno=breakmax;
			for(kk=0;kk<n;++kk)
			{
				kbranch=doreorder?updownorder[kk]:kk;dd=-1;
				init=initial?initial[kbranch]:0;
				sizl=sizelot?sizelot[kbranch]:0;
				minl1=minlot1?minlot1[kbranch]:0;
				if(sizl>lm_eps || (!minlot1 && fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]+rounderror))
				{
					dd=digitisei(KB.oldw[kbranch],init,minlot[kbranch],sizl,minl1);
					naive[kbranch]=digit2w(KB.oldw[kbranch],init,dd,minlot[kbranch],sizl,minl1);
					if(sizl>lm_eps)
					{
						if(naive[kbranch]<KB.oldw[kbranch])
						{
							U[kbranch]=Ufirst[kbranch];
							L[kbranch]=dmin(
								digit2w(KB.oldw[kbranch],init,dd+more,minlot[kbranch],sizl,minl1),
								Ufirst[kbranch]);
						}
						else if(naive[kbranch]>KB.oldw[kbranch])
						{
							L[kbranch]=Lfirst[kbranch];
							U[kbranch]=dmax(
								digit2w(KB.oldw[kbranch],init,dd-more,minlot[kbranch],sizl,minl1),
								Lfirst[kbranch]);
						}
					}
					else if(Ufirst[kbranch] <= minlot[kbranch])
					{
						L[kbranch]=dmax(init,Lfirst[kbranch]);
						U[kbranch]=dmin(init,Ufirst[kbranch]);
					}
					else if(Lfirst[kbranch] >= minlot[kbranch])
					{
						L[kbranch]=dmax(init,Lfirst[kbranch]);
						U[kbranch]=dmin(init,Ufirst[kbranch]);
					}
					else if(fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]*breakpoint)
					{
						L[kbranch]=dmax(init,Lfirst[kbranch]);
						U[kbranch]=dmin(init,Ufirst[kbranch]);doit++;
					}
					else if(doit>maxset)
					{
					//	AddLog("Enough resets %d\n",doit);
						continue;
					}
					else if(KB.oldw[kbranch]-init > minlot[kbranch]*breakpoint)
					{
						L[kbranch]=dmax(init+minlot[kbranch],Lfirst[kbranch]);
						U[kbranch]=Ufirst[kbranch];doit++;
					}
					else if(KB.oldw[kbranch]-init < -minlot[kbranch]*breakpoint)
					{
						L[kbranch]=Lfirst[kbranch];doit++;
						U[kbranch]=dmin(init-minlot[kbranch],Ufirst[kbranch]);
					}
					if(L[kbranch]>U[kbranch])
					{
						bad=1;break;
					}
				}
				else if(minlot1)
				{
					if(fabs(minlot[kbranch])>lm_eps&&fabs(minlot1[kbranch])>lm_eps)
					{
						if(fabs(KB.oldw[kbranch]-minlot[kbranch]) < fabs(KB.oldw[kbranch]-minlot1[kbranch]))
						{
							if(KB.oldw[kbranch]>=minlot[kbranch])
							{
								L[kbranch]=dmax(minlot[kbranch],Lfirst[kbranch]);
								U[kbranch]=Ufirst[kbranch];
							}
							else if(fabs(init)<lm_eps)
							{
								L[kbranch]=dmax(0,Lfirst[kbranch]);
								U[kbranch]=dmin(0,Ufirst[kbranch]);
							}
							else if(fabs(init)>minhold[kbranch])
							{
								L[kbranch]=dmax(init,Lfirst[kbranch]);
								U[kbranch]=dmin(init,Ufirst[kbranch]);
							}
							else if(fabs(init)>mintrade[kbranch])
							{
								L[kbranch]=dmax(0,Lfirst[kbranch]);
								U[kbranch]=dmin(0,Ufirst[kbranch]);
							}
							else
							{
								L[kbranch]=Lfirst[kbranch];
								U[kbranch]=dmin(minlot1[kbranch],Ufirst[kbranch]);
							}
						}
						else
						{
							if(KB.oldw[kbranch]<=minlot1[kbranch])
							{
								U[kbranch]=dmin(minlot1[kbranch],Ufirst[kbranch]);
								L[kbranch]=Lfirst[kbranch];
							}
							else if(fabs(init)<lm_eps)
							{
								L[kbranch]=dmax(0,Lfirst[kbranch]);
								U[kbranch]=dmin(0,Ufirst[kbranch]);
							}
							else if(fabs(init)>minhold[kbranch])
							{
								L[kbranch]=dmax(init,Lfirst[kbranch]);
								U[kbranch]=dmin(init,Ufirst[kbranch]);
							}
							else if(fabs(init)>mintrade[kbranch])
							{
								L[kbranch]=dmax(0,Lfirst[kbranch]);
								U[kbranch]=dmin(0,Ufirst[kbranch]);
							}
							else
							{
								U[kbranch]=Ufirst[kbranch];
								L[kbranch]=dmax(minlot[kbranch],Lfirst[kbranch]);
							}
						}
					}
					else
					{
						if(fabs(KB.oldw[kbranch]) < minhold[kbranch]*.5)
						{
							L[kbranch]=dmax(0,Lfirst[kbranch]);
							U[kbranch]=dmin(0,Ufirst[kbranch]);
						}
						else if(fabs(KB.oldw[kbranch]) < minhold[kbranch] && KB.oldw[kbranch]>0)
						{
							L[kbranch]=dmax(dmin(Ufirst[kbranch],minhold[kbranch]),Lfirst[kbranch]);
							U[kbranch]=Ufirst[kbranch];
						}
						else if(fabs(KB.oldw[kbranch]) < minhold[kbranch] && KB.oldw[kbranch]<0)
						{
							U[kbranch]=dmin(dmax(Lfirst[kbranch],-minhold[kbranch]),Ufirst[kbranch]);
							L[kbranch]=Lfirst[kbranch];
						}

						if(fabs(KB.oldw[kbranch]-init) < mintrade[kbranch]*.5)
						{
							L[kbranch]=dmax(init,Lfirst[kbranch]);
							U[kbranch]=dmin(init,Ufirst[kbranch]);
						}
						else if(fabs(KB.oldw[kbranch]-init) < mintrade[kbranch] && KB.oldw[kbranch]>0)
						{
							L[kbranch]=dmax(dmin(Ufirst[kbranch],init+mintrade[kbranch]),Lfirst[kbranch]);
							U[kbranch]=Ufirst[kbranch];
						}
						else if(fabs(KB.oldw[kbranch]-init) < mintrade[kbranch] && KB.oldw[kbranch]<0)
						{
							U[kbranch]=dmin(dmax(Lfirst[kbranch],init-mintrade[kbranch]),Ufirst[kbranch]);
							L[kbranch]=Lfirst[kbranch];
						}
					}
				}
				else
					naive[kbranch]=KB.oldw[kbranch];
			}
			more--;
			if(bad) break;
			dcopyvec(n+m,L,lower);
			dcopyvec(n+m,U,upper);
			OP->OptFunc(info);
			if(OP->back>1) 
			{
				bad=1;
				if(doreorder)
				{
					breakpoint*=breduce;
					OP->AddLog("\t\t*** %d Breakpoint now %f ***\n",breakno,breakpoint);
					if(breakno<breakmax)more++;
				}
			}
		}
		if(OP->back<=1)
		{
			OP->AddLog("Successful new start found for stage %d\n",stage);
			OP->back=roundopt(info,KB,L,U,Lfirst,Ufirst,initial,minlot,sizelot,stage,
				naive,nround,minlot1,utility,1,minhold,mintrade);
		}
		else {OP->AddLog("Could not find new start\n");OP->back=25;}
	}
	return OP->back;
}
short threshopt(void*info,class KeepBest &KB,vector L,
						vector U,vector Lfirst,vector Ufirst,vector initial,
						vector minlot,size_t stage,vector naive,vector minlot1=0,
						size_t rounded=0,double oldutil=0,bool nopt=false)
{
	OptParamRound* OP=(OptParamRound*)info;
	size_t n=OP->n;
	size_t m=OP->m;
	vector lower=OP->lower;
	vector upper=OP->upper;
	vector x=OP->x;
	std::valarray<double>updowntest;
	std::valarray<size_t>updownorder;
	std::valarray<unsigned char>updownbad;
	double score_test=score_test_first;
//	if(stage>5)score_test*=1.0/stage;
	if(OP->back>1)return OP->back;
	bool firsttime=(L==lower);
	double utility;
	size_t nround=0;
	std::valarray<double>LUnext;

	if(firsttime)
	{
		LUnext.resize(2*(n+m));
		L=&LUnext[0];
		U=&LUnext[n+m];
		dcopyvec(n+m,lower,L);
		dcopyvec(n+m,upper,U);
		utility=OP->UtilityFunc(info);
	}
	else
	{
		dcopyvec(n+m,L,lower);
		dcopyvec(n+m,U,upper);
		if(!nopt){OP->OptFunc(info);}
		else{OP->AddLog("Did not need to optimise here\n");}
		utility=OP->UtilityFunc(info);
	}

/*
	{
		FILE*INTERDATA=fopen("interdata","a");
		if(INTERDATA)
		{
			fprintf(INTERDATA,"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++%d\n",OP->back);
			for(size_t i=0;i<n;++i)
			{
				fprintf(INTERDATA,"%3d %30.16e %30.16e %30.16e\n",i+1,lower[i],x[i],upper[i]);
			}
			fclose(INTERDATA);
		}
	}
*/
	size_t kbranch,kk;
	double dd=-1,init,nw;//sizl,minl1,minl3,minl4;
#ifdef USEGETENV
	double breakpoint=(!getenv("BPOINT")?1:atof(getenv("BPOINT")));
	double breduce=(!getenv("BREDUCE")?.8:atof(getenv("BREDUCE")));
	int doit=0,maxset=(!getenv("MSET")?20:atoi(getenv("MSET")));
#else
	double breakpoint=1;
	double breduce=.8;
	int doit=0,maxset=20;
#endif
	bool doreorder=0;

	bool ok=0;
	if(OP->back <= 1)
	{
		nround=0;
		ok=1;
		dcopyvec(n,x,KB.oldw);
//		std::valarray<double>score(n);
//		score=lm_max;
//		for(kk=0;kk<n;++kk)
//		{
//			init=initial?initial[kk]:0;
//			score[kk]=fabs(fabs(x[kk]-init)-minlot[kk])/minlot[kk];
//		}
		for(kk=0;kk<n;++kk)
		{
			kbranch=kk;dd=-1;
			init=initial?initial[kbranch]:0;
/*			if(score[kbranch]<score_test&&(fabs(x[kbranch]-init)<minlot[kbranch]))
			{
//					printf("Discarding %-.8e %-.8e score %-.8e this time\n",x[kbranch]-init,minlot[kbranch],score[kbranch]);
				if(score[kbranch]<1e-15)nround++;
				continue;
			}*/
			if(fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror && (minlot1&&fabs(x[kbranch])<=minlot1[kbranch]+rounderror))
			{
/*				dd=digitisei(x[kbranch],init,minlot[kbranch],0,0);
				nw=naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],0,0);
				if(fabs(nw)<minlot1[kbranch])
				{*/
					if(x[kbranch]>0){nw=naive[kbranch]=dmax((digit2w(x[kbranch],init,1,minlot[kbranch],0,0)),(digit2w(x[kbranch],0,1,minlot1[kbranch],0,0)));}
					else{nw=naive[kbranch]=dmin((digit2w(x[kbranch],init,-1,minlot[kbranch],0,0)),(digit2w(x[kbranch],0,1,minlot1[kbranch],0,0)));}
//				}
				if(nw < Lfirst[kbranch] -lm_eps)
				{
					naive[kbranch]=digit2w(x[kbranch],init,dd+1,minlot[kbranch],0,0);
					OP->AddLog("Rounded weight increased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
				}
				else if(nw > Ufirst[kbranch] +lm_eps)
				{
					naive[kbranch]=digit2w(x[kbranch],init,dd-1,minlot[kbranch],0,0);
					OP->AddLog("Rounded weight decreased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
				}
			}
			else if(fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror)
			{
				dd=digitisei(x[kbranch],init,minlot[kbranch],0,0);
				nw=naive[kbranch]=digit2w(x[kbranch],init,dd,minlot[kbranch],0,0);
				if(minlot1&&fabs(nw)<minlot1[kbranch])
				{
					if(x[kbranch]>0){nw=naive[kbranch]=dmax((digit2w(x[kbranch],init,1,minlot[kbranch],0,0)),(digit2w(x[kbranch],0,1,minlot1[kbranch],0,0)));}
					else{nw=naive[kbranch]=dmin((digit2w(x[kbranch],init,-1,minlot[kbranch],0,0)),(digit2w(x[kbranch],0,-1,minlot1[kbranch],0,0)));}
				}
				if(nw < Lfirst[kbranch] -lm_eps)
				{
					naive[kbranch]=digit2w(x[kbranch],init,dd+1,minlot[kbranch],0,0);
					OP->AddLog("Rounded weight increased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
				}
				else if(nw > Ufirst[kbranch] +lm_eps)
				{
					naive[kbranch]=digit2w(x[kbranch],init,dd-1,minlot[kbranch],0,0);
					OP->AddLog("Rounded weight decreased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
				}
			}
			else if(minlot1&&fabs(x[kbranch])<=minlot1[kbranch]+rounderror)
			{
				dd=digitisei(x[kbranch],0,minlot1[kbranch],0,0);
				nw=naive[kbranch]=digit2w(x[kbranch],0,dd,minlot1[kbranch],0,0);
				if(fabs(nw-init)<minlot[kbranch])
				{
					if(x[kbranch]>0){nw=naive[kbranch]=dmax((digit2w(x[kbranch],init,1,minlot[kbranch],0,0)),(digit2w(x[kbranch],0,1,minlot1[kbranch],0,0)));}
					else{nw=naive[kbranch]=dmin((digit2w(x[kbranch],init,-1,minlot[kbranch],0,0)),(digit2w(x[kbranch],0,-1,minlot1[kbranch],0,0)));}
				}
				if(nw < Lfirst[kbranch] -lm_eps)
				{
					naive[kbranch]=digit2w(x[kbranch],0,dd+1,minlot1[kbranch],0,0);
					OP->AddLog("Rounded weight increased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
				}
				else if(nw > Ufirst[kbranch] +lm_eps)
				{
					naive[kbranch]=digit2w(x[kbranch],0,dd-1,minlot1[kbranch],0,0);
					OP->AddLog("Rounded weight decreased from %-.8e to %-.8e (change %-.8e)\n",nw,naive[kbranch],naive[kbranch]-nw);
				}
			}
			else
			{
				nw=naive[kbranch]=x[kbranch];
			}

			
			if(x[kbranch]<(naive[kbranch]-rounderror))
			{
				ok=0;
				if(naive[kbranch]!=Lfirst[kbranch])
				{
					L[kbranch]=naive[kbranch];
//					U[kbranch]=Ufirst[kbranch];
				}
				else
					U[kbranch]=dmin(Ufirst[kbranch],naive[kbranch]);
				if(fabs(minlot[kbranch])>fabs(init))
				{
					if(init>0)
					{
						L[kbranch]=dmin(Ufirst[kbranch],dmax(Lfirst[kbranch],naive[kbranch]));
					}
					else
					{
						U[kbranch]=dmax(Lfirst[kbranch],dmin(Ufirst[kbranch],naive[kbranch]));
					}
				}
			}
			else if(x[kbranch]>(naive[kbranch]+rounderror))
			{
				ok=0;
				if(naive[kbranch]!=Ufirst[kbranch])
				{
					U[kbranch]=naive[kbranch];
//					L[kbranch]=Lfirst[kbranch];
				}
				else
					L[kbranch]=dmax(Lfirst[kbranch],naive[kbranch]);
				if(fabs(minlot[kbranch])>fabs(init))
				{
					if(init>0)
					{
						L[kbranch]=dmin(Ufirst[kbranch],dmax(Lfirst[kbranch],naive[kbranch]));
					}
					else
					{
						U[kbranch]=dmax(Lfirst[kbranch],dmin(Ufirst[kbranch],naive[kbranch]));
					}
				}
			}
			else nround++;

			if(fabs(fabs(dd-(long)(dd))-1)<lm_rooteps)
			{
				OP->AddLog("minlot---- kbranch %d %f %ld\tLUxn %-.8e %-.8e %-.8e %-.8e\n",kbranch,dd,(long)(dd),L[kbranch],U[kbranch],x[kbranch],naive[kbranch]);
			}

			if(L[kbranch]>U[kbranch])
			{
				if(L[kbranch]<=Ufirst[kbranch])U[kbranch]=Ufirst[kbranch];
				else if(U[kbranch]>=Lfirst[kbranch])L[kbranch]=Lfirst[kbranch];
				else
				{
					U[kbranch]=Ufirst[kbranch];
					L[kbranch]=Lfirst[kbranch];
				}
			}
		}
		OP->AddLog("%d rounded at stage %d (out of %d) utility %-.16e change %-.16e\n",nround,stage,n,utility,utility-oldutil);
		nround=thresh_check(n,x,initial,Lfirst,Ufirst,minlot,minlot1,rounderror);
		OP->AddLog("%d rounded at stage %d (out of %d) utility %-.16e change %-.16e\n",nround,stage,n,utility,utility-oldutil);
		if(firsttime)dcopyvec(n,x,KB.first);

		if(nround==KB.nround && fabs(utility-KB.utility)<=lm_eps)
			KB.stuck++;
		if(KB.nround < nround)
		{
			KB.Setw(x,OP->back,nround,utility,stage);
			KB.Message();KB.stuck=0;
		}
		else if(KB.nround==nround && utility < KB.utility)
		{
			KB.Setw(x,OP->back,nround,utility,stage);
			KB.Message();KB.stuck=0;
		}

		if(nround==rounded && fabs(utility-oldutil)<=lm_eps)
			ok=1;
//		if(KB.stuck>0)ok=1;
		//printf("stuck %d line %d nround %d %d\n",KB.stuck,__LINE__,KB.nround,nround);
		if(!ok && stage<KB.stage+5)
			threshopt(info,KB,L,U,Lfirst,Ufirst,initial,minlot,
			stage+1,naive,minlot1,nround,utility,false);
		else if(ok && stage<KB.stage+5 && nround<n)
		{
			OP->AddLog("End of branch; stage %d\n",stage);
			bool doopt=0;
			updowntest.resize(n);
			updownorder.resize(n);
			updownbad.resize(n);
			std::valarray<double> keephere(n);
			dcopyvec(n,x,&keephere[0]);

			updownbad=(unsigned char)0;
			doreorder=0;
			doit=0;
			double LL,UU;
			while(doit<(int)n)
			{
				dcopyvec(n,&keephere[0],x);
				if(!doit)
				{
					for(kbranch=0;kbranch<n;++kbranch)
					{
						init=initial?initial[kbranch]:0;
						if(fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror&&(minlot1&&fabs(x[kbranch]) <= minlot1[kbranch]+rounderror))
						{
							updowntest[kbranch]=10+(fabs(x[kbranch]-init)/minlot[kbranch])+(fabs(x[kbranch])/minlot1[kbranch]);
							doreorder=1;
						}
						else if(fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror)
						{
							updowntest[kbranch]=10+fabs(x[kbranch]-init)/minlot[kbranch];
							doreorder=1;
						}
						else if(minlot1&&fabs(x[kbranch]) <= minlot1[kbranch]+rounderror)
						{
							updowntest[kbranch]=10+fabs(x[kbranch])/minlot1[kbranch];
							doreorder=1;
						}
						else
							updowntest[kbranch]=fabs(x[kbranch])+fabs(x[kbranch]-init);
					}
				}
				if(doreorder)getorder(n,&updowntest[0],&updownorder[0],&updownbad[0],0);
				for(kk=doit;kk<n;++kk)
				{
					kbranch=doreorder?updownorder[kk]:kk;
					init=initial?initial[kbranch]:0;
					LL=Lfirst[kbranch];
					UU=Ufirst[kbranch];
					if(fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror&&(minlot1&&fabs(x[kbranch]) <= minlot1[kbranch]+rounderror))
					{
						if(fabs(x[kbranch]-init) < fabs(x[kbranch]))
						{
							if(x[kbranch]>0)
							{
/*								naive[kbranch]=dmax((digit2w(x[kbranch],0,digitisei(x[kbranch],0,minlot1[kbranch],0,0),minlot1[kbranch],0,0)),(digit2w(x[kbranch],init,digitisei(x[kbranch],init,minlot[kbranch],0,0),minlot[kbranch],0,0)));
								L[kbranch]=dmax(dmin(Ufirst[kbranch],naive[kbranch]),Lfirst[kbranch]);
								U[kbranch]=Ufirst[kbranch];*/
								naive[kbranch]=digit2w(x[kbranch],0,0 ,minlot1[kbranch],0,0);
								L[kbranch]=dmax(dmin(Ufirst[kbranch],naive[kbranch]),Lfirst[kbranch]);
								U[kbranch]=Ufirst[kbranch];
								doopt=1;doit=kk;break;
							}
							else if(x[kbranch]<0)
							{
/*								naive[kbranch]=dmin((digit2w(x[kbranch],0,digitisei(x[kbranch],0,minlot1[kbranch],0,0),minlot1[kbranch],0,0)),(digit2w(x[kbranch],init,digitisei(x[kbranch],init,minlot[kbranch],0,0),minlot[kbranch],0,0)));
								L[kbranch]=Lfirst[kbranch];
								U[kbranch]=dmin(dmax(Lfirst[kbranch],naive[kbranch]),Ufirst[kbranch]);*/
								naive[kbranch]=digit2w(x[kbranch],0,0 ,minlot1[kbranch],0,0);
								L[kbranch]=Lfirst[kbranch];
								U[kbranch]=dmin(dmax(Lfirst[kbranch],naive[kbranch]),Ufirst[kbranch]);
								doopt=1;doit=kk;break;
							}
						}
						else
						{
							if(x[kbranch]>init)
							{
								naive[kbranch]=digit2w(x[kbranch],init,0 ,minlot[kbranch],0,0);
								L[kbranch]=dmax(dmin(Ufirst[kbranch],naive[kbranch]),Lfirst[kbranch]);
								U[kbranch]=Ufirst[kbranch];
							}
							else if(x[kbranch]<init)
							{
								naive[kbranch]=digit2w(x[kbranch],init,0 ,minlot[kbranch],0,0);
								L[kbranch]=Lfirst[kbranch];
								U[kbranch]=dmin(dmax(Lfirst[kbranch],naive[kbranch]),Ufirst[kbranch]);
							}
							
							doopt=1;doit=kk;break;
						}
					}
					else if(fabs(x[kbranch]-init) <= minlot[kbranch]+rounderror)
					{
						dd=digitisei(x[kbranch],init,minlot[kbranch],0,0);
						if(x[kbranch]>init)
						{
							naive[kbranch]=digit2w(x[kbranch],init,dd+1,minlot[kbranch],0,0);
							L[kbranch]=dmax(dmin(Ufirst[kbranch],naive[kbranch]),Lfirst[kbranch]);
							U[kbranch]=Ufirst[kbranch];
						}
						else if(x[kbranch]<init)
						{
							naive[kbranch]=digit2w(x[kbranch],init,dd-1,minlot[kbranch],0,0);
							L[kbranch]=Lfirst[kbranch];
							U[kbranch]=dmin(dmax(Lfirst[kbranch],naive[kbranch]),Ufirst[kbranch]);
						}
						
						doopt=1;doit=kk;break;
					}
					else if(minlot1&&fabs(x[kbranch]) <= minlot1[kbranch]+rounderror)
					{
						dd=digitisei(x[kbranch],0,minlot1[kbranch],0,0);
						if(x[kbranch]>0)
						{
							naive[kbranch]=digit2w(x[kbranch],0,dd+1,minlot1[kbranch],0,0);
							L[kbranch]=dmax(dmin(Ufirst[kbranch],naive[kbranch]),Lfirst[kbranch]);
							U[kbranch]=Ufirst[kbranch];
						}
						else if(x[kbranch]<0)
						{
							naive[kbranch]=digit2w(x[kbranch],0,dd-1,minlot1[kbranch],0,0);
							L[kbranch]=Lfirst[kbranch];
							U[kbranch]=dmin(dmax(Lfirst[kbranch],naive[kbranch]),Ufirst[kbranch]);
						}
						
						doopt=1;doit=kk;break;
					}
					else
						naive[kbranch]=x[kbranch];
				}
				if(doopt)
				{
					dcopyvec(n+m,L,lower);
					dcopyvec(n+m,U,upper);
					OP->OptFunc(info);
					if(OP->back<1) 
					{
						OP->AddLog("================================= BREAK AWAY +++++++++++++++++++++++++++++++++++++\n");
						break;
					}
					else
					{
						L[kbranch]=LL;
						U[kbranch]=UU;
						doit++;
					}
				}
			}
			if(doopt)
				threshopt(info,KB,L,U,Lfirst,Ufirst,initial,minlot,stage+1,
				naive,minlot1,nround,utility,OP->back<1);
			else
			{
				OP->AddLog("No re-opt stage %d\n",stage);
			}
		}
	}

	if(OP->back>1)
	{
		int more=1,breakno=0,breakmax=10;
		bool bad=1;
		while(bad==1 && (more>0||breakno<breakmax))
		{
			OP->AddLog("Stage %d New start after infeasibility with %d step%s\n",stage,more,more==1?".":"s.");
			bad=0;
			for(kbranch=0;kbranch<n;++kbranch)
			{
				if(x[kbranch] > U[kbranch])
				{
					OP->AddLog("bounds on %d %-.8e (%-.8e,%-.8e)\n",kbranch,x[kbranch],L[kbranch],U[kbranch]);
				}
				else if(x[kbranch] < L[kbranch] || x[kbranch] > U[kbranch])
				{
					OP->AddLog("bounds on %d %-.8e (%-.8e,%-.8e)\n",kbranch,x[kbranch],L[kbranch],U[kbranch]);
				}
				if(L[kbranch]==U[kbranch])
				{
					L[kbranch]=Lfirst[kbranch];
					U[kbranch]=Ufirst[kbranch];
				}
			}
			updowntest.resize(n);
			updownorder.resize(n);
			updownbad.resize(n);

			updownbad=(unsigned char)0;
			doreorder=0;
			doit=0;
			for(kbranch=0;kbranch<n;++kbranch)
			{
				init=initial?initial[kbranch]:0;
				if(fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]+rounderror&&(minlot1&&fabs(KB.oldw[kbranch]) <= minlot1[kbranch]+rounderror))
				{
					updowntest[kbranch]=10+(fabs(KB.oldw[kbranch]-init)/minlot[kbranch])+(fabs(KB.oldw[kbranch])/minlot1[kbranch]);
					doreorder=1;
				}
				else if(fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]+rounderror)
				{
					updowntest[kbranch]=10+fabs(KB.oldw[kbranch]-init)/minlot[kbranch];
					doreorder=1;
				}
				else if(minlot1&&fabs(KB.oldw[kbranch]) <= minlot1[kbranch]+rounderror)
				{
					updowntest[kbranch]=10+fabs(KB.oldw[kbranch])/minlot1[kbranch];
					doreorder=1;
				}
				else
					updowntest[kbranch]=fabs(KB.oldw[kbranch])+fabs(KB.oldw[kbranch]-init);
			}

			if(doreorder)
			{
				getorder(n,&updowntest[0],&updownorder[0],&updownbad[0],0);breakno++;
			}
			else
				breakno=breakmax;
			for(kk=0;kk<n;++kk)
			{
				kbranch=doreorder?updownorder[kk]:kk;
				init=initial?initial[kbranch]:0;
				if(fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]+rounderror&&(minlot1&&fabs(KB.oldw[kbranch]) <= minlot1[kbranch]+rounderror))
				{
					if(init>minlot1[kbranch])
					{
						if(KB.oldw[kbranch]>0){naive[kbranch]=dmax((digit2w(KB.oldw[kbranch],init,0,minlot[kbranch],0,0)),(digit2w(KB.oldw[kbranch],0,0,minlot1[kbranch],0,0)));}
						else{naive[kbranch]=dmin((digit2w(KB.oldw[kbranch],init,0,minlot[kbranch],0,0)),(digit2w(KB.oldw[kbranch],0,0,minlot1[kbranch],0,0)));}
						if(Ufirst[kbranch] <= minlot[kbranch])
						{
							L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
							U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
						}
						else if(Lfirst[kbranch] >= minlot[kbranch])
						{
							L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
							U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
						}
						else if(fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]*breakpoint)
						{
							L[kbranch]=dmax(naive[kbranch],Lfirst[kbranch]);
							U[kbranch]=dmin(naive[kbranch],Ufirst[kbranch]);doit++;
						}
						else if(doit>maxset)
						{
							//	AddLog("Enough resets %d\n",doit);
							continue;
						}
						else if(KB.oldw[kbranch]-init > minlot[kbranch]*breakpoint)
						{
							L[kbranch]=dmax(naive[kbranch],Lfirst[kbranch]);
							U[kbranch]=Ufirst[kbranch];doit++;
						}
						else if(KB.oldw[kbranch]-init < -minlot[kbranch]*breakpoint)
						{
							L[kbranch]=Lfirst[kbranch];doit++;
							U[kbranch]=dmin(naive[kbranch],Ufirst[kbranch]);
						}
						if(L[kbranch]>U[kbranch])
						{
							bad=1;break;
						}
					}
					else
					{
						dd=digitisei(KB.oldw[kbranch],0,minlot1[kbranch],0,0);
						naive[kbranch]=digit2w(KB.oldw[kbranch],0,dd,minlot1[kbranch],0,0);
						if(Ufirst[kbranch] <= minlot1[kbranch])
						{
							L[kbranch]=dmax(dmin(Ufirst[kbranch],0),Lfirst[kbranch]);
							U[kbranch]=dmin(dmax(Lfirst[kbranch],0),Ufirst[kbranch]);
						}
						else if(Lfirst[kbranch] >= minlot1[kbranch])
						{
							L[kbranch]=dmax(dmin(Ufirst[kbranch],0),Lfirst[kbranch]);
							U[kbranch]=dmin(dmax(Lfirst[kbranch],0),Ufirst[kbranch]);
						}
						else if(fabs(KB.oldw[kbranch]) <= minlot1[kbranch]*breakpoint)
						{
							L[kbranch]=dmax(naive[kbranch],Lfirst[kbranch]);
							U[kbranch]=dmin(naive[kbranch],Ufirst[kbranch]);doit++;
						}
						else if(doit>maxset)
						{
							//	AddLog("Enough resets %d\n",doit);
							continue;
						}
						else if(KB.oldw[kbranch] > minlot1[kbranch]*breakpoint)
						{
							L[kbranch]=dmax(naive[kbranch],Lfirst[kbranch]);
							U[kbranch]=Ufirst[kbranch];doit++;
						}
						else if(KB.oldw[kbranch] < -minlot1[kbranch]*breakpoint)
						{
							L[kbranch]=Lfirst[kbranch];doit++;
							U[kbranch]=dmin(naive[kbranch],Ufirst[kbranch]);
						}
						if(L[kbranch]>U[kbranch])
						{
							bad=1;break;
						}
					}

				}
				else if(minlot1&&fabs(KB.oldw[kbranch]) <= minlot1[kbranch]+rounderror)
				{
					dd=digitisei(KB.oldw[kbranch],0,minlot1[kbranch],0,0);
					if(!dd&&fabs(KB.oldw[kbranch]) > minlot1[kbranch]*breakpoint)
					{
						if(KB.oldw[kbranch]>init)dd++;
						if(KB.oldw[kbranch]<init)dd--;
					}
					naive[kbranch]=digit2w(KB.oldw[kbranch],0,dd,minlot1[kbranch],0,0);
					if(Ufirst[kbranch] <= minlot1[kbranch])
					{
						L[kbranch]=dmax(dmin(Ufirst[kbranch],0),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],0),Ufirst[kbranch]);
					}
					else if(Lfirst[kbranch] >= minlot1[kbranch])
					{
						L[kbranch]=dmax(dmin(Ufirst[kbranch],0),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],0),Ufirst[kbranch]);
					}
					else if(fabs(KB.oldw[kbranch]) <= minlot1[kbranch]*breakpoint)
					{
						if(Lfirst[kbranch]>=0)
						{
							L[kbranch]=dmax(naive[kbranch],Lfirst[kbranch]);
							U[kbranch]=dmax(Lfirst[kbranch],dmin(naive[kbranch],Ufirst[kbranch]));doit++;
						}
						else
						{
							L[kbranch]=dmin(Ufirst[kbranch],dmax(naive[kbranch],Lfirst[kbranch]));
							U[kbranch]=dmin(naive[kbranch],Ufirst[kbranch]);doit++;
						}
					}
					else if(doit>maxset)
					{
					//	AddLog("Enough resets %d\n",doit);
						continue;
					}
					else if(KB.oldw[kbranch] > minlot1[kbranch]*breakpoint)
					{
						L[kbranch]=dmax(naive[kbranch],Lfirst[kbranch]);
						U[kbranch]=Ufirst[kbranch];doit++;
					}
					else if(KB.oldw[kbranch] < -minlot1[kbranch]*breakpoint)
					{
						L[kbranch]=Lfirst[kbranch];doit++;
						U[kbranch]=dmin(naive[kbranch],Ufirst[kbranch]);
					}
					if(L[kbranch]>U[kbranch])
					{
						bad=1;break;
					}
				}
				else if(fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]+rounderror)
				{
					dd=digitisei(KB.oldw[kbranch],init,minlot[kbranch],0,0);
					if(!dd&&fabs(KB.oldw[kbranch]-init) > minlot[kbranch]*breakpoint)
					{
						if(KB.oldw[kbranch]>init)dd++;
						if(KB.oldw[kbranch]<init)dd--;
					}
					naive[kbranch]=digit2w(KB.oldw[kbranch],init,dd,minlot[kbranch],0,0);
					if(Ufirst[kbranch] <= minlot[kbranch])
					{
						L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
					}
					else if(Lfirst[kbranch] >= minlot[kbranch])
					{
						L[kbranch]=dmax(dmin(Ufirst[kbranch],init),Lfirst[kbranch]);
						U[kbranch]=dmin(dmax(Lfirst[kbranch],init),Ufirst[kbranch]);
					}
					else if(fabs(KB.oldw[kbranch]-init) <= minlot[kbranch]*breakpoint)
					{
						if(Lfirst[kbranch]>=0)
						{
							L[kbranch]=dmax(naive[kbranch],Lfirst[kbranch]);
							U[kbranch]=dmax(Lfirst[kbranch],dmin(naive[kbranch],Ufirst[kbranch]));doit++;
						}
						else
						{
							L[kbranch]=dmin(Ufirst[kbranch],dmax(naive[kbranch],Lfirst[kbranch]));
							U[kbranch]=dmin(naive[kbranch],Ufirst[kbranch]);doit++;
						}
					}
/*					else if(doit>maxset)
					{
					//	AddLog("Enough resets %d\n",doit);
						continue;
					}*/
					else if(KB.oldw[kbranch]-init > minlot[kbranch]*breakpoint)
					{
						L[kbranch]=dmax(naive[kbranch],Lfirst[kbranch]);
						U[kbranch]=Ufirst[kbranch];doit++;
					}
					else if(KB.oldw[kbranch]-init < -minlot[kbranch]*breakpoint)
					{
						L[kbranch]=Lfirst[kbranch];doit++;
						U[kbranch]=dmin(naive[kbranch],Ufirst[kbranch]);
					}
					if(L[kbranch]>U[kbranch])
					{
						bad=1;break;
					}
				}
				else
					naive[kbranch]=KB.oldw[kbranch];
			}
			more--;
			if(bad) break;
			dcopyvec(n+m,L,lower);
			dcopyvec(n+m,U,upper);
			OP->OptFunc(info);
			if(OP->back>1) 
			{
				bad=1;
				if(doreorder)
				{
					breakpoint*=breduce;
					OP->AddLog("\t\t*** %d Breakpoint now %f ***\n",breakno,breakpoint);
					if(breakno<breakmax)more++;
				}
				//printf("breakpoint %f line %d\n",breakpoint,__LINE__);
			}
		}
		if(OP->back<=1)
		{
			OP->AddLog("Successful new start found for stage %d\n",stage);
			OP->back=threshopt(info,KB,L,U,Lfirst,Ufirst,initial,minlot,stage,
				naive,minlot1,nround,utility,true);
		}
		else {OP->AddLog("Could not find new start\n");OP->back=25;}
	}
	return OP->back;
}
void Thresh(void*info,vector initial,vector minlot,
						vector roundw,vector minlot1)
{
	OptParamRound* OP=(OptParamRound*)info;
	size_t n=OP->n;
	size_t m=OP->m;
	vector lower=OP->lower;
	vector upper=OP->upper;
	std::valarray<double>Lkeep(n+m),Ukeep(n+m),naive(n),LL,UU;
	class KeepBest KB(n);
	dcopyvec(n,OP->x,KB.w);
	KB.printstream=OP->Getlogprint();
	dcopyvec(n+m,lower,&Lkeep[0]);
	dcopyvec(n+m,upper,&Ukeep[0]);
	bool changed=0;
	size_t i,nround;
	short back=0;
	bool bad=false;
	for(i=0;i<n;++i)
	{
		double init=initial?initial[i]:0;
		if(upper[i] + lm_eps8 < minlot[i]+init) 
		{
			if(init<upper[i]){upper[i]=dmin(upper[i],(dmax(init,lower[i])));changed=1;}
			else if (init>upper[i]){upper[i]=dmin(upper[i],(dmax(init-minlot[i],lower[i])));changed=1;}
		}
		if(lower[i] - lm_eps8 > init-minlot[i]) 
		{
			if(init>lower[i]){lower[i]=dmax(lower[i],(dmin(init,upper[i])));changed=1;}
			else if(init < lower[i]){lower[i]=dmax(lower[i],(dmin(init+minlot[i],upper[i])));changed=1;}
		}
		if(lower[i]>upper[i])bad=true;
	}
	if(minlot1)
	{
		for(i=0;i<n;++i)
		{
			double init=initial?initial[i]:0;
			if(upper[i] + lm_eps8 < minlot1[i]) 
			{
				if(0<upper[i]){upper[i]=dmin(upper[i],(dmax(0,lower[i])));changed=1;}
				else if(0>upper[i]){upper[i]=dmin(upper[i],(dmax(-minlot1[i],lower[i])));changed=1;}
			}
			if(lower[i] - lm_eps8 > -minlot1[i]) 
			{
				if(0>lower[i]){lower[i]=dmax(lower[i],(dmin(0,upper[i])));changed=1;}
				else if(0<lower[i]){lower[i]=dmax(lower[i],(dmin(minlot1[i],upper[i])));changed=1;}
			}
			if(init!=0&&(init-minlot[i]) < -minlot1[i]&&lower[i] - lm_eps8>dmin((init-minlot[i]),-minlot1[i]))
			{
				if(minlot1[i]>init){lower[i]=dmax(lower[i],dmax(init+minlot[i],minlot1[i]));changed=1;}
				else{lower[i]=dmax(lower[i],init);changed=1;}
			}
			if(init!=0&&(init-minlot[i]) < -minlot1[i]&&upper[i] + lm_eps8<dmax(init+minlot[i],minlot1[i]))
			{
				if(-minlot1[i]<init){upper[i]=dmin(upper[i],dmin((init-minlot[i]),-minlot1[i]));changed=1;}
				else{upper[i]=dmin(upper[i],init);changed=1;}
			}
			if(lower[i]>upper[i])bad=true;
		}
	}
	if(changed)
	{
		OP->AddLog("Changed bounds due to high threshold and reoptimise\n");
		LL.resize(n+m);
		UU.resize(n+m);
		dcopyvec(n+m,&Lkeep[0],&LL[0]);
		dcopyvec(n+m,&Ukeep[0],&UU[0]);
		dcopyvec(n+m,lower,&Lkeep[0]);
		dcopyvec(n+m,upper,&Ukeep[0]);
	}
	if(!bad)
	{
		OP->OptFunc(info);
		back=OP->back;
		if(back<2)
		{
			if(!minlot1)
			{
				if(treestart(OP,true,initial,minlot,0,KB.w)){OP->back=0;}
				dcopyvec(n,KB.w,roundw);
			}
			else
			{
				threshopt(OP,KB,lower,upper,&Lkeep[0],&Ukeep[0],initial,minlot,0,&naive[0],minlot1);
				dcopyvec(n,KB.w,roundw);
				dcopyvec(n,KB.w,OP->x);//To get U1 correct!
//				if(treestart(OP,true,initial,minlot,0,KB.w,minlot1)){OP->back=0;}
//				dcopyvec(n,KB.w,roundw);
			}
			nround=thresh_check(n,roundw,initial,&Lkeep[0],&Ukeep[0],minlot,minlot1,rounderror);
			if(nround!=n)OP->back=2;//Infeasible
		}
		double U1=OP->UtilityFunc(info);
		OP->AddLog("Start from optimum back=%d U=%20.8f\n",OP->back,U1);
		if(initial)
		{
			if(LL.size())
			{
				dcopyvec(n+m,&LL[0],lower);
				dcopyvec(n+m,&UU[0],upper);
			}
			else
			{
				dcopyvec(n+m,&Lkeep[0],lower);
				dcopyvec(n+m,&Ukeep[0],upper);
			}
			for(i=0;i<n;++i)
			{
				lower[i]=dmax((initial[i]-1e-8),lower[i]);
				upper[i]=dmin((initial[i]+1e-8),upper[i]);
				if(lower[i]>upper[i])bad=true;
			}
			if(!bad)OP->OptFunc(info);
			dcopyvec(n+m,&Lkeep[0],lower);
			dcopyvec(n+m,&Ukeep[0],upper);
//			OP->AddLog("back %d bad %d\n",OP->back,bad);
			if(!bad && OP->back<2)
			{
//			OP->AddLog("back %d bad %d\n",OP->back,bad);
				dcopyvec(n,initial,OP->x);
				if(!minlot)
				{
					if(treestart(OP,true,initial,minlot,0,KB.w)){OP->back=0;}
				}
				else
				{
					threshopt(info,KB,lower,upper,&Lkeep[0],&Ukeep[0],initial,minlot,0,&naive[0],minlot1);
//					if(treestart(OP,true,initial,minlot,0,KB.w,minlot1)){OP->back=0;}
				}
				nround=thresh_check(n,KB.w,initial,&Lkeep[0],&Ukeep[0],minlot,minlot1,rounderror);
				if(nround!=n)OP->back=2;//Infeasible
				dcopyvec(n,KB.w,OP->x);//To get U2 correct!
				double U2=OP->UtilityFunc(info);
				OP->AddLog("Start from initial back=%d U=%20.8f\n",OP->back,U2);
				if(U2>U1||OP->back>1)
				{
					dcopyvec(n,roundw,OP->x);
					dcopyvec(n,roundw,KB.w);
					OP->back=0;
				}
				else
				{
					back=OP->back;
				}
			}
			else
			{
				OP->back=back;
				dcopyvec(n,roundw,OP->x);
				dcopyvec(n,roundw,KB.w);
				bad=false;
			}
		}
	}
	if(LL.size())//We musn't lose the original bounds
	{
		dcopyvec(n+m,&LL[0],lower);
		dcopyvec(n+m,&UU[0],upper);
	}
	else
	{
		dcopyvec(n+m,&Lkeep[0],lower);
		dcopyvec(n+m,&Ukeep[0],upper);
	}
	if(bad)
	{
		OP->back=2;return;
	}
	if(KB.back!=-1)KB.Message();
	dcopyvec(n,KB.w,roundw);
	if(OP->back==25)OP->back=0;
	if(OP->back<2)
	{
		double compromise = lm_rooteps; bad = false;
		for(i=0;i<n;++i)
		{
			double init=initial?initial[i]:0;
			if(fabs(fabs(roundw[i])-fabs(round_weight(roundw[i],init,minlot[i],0))) > compromise && fabs(fabs(roundw[i]-init)-minlot[i])>compromise)
			{
				if (init) { OP->AddLog("Threshold constraint failed for trade %d; threshold is %e\n", i + 1, roundw[i] - init);  }
				else { OP->AddLog("Threshold constraint failed for stock %d; threshold is %e\n", i + 1, roundw[i] - init);  }
				if (init) { printf("Threshold constraint failed for trade %d; threshold is %e\n", i + 1, roundw[i] - init); bad = true; }
				else { printf("Threshold constraint failed for stock %d; threshold is %e\n", i + 1, roundw[i] - init); bad = true; }
			}
			if(minlot1&&fabs(fabs(roundw[i])-fabs(round_weight(roundw[i],0,minlot1[i],0))) > compromise && fabs(fabs(roundw[i])-minlot1[i])>compromise)
			{
				OP->AddLog("Threshold constraint failed for stock %d; threshold is %e\n", i + 1, roundw[i]);
				printf("Threshold constraint failed for stock %d; threshold is %e\n", i + 1, roundw[i]); bad = true;
			}
		}
		nround=thresh_check(n,roundw,initial,lower,upper,minlot,minlot1,rounderror);
		OP->AddLog("first  check %d\n",nround);
		nround=thresh_check(n,roundw,initial,lower,upper,minlot,minlot1,compromise);
		OP->AddLog("second check %d\n",nround);
	}
	if(bad)OP->back=2;
}

class roundstep
{
public:
	double util;
	vector L;
	vector U;
	vector kL;
	vector kU;
	vector w;
	OptParamRound*info;
	class roundstep*next;
	class roundstep*prev;
	size_t nround;
	short back;
	size_t* bound_order;
	short* can_repeat;
	size_t count;
	bool success;
};
void treenext(class roundstep*rstep,vector initial,vector minlot,
						vector sizelot,bool passedfromthresh=false,vector thresh=0)
{
	OptParamRound*info=rstep->info;
	dimen n=info->n;
	dimen m=info->m;
	size_t firstlim=n/*(n<100)?n:5*/,roundy=n;
	int stuck;
	vector x=info->x;//,c=info->c,H=info->H;
	std::valarray<double>bound_error(n);

	if(rstep->prev)
	{
		dcopyvec(m+n,rstep->L,info->lower);
		dcopyvec(m+n,rstep->U,info->upper);
	//	info->OptSetup(basket,trades);
		info->OptFunc(info);
	//	rstep->util=info->utility_base(n,x,c,H);
		rstep->util=info->UtilityFunc(info);
		rstep->back=info->back;
		dcopyvec(n,x,rstep->w);
		dcopyvec(m+n,rstep->kL,info->lower);
		dcopyvec(m+n,rstep->kU,info->upper);
	}


	rstep->nround=0;
	bool fixup=false;
	size_t i,j,i6=0;
	double init,nwL,nwU;
	long dd;
	class roundstep *next=rstep->next=new class roundstep,*roundstuck;
	if(!next) return;
	next->can_repeat=rstep->can_repeat;
	next->success=rstep->success;

	next->kL=rstep->kL;
	next->kU=rstep->kU;
	next->L=new double[n+m];
	next->U=new double[n+m];
	next->w=new double[n];
	next->bound_order=new size_t[n];
	if(!(next->L&&next->U&&next->w&&next->bound_order))	return;
	next->prev=rstep;
	next->info=info;
	next->next=0;
	next->nround=0;
	next->util=lm_max;
	next->count=next->prev->count+1;
	next->back=info->back;
	if(rstep->prev&&rstep->prev->nround==n&&rstep->back<2)
	{
		rstep->back=6;fixup=true;
	}
	else
		fixup=false;

	while(rstep->back==6&&i6<n)
	{
		for(j=i6;j<n;++j)
		{
			dd=0;
			if(rstep->prev&&rstep->prev->nround==n)
				i=rstep->prev->bound_order[j];
			else
				i=rstep->bound_order[j];
			init=initial?initial[i]:0;
			if(rstep->L[i]==rstep->kL[i]&&rstep->U[i]==rstep->kU[i]){i6++;continue;}
			else
			{
				if(rstep->prev&&rstep->prev->L[i]==rstep->kL[i]&&rstep->prev->U[i]==rstep->kU[i])
				{
					if(rstep->U[i]==rstep->kU[i])
					{
						if(sizelot&&sizelot[i]>lm_eps)
						{
							dd=digitisei(rstep->prev->w[i],init,minlot[i],sizelot[i]);
							if(rstep->prev->w[i]>init)
							{
								nwL=digit2w(rstep->prev->w[i],init,dd,minlot[i],sizelot[i]);
								nwU=digit2w(rstep->prev->w[i],init,dd+1,minlot[i],sizelot[i]);
							}
							else
							{
								nwL=digit2w(rstep->prev->w[i],init,dd-1,minlot[i],sizelot[i]);
								nwU=digit2w(rstep->prev->w[i],init,dd,minlot[i],sizelot[i]);
							}
						}
						else if(rstep->prev->w[i]>=init)
						{
							nwL=init;
							nwU=minlot[i]+init;
						}
						else if(rstep->prev->w[i]<init)
						{
							nwU=init;
							nwL=-minlot[i]+init;
						}
						rstep->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->kU[i]));
						rstep->L[i]=rstep->kL[i];
					}
					else if(rstep->L[i]==rstep->kL[i])
					{
						if(sizelot&&sizelot[i]>lm_eps)
						{
							dd=digitisei(rstep->prev->w[i],init,minlot[i],sizelot[i]);
							if(rstep->prev->w[i]>init)
							{
								nwL=digit2w(rstep->prev->w[i],init,dd,minlot[i],sizelot[i]);
								nwU=digit2w(rstep->prev->w[i],init,dd+1,minlot[i],sizelot[i]);
							}
							else
							{
								nwL=digit2w(rstep->prev->w[i],init,dd-1,minlot[i],sizelot[i]);
								nwU=digit2w(rstep->prev->w[i],init,dd,minlot[i],sizelot[i]);
							}
						}
						else if(rstep->prev->w[i]>=init)
						{
							nwL=init;
							nwU=minlot[i]+init;
						}
						else if(rstep->prev->w[i]<init)
						{
							nwU=init;
							nwL=-minlot[i]+init;
						}
						if(fabs((nwU-(rstep->prev->w[i]))-(rstep->prev->w[i]-nwL))< lm_rooteps)
						{
							if(rstep->L[i]==rstep->kL[i])
							{
								rstep->L[i]=dmin(rstep->kU[i],dmax(nwU,rstep->L[i]));
								rstep->U[i]=rstep->kU[i];
							}
							else if(rstep->U[i]==rstep->kU[i])
							{
								rstep->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->U[i]));
								rstep->L[i]=rstep->kL[i];
							}
						}
						else
						{
							rstep->L[i]=dmin(rstep->kU[i],dmax(nwU,rstep->kL[i]));
							rstep->U[i]=rstep->kU[i];
						}
					}
				}
				else
				{
					double wuse=fixup?rstep->w[i]:rstep->prev->w[i];
					if(sizelot&&sizelot[i]>lm_eps)
					{
						dd=digitisei(wuse,init,minlot[i],sizelot[i]);
						if(wuse>init)
						{
							nwL=dmax((digit2w(wuse,init,dd-1,minlot[i],sizelot[i])),rstep->kL[i]);
							nwU=dmin((digit2w(wuse,init,dd+1,minlot[i],sizelot[i])),rstep->kU[i]);
						}
						else
						{
							nwL=dmax((digit2w(wuse,init,dd-1,minlot[i],sizelot[i])),rstep->kL[i]);
							nwU=dmin((digit2w(wuse,init,dd+1,minlot[i],sizelot[i])),rstep->kU[i]);
						}
					}
					else if(wuse>=init)
					{
						nwL=init;
						nwU=minlot[i]+init;
					}
					else if(wuse<init)
					{
						nwU=init;
						nwL=-minlot[i]+init;
					}
					if(wuse>rstep->U[i])
					{
						rstep->U[i]=rstep->kU[i];
						rstep->L[i]=dmax(nwU,rstep->kL[i]);
					}
					else if(wuse<rstep->L[i])
					{
						rstep->L[i]=rstep->kL[i];
						rstep->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->kU[i]));
					}
					else if(rstep->prev&&rstep->prev->nround==n)
					{
						if(rstep->L[i]==rstep->kL[i])
						{
							rstep->U[i]=rstep->kU[i];
							rstep->L[i]=dmin(rstep->kU[i],dmax(nwU,rstep->kL[i]));
						}
						else if(rstep->U[i]==rstep->kU[i])
						{
							rstep->L[i]=rstep->kL[i];
							rstep->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->kU[i]));
						}
						else if(wuse==rstep->L[i])
						{
							rstep->L[i]=rstep->kL[i];
							rstep->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->kU[i]));
						}
						else if(wuse==rstep->U[i])
						{
							rstep->U[i]=rstep->kU[i];
							rstep->L[i]=dmin(rstep->kU[i],dmax(nwU,rstep->kL[i]));
						}
					}
				}
				i6=j+1;break;
			}
		}
		dcopyvec(m+n,rstep->L,info->lower);
		dcopyvec(m+n,rstep->U,info->upper);
//		info->OptSetup(basket,trades);
		info->OptFunc(info);
//		rstep->util=info->utility_base(n,x,c,H);
		rstep->util=info->UtilityFunc(info);
		rstep->back=info->back;
		if(rstep->back==6)
		{
			j=i6-1;
			i=rstep->bound_order[j];
			if(rstep->U[i]==rstep->kU[i])//&&rstep->prev->bound_order[j]!=rstep->bound_order[j])
			{
				rstep->U[i]=rstep->L[i];
				rstep->L[i]=rstep->kL[i];
			}
			else if(rstep->L[i]==rstep->kL[i])//&&rstep->prev->bound_order[j]!=rstep->bound_order[j])
			{
				rstep->L[i]=rstep->U[i];
				rstep->U[i]=rstep->kU[i];
			}
			dcopyvec(n,rstep->w,x);
		}
		dcopyvec(n,x,rstep->w);
		dcopyvec(m+n,rstep->kL,info->lower);
		dcopyvec(m+n,rstep->kU,info->upper);
	}
	dcopyvec(m+n,rstep->L,next->L);
	dcopyvec(m+n,rstep->U,next->U);
	double switch1=1;
	for(i=0;i<n;++i)
	{
		init=initial?initial[i]:0;dd=0;
		if(sizelot&&sizelot[i]>lm_eps)
		{
			dd=digitisei(x[i],init,minlot[i],sizelot[i]);
			if(x[i]>init)
			{
				nwL=digit2w(x[i],init,dd,minlot[i],sizelot[i]);
				nwU=digit2w(x[i],init,dd+1,minlot[i],sizelot[i]);
			}
			else
			{
				nwL=digit2w(x[i],init,dd-1,minlot[i],sizelot[i]);
				nwU=digit2w(x[i],init,dd,minlot[i],sizelot[i]);
			}
			if(fabs(x[i]-nwL)<round_eps || fabs(x[i]-nwU)<round_eps || x[i] == init)
			{
				bound_error[i]=i;
				rstep->nround++;
				continue;
			}
			if((nwU-(x[i]))/(x[i]-nwL)<switch1)
			{
				if(nwU>=rstep->L[i])
					bound_error[i]=n+nwU-(x[i]);
				else
					bound_error[i]=n+x[i]-nwL;
			}
			else
			{
				if(nwL<=rstep->U[i])
					bound_error[i]=n+x[i]-nwL;
				else
					bound_error[i]=n+nwU-(x[i]);
			}
		}
		else
		{
			if(!thresh || fabs(x[i])>=thresh[i] || x[i]==0)
			{
				if(fabs(x[i]-init)>=minlot[i]||x[i]==init)
				{
					bound_error[i]=i;
					rstep->nround++;
					continue;
				}
				else
					bound_error[i]=n+fabs(x[i]-init);
			}
			else
			{
				bound_error[i]=n+dmax(fabs(x[i]),(fabs(x[i]-init)));
			}
		}
	}
	info->AddLog("first nround=%d\n",rstep->nround);
	/*if(!sizelot)rstep->nround=thresh_check(n,x,initial,rstep->kL,rstep->kU,minlot,0,round_eps);
	else*/ rstep->nround=round_check(n,x,initial,rstep->kL,rstep->kU,minlot,sizelot,round_eps);
	info->AddLog("then  nround=%d\n",rstep->nround);
	getorder(n,&bound_error[0],next->bound_order,0);//printorder(n,next->bound_order);
//	for(j=rstep->nround;j<min(n/4+rstep->nround,n);++j)
	roundy=max(((long)(rstep->nround*.5+n*.5)),(rstep->nround+1));
//	stuck=(rstep->prev&&(rstep->prev->nround==rstep->nround))?true:false;
	stuck=0;roundstuck=rstep;
	while(roundstuck->prev&&(roundstuck->prev->nround==roundstuck->nround))
	{
		stuck++;
		roundstuck=roundstuck->prev;
	}
	for(j=0;j<min(max(1,roundy),n);++j)
	{
//		i=next->bound_order[n-j-1];
		i=next->bound_order[j];dd=0;
		init=initial?initial[i]:0;
		if(sizelot&&sizelot[i]>lm_eps)
		{
			dd=digitisei(x[i],init,minlot[i],sizelot[i]);
			if(x[i]>init)
			{
				if(!(j%2&&next->count%2))
				{
					nwL=digit2w(x[i],init,dd-1,minlot[i],sizelot[i]);
					nwU=digit2w(x[i],init,dd+(long)stuck,minlot[i],sizelot[i]);
					if(nwL<rstep->kL[i])
					{
						nwL=digit2w(x[i],init,dd,minlot[i],sizelot[i]);
						nwU=digit2w(x[i],init,dd+1+(long)stuck,minlot[i],sizelot[i]);
					}
				}
				else
				{
					nwL=digit2w(x[i],init,dd,minlot[i],sizelot[i]);
					nwU=digit2w(x[i],init,dd+1+(long)stuck,minlot[i],sizelot[i]);
				}
			}
			else
			{
				if(!(j%2&&next->count%2))
				{
					nwL=digit2w(x[i],init,dd-(long)stuck,minlot[i],sizelot[i]);
					nwU=digit2w(x[i],init,dd+1,minlot[i],sizelot[i]);
					if(nwU>rstep->kU[i])
					{
						nwL=digit2w(x[i],init,dd-1-(long)stuck,minlot[i],sizelot[i]);
						nwU=digit2w(x[i],init,dd,minlot[i],sizelot[i]);
					}
				}
				else
				{
					nwL=digit2w(x[i],init,dd-1-(long)stuck,minlot[i],sizelot[i]);
					nwU=digit2w(x[i],init,dd,minlot[i],sizelot[i]);
				}
			}
			//info->AddLog("closeness %d %e %e %e\n",i,x[i]-nwL,x[i]-nwU,x[i]);
			if(fabs(x[i]-nwL)<round_eps || fabs(x[i]-nwU)<round_eps || x[i] == init)
			{
				continue;
				//				break;
			}
			if(fabs((nwU-(x[i]))-(x[i]-nwL))< lm_rooteps)
			{
				if(false&&!(j%2&&next->count%2))
				{
					next->L[i]=dmin(rstep->kU[i],dmax(nwU,rstep->L[i]));
				}
				else if(false)
				{
					next->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->U[i]));
				}
			}
			else if((nwU-(x[i]))/(x[i]-nwL)<switch1)
			{
				if(nwU>=rstep->L[i]&&nwU<=rstep->kU[i])
					next->L[i]=dmin(rstep->kU[i],dmax(nwU,rstep->L[i]));
				else
					next->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->U[i]));
			}
			else
			{
				if(nwL<=rstep->U[i]&&nwL>=rstep->kL[i])
					next->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->U[i]));
				else
					next->L[i]=dmin(rstep->kU[i],dmax(nwU,rstep->L[i]));
			}
			if(next->U[i]<next->L[i])
			{
				if(x[i]>init)
				{
					next->L[i]=dmin(rstep->kU[i],dmax(nwU,rstep->kL[i]));
					next->U[i]=rstep->kU[i];
				}
				else if(x[i]<init)
				{
					next->U[i]=dmax(rstep->kL[i],dmin(nwL,rstep->kU[i]));
					next->L[i]=rstep->kL[i];
				}
				else
				{
					next->U[i]=dmax(rstep->kL[i],dmin(init,rstep->kU[i]));
					next->L[i]=rstep->kL[i];
				}
				//printf("bound problem\n");
			}
//			printf("%3d %20.8e %20.8e %20.8e trade %20.8e\n",i,next->L[i],next->U[i],x[i],x[i]-init);
		}
		else
		{
			i=next->bound_order[j];
			if(!thresh || fabs(x[i])>=thresh[i] || x[i]==0)
			{
				if(!(rstep->nround==n&&fabs(fabs(x[i]-init)-minlot[i])<lm_eps8)&&((fabs(x[i]-init)>=fabs(minlot[i])||x[i]==init)))
				{
					continue;
				}
				if(fabs(minlot[i])-fabs(x[i]-init)<fabs(x[i]-init)*switch1)
				{
					if(x[i]-init>0)
					{
						next->L[i]=dmax(dmin(rstep->kU[i],minlot[i]+init),rstep->kL[i]);
						next->L[i]=dmin(next->U[i],next->L[i]);
					}
					else
					{
						next->U[i]=dmin(dmax(rstep->kL[i],-minlot[i]+init),rstep->kU[i]);
						next->U[i]=dmax(next->U[i],next->L[i]);
					}
				}
				else
				{
					next->U[i]=dmin(dmax(rstep->kL[i],init),rstep->kU[i]);
					next->L[i]=dmax(dmin(rstep->kU[i],init),rstep->kL[i]);
				}	
				if(rstep->nround==n&&fabs(fabs(x[i]-init)-minlot[i])<lm_eps8&&rstep->can_repeat[i])
				{
					if(rstep->can_repeat[i]==3)
					{
						rstep->can_repeat[i]--;
						if(rstep->kL[i]<init+lm_eps8 && x[i] > init)
						{
							next->L[i]=init+minlot[i];//rstep->kL[i] next time
							next->U[i]=dmin(init+minlot[i],rstep->kU[i]);
						}
						else if(rstep->kU[i]>init-lm_eps8 && x[i] < init)
						{
							next->U[i]=init-minlot[i];//rstep->kU[i] next time
							next->L[i]=dmax(rstep->kL[i],init-minlot[i]);
						}
					}
					else if(rstep->can_repeat[i]==2)
					{
						rstep->can_repeat[i]--;
						if(rstep->kL[i]<init+lm_eps8 && x[i] > init)
						{
							next->L[i]=init+minlot[i];//rstep->kL[i] next time
							next->U[i]=rstep->kU[i];
						}
						else if(rstep->kU[i]>init-lm_eps8 && x[i] < init)
						{
							next->U[i]=init-minlot[i];//rstep->kU[i] next time
							next->L[i]=rstep->kL[i];
						}
					}
					else if(rstep->can_repeat[i]==1)
					{
						rstep->can_repeat[i]--;
						next->L[i]=rstep->kL[i];
						next->U[i]=rstep->kU[i];
					}
				}
			}
			else if(fabs(minlot[i])-fabs(x[i]-init)<fabs(x[i]-init)*switch1)
			{
				if(fabs(minlot[i])-fabs(x[i]-init)<fabs(x[i]-init)*switch1 && fabs(thresh[i])-fabs(x[i])<fabs(x[i])*switch1)
				{
					if(x[i]-init>0)
						next->L[i]=dmax(dmin(rstep->kU[i],dmax(thresh[i],minlot[i]+init)),rstep->kL[i]);
					else
						next->U[i]=dmin(dmax(rstep->kL[i],dmin(-thresh[i],-minlot[i]+init)),rstep->kU[i]);
				}
				else
				{
					if(x[i]-init>0)
						next->L[i]=dmax(dmin(rstep->kU[i],dmax(thresh[i],init)),rstep->kL[i]);
					else
						next->U[i]=dmin(dmax(rstep->kL[i],dmin(-thresh[i],init)),rstep->kU[i]);
				}	
			}
			else
			{
				if(x[i]-init>0)
					next->L[i]=dmax(dmin(rstep->kU[i],0),rstep->kL[i]);
				else
					next->U[i]=dmin(dmax(rstep->kL[i],0),rstep->kU[i]);
			}	
		}
	}
	if(rstep->nround==n&&next->count==2&&rstep->back<=1){rstep->util=info->UtilityFunc(info);return;}
	if(!next->success&&rstep->nround==n&&rstep->back<=1)
		next->success=true;
	if(rstep->nround==n&&passedfromthresh&&next->count>20){rstep->util=info->UtilityFunc(info);return;}
	if((rstep->nround<n&&next->count<(firstlim*2)&&!next->success)||(next->count<firstlim/*&&info->TimeOptData==0*/))
	{
		info->AddLog("stage %d %d rounded\n",next->count,rstep->nround);
//		_ASSERT(next->count<7);
		treenext(next,initial,minlot,sizelot,passedfromthresh,thresh);
	}
}
bool treestart(class OptParamRound*info,bool passedfromthresh,vector initial,vector minlot,
						vector sizelot,vector roundw,vector thresh)
{
	size_t i;
	dimen n=info->n;
	dimen m=info->m;
	vector x=info->x;//At the start this is the unrounded optimal solution
	class roundstep *next=new class roundstep,*start,*prev;
	next->can_repeat=new short[n];
	set_repeat(n,(short)3,next->can_repeat);

	next->success=false;
	next->count=1;
	next->kL=new double[n+m];
	next->kU=new double[n+m];
	dcopyvec(n+m,info->lower,next->kL);
	dcopyvec(n+m,info->upper,next->kU);
	next->L=new double[n+m];
	next->U=new double[n+m];
	next->w=new double[n];
	next->bound_order=new size_t[n];for(i=0;i<n;++i) next->bound_order[i]=i;
	next->prev=0;
	next->info=info;
	next->back=info->back;
	dcopyvec(n,x,next->w);
	dcopyvec(m+n,next->kL,next->L);
	dcopyvec(m+n,next->kU,next->U);
	treenext(next,initial,minlot,sizelot,passedfromthresh,thresh);//すぎの木
	start=next;
	while(next)
	{
		prev=next;
		next=next->next;
	}
	double ulow=lm_max;
	bool back=false;
	size_t nround=0;
	if(prev->prev&&prev->prev->back<2)
	{
		dcopyvec(n,prev->prev->w,roundw);
		info->AddLog("%d Rounded at level %d\n",prev->prev->nround,prev->prev->count);
	}
	if(prev->nround==n&&prev->back<2)
	{
		dcopyvec(n,prev->w,roundw);
		ulow=prev->util;
		info->back=prev->back;
		back=true;
	}
	while(prev)
	{
		if(prev->nround>nround)
		{
			dcopyvec(n,prev->w,roundw);nround=prev->nround;
		}
		if(prev->nround==n && ulow>prev->util&&prev->back<2)
		{
			dcopyvec(n,prev->w,roundw);
			ulow=prev->util;
			info->back=prev->back;
			back=true;
		}
		delete[] prev->L;
		delete[] prev->U;
		delete[] prev->w;
		delete[] prev->bound_order;
		if(prev==start)
		{
			delete[] start->kL;
			delete[] start->kU;
			delete[] start->can_repeat;
		}
		prev=prev->prev;
		if(prev)delete prev->next;
	}
	if(start)delete start;
	info->AddLog("%d stocks were rounded properly\n",nround);
	return back;
}	

extern "C" DLLEXPORT short Droptwo(void*info,dimen basket,dimen trades,bool SOCP=false,bool onlyfast=false,bool revway=false)
{
	double baskthresh=lm_eps;//was 1e-8 seems better to have it small
	size_t bbelow=0,tbelow=0;
	size_t badlim=50;
	size_t breset=0,treset=0;
	OptParamRound*GET=(OptParamRound*)info;
//	ExtraR*OP=(ExtraR*)(GET->MoreInfo);
	dimen n=GET->n;
	dimen m=GET->m;
	vector x=GET->x;
	vector lower=GET->lower;
	vector upper=GET->upper;
//________________________________________________
	dimen mabs=GET->mabs;
	int lp=GET->lp;
	long longbasket=GET->longbasket;
	long shortbasket=GET->shortbasket;
	long tradebuy=GET->tradebuy;
	long tradesell=GET->tradesell;
	vector initial=GET->initial;
	size_t zerosi=initial?zeros_in_initial(n,initial):0;
	double equalbounds=GET->equalbounds,stucku=lm_max;
	double dropfac=GET->dropfac;
//________________________________________________
	if((long) trades<0)trades=n;
	if((long) basket<0)basket=n;
	size_t basketnow,tradesnow,basket1,trades1,makez,ib,blow=0,tlow=0,tdone=0,bdone=0,tpdone=0,bpdone=0;
        bool first_time_to_optimise=false;
        double uquick=lm_max,u,init;
	DropResult OldResults;
	bool onesided=true,wasstuck=false;
	size_t basketnow1,tradesnow1;
	if(basket<=n && longbasket>-1 && shortbasket==(long)n)shortbasket=max(0,(long)basket-longbasket);
	else if(basket<n && longbasket==(long)n && shortbasket>-1)longbasket=max(0,(long)basket-shortbasket);
	if(trades<=n && tradebuy>-1 && tradesell==(long)n)tradesell=max(0,(long)trades-tradebuy);
	else if(trades<n && tradebuy==(long)n && tradesell>-1)tradebuy=max(0,(long)trades-tradesell);
	short back=0;
	bool nogood=false,notradelim=(trades==n),nobasklim=(basket==n);
	if(nobasklim)
	{
		longbasket=shortbasket=-1;
	}
	if(notradelim)
	{
		tradebuy=tradesell=-1;
	}
	size_t i;
	int way,iway;
	std::valarray<unsigned char> dropbadb(n),dropbadt(n);
	dropbadb=(unsigned char)0;
	dropbadt=(unsigned char)0;
	std::valarray<double> keept(n);
	if(initial)
		dsubvec(n,x,initial,&keept[0]);
	else
		dcopyvec(n,x,&keept[0]);
	long Nlong,Nshort,Nlong1,Nshort1;
	long Nbuy,Nsell,Nbuy1,Nsell1;
	basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
	tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);
	if(longbasket==-1&&shortbasket==-1&&tradebuy==-1&&tradesell==-1)
	{
		if(basketnow<=basket && tradesnow <= trades)
			return GET->back;
	}
	else if(Nlong<=longbasket&&Nshort<=shortbasket&&tradebuy==-1&&tradesell==-1)
			return GET->back;
	else if(longbasket==-1&&shortbasket==-1&&Nbuy<tradebuy&&Nsell<=tradesell)
			return GET->back;
	setbadness(n,lower,upper,&dropbadb[0],&dropbadt[0],initial,equalbounds);
/*	for(i=0;i<n;++i)
	{
		if(fabs(lower[i]-upper[i])<=equalbounds)
		{
			if(fabs(lower[i])>equalbounds+lm_eps)
				dropbadb[i]=1;
			if(fabs(lower[i]-(initial?initial[i]:0))>equalbounds+lm_eps)
				dropbadt[i]=1;
		}
	}

	for(i=0;i<n;++i)
	{
		if(lower[i]>lm_eps || upper[i]<-lm_eps)
			dropbadb[i]=1;
		if(lower[i]>(initial?initial[i]:0)+lm_eps || upper[i]<(initial?initial[i]:0)-lm_eps)
			dropbadt[i]=1;
	}*/
	std::valarray<double> first(n);
	std::valarray<double> keepx(n);
	std::valarray<double> quick(n);
	std::valarray<double> keepL(n+m);
	std::valarray<double> keepU(n+m);

	std::valarray<size_t> basketorder(n);
	std::valarray<size_t> tradeorder(n);

	dcopyvec(n,x,&keepx[0]);
	dcopyvec(n,x,&first[0]);//Use for fast double drop only
	if(initial)
		dsubvec(n,x,initial,&keept[0]);
	else
		dcopyvec(n,x,&keept[0]);
	dcopyvec(n+m,lower,&keepL[0]);
	dcopyvec(n+m,upper,&keepU[0]);

	if(mabs)
	{
		modifyorder2(n,&keepx[0],&basketorder[0],&dropbadb[0],-1,-1,GET);
		modifyorder2(n,&keept[0],&tradeorder[0],&dropbadt[0],-1,-1,GET,true);
	}
	else
	{
		modifyorder2(n,&keepx[0],&basketorder[0],&dropbadb[0],longbasket,shortbasket,GET);
		modifyorder2(n,&keept[0],&tradeorder[0],&dropbadt[0],tradebuy,tradesell,GET,true);
	}

	basketnow1=basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
	Nlong1=Nlong;Nshort1=Nshort;
	tradesnow1=tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);
	Nbuy1=Nbuy;Nsell1=Nsell;

	if(initial&&tradesnow1<=trades)
	{
		long ibask=sizenow(n,initial,baskthresh,Nlong,Nshort),idiff;
		idiff=((long)basket-ibask);
		if(idiff<2&&idiff>-2)
			modifyorder2(n,initial,&basketorder[0],&dropbadb[0],-1,-1,lp?GET:0);
	}
	long buyset=-1,longset=-1;
	size_t kp,kn,itop;
	long sellset=-1,shortset=-1;
	short doingbasketsortrades=0;

	if((Nbuy>tradebuy || Nsell>tradesell) && tradebuy!=-1&& tradesell!=-1)
	{
		buyset=tradebuy;
		sellset=tradesell;
		for(i=0,kp=0,kn=0;i<n;++i)
		{
			ib=tradeorder[i];
			if(keept[ib]>round_eps && kp<(size_t)buyset){kp++;continue;}
			if(keept[ib]<-round_eps && kn<(size_t)sellset){kn++;continue;}
			break;
		}
		itop=n-i;
		for(i=0,makez=0;i<itop&&makez<n;++i)
		{
			ib=tradeorder[n-i-1];
			init=(initial?initial[ib]:0);
			if(dropbadt[ib])
			{
				GET->AddLog("ERROR in Droptwo %d",__LINE__);nogood=true;
			}
			else if(upper[ib]-lower[ib]>equalbounds&& 
				(init<=upper[ib]) && (init>=lower[ib]))
			{
				lower[ib]=upper[ib]=init;makez++;
			}
			else if(fabs(keept[ib])<=round_eps)
				makez++;
		}
		if(nogood && makez==n)
			nogood=false;
		if(nogood)back=6;

//		checkbound(n,initial,lower,upper);
		back=GET->OptFunc(info);
//		OP->OptSetup(n);
//		checkbound(n,initial,lower,upper,x);
//		back=GET->back;
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(back==6||back==16) 
		{
			dcopyvec(n,&keepx[0],x);
			//			if(!mabs)return back;
			if((tradesnow-trades) > 10)dropfac=.2;
			else dropfac=.99;
			GET->AddLog("basketnow %d (%d) line %d tradesnow %d (%d) dropfac set to %f\n",basketnow,basket,__LINE__,tradesnow,trades,dropfac);
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);

		basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);

		if(!mabs&&(Nbuy<=tradebuy) && (Nsell<=tradesell) && basketnow <= basket 
			&& longbasket==-1 && shortbasket==-1)
		{
			if(back<=1)
			{
				dcopyvec(n,x,&quick[0]);
				//uquick=OP->utility_base(n,x,c,OP->H);
				uquick=GET->UtilityFunc(info);
				GET->AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		else if((Nbuy<=tradebuy) && (Nsell<=tradesell) && basketnow <= basket 
			&& Nlong<=longbasket && Nshort<=shortbasket)
		{
			if(back<=1)
			{
				dcopyvec(n,x,&quick[0]);
				//uquick=OP->utility_base(n,x,c,H);
				uquick=GET->UtilityFunc(info);
				GET->AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		basketnow=basketnow1;
		tradesnow=tradesnow1;
		Nbuy=Nbuy1;
		Nsell=Nsell1;
		Nlong=Nlong1;
		Nshort=Nshort1;
	}
	else if(tradesnow > trades)
	{
		trades1=trades;
		for(i=0,makez=0;i<n&&makez<(n-trades1);++i)
		{
			ib=tradeorder[n-i-1];
			init=(initial?initial[ib]:0);
			if(dropbadt[ib])
			{
				GET->AddLog("ERROR in Droptwo %d",__LINE__);nogood=true;
			}
			else if(upper[ib]-lower[ib]>equalbounds&& 
				(init<=upper[ib]) && (init>=lower[ib]))
			{
				lower[ib]=upper[ib]=init;makez++;
			}
			else if(fabs(keept[ib])<=round_eps)
				makez++;
		}
		if(nogood && makez==(n-trades1))
			nogood=false;
		if(nogood)back=6;

//		checkbound(n,initial,lower,upper);
		back=GET->OptFunc(info);
//		OP->OptSetup(n);
//		checkbound(n,initial,lower,upper,x);
//		back=GET->back;
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(back==6||back==16) 
		{
			dcopyvec(n,&keepx[0],x);
		//	if(!mabs)return back;
			if((tradesnow-trades) > 10)dropfac=.1;
			else dropfac=.99;
			GET->AddLog("basketnow %d (%d) line %d tradesnow %d (%d) dropfac set to %f\n",basketnow,basket,__LINE__,tradesnow,trades,dropfac);
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);

		basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);
		if((basketnow<=basket) && (tradesnow<=trades)
			&& longbasket==-1 && shortbasket==-1)
		{
			if(back<=1)
			{
				dcopyvec(n,x,&quick[0]);
				//uquick=OP->utility_base(n,x,c,H);
				uquick=GET->UtilityFunc(info);
				GET->AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		else if((basketnow<=basket) && (tradesnow<=trades)
			&& Nlong<=longbasket && Nshort<=shortbasket)
		{
			if(back<=1)
			{
				dcopyvec(n,x,&quick[0]);
				//uquick=OP->utility_base(n,x,c,H);
				uquick=GET->UtilityFunc(info);
				GET->AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		basketnow=basketnow1;
		tradesnow=tradesnow1;
		Nbuy=Nbuy1;
		Nsell=Nsell1;
		Nlong=Nlong1;
		Nshort=Nshort1;
	}
	if(!mabs&&(Nlong > longbasket || Nshort > shortbasket) && longbasket!=-1 && shortbasket!=-1)
	{
		longset=longbasket;
		shortset=shortbasket;
		dcopyvec(n,&keepx[0],x);
		basket1=basket;
		for(i=0,kp=0,kn=0;i<n;++i)
		{
			ib=basketorder[i];
			if(keepx[ib]>round_eps && kp<(size_t)longset){kp++;continue;}
			if(keepx[ib]<-round_eps && kn<(size_t)shortset){kn++;continue;}
			break;
		}
		itop=n-i;
		for(i=0,makez=0;i<itop&&makez<n;++i)
		{
			ib=basketorder[n-i-1];
			if(dropbadb[ib])
			{
				GET->AddLog("ERROR in Droptwo %d",__LINE__);nogood=true;
			}
			else if(upper[ib]-lower[ib]>equalbounds&& 
				0<=upper[ib] && 0>=lower[ib])
			{
				lower[ib]=upper[ib]=0;makez++;
			}
			else if(fabs(x[ib])<=round_eps)
				makez++;
		}
		if(nogood && makez==n)
			nogood=false;
		if(nogood)back=6;

//		checkbound(n,initial,lower,upper);
		back=GET->OptFunc(info);
//		OP->OptSetup(n);
//		checkbound(n,initial,lower,upper,x);
//		back=GET->back;
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(back==6||back==16) 
		{
			dcopyvec(n,&keepx[0],x);
//			if(!mabs)return back;
			if((basketnow-basket) > 10)dropfac=.1;
			else dropfac=.99;
			GET->AddLog("basketnow %d (%d) line %d tradesnow %d (%d) dropfac set to %f\n",basketnow,basket,__LINE__,tradesnow,trades,dropfac);
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);

		basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);
		if((Nlong<=longbasket) &&(Nshort<=shortbasket) && (tradesnow<=trades)&&
			tradebuy==-1&&tradesell==-1)
		{
			if(uquick>(u=GET->UtilityFunc(info)/*OP->utility_base(n,x,c,H)*/)&&back<=1)
			{
				dcopyvec(n,x,&quick[0]);
				uquick=u;
				GET->AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		else if((Nlong<=longbasket) &&(Nshort<=shortbasket) && (tradesnow<=trades)&&
			Nbuy<=tradebuy&&Nsell<=tradesell)
		{
			if(uquick>(u=GET->UtilityFunc(info)/*u=OP->utility_base(n,x,c,H)*/)&&back<=1)
			{
				dcopyvec(n,x,&quick[0]);
				uquick=u;
				GET->AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		basketnow=basketnow1;
		tradesnow=tradesnow1;
		Nbuy=Nbuy1;
		Nsell=Nsell1;
		Nlong=Nlong1;
		Nshort=Nshort1;
		dcopyvec(n,x,&first[0]);//Use for fast double drop only
	}
	else if(basketnow > basket)
	{
		dcopyvec(n,&keepx[0],x);
		basket1=basket;
		for(i=0,makez=0;i<n&&makez<(n-basket1);++i)
		{
			ib=basketorder[n-i-1];
			if(dropbadb[ib])
			{
				GET->AddLog("ERROR in Droptwo %d",__LINE__);nogood=true;
			}
			else if(upper[ib]-lower[ib]>equalbounds&&
				(0<=upper[ib]) && (0>=lower[ib]))
			{
				lower[ib]=upper[ib]=0;makez++;
			}
			else if(fabs(x[ib])<=round_eps)
				makez++;
		}
		if(nogood && makez==(n-basket1))
			nogood=false;
		if(nogood)back=6;

//		checkbound(n,initial,lower,upper);
		back=GET->OptFunc(info);
//		OP->OptSetup(n);
//		checkbound(n,initial,lower,upper,x);
//		back=GET->back;
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(back==6||back==16) 
		{
			dcopyvec(n,&keepx[0],x);
//			if(!mabs)return back;
			if((basketnow-basket) > 10)dropfac=.1;
			else dropfac=.99;
			GET->AddLog("basketnow %d (%d) line %d tradesnow %d (%d) dropfac set to %f\n",basketnow,basket,__LINE__,tradesnow,trades,dropfac);
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);

		basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);
		//u=OP->utility_base(n,x,c,H);
		u=GET->UtilityFunc(info);
		if((basketnow<=basket) && (tradesnow<=trades) && tradebuy==-1&&tradesell==-1)
		{
			int kkkk=0;
			std::valarray<double>kpx(n);
			dcopyvec(n,x,&kpx[0]);
			while(basketnow<basket&&kkkk<10)
			{

				//Use the gradient to give the order of stocks to add back in
				std::valarray<double>xhere(n),/*buysell,*/grad(n);
/*				if(OP->ModCObjectInfo) buysell.resize(n);
				OP->qphess_base(n,1,1,1,H,x,&grad[0]);
				daddvec(n,&grad[0],c,&grad[0]);
				if(OP->ModCObjectInfo)
				{
					buysell=0;
					OP->ResetInitial(0);
					OP->ModDeriv(n,x,&buysell[0],OP->ModCObjectInfo);
					OP->ResetInitial();
					daxpyvec(n,OP->scale_utility_external_terms,&buysell[0],&grad[0]);
				}*/
				GET->grad=&grad[0];
				GET->GradFunc(info);
				//GradientDropOrder(OP,x,&grad[0]);
				modifyorder2(n,&grad[0],&basketorder[0],&dropbadb[0],-1,-1,lp?GET:0);
				dcopyvec(n+m,&keepL[0],lower);
				dcopyvec(n+m,&keepU[0],upper);
				for(i=0,makez=kkkk;i<n&&makez<(n-basket1);++i)
				{
					ib=basketorder[n-i-1];
					if(x[ib]!=0)continue;
					if(dropbadb[ib])
					{
						GET->AddLog("ERROR in Droptwo %d",__LINE__);nogood=true;
					}
					else if(upper[ib]-lower[ib]>equalbounds&&
						(0<=upper[ib]) && (0>=lower[ib]))
					{
						lower[ib]=upper[ib]=0;makez++;
					}
					else if(fabs(x[ib])<=round_eps)
						makez++;
				}
				if(nogood && makez==(n-basket1))
					nogood=false;
				if(nogood)back=6;
				
				//		checkbound(n,initial,lower,upper);
		back=GET->OptFunc(info);
//				OP->OptSetup(n);
				//		checkbound(n,initial,lower,upper,x);
//				back=GET->back;
				if(back==6||back==16) 
				{
					for(i=0;i<n;++i)
					{
						if(fabs(kpx[i])>0)grad[i]*=kpx[i];
					}
					modifyorder2(n,&grad[0],&basketorder[0],&dropbadb[0],-1,-1,lp?GET:0);
					dcopyvec(n+m,&keepL[0],lower);
					dcopyvec(n+m,&keepU[0],upper);
					for(i=0,makez=0;i<n&&makez<(n-basket1);++i)
					{
						ib=basketorder[n-i-1];
						if(x[ib]!=0)continue;
						if(dropbadb[ib])
						{
							GET->AddLog("ERROR in Droptwo %d",__LINE__);nogood=true;
						}
						else if(upper[ib]-lower[ib]>equalbounds&&
							(0<=upper[ib]) && (0>=lower[ib]))
						{
							lower[ib]=upper[ib]=0;makez++;
						}
						else if(fabs(x[ib])<=round_eps)
							makez++;
					}
					if(nogood && makez==(n-basket1))
						nogood=false;
					if(nogood)back=6;
					
					//		checkbound(n,initial,lower,upper);
		back=GET->OptFunc(info);
//					OP->OptSetup(n);
					//		checkbound(n,initial,lower,upper,x);
//					back=GET->back;
				}
				if(initial)
					dsubvec(n,x,initial,&keept[0]);
				else
					dcopyvec(n,x,&keept[0]);
				
				basketnow=sizenow(n,x,10*baskthresh,Nlong,Nshort);
				tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);
				if(basketnow<=basket)
				{
					dcopyvec(n,x,&kpx[0]);
				}
				kkkk++;
			}
			dcopyvec(n,&kpx[0],x);
			if(uquick>(u=GET->UtilityFunc(info)/*u=OP->utility_base(n,x,c,H)*/)&&back<=1)
			{
				dcopyvec(n,x,&quick[0]);
				uquick=u;
				GET->AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		if((basketnow<=basket) && (tradesnow<=trades) && Nbuy<=tradebuy&&Nsell<=tradesell)
		{
			if(uquick>(u=GET->UtilityFunc(info)/*u=OP->utility_base(n,x,c,H)*/)&&back<=1)
			{
				dcopyvec(n,x,&quick[0]);
				uquick=u;
				GET->AddLog("Keep weights with u=%20.10e\n",uquick);
			}
		}
		basketnow=basketnow1;
		tradesnow=tradesnow1;
		Nbuy=Nbuy1;
		Nsell=Nsell1;
		Nlong=Nlong1;
		Nshort=Nshort1;
		dcopyvec(n,x,&first[0]);//Use for fast double drop only
	}

	dcopyvec(n,&first[0],x);//This start is just for fast double drop
	dcopyvec(n,&keepx[0],&first[0]);//Now this really is the first non dropping solution
//	if((long)basket>0 && (long)trades>0 && basket < n && trades < n ) dcopyvec(n,&first[0],x);//This start is just for fast double drop
	if(initial)
		dsubvec(n,x,initial,&keept[0]);
	else
		dcopyvec(n,x,&keept[0]);

	if(mabs)
	{
		modifyorder2(n,&keepx[0],&basketorder[0],&dropbadb[0],-1,-1,GET);
		modifyorder2(n,&keept[0],&tradeorder[0],&dropbadt[0],-1,-1,GET,true);
	}
	else
	{
		modifyorder2(n,&keepx[0],&basketorder[0],&dropbadb[0],longbasket,shortbasket,GET);
		modifyorder2(n,&keept[0],&tradeorder[0],&dropbadt[0],tradebuy,tradesell,GET,true);
	}

	basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
	tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);

	dcopyvec(n+m,&keepL[0],lower);
	dcopyvec(n+m,&keepU[0],upper);


	size_t fast=1;
//	if(lp&&basketnow<=basket&&tradesnow<=trades&&back<=2)fast=0;
	OldResults.basket=basketnow;
	OldResults.trades=tradesnow;
	OldResults.u=lm_max;
	size_t stuck=0,loopc=0,basketlow=n,tradeslow=n;
	while(fast||
		(basketnow>basket&&longbasket==-1&&shortbasket==-1) || 
		(/*basketnow>basket&&*/longbasket>-1&&shortbasket>-1&&(Nlong>longbasket||Nshort>shortbasket)) || 
		(tradesnow>trades&&tradebuy==-1&&tradesell==-1) ||
		(/*tradesnow>trades&&*/tradebuy>-1&&tradesell>-1&&(Nbuy>tradebuy||Nsell>tradesell))
		)
	{
		if(mabs||(longbasket==-1&&shortbasket==-1))
		{
			if(fast){basket1=basket;}
			/*	else if(back==6)
			{
			AddLog("Reset dropbads b and t\n");
			dropbadb=(unsigned char)0;
			dropbadt=(unsigned char)0;
			setbadness(n,lower,upper,&dropbadb[0],&dropbadt[0],initial,equalbounds);
			basket1=basketnow-1;
			}*/
			else 
			{
				/*if(back==6)
				{
				AddLog("Reset dropbads b and t\n");
				dropbadb=(unsigned char)0;
				dropbadt=(unsigned char)0;
				setbadness(n,lower,upper,&dropbadb[0],&dropbadt[0],initial,equalbounds);
				}*/
				basket1=(size_t)dmax((double)(basket/*-1*/),basketnow*(1.0-dropfac) + dropfac*(basket-bbelow));
				if(stuck&&back<=1)basket1-=stuck;
			}
			GET->AddLog("basket1 %d\n",basket1);
		}
		else
		{
			if(fast)
			{
				longset=longbasket;
				shortset=shortbasket;
			}
			else
			{
				longset=(long)dmax((double)longbasket,Nlong*(1.0-dropfac)+dropfac*longbasket);
				shortset=(long)dmax((double)shortbasket,Nshort*(1.0-dropfac)+dropfac*shortbasket);
			}
			basket1=longset+shortset;
			GET->AddLog("longset %d shortset %d\n",longset,shortset);
		}
		if(mabs||(tradebuy==-1&&tradesell==-1))
		{
			if(fast)trades1=trades;
			else trades1=(size_t)dmax((double)(trades/*-1*/),tradesnow*(1.0-dropfac) + dropfac*(trades-tbelow));
			if(stuck&&back<=1)trades1-=stuck;
			GET->AddLog("trades1 %d\n",trades1);
		}
		else
		{
			if(fast)
			{
				buyset=tradebuy;
				sellset=tradesell;
			}
			else
			{
				buyset=(long)dmax((double)tradebuy,Nbuy*(1.0-dropfac)+dropfac*tradebuy);
				sellset=(long)dmax((double)tradesell,Nsell*(1.0-dropfac)+dropfac*tradesell);
			}
			trades1=buyset+sellset;
			GET->AddLog("buyset %d sellset %d\n",buyset,sellset);
		}
		modifyorder2(n,&keepx[0],&basketorder[0],&dropbadb[0],longset,shortset,GET);
		modifyorder2(n,&keept[0],&tradeorder[0],&dropbadt[0],buyset,sellset,GET,true);

		blow=tlow=0;
		if((longbasket==-1||longbasket==(long)n)&&(shortbasket==-1||shortbasket==(long)n)
			&&(tradebuy==-1||tradebuy==(long)n)&&(tradesell==-1||tradesell==(long)n))
		{
			if(basketnow<=basket/*1+2*/ || tradesnow<=trades/*1+2*/)
				onesided=true;
			else
				onesided=false;
		}
		else if((tradebuy==-1||tradebuy==(long)n)&&(tradesell==-1||tradesell==(long)n))
		{
			if((Nlong<=longbasket && Nshort<=shortbasket) || tradesnow<=trades)
				onesided=true;
			else
				onesided=false;
		}
		else if((longbasket==-1||longbasket==(long)n)&&(shortbasket==-1||shortbasket==(long)n))
		{
			if((Nbuy<=tradebuy && Nsell<=tradesell) || basketnow<=basket)
				onesided=true;
			else
				onesided=false;
		}
		else
		{
			if((Nlong<=longbasket && Nshort<=shortbasket) || (Nbuy<=tradebuy && Nsell<=tradesell))
				onesided=true;
			else
				onesided=false;
		}

		if(stuck&&back<=1)wasstuck=true;
		else if(stuck&&back==6)wasstuck=false;
		else if(fast)wasstuck=true;

		if(wasstuck)
		{
			onesided=true;
			GET->AddLog("onesided option STUCK %d\n",stuck);
		}

		bdone=tdone=0;
		std::valarray<size_t>orderdone(n);
		orderdone = (size_t)-1;
		//memset(&orderdone[0],-1,n*sizeof(size_t));
		for(iway=0;iway<=1;iway++)
		{
			way=revway?1-iway:iway;
			if((way==0))
			{
				if(mabs||(longbasket==-1&&shortbasket==-1))
				{
					blow=bdone;
					movefixed(n,x,&basketorder[0],lower,upper,equalbounds,&dropbadb[0]);
					for(i=0,makez=blow,tdone=0;i<n&&makez<(n-basket1);++i)
					{
						doingbasketsortrades=1;
						ib=basketorder[n-i-1];
						init=(initial?initial[ib]:0);
						if(orderdone[ib]!=(size_t)-1)
						{
							makez--;
						}
						if(dropbadb[ib])
						{
							if(fabs(x[ib])<=round_eps)
							{
								if(fabs(keept[ib])<=round_eps)
								{
									orderdone[ib]=tdone;tdone++;
								}
								makez++;
							}
							else if(upper[ib]-lower[ib]>equalbounds&& 
								//(init<=upper[ib]) && (init>=lower[ib]) &&
								(0<=upper[ib]) && (0>=lower[ib]))
							{
								if(stuck&&back<=1)
								{
															lower[ib]=upper[ib]=0;makez++;
								}
							}
							else if(upper[ib]-lower[ib]<=equalbounds&& fabs(keept[ib])<=round_eps)
							{
								if(stuck&&back<=1)
								{
															lower[ib]=upper[ib]=init;
								}
							}
							else
							{
								GET->AddLog("ERROR in Droptwo line %d\n",__LINE__);
								nogood=true;
							}
						}
						else if((upper[ib]-lower[ib]>equalbounds) &&
							(0<=upper[ib]) && (0>=lower[ib]) &&
							(((!onesided&&(fabs(init)<=round_eps))||onesided)))
						{
							lower[ib]=upper[ib]=0;makez++;
							if(fabs(init)<=round_eps)
							{
								orderdone[ib]=tdone;
								tdone++;
							}
						}
						else if(fabs(x[ib])<=round_eps)
						{
							if(fabs(keept[ib])<=round_eps)
							{
								orderdone[ib]=tdone;
								tdone++;
							}
							if(stuck&&back<=1)
							{
															lower[ib]=upper[ib]=0;
							}
							makez++;
						}
					}
					GET->AddLog("basket -- %d dropped %d trades done by default (prev %d)\n",makez,tdone,tpdone);
					if(nogood && makez==(n-basket1))
						nogood=false;
				}
				else
				{
					blow=bdone;
					movefixed(n,x,&basketorder[0],lower,upper,equalbounds,&dropbadb[0],longset,shortset);
					for(i=0,kp=0,kn=0;i<n;++i)
					{
						ib=basketorder[i];
						if(x[ib]>round_eps && kp<(size_t)longset){kp++;continue;}
						if(x[ib]<-round_eps && kn<(size_t)shortset){kn++;continue;}
						break;
					}
					itop=n-i;
					for(i=0,makez=blow,tdone=0;i<itop&&makez<n-trades1;++i)
					{
						doingbasketsortrades=1;
						ib=basketorder[n-i-1];
						if(orderdone[ib]!=(size_t)-1)
						{
							makez--;
						}
						init=(initial?initial[ib]:0);
						if(dropbadb[ib])
						{
							if(fabs(x[ib])<=round_eps)
							{
								if(fabs(keept[ib])<=round_eps)
								{
									orderdone[ib]=tdone;tdone++;
								}
								makez++;
							}
							else if(upper[ib]-lower[ib]>equalbounds&& 
								//(init<=upper[ib]) && (init>=lower[ib]) &&
								(0<=upper[ib]) && (0>=lower[ib]))
							{
								if(stuck&&back<=1)
								{
															lower[ib]=upper[ib]=0;makez++;
								}
							}
							else if(upper[ib]-lower[ib]<=equalbounds&& fabs(keept[ib])<=round_eps)
							{
								if(stuck&&back<=1)
								{
															lower[ib]=upper[ib]=init;
								}
							}
							else
							{
								GET->AddLog("ERROR in Droptwo line %d\n",__LINE__);
								nogood=true;
							}
						}
						else if(upper[ib]-lower[ib]>equalbounds&& 
							(0<=upper[ib]) && (0>=lower[ib]) &&
							(((!onesided&&(fabs(init)<=round_eps))||onesided)))
						{
							lower[ib]=upper[ib]=0;makez++;
							if(fabs(init)<=round_eps)
							{
								orderdone[ib]=tdone;
								tdone++;
							}
						}
						else if(fabs(x[ib])<=round_eps)
						{
							if(fabs(keept[ib])<=round_eps)
							{
								orderdone[ib]=tdone;
								tdone++;
							}
							if(stuck&&back<=1)
							{
															lower[ib]=upper[ib]=0;
							}
							makez++;
						}
					}
					GET->AddLog("lsbasket -- %d dropped %d trades done by default (prev %d)\n",makez,tdone,tpdone);
					if(nogood && makez==n)
						nogood=false;
				}
			}
			else
			{
				if(mabs||(tradebuy==-1&&tradesell==-1))
				{
					tlow=tdone;
					movefixed(n,&keept[0],&tradeorder[0],lower,upper,equalbounds,&dropbadt[0]);
					for(i=0,makez=tlow,bdone=0;i<n&&makez<(n-trades1);++i)
					{
						doingbasketsortrades=2;
						ib=tradeorder[n-i-1];
						if(orderdone[ib]!=(size_t)-1)
						{
							makez--;
						}
						init=(initial?initial[ib]:0);
						if(dropbadt[ib])
						{
							if(fabs(keept[ib])<=round_eps)
							{
								if(fabs(x[ib])<=round_eps)
								{
									orderdone[ib]=bdone;bdone++;
								}
								makez++;
							}
							else if(upper[ib]-lower[ib]>equalbounds&& 
								(init<=upper[ib]) && (init>=lower[ib]) /*&&
								(0<=upper[ib]) && (0>=lower[ib])*/)
							{
								if(stuck&&back<=1)
								{
															lower[ib]=upper[ib]=init;makez++;
								}
							}
							else if(upper[ib]-lower[ib]<=equalbounds&& fabs(x[ib])<=round_eps)
							{
								if(stuck&&back<=1)
								{
															lower[ib]=upper[ib]=0;
								}
							}
							else
							{
								GET->AddLog("ERROR in Droptwo line %d\n",__LINE__);
								nogood=true;
							}
						}
						else if(upper[ib]-lower[ib]>equalbounds&& 
							(init<=upper[ib]) && (init>=lower[ib]) &&
							(((!onesided&&(fabs(init)<=round_eps))||onesided)))
						{
							lower[ib]=upper[ib]=init;makez++;
							if(fabs(init)<=round_eps)
							{
								orderdone[ib]=bdone;bdone++;
							}
						}
						else if(fabs(keept[ib])<=round_eps)
						{
							if(fabs(x[ib])<=round_eps)
							{
								orderdone[ib]=bdone;bdone++;
							}
							if(stuck&&back<=1)
							{
															lower[ib]=upper[ib]=init;
							}
							makez++;
						}
					}
					GET->AddLog("trades -- %d dropped %d basket done by default (prev %d)\n",makez,bdone,bpdone);
					if(nogood && makez==(n-trades1))
						nogood=false;
				}
				else
				{
					tlow=tdone;
					movefixed(n,&keept[0],&tradeorder[0],lower,upper,equalbounds,&dropbadt[0],buyset,sellset);
					for(i=0,kp=0,kn=0;i<n;++i)
					{
						ib=tradeorder[i];
						if(keept[ib]>round_eps && kp<(size_t)buyset){kp++;continue;}
						if(keept[ib]<-round_eps && kn<(size_t)sellset){kn++;continue;}
						break;
					}
					itop=n-i;
					for(i=0,makez=tlow,bdone=0;i<itop&&makez<n;++i)
					{
						doingbasketsortrades=2;
						ib=tradeorder[n-i-1];
						if(orderdone[ib]!=(size_t)-1)
						{
							makez--;
						}
						init=(initial?initial[ib]:0);
						if(dropbadt[ib])
						{
							if(fabs(keept[ib])<=round_eps)
							{
								if(fabs(x[ib])<=round_eps)
								{
									orderdone[ib]=bdone;bdone++;
								}
								makez++;
							}
							else if(upper[ib]-lower[ib]>equalbounds&& 
								(init<=upper[ib]) && (init>=lower[ib])/* &&
								(0<=upper[ib]) && (0>=lower[ib])*/)
							{
								if(stuck&&back<=1)
								{
															lower[ib]=upper[ib]=init;makez++;
								}
							}
							else if(upper[ib]-lower[ib]<=equalbounds&& fabs(x[ib])<=round_eps)
							{
								if(stuck&&back<=1)
								{
															lower[ib]=upper[ib]=0;
								}
							}
							else
							{
								GET->AddLog("ERROR in Droptwo line %d\n",__LINE__);
								nogood=true;
							}
						}
						else if(upper[ib]-lower[ib]>equalbounds&& 
							(init<=upper[ib]) && (init>=lower[ib]) &&
							(((!onesided&&(fabs(init)<=round_eps))||onesided)))
						{
							lower[ib]=upper[ib]=init;makez++;
							if(fabs(init)<=round_eps)
							{
								orderdone[ib]=bdone;bdone++;
							}
						}
						else if(fabs(keept[ib])<=round_eps)
						{
							if(fabs(x[ib])<=round_eps)
							{
								orderdone[ib]=bdone;bdone++;
							}
							if(stuck&&back<=1)
							{
															lower[ib]=upper[ib]=init;
							}
							makez++;
						}
					}
					GET->AddLog("bstrades -- %d dropped %d basket done by default (prev %d)\n",makez,bdone,bpdone);
					if(nogood && makez==n)
						nogood=false;
				}
			}
		}
		if(nogood){back=6;break;}

		if(onesided)
		{
			if(tradesnow<=trades || longbasket==-1&&shortbasket==-1)
				doingbasketsortrades=1;
			if(basketnow<=basket)
				doingbasketsortrades=2;
		}

//		checkbound(n,initial,lower,upper);
		back=GET->OptFunc(info);
//		OP->OptSetup(n);
//		checkbound(n,initial,lower,upper,x);
//		back=GET->back;
		
		if(!fast && back<=1)
		{
			if(initial)
				dsubvec(n,x,initial,&keept[0]);
			else
				dcopyvec(n,x,&keept[0]);
			basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
			tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);
			basketlow=min(basketnow,basketlow);
			tradeslow=min(tradesnow,tradeslow);
			if((long)basket >= (long)basketlow)
			{
				if((long)tradesnow - (long)trades1 >10)
				{
					dropfac*=7e-1;GET->AddLog("######################## dropfac now %e\n",dropfac);
					if(!stuck)
						back=6;
				}
			}
			else if((long)trades >= (long)tradeslow)
			{
				if((long)basketnow - (long)basket1 >10)
				{
					dropfac*=7e-1;GET->AddLog("######################## dropfac now %e\n",dropfac);
					if(!stuck)
						back=6;
				}
			}
			if(stuck&&((long)basket >= (long)basketnow&&(long)trades >= (long)tradesnow))
			{
				back=6;dropfac*=7e-1;GET->AddLog("##### bad progress ##### dropfac now %e\n",dropfac);
			}
			else if(back<=1 && !stuck)
			{
				breset=reset_bad_drop(n,x,0,&dropbadb[0]);
				if(breset)
					GET->AddLog("######################################################### %d bad drop reset%s for basket\n",breset,breset>1?"s":" ");
				treset=reset_bad_drop(n,x,initial,&dropbadt[0]);
				if(treset)
					GET->AddLog("######################################################### %d bad drop reset%s for trades\n",treset,treset>1?"s":" ");
			}
			if(dropfac<1.0/(double)n)
			{
				back=6;GET->AddLog("dropfac has got too small %e\n",dropfac);
			}
		}
		if(back<=1)
		{
			dcopyvec(n,x,&keepx[0]);
			first_time_to_optimise=false;
/*			for(i=0;i<n;++i)
			{
				if(dropbadb[i]&&!x[i])
				{
					dropbadb[i]=0;
					AddLog("stock %d unmarked for no drop\n",i+1);
				}
				if(dropbadt[i]&&!(x[i]==initial[i]))
				{
					dropbadt[i]=0;
					AddLog("trade %d unmarked for no drop\n",i+1);
				}
			}*/
		}
		else
		{
			bool done=0;
			if(!onesided) doingbasketsortrades=0;
			dcopyvec(n,&keepx[0],x);
			if(initial)
				dsubvec(n,x,initial,&keept[0]);
			else
				dcopyvec(n,x,&keept[0]);
			basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
			tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);
//			modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0],longset,sellset);
//			modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0],buyset,sellset);
			while(basketnow<n&&!fast)
			{
				if(doingbasketsortrades==2&&!first_time_to_optimise)break;
				if(lower[basketorder[basketnow]]!=upper[basketorder[basketnow]])
				{
					basketnow++;continue;
				}
				if(fabs(lower[basketorder[basketnow]])<=round_eps&&!dropbadb[basketorder[basketnow]])
				{
					dropbadb[basketorder[basketnow]]=1;
					if(initial&&fabs(initial[basketorder[basketnow]])>lm_eps8) done=true;
					else if(!initial)done=false;
					break;
				}
				basketnow++;
//				if((size_t)trades != -1)break;
			}
			while(!done&&(tradesnow<n&&!fast))
			{
				if(doingbasketsortrades==1&&!first_time_to_optimise)break;
				if(lower[tradeorder[tradesnow]]!=upper[tradeorder[tradesnow]])
				{
					tradesnow++;continue;
				}
				if(initial)
				{
					if(fabs(lower[tradeorder[tradesnow]]-initial[tradeorder[tradesnow]])<=round_eps&&!dropbadt[tradeorder[tradesnow]])
					{
						dropbadt[tradeorder[tradesnow]]=1;
						break;
					}
				}
				else
				{
					if(fabs(lower[tradeorder[tradesnow]]-0)<=round_eps&&!dropbadt[tradeorder[tradesnow]])
					{
						dropbadt[tradeorder[tradesnow]]=1;done=1;break;
					}
				}
				tradesnow++;
			}
			if(first_time_to_optimise)
			{
				dcopyvec(n+m,&keepL[0],lower);
				dcopyvec(n+m,&keepU[0],upper);
			}
		}
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);
		//		modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0]);
		//		modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0]);
		basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);bpdone=bdone;tpdone=tdone;
		if(basket1==basket&&basketnow>basket)
			bbelow++;
		else
			bbelow=0;
		if(trades1==trades&&tradesnow>trades)
			tbelow++;
		else
			tbelow=0;
		if(longbasket!=-1 && shortbasket!=-1)
		{
			if(basketnow<=basket)
			{
				if(Nlong>longbasket)basket-=(Nlong-longbasket);
				else if(Nshort>shortbasket)basket-=(Nshort-shortbasket);
				if((long)basket < 0)basket=0;
				GET->AddLog("basket reduced to %d\n",basket);
			}
		}
		if(tradebuy!=-1 && tradesell!=-1)
		{
			if(tradesnow<=trades)
			{
				if(Nbuy>tradebuy)trades-=(Nbuy-tradebuy);
				else if(Nsell>tradesell)trades-=(Nsell-tradesell);
				if((long)trades < 0)trades=0;
				GET->AddLog("trades reduced to %d\n",trades);
			}
		}
		if(longbasket==-1 && shortbasket==-1  &&tradebuy==-1 && tradesell==-1)
		{
			if((size_t)basket<n && (size_t)trades <n)
				badlim = n-bad_sum(n,&dropbadb[0],&dropbadt[0]);
			else if((size_t)basket<n)
				badlim = n-bad_sum(n,&dropbadb[0]);
			else if((size_t)trades <n)
				badlim=n-bad_sum(n,&dropbadt[0]);
		}
		GET->AddLog("basket now %d trades now %d\n",basketnow,tradesnow);
		GET->AddLog("long now %d short now %d\n",Nlong,Nshort);
		GET->AddLog("buy now %d sell now %d\n",Nbuy,Nsell);
		dcopyvec(n+m,&keepL[0],lower);
		dcopyvec(n+m,&keepU[0],upper);
		if(!fast && (basketnow==(size_t)OldResults.basket) && (tradesnow==(size_t)OldResults.trades))
		{
			u=GET->UtilityFunc(info);
			if((tradesnow<trades1) && (basketnow>=basket1))
			{
				if(stuck>(basketnow-basket1+breset)&&u==stucku){break;}
			}
			else if((basketnow<basket1)&&(tradesnow>=trades1))
			{
				if(stuck>(tradesnow-trades1+treset)&&u==stucku){break;}
			}
			else
			{
				if((stuck>(basketnow-basket1+breset))&&(stuck>(tradesnow-trades1+treset))&&(u==stucku)){break;}
			}
			stuck++;
			GET->AddLog("STUCK %d badlim %d\n",stuck,badlim);
			if(back!=6&&basketnow<=basket&&tradesnow<trades)break;

			if(stuck && back<=1 && (u==OldResults.u))
			{
				back=6;
				break;
			}
			if(stuck > badlim)
			{
				back=6;
				break;
			}
			stucku=u;
		}
		else
		{
			OldResults.basket=basketnow;
			OldResults.trades=tradesnow;
			OldResults.u=GET->UtilityFunc(info);
			stuck=0;
		}
		if(fast&&!onlyfast)
		{
			if(longbasket==-1&&shortbasket==-1&&tradebuy==-1&&tradesell==-1)
			{
				if(uquick>(u=GET->UtilityFunc(info)/*u=OP->utility_base(n,x,c,H)*/)&&basketnow<=basket&&tradesnow<=trades)
				{
					dcopyvec(n,x,&quick[0]);uquick=u;
					GET->AddLog("Keep fast weights u=%20.10e\n",uquick);
				}
			}
			else if(Nlong<=longbasket&&Nshort<=shortbasket&&tradebuy==-1&&tradesell==-1)
			{
				if(uquick>(u=GET->UtilityFunc(info)/*u=OP->utility_base(n,x,c,H)*/)&&basketnow<=basket&&tradesnow<=trades)
				{
					dcopyvec(n,x,&quick[0]);uquick=u;
					GET->AddLog("Keep fast weights u=%20.10e\n",uquick);
				}
			}
			else if(Nsell<=tradesell&&Nbuy<=tradebuy&&shortbasket==-1&&longbasket==-1)
			{
				if(uquick>(u=GET->UtilityFunc(info)/*u=OP->utility_base(n,x,c,H)*/)&&basketnow<=basket&&tradesnow<=trades)
				{
					dcopyvec(n,x,&quick[0]);uquick=u;
					GET->AddLog("Keep fast weights u=%20.10e\n",uquick);
				}
			}
			else if(Nsell<=tradesell&&Nbuy<=tradebuy&&Nlong<=longbasket&&Nshort<=shortbasket)
			{
				if(uquick>(u=GET->UtilityFunc(info)/*u=OP->utility_base(n,x,c,H)*/)&&basketnow<=basket&&tradesnow<=trades)
				{
					dcopyvec(n,x,&quick[0]);uquick=u;
					GET->AddLog("Keep fast weights u=%20.10e\n",uquick);
				}
			}
			dcopyvec(n,&first[0],x);//First non dropping solution
			dcopyvec(n,&first[0],&keepx[0]);//First non dropping solution
			if(initial)
				dsubvec(n,x,initial,&keept[0]);
			else
				dcopyvec(n,x,&keept[0]);
//			modifyorder(n,&keepx[0],&basketorder[0],&dropbadb[0]);
//			modifyorder(n,&keept[0],&tradeorder[0],&dropbadt[0]);
			basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
			tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);bpdone=bdone;tpdone=tdone;
		}

		if(fast)wasstuck=false;
		fast=0;
		if(loopc++>10*n)
		{
			GET->AddLog("Dropping is not converging in under %d iterations\n",loopc);
			back=6;
			break;
		}
	}
	if(!SOCP&&back!=6&&basket>1&&trades>=n&&n<1500)dropopt(GET,basket,x,&dropbadb[0],&basketorder[0]);//To make it work with SOCP need to change defs of OptParamRound etc.....
	if((!mabs&&(uquick<(u=GET->UtilityFunc(info)/*u=OP->utility_base(n,x,c,H)*/) ) || (uquick!=lm_max&&((basketnow>basket||tradesnow>trades)||back==6||back==16))))
	{
		GET->AddLog("last u=%20.10e\n",u);
		dcopyvec(n,&quick[0],x);back=0;
		//u=OP->utility_base(n,x,c,H);
		u=GET->UtilityFunc(info);
		GET->AddLog("Copy fast weights at end u=%20.10e\n",u);
	}
	if(back<2)
	{
		if(shortbasket!=-1&&longbasket!=-1&&(tradebuy==-1&&tradesell==-1)&&!nobasklim)
		{
			basket=shortbasket+longbasket;
			double unow,ukeep=GET->UtilityFunc(info);
			basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
			std::valarray<double>xhere(n);
			dcopyvec(n,x,&xhere[0]);
			if(Nlong<longbasket || Nshort<shortbasket)
			{
				for(i=0;i<n;++i)
				{
					if(x[i]>0)
					{
						lower[i]=0;upper[i]=keepU[i];
					}
					else if(x[i]<0)
					{
						lower[i]=keepL[i];upper[i]=0;
					}
					else
					{
						lower[i]=0;upper[i]=0;
					}
				}
				size_t ig;
				std::valarray<double>grad(n);
				int icount=0;
				if(Nshort<shortbasket)
					icount+=shortbasket-Nshort;
				if(Nlong<longbasket)
					icount+=longbasket-Nlong;
				icount*=5;
				size_t nochange=0,added;
				while((Nshort<shortbasket || Nlong<longbasket)&&icount--)
				{
					bool tryonce=true;
					GET->AddLog("Increase icount = %d\n",icount);
					GET->grad=&grad[0];
					GET->GradFunc(info);
					modifyorder2(n,&grad[0],&basketorder[0],&dropbadb[0],-1,-1,lp?GET:0);
					for(i=0,added=0;i<n;++i)
					{
						ig=basketorder[n-i-1];
						if(x[ig]==0&&grad[ig]>0 && Nshort<shortbasket)
						{
							lower[ig]=keepL[ig];
							GET->AddLog("Added %d\n",ig);
							if(added++>=nochange)break;
						}
						else if(x[ig]==0&&grad[ig]<0 && Nlong<longbasket)
						{
							upper[ig]=keepU[ig];
							GET->AddLog("Added %d\n",ig);
							if(added++>=nochange)break;
						}
					}
					back=GET->OptFunc(info);
					if(back<2)
					{
						basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
						unow=GET->UtilityFunc(info);
						GET->AddLog("Utility %20.8e Nlong %d Nshort %d\n",unow,Nlong,Nshort);
						if(Nlong<=longbasket  &&Nshort<=shortbasket&&unow<=ukeep)
						{
							dcopyvec(n,x,&xhere[0]);ukeep=unow;
						}
						nochange++;
					}
					if(tryonce&&i<n)
					{
						int j=n;
						if(Nshort>shortbasket)
						{
							while(Nshort>shortbasket&&j)
							{
								tryonce=false;
								for(j=i;j>=0;--j)
								{
									ig=basketorder[n-j-1];
									if(x[ig]<0)
									{
										lower[ig]=0;Nshort--;break;
									}
								}
								back=GET->OptFunc(info);
								if(back<2)
								{
									basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
									unow=GET->UtilityFunc(info);
									GET->AddLog("Utility %20.8e Nlong %d Nshort %d\n",unow,Nlong,Nshort);
									if(Nlong<=longbasket  &&Nshort<=shortbasket&&unow<=ukeep)
									{
										dcopyvec(n,x,&xhere[0]);ukeep=unow;
									}
								}
							}
						}
						else if(Nlong>longbasket)
						{
							while(Nlong>longbasket&&j)
							{
								tryonce=false;
								for(j=i;j>=0;--j)
								{
									ig=basketorder[n-j-1];
									if(x[ig]>0)
									{
										upper[ig]=0;Nlong--;break;
									}
								}
								back=GET->OptFunc(info);
								if(back<2)
								{
									basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
									unow=GET->UtilityFunc(info);
									GET->AddLog("Utility %20.8e Nlong %d Nshort %d\n",unow,Nlong,Nshort);
									if(Nlong<=longbasket  &&Nshort<=shortbasket&&unow<=ukeep)
									{
										dcopyvec(n,x,&xhere[0]);ukeep=unow;
									}
								}
							}
						}
					}
				}
			}
			dcopyvec(n,&xhere[0],x);
		}
		else if((shortbasket==-1&&longbasket==-1)&&(tradebuy!=-1&&tradesell!=-1)&&!notradelim)
		{
			std::valarray<double>xhere(n);//,buysell;
			dcopyvec(n,x,&xhere[0]);
			double unow,ukeep=GET->UtilityFunc(info);
			basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
			dsubvec(n,x,initial,x);
			tradesnow=sizenow(n,x,baskthresh,Nbuy,Nsell);
			daddvec(n,x,initial,x);
			if(Nbuy<tradebuy || Nsell<tradesell)
			{
				for(i=0;i<n;++i)
				{
					if(x[i]>initial[i])
					{
						lower[i]=initial[i];upper[i]=keepU[i];
					}
					else if(x[i]<initial[i])
					{
						lower[i]=keepL[i];upper[i]=initial[i];
					}
					else
					{
						lower[i]=initial[i];upper[i]=initial[i];
					}
				}
				size_t ig;
				std::valarray<double>grad(n);
				int icount=0;
				if(Nsell<tradesell)
					icount+=tradesell-Nsell;
				if(Nbuy<tradebuy)
					icount+=tradebuy-Nbuy;
				icount*=3;
				size_t nochange=0,added;
				while((Nsell<tradesell || Nbuy<tradebuy)&&icount--&&basketnow<=basket)
				{
					bool tryonce=true;
					GET->AddLog("Increase icount = %d nochange %d\n",icount,nochange);
					GET->grad=&grad[0];
					GET->GradFunc(info);
					modifyorder2(n,&grad[0],&basketorder[0],&dropbadb[0],buyset,sellset,lp?GET:0);
					for(i=0,added=0;i<n;++i)
					{
						ig=basketorder[n-i-1];
						if(x[ig]==initial[ig]&&grad[ig]>0 && Nsell<tradesell)
						{
							lower[ig]=keepL[ig];
							GET->AddLog("Added %d\n",ig);
							if(++added>nochange)break;
						}
						else if(x[ig]==initial[ig]&&grad[ig]<0 && Nbuy<tradebuy)
						{
							upper[ig]=keepU[ig];
							GET->AddLog("Added %d\n",ig);
							if(++added>nochange)break;
						}
					}
					back=GET->OptFunc(info);
					if(back<2)
					{
						basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
						dsubvec(n,x,initial,x);
						tradesnow=sizenow(n,x,baskthresh,Nbuy,Nsell);
						daddvec(n,x,initial,x);
						unow=GET->UtilityFunc(info);
						GET->AddLog("Utility %20.8e Nbuy %d Nsell %d\n",unow,Nbuy,Nsell);
						if(Nbuy<=tradebuy  &&Nsell<=tradesell&&unow<=ukeep&&basketnow<=basket)
						{
							dcopyvec(n,x,&xhere[0]);ukeep=unow;
						}
						nochange+=dmax(1,(dmax((tradesell-Nsell)*.25,(tradebuy-Nbuy)*.25)));
					}
					if(tryonce && i <n)
					{
						int j=n;
						if(Nsell>tradesell)
						{
							nochange=0;
							while(Nsell>tradesell&&j!=-1)
							{
								tryonce=false;
								for(j=i;j>=0;--j)
								{
									ig=tradeorder[n-j-1];
									if(x[ig]<initial[ig])
									{
										lower[ig]=initial[ig];Nsell--;break;
									}
									else if(x[ig]>initial[ig])
										
										
									{
										upper[ig]=initial[ig];Nbuy--;break;
									}
								}
								if(j==-1)break;
								back=GET->OptFunc(info);
								if(back<2)
								{
									basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
									dsubvec(n,x,initial,x);
									tradesnow=sizenow(n,x,baskthresh,Nbuy,Nsell);
									daddvec(n,x,initial,x);
									unow=GET->UtilityFunc(info);
									GET->AddLog("Utility %20.8e Nbuy %d Nsell %d\n",unow,Nbuy,Nsell);
									if(Nbuy<=tradebuy  &&Nsell<=tradesell&&unow<=ukeep&&basketnow<=basket)
									{
										dcopyvec(n,x,&xhere[0]);ukeep=unow;
									}
								}
							}
						}
						else if(Nbuy>tradebuy)
						{
							nochange=0;
							while(Nbuy>tradebuy&&j)
							{
								tryonce=false;
								for(j=i;j>=0;--j)
								{
									ig=basketorder[n-j-1];
									if(x[ig]>initial[ig])
										
										
									{
										upper[ig]=initial[ig];Nbuy--;break;
									}
									else if(x[ig]<initial[ig])
									{
										lower[ig]=initial[ig];Nsell--;break;
									}
								}
								back=GET->OptFunc(info);
								if(back<2)
								{
									basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
									dsubvec(n,x,initial,x);
									tradesnow=sizenow(n,x,baskthresh,Nbuy,Nsell);
									daddvec(n,x,initial,x);
									unow=GET->UtilityFunc(info);
									GET->AddLog("Utility %20.8e Nbuy %d Nsell %d\n",unow,Nbuy,Nsell);
									if(Nbuy<=tradebuy  &&Nsell<=tradesell&&unow<=ukeep&&basketnow<=basket)
									{
										dcopyvec(n,x,&xhere[0]);ukeep=unow;
									}
								}
							}
						}
					}
				}
			}
			dcopyvec(n,&xhere[0],x);
		}
	}
	dcopyvec(n+m,&keepL[0],lower);
	dcopyvec(n+m,&keepU[0],upper);
	if(back<=1)
	{
		if(initial)
			dsubvec(n,x,initial,&keept[0]);
		else
			dcopyvec(n,x,&keept[0]);
		basketnow=sizenow(n,x,baskthresh,Nlong,Nshort);
		tradesnow=sizenow(n,&keept[0],baskthresh,Nbuy,Nsell);bpdone=bdone;tpdone=tdone;
		if(longbasket!=-1 && shortbasket!=-1)basket=longbasket+shortbasket;
		if(tradebuy!=-1 && tradesell!=-1)trades=tradebuy+tradesell;
		if(basket==-1)basket=n;
		if(trades==-1)trades=n;
		if(longbasket==-1)longbasket=n;
		if(tradebuy==-1)tradebuy=n;
		if(shortbasket==-1)shortbasket=n;
		if(tradesell==-1)tradesell=n;
		if(basketnow>basket||tradesnow>trades||Nlong>longbasket||Nshort>shortbasket||Nbuy>tradebuy||Nsell>tradesell)
		{
			GET->AddLog("Final x in droptwo does not satisfy the basket constraints\n");
			back=6;
		}
	}
	else
			GET->AddLog("back=%d\n",back);
	return back;
}

