from sys import argv
from re import sub
from safe import pickout #(dimen nstocks,char **stocklist,dimen M_nstocks,char** M_stocklist,vector QFIX)
del argv[0]
if len(argv)==0:
    raise 'No data file given'
file=open(argv[0])

def swap(i,j,o):
    d=o[j]
    o[j]=o[i]
    o[i]=d
    
names=[]
cov=[]
for line in file.readlines():
    line=line.strip()
    line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
    data=line.split(',')
    data[0]=data[0].replace(' ','_')
    names.append(data[0])
    del data[0]
    cov+=data

line=''
for i in names:line+='%s '%i
#print line

n=len(names)
ij=0
for i in range(n):
    line=''
    for j in range(i+1):
        cov[ij]=float(cov[ij])/120000
        line+='%20.10e '%cov[ij]
        ij+=1
#    print line

newnames='CASH Europe_Cash Europe_Equity Europe_Fix_Government Europe_Property Japan_Cash Japan_Equity Japan_Fix_Government Japan_Property Switzerland_Cash Switzerland_Equity Switzerland_Fix_Government Switzerland_Property UK_Cash UK_Equity UK_Fix_Government UK_Fix_High_Yield UK_Property US_Cash US_Equity US_Fix_Government US_Fix_High_Yield US_Property World_Equity_[Global] World_Fix_Emerging_[Global] World_Fix_Government_[Global] World_Fix_High_Yield_[Global] World_Gold_[Global] World_Hedge_Funds_#1_[Global] World_Property_[Global]' 
nlist=newnames.split()
start=0
for i in range(len(nlist)):
    if nlist[i].upper().find('CASH')>-1:
        swap(i,start,nlist)
        start+=1

pickout(len(nlist),nlist,len(names),names,cov)

"""
DATA
CASH EQUITIES BONDS
first
.2 .5 .3
lbound
0 .2 .2
ubound
.6 .6 .6
Growth
0 .06 .01
0 .04 .02
0 .06 .03
Yield
.02 .01 .02
.03 .02 .02
.02 .03 .04
LIAB
.02 0 .03
desiredturnover
.2
maxrisk
.2
COV
0.085291178592080463
-0.0010384120058427593 0.079105769342181526
0.00963279430037145 0.00098092427209120481 0.077833750263356677
"""
n=len(nlist)
newnames=''
for i in nlist:newnames+=i+' '
print 'DATA'
print newnames
print 'first'
print '%20.10e '%(1.0/n)*n
print 'lbound'
print '0 '*n
print 'ubound'
print '1 '*n
print 'Growth'
print '0 '+'.1 '*(n-1)
print 'Yield'
print '.2 '*n
print 'LIAB'
print '.3'
print 'desiredturnover'
print '1'
print 'maxrisk'
print '1'
print 'COV'
ij=0
for i in range(n):
    line=''
    for j in range(i+1):
        line+='%20.10e '%(cov[ij])
        ij+=1
    print line
