#include "ldefns.h"

/*
	purpose
	=======
		dtmxsolve solves systems of triangular equations
		important.	in double precision implementations the real
		---------	declarations should be interpreted to mean
				double precision
	description
	===========
		dtmxsolve solves the equations
		t*x = b ,   or	 ( t**t )*x = b ,
		where t is an n by n upper or lower triangular matrix
		the type of triangular system solved is controlled by the
		parameter job as described in the parameter section below
	parameters
	==========
		job   - short
			on entry, job must contain one of the values -2, -1, 0, 1, 2
			to specify the type of triangular system to be solved as
			follows
			job =  0	t is assumed to be diagonal and the
					equations t*x = b are solved
			job =  1	t is assumed to be upper triangular and the
					equations t*x = b are solved
			job = -1	t is assumed to be upper triangular and the
					equations ( t**t )*x = b are solved
			job =  2	t is assumed to be lower triangular and the
					equations t*x = b are solved
			job = -2	t is assumed to be lower triangular and the
					equations ( t**t )*x = b are solved
					unchanged on exit
		n     - dimen
			on entry, n specifies the order of the matrix t. n must be at
			least unity
			unchanged on exit
		t     - real matrix of dimension ( nrt, nct ). nct must be at least n
			before entry t must contain the triangular elements. only
			those elements contained in the triangular part of t are
			referenced by this routine
			unchanged on exit
		nrt   - dimen
			on entry, nrt specifies the first dimension of t as declared
			in the calling (sub) program. nrt must be at least n
		b     - real vector of dimension ( n )
			before entry, b must contain the right hand side of the
			equations to be solved
			on successful exit, b contains the solution vector x
		idiag - short
			before entry, idiag must be assigned a value. for users
			unfamiliar with this parameter (described in chapter p01)
			the recommended value is zero

		return value
			0	success
			1	invalid arguments (n, nrt, job)
			> 1	(return - 1)th diagonal element of t is
				either zero or is too small to avoid overflow
				in computing an element of x

		further comments
		================
			if t is part of a matrix a partitioned as
			a =	( a1  a2 ) ,
				( a3  t	 )
			where a1 is an m by k matrix ( m>=0, k>=0), then this routine
			may be called with the parameter t as a( m + 1, k + 1 ) and nrt as
			the first dimension of a as declared in the calling (sub) program.
*/
short dtmxsolve(short job, dimen n, matrix t, dimen nrt, vector b, short idiag)
{

    	int	fail;
    	dimen	k;

    	--b;
    	t -= nrt + 1;

    	if (n < 1 || nrt < n || abs(job) > 2) return lm_check_fail(idiag, CS(1), "dtmxsolve");

    	if (job == 1 || job == -2){
		for (k = n; k>=1; --k) if((fail=(b[k]!=0.0))) break;
		}
	else	{
		for (k = 1; k <= n; ++k) if((fail=(b[k]!=0.0))) break;
		}

	if(fail)
		switch(job){
			case 0:
				for (; k <= n; ++k) {
					b[k] = dprotdiv(&b[k], &t[k + k * nrt], &fail);
					if (fail) break;
					}
				break;
			case 1:
				for(;k>=1;--k){
					b[k] = dprotdiv(&b[k], &t[k + k * nrt], &fail);
					if (fail) break;
					if (k > 1) BITA_daxpy(k-1, -b[k], &t[k * nrt + 1], 1, &b[1], 1);
					}
				break;
			case 2:
				for (; k <= n; ++k) {
					b[k] = dprotdiv(&b[k], &t[k + k * nrt], &fail);
					if (fail) break;
					if (k < n) BITA_daxpy(n-k, -b[k], &t[k + 1 + k * nrt], 1, &b[k + 1],1);
					}
				break;
			case -1:
				for (; k <= n; ++k) {
					if (k > 1) b[k] -= ddotvec((dimen)(k-1), &t[k * nrt + 1], &b[1]);
					b[k] = dprotdiv(&b[k], &t[k + k * nrt], &fail);
					if (fail) break;
					}
				break;
			case -2:
				for(;k>=1;--k){
					if (k < n) b[k] -= ddotvec((dimen)(n-k), &t[k + 1 + k * nrt], &b[k + 1]);
					b[k] = dprotdiv(&b[k], &t[k + k * nrt], &fail);
					if (fail) break;
					}
			}

    	return (short) (fail ? lm_check_fail(idiag, (short)(k+1), "dtmxsolve") : 0);
}
