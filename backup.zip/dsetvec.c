/*
	set a vector  to a constant
*/
#include "ldefns.h"

void dsetvec(dimen n, real alpha, vector x)
{
	dset(n,alpha,x,1);
}
