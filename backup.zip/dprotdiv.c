#include "ldefns.h"
#include "constant.h"

/*
	dprotdiv returns the value div given by
		div =	( a/b                 if a/b does not overflow,
      			(
			( 0.0                 if a == 0.0,
			(
			( sign( a/b )*flmax   if a != 0.0  and a/b would overflow,

	where  flmax  is a large value. in addition if
	a/b would overflow then  fail is returned as 1, otherwise  fail is
	returned as 0
	note that when  a and b  are both zero, fail is returned as 1, but
	div  is returned as  0.0. in all other cases of overflow  div is such
	that  abs( div ) = flmax

	when  b = 0  then  sign( a/b )  is taken as  sign( a )
*/
real dprotdiv(real *a, real *b, int *fail)
{

	real absb, div;
	int	dfail;

	if(fail==NULL) fail = &dfail;

	if (*a == 0.){
		div = 0.;
		*fail = *b==0;
		}
	else if (*b == 0.){
	    	div = dsign(lm_rsafe_range, *a);
	    	*fail = 1;
		}
	else	{
		absb = fabs(*b);
	    	if (absb >= 1.){
			*fail = 0;
			div = (fabs(*a) >= absb * lm_safe_range ? *a / *b : 0.0);
	    		}
		else if (fabs(*a) <= absb * lm_rsafe_range){
		    	*fail = 0;
		    	div = *a / *b;
			}
		else	{
			*fail = 1;
		    	div = lm_rsafe_range;
		    	if((*a < 0. && *b > 0.) || (*a > 0. && *b < 0.)) div = -div;
	    		}
		}
	return div;
}
