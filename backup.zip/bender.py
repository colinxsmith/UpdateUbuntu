from Opt import *
from math import sqrt
if jython:
    #There is no sum function in jython!
    def sum(a,start=0):
        s=start
        for i in a:s+=i
        return s
def benderopt(n,alpha,w,rhs):
    dd=dot(alpha,w)
    bend=Opt()
    bend.log=0
    bend.n=n
    bend.m=1
    bend.alpha=map(lambda t:t,w)
    bend.A=map(lambda t:t,w)
    bend.L=[-10]*n+[0]
    bend.U=[10]*n+[rhs-dd]
    bend.gamma=1
    bend.opt()
    for i in range(n):
        alpha[i]=bend.w[i]
    del bend  
DATA=['CASH','EQUITIES','BONDS']
"""
#____________________________________________________________________________
#To get a proper positive definite covariance matrix I'm using random prices
#and calculating their covariances
from random import *
n=100
CASH=map(lambda t:random(),range(n))
EQUITIES=map(lambda t:random(),range(n))
BONDS=map(lambda t:random(),range(n))
weights=[1]*n
COV=[]
for i in range(len(DATA)):
    for j in range(i+1):
        COV.append(covariance1(eval(DATA[i]),eval(DATA[j]),weights,n))
#____________________________________________________________________________
"""
#Now I'll use the same covariances
COV=[0.085291178592080463, -0.0010384120058427593, 0.079105769342181526,
     0.00963279430037145, 0.00098092427209120481, 0.077833750263356677]
opt=Opt()
opt.n=3
opt.m=1
opt.mask=[0,1,1]
opt.names=DATA
opt.bench=[0]*opt.n
nyears=3
first=[0,.5,.5]
LIAB=[.02,0.1,.15]
Growth=[[0,.06,.01],[0,.04,.02],[0,.06,.03]]
Yield=[[.02,.01,.02],[.03,.02,.02],[.02,.03,.04]]
lbound=[0,.2,.2]
ubound=[.6,.6,.6]

Alphas=[map(lambda t:((1+Growth[1][t]+Yield[1][t])*(1+Growth[2][t]+Yield[2][t])),range(opt.n)),
       map(lambda t:((1+Growth[2][t]+Yield[2][t])),range(opt.n)),
       map(lambda t:1,range(opt.n))]

desiredturnover=.05
opt.nfac=-1
opt.Q=COV
opt.revise=1
opt.maxrisk=.2
opt.minrisk=0

OldValue=FinalWealth=1e23
Conv=sqrt(epsget())
Converged=0

for kk in range(100):
    print '$'*20+(' Iteration %d '%kk)+'$'*20
    opt.initial=map(lambda t:t,first)
    
    for year in range(nyears):
        opt.alpha=map(lambda t:t,Alphas[year])
        WealthFactor=map(lambda t:(1+Growth[year][t]+Yield[year][t]),range(opt.n))
        TotalYield=dot(Yield[year],opt.initial)
        wealthnow=sum(opt.initial)
        SetWealth=dot(opt.initial,WealthFactor)
        if kk>0 and year<(nyears-2):
            DesiredExpectedAlpha=FinalWealth
            for i in range(year,nyears):DesiredExpectedAlpha+=LIAB[i]*Alphas[i][0]
            opt.m=2
            opt.A=[1]*(opt.m*opt.n)
            for i in range(opt.n):
                opt.A[opt.m*i+1]=opt.alpha[i]
            opt.L=lbound+[SetWealth,DesiredExpectedAlpha]
            opt.U=ubound+[SetWealth,DesiredExpectedAlpha]
        else:
            opt.m=1
            opt.A=[1]*opt.n
            opt.L=lbound+[SetWealth]
            opt.U=ubound+[SetWealth]
        opt.L[0]=LIAB[year]
        opt.delta=desiredturnover*wealthnow
        opt.gamma=.9999
        opt.log=0

        back=opt.opt()
        print opt.returnmessage
        print '%20s %20s %20s %20s'%('Asset Class','Initial','Final','Alphas used')
        for i in range(opt.n):
            print '%20s %20.8e %20.8e %20.8e'%(opt.names[i],opt.initial[i],opt.w[i],opt.alpha[i])

        opt.props()
        EWealth=opt.rreturn
        for i in range(year,nyears):
            EWealth-=LIAB[i]*Alphas[i][0]

        print 'Initial Wealth\t\t%20.8e'%sum(opt.initial)
        print 'Wealth Now\t\t%20.8e'%sum(opt.w)
        print 'Wealth Less Liability\t%20.8e'%(sum(opt.w)-LIAB[year])
        print 'Gamma\t\t\t%20.8e'%opt.ogamma
        print 'Risk\t\t\t%20.8e'%opt.risk
        print 'Expected Final Wealth\t%20.8e'%EWealth
        print 'Turnover\t\t%20.8e'%(turnover(opt.w,opt.initial,opt.mask)/wealthnow)
        print 'Total Turnover\t\t%20.8e'%(turnover(opt.w,first,opt.mask))

        opt.initial=map(lambda t:t,opt.w)
        opt.initial[0]-=LIAB[year]

        if year==(nyears-1):
            OldValue=FinalWealth
            FinalWealth=EWealth
            print 'Difference %-.8e'%(FinalWealth-OldValue)
            if abs(FinalWealth-OldValue)/FinalWealth < Conv:
                Converged=1
                print '$'*20+(' Converged on iteration %d '%kk)+'$'*20
                
    if back==6 or back==8 or back==9:break
    elif Converged:break
if not Converged:print 'Needs more than %d iterations'%kk
        
