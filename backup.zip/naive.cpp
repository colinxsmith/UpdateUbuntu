#include "baseoptimise.h"
//This came from the Python
#define unround 1e60
//#define LOGPRINT
double check_digit(double digit)
{
	double delta=fabs(fabs(digit-(long)(digit))-1);
	if(delta<=(lm_rooteps))
	{
		long ndelta=delta/lm_eps;
		if(digit>0)
		{
			digit+=ndelta*lm_eps;
		}
		else if(digit<0)
		{
			digit-=ndelta*lm_eps;
		}
	}
	return digit;
}
void	NaiveRound(size_t n,vector w,vector initial,
				   vector minlot,vector sizelot,vector roundw)
{
	size_t i;
	for(i=0;i<n;i++){roundw[i]=round_weight(w[i],
		(initial?initial[i]:0),minlot[i],sizelot?sizelot[i]:0);}
}
void digitise(size_t n,vector w,vector initial,vector minlot,vector sizelot,vector digit)
{
	//digit[i] will be an integer if w[i] satisfies roundlot conditions
	size_t i;
	for(i=0;i<n;++i)
	{
		digit[i]=digitisei(w[i],(initial?initial[i]:0),minlot[i],sizelot?sizelot[i]:0);
	}
}
double digitisei(double w,double initial,double minl,double sizl,double minlb)
{
#ifdef LOGPRINT
	printf("digitisei w %25.20e\n",w);
#endif
	double ww=w-initial;
	double wa=fabs(ww);
	double digit=0,one=1.0,p5=0.5;
	if(minlb==0)
	{
		if(wa<lm_eps){digit=0;}
		else if(wa<minl){digit=0/*wa/minl*/;}
		else if(sizl<lm_eps){digit=unround;}
		else if(wa>=minl){digit=one+(wa-minl)/sizl;}
		if(ww<0){digit=-digit;}
	}
	else
	{//This isn't right or needed!
		if(ww<minl && ww>minlb)
		{
			double init_check=(minl+minlb)*p5;
			if(fabs(init_check-initial)<1e-15)
			{
				digit=initial;
			}
			else if(fabs(init_check)<1e-15)
			{
				digit=0;
			}
		}
		else{digit=unround;}
	}
	if(fabs(digit)!=unround)
	{
#ifdef LOGPRINT
		printf("digit %25.20e\n",digit);
#endif
		digit=check_digit(digit);
#ifdef LOGPRINT
		printf("digit %25.20e\n",digit);
#endif
	}
	
	return digit;
}
double digit2w(double w,double initial,double d,double minl,double sizl,double minlb)
{
	d=check_digit(d);
#ifdef LOGPRINT
	printf("digit2w w %25.20e d %25.20e\n",w,d);
#endif
	//Find nearest integer to d[i] (from digitise) and work out corresponding weight
	double roundw=w,p5=0.5;
	long p=0,lone=1;
	if(fabs(d)==unround){p=1000000000;}
	else if(fabs(d)<=lm_eps8){p=0;}
/*	else if(d>0)p=(long)floor(d+p5);
	else if(d<0)p=(long)floor(d-p5);*/
	else p=(long)floor(fabs(d)+p5);//This is the right way

	if(d<0)p=-p;
	if(fabs(d)==unround){roundw=w-initial;}
	else if(labs(p)<=lone)
	{
		if(minlb==0)
			roundw=minl*p;
		else if(roundw>=0)
			roundw=minl*p;
		else if(roundw<=0)
			roundw=minlb*p;
	}
	else if(d>0&&minl==sizl){roundw=sizl*p;}
	else if(d<0&&minl==sizl){roundw=sizl*p;}
	else if(d>0){roundw=sizl*(p-lone)+minl;}
	else if(d<0){roundw=sizl*(p+lone)-minl;}
	roundw+=initial;
#ifdef LOGPRINT
	printf("digit2w roundw %25.20e\n",roundw);
#endif
	return roundw;
}
double round_weight(double x,double initial,double minl,double sizel,double minlb)
{
	return digit2w(x,initial,digitisei(x,initial,minl,sizel,minlb),minl,sizel,minlb);
}
