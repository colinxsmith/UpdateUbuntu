#include "optimise.h"
#ifdef __SYSNT__
#ifdef __SYSNT64__
//#define _WIN32_WINNT 0x0501
#endif
#include <windows.h>
#ifdef __SYSNT64__
#include <tchar.h>
#endif
	LPCTSTR  lpRootPathName ;		/* address of root directory of the file system */
	LPTSTR  lpVolumeNameBuffer;		/* address of name of the volume */
 	DWORD  nVolumeNameSize;			/* length of lpVolumeNameBuffer */
	LPDWORD  lpVolumeSerialNumber ;		/* address of volume serial number */
	LPDWORD  lpMaximumComponentLength;	/* address of system's maximum filename length*/
	LPDWORD  lpFileSystemFlags ;		/* address of file system flags */
	LPTSTR  lpFileSystemNameBuffer ;	/* address of name of file system */
	DWORD  nFileSystemNameSize; 		/* length of lpFileSystemNameBuffer */
#endif
#ifdef MSDOSS
#include<windows.h>
	LPCTSTR  lpRootPathName ;		/* address of root directory of the file system */
	LPTSTR  lpVolumeNameBuffer;		/* address of name of the volume */
 	DWORD  nVolumeNameSize;			/* length of lpVolumeNameBuffer */
	LPDWORD  lpVolumeSerialNumber ;		/* address of volume serial number */
	LPDWORD  lpMaximumComponentLength;	/* address of system's maximum filename length*/
	LPDWORD  lpFileSystemFlags ;		/* address of file system flags */
	LPTSTR  lpFileSystemNameBuffer ;	/* address of name of file system */
	DWORD  nFileSystemNameSize; 		/* length of lpFileSystemNameBuffer */
#endif
#if	defined(sun)&&defined(__svr4__)
#include <sys/systeminfo.h>
#include <stdio.h>
#endif
#if defined(__linux__)
       #include <arpa/inet.h>
       #include <sys/socket.h>
       #include <netdb.h>
       #include <ifaddrs.h>
//       #include <stdio.h>
//       #include <stdlib.h>
//       #include <unistd.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#endif
#if defined(__SYSNT__) || defined(MSDOSS)
unsigned long	getvolid( void );
#endif
unsigned long	guniqid( void )
{
#if defined(__linux__)
	int s,top;
	char* defaultname=(char*)"eth0";
	long result=0,num;
	size_t order[6];
	char back[256];
	struct ifreq buffer;
	s = socket(PF_INET, SOCK_DGRAM, 0);
	memset(&buffer, 0x00, sizeof(buffer));
	strcpy(buffer.ifr_name, defaultname);
	if(ioctl(s, SIOCGIFHWADDR, &buffer)<0)
	{
//We get here if there is no driver with name defaultname. We have to search for a valid driver
		//printf("SIOCGIFHWADDR(%s): %m\n", buffer.ifr_name);
		struct ifaddrs *ifaddr, *ifa;
		if(getifaddrs(&ifaddr) == -1)
		{
			printf("getifaddrs %m\n");
			ifaddr->ifa_name=(char*)"wlan0";
		}
		else
		{
			for(ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next)
			{
				memset(&buffer, 0x00, sizeof(buffer));
				strcpy(buffer.ifr_name, ifa->ifa_name);
				//printf("%s\n",buffer.ifr_name);
				if(ioctl(s, SIOCGIFHWADDR, &buffer)<0)
				{
					//printf("SIOCGIFHWADDR(%s): %m\n", buffer.ifr_name);
				}
				else
				{
					/*printf("%lx\n",buffer.ifr_hwaddr.sa_data);
					for(int i=0;i<6;++i)
						printf("%2x ",buffer.ifr_hwaddr.sa_data[i]);
					printf("\n");*/
					if(buffer.ifr_hwaddr.sa_data[0]||buffer.ifr_hwaddr.sa_data[0]||buffer.ifr_hwaddr.sa_data[1]||buffer.ifr_hwaddr.sa_data[2]||buffer.ifr_hwaddr.sa_data[3]||buffer.ifr_hwaddr.sa_data[4]||buffer.ifr_hwaddr.sa_data[5]) break;//keep the first driver found with a non-zero address (avoids "lo")
				}
			}
			freeifaddrs(ifaddr);
		}
	}
	close(s);
	for(s=0;s<6;s++)order[s]=s;
	top=5;
	while(top>0)
	{
		for(s=0;s<top;s++)
		{
			if((unsigned int)buffer.ifr_hwaddr.sa_data[order[s]]<(unsigned int)buffer.ifr_hwaddr.sa_data[order[top]])
			{
				std::swap(order[s],order[top]);
			}
		}
		top--;
	}
	//Only use 4 keys in Robin's validating stuff
	sprintf(back,"%.2x%.2x%.2x%.2x",(unsigned char)buffer.ifr_hwaddr.sa_data[order[0]],
		(unsigned char)buffer.ifr_hwaddr.sa_data[order[1]],
		(((unsigned char)buffer.ifr_hwaddr.sa_data[order[2]]+(unsigned char)buffer.ifr_hwaddr.sa_data[order[3]])/2)&0xff,
		(((unsigned char)buffer.ifr_hwaddr.sa_data[order[4]]+(unsigned char)buffer.ifr_hwaddr.sa_data[order[5]])/2)&0xff);
	sscanf(back,"%lx",&result);
	return result;
#endif
#if	defined(sun)
#	if defined(__svr4__)
#	define	bufLen 257
	/*Solaris version*/
	char	buf[bufLen];
	int i = sysinfo( SI_HW_SERIAL, buf, bufLen );
	long	result;
#if	0
	printf("guniqid: sysinfo--> %d buf=%s\n", i, buf );
#endif
	i = sscanf( buf, "%ld", &result );
	return	result;
#	else
	return	gethostid();
#	endif	
#endif
#if	defined(HP_UX)
#include	<stdio.h>
#include	<sys/utsname.h>
	struct utsname q;
	long	int serno;

	uname(&q);
	sscanf(q.__idnumber,"%ld",&serno);

	return serno;
#	endif
#if defined(__SYSNT__) || defined(MSDOSS)
#ifdef OLDWAY
	TCHAR name1[80],name3[80];
	unsigned	int	serial,maxfilelen,filesys;

	lpRootPathName = (LPCTSTR)"c:\\" ; /* "c:\\";  For a particular drive, NULL for installed drive.*/
	lpVolumeNameBuffer  = name1;
	lpVolumeSerialNumber = &serial;
	lpMaximumComponentLength = &maxfilelen;
	lpFileSystemFlags = &filesys;
	nVolumeNameSize = 80;
	lpFileSystemNameBuffer = name3;
	nFileSystemNameSize = 80;

	if( GetVolumeInformation(lpRootPathName,lpVolumeNameBuffer,
	nVolumeNameSize,lpVolumeSerialNumber,lpMaximumComponentLength,	
	lpFileSystemFlags,lpFileSystemNameBuffer,nFileSystemNameSize ) )
		return serial;
	else
		return 0;
#else
	return getvolid();
#endif
#endif
}

#if defined(__SYSNT__) || defined(MSDOSS)
long installed_drive()
{
#ifndef __SYSNT64__
	char name1[80],name3[80];
#else
	TCHAR name1[80],name3[80];
#endif
#if defined( __CYGWIN__) && defined( __LP64__ )
	unsigned	int	serial,maxfilelen,filesys;
#else
	unsigned	long	serial,maxfilelen,filesys;
#endif

	lpRootPathName = 0 ; /* "c:\\";  For a particular drive, NULL for installed drive.*/
	lpVolumeNameBuffer  = name1;
	lpVolumeSerialNumber = &serial;
	lpMaximumComponentLength = &maxfilelen;
	lpFileSystemFlags = &filesys;
	nVolumeNameSize = 80;
	lpFileSystemNameBuffer = name3;
	nFileSystemNameSize = 80;

	if( GetVolumeInformation(lpRootPathName,lpVolumeNameBuffer,
	nVolumeNameSize,lpVolumeSerialNumber,lpMaximumComponentLength,	
	lpFileSystemFlags,lpFileSystemNameBuffer,nFileSystemNameSize ) )
		return serial;
	else
		return 0;
}
#endif


//If we ever need to do licencing using MAC address for ethernet interface here's a start

#if defined(__linux__)
extern "C" DLLEXPORT void getmacaddress()
{
	int s;
	long result=0;
	char back[256];
	struct ifreq buffer;
	s = socket(PF_INET, SOCK_DGRAM, 0);
	memset(&buffer, 0x00, sizeof(buffer));
	strcpy(buffer.ifr_name, "eth0");
	if(ioctl(s, SIOCGIFHWADDR, &buffer)<0)
	{
		printf("SIOCGIFHWADDR(%s): %m\n", "eth0");
	}
	close(s);
	for( s = 0; s < 6; s++ )
	{
		printf("%.2x ", (unsigned char)buffer.ifr_hwaddr.sa_data[s]);
	}
	sprintf(back,"%.2x%.2x%.2x%.2x%.2x%.2x",(unsigned char)buffer.ifr_hwaddr.sa_data[0],
		(unsigned char)buffer.ifr_hwaddr.sa_data[1],
		(unsigned char)buffer.ifr_hwaddr.sa_data[2],
		(unsigned char)buffer.ifr_hwaddr.sa_data[3],
		(unsigned char)buffer.ifr_hwaddr.sa_data[4],
		(unsigned char)buffer.ifr_hwaddr.sa_data[5]);
	sscanf(back,"%lx",&result);
	result=result>>0x10;
	printf("\n%s %lx %ld \n",back,result,result);
}
#endif
#if defined(__SYSNT__) || defined(MSDOSS)
// Visual C++ 5.0: cl -GX getmac-netbios.cpp netapi32.lib
// cygwin: g++  getmac-netbios.cpp -lnetapi32 
// Borland C++ 5.0: bcc32 getmac-netbios.cpp

#include <windows.h>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <strstream>
#include <string>

//using namespace std;

bool GetAdapterInfo(int nAdapterNum, std::string & sMAC)
{
    // Reset the LAN adapter so that we can begin querying it 
    NCB Ncb;
    memset(&Ncb, 0x00, sizeof(Ncb));
    Ncb.ncb_command = NCBRESET;
    Ncb.ncb_lana_num = nAdapterNum;
    if (Netbios(&Ncb) != NRC_GOODRET) {
        char acTemp[80];
		std::ostrstream outs(acTemp, sizeof(acTemp));
        outs << "error " << Ncb.ncb_retcode << " on reset" << std::ends;
        sMAC = acTemp;
        return false;
    }
    
    // Prepare to get the adapter status block 
    memset(&Ncb, 0, sizeof(Ncb));
    Ncb.ncb_command = NCBASTAT;
    Ncb.ncb_lana_num = nAdapterNum;
    strcpy((char *) Ncb.ncb_callname, "*");
    struct ASTAT {
        ADAPTER_STATUS adapt;
        NAME_BUFFER NameBuff[30];
    } Adapter;
    memset(&Adapter, 0, sizeof(Adapter));
    Ncb.ncb_buffer = (unsigned char *)&Adapter;
    Ncb.ncb_length = sizeof(Adapter);
    
    // Get the adapter's info and, if this works, return it in standard,
    // colon-delimited form.
    if (Netbios(&Ncb) == 0) {
        char acMAC[18];
        sprintf(acMAC, "%02X:%02X:%02X:%02X:%02X:%02X",
                int (Adapter.adapt.adapter_address[0]),
                int (Adapter.adapt.adapter_address[1]),
                int (Adapter.adapt.adapter_address[2]),
                int (Adapter.adapt.adapter_address[3]),
                int (Adapter.adapt.adapter_address[4]),
                int (Adapter.adapt.adapter_address[5]));
        sMAC = acMAC;
        return true;
    }
    else {
        char acTemp[80];
		std::ostrstream outs(acTemp, sizeof(acTemp));
        outs << "error " << Ncb.ncb_retcode << " on ASTAT" << std::ends;
        sMAC = acTemp;
        return false;
    }
}

#ifdef GETTINGREADYFORTHEFUTURE

//#include<windows.h>
#include<iphlpapi.h>
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
//#include<cstdio>
//#include<cstdlib>
//#include<vector>
//#include<string>

#pragma comment(lib,"iphlpapi.lib")//Need recent Visual Studio to be able to compile this.

#define MALLOC(x) HeapAlloc(GetProcessHeap(), 0, (x))
#define FREE(x) HeapFree(GetProcessHeap(), 0, (x))


unsigned long	getvolid( void )
{
	PIP_ADAPTER_INFO pAdapterInfo;
	PIP_ADAPTER_INFO pAdapter = NULL;
	DWORD dwRetVal = 0;
	UINT i;
	unsigned long back=0,b1,order[6],s,top,maddress[6];

//	struct tm newtime;
//	char buffer[32];
	char myMAC[9];
	std::string AdapterName;
//	errno_t error;

	ULONG ulOutBufLen = sizeof (IP_ADAPTER_INFO);
	pAdapterInfo = (IP_ADAPTER_INFO *) MALLOC(sizeof (IP_ADAPTER_INFO));
	if (pAdapterInfo == NULL)
	{
		printf("Error allocating memory needed to call GetAdaptersinfo\n");
		return 1;
	}
	// Make an initial call to GetAdaptersInfo to get
	// the necessary size into the ulOutBufLen variable
	if (GetAdaptersInfo(pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW)
	{
		FREE(pAdapterInfo);
		pAdapterInfo = (IP_ADAPTER_INFO *) MALLOC(ulOutBufLen);
		if (pAdapterInfo == NULL) 
		{
			printf("Error allocating memory needed to call GetAdaptersinfo\n");
			return 1;
		}
	}

	if ((dwRetVal = GetAdaptersInfo(pAdapterInfo, &ulOutBufLen)) == NO_ERROR)
	{
		pAdapter = pAdapterInfo;
		while (pAdapter)
		{
/*			printf("\tComboIndex: \t%d\n", pAdapter->ComboIndex);
			printf("\tAdapter Name: \t%s\n", pAdapter->AdapterName);
			printf("\tAdapter Desc: \t%s\n", pAdapter->Description);
			printf("\tAdapter Addr: \t");
			for (i = 0; i < pAdapter->AddressLength; i++)
			{
				if (i == (pAdapter->AddressLength - 1))
					printf("%.2X\n", (int) pAdapter->Address[i]);
				else
					printf("%.2X-", (int) pAdapter->Address[i]);
			}*/

			AdapterName=pAdapter->Description;
			if(pAdapter->Type==MIB_IF_TYPE_ETHERNET /*&& AdapterName.find("Virtual")==AdapterName.npos*/)//We might need to exclude some adapters, not yet though
			{//This will use information from all found adapters. 
				_ASSERT(pAdapter->AddressLength==6);
				for(i=0;i<pAdapter->AddressLength; i++)
				{
					sprintf(myMAC,"%.2x",(int) pAdapter->Address[i]);sscanf(myMAC,"%2lx",&maddress[i]);
				}
				for(s=0;s<6;s++)order[s]=s;
				top=5;
				while(top>0)
				{
					for(s=0;s<top;s++)
					{
						if(maddress[order[s]]<maddress[order[top]])
						{
							std::swap(order[s],order[top]);
						}
					}
					top--;
				}
				sprintf(myMAC,"%.2x%.2x%.2x%.2x",maddress[order[0]],maddress[order[1]],((maddress[order[2]]+maddress[order[3]])/2)&0xff,((maddress[order[4]]+maddress[order[5]])/2)&0xff);
				sscanf(myMAC,"%lx",&b1);
				back^=b1;
			}
			pAdapter = pAdapter->Next;
//			printf("\n");
		}
	} 
	else 
	{
		printf("GetAdaptersInfo failed with error: %d\n", dwRetVal);
	}
	if(pAdapterInfo)FREE(pAdapterInfo);
	return back;
}

#else
unsigned long getvolid()
{
    // Get adapter list
	unsigned long back=0,b1;
	unsigned char*pmac,code[6];
	size_t order[6],i,s,top;
    LANA_ENUM AdapterList;
    NCB Ncb;
    memset(&Ncb, 0, sizeof(NCB));
    Ncb.ncb_command = NCBENUM;
    Ncb.ncb_buffer = (unsigned char *)&AdapterList;
    Ncb.ncb_length = sizeof(AdapterList);
    Netbios(&Ncb);

    // Get all of the local ethernet addresses
	std::string sMAC;
	char myMAC[20];
    for (i = 0; i < AdapterList.length; ++i) {
        if (GetAdapterInfo(AdapterList.lana[i], sMAC)) {
			pmac=(unsigned char*)sMAC.c_str();
			//printf("%s\n",sMAC.c_str());
			sprintf(myMAC,"%c%c",pmac[0],pmac[1]);sscanf(myMAC,"%2lx",&b1);code[0]=(unsigned char) b1;
			sprintf(myMAC,"%c%c",pmac[3],pmac[4]);sscanf(myMAC,"%2lx",&b1);code[1]=(unsigned char) b1;
			sprintf(myMAC,"%c%c",pmac[6],pmac[7]);sscanf(myMAC,"%2lx",&b1);code[2]=(unsigned char) b1;
			sprintf(myMAC,"%c%c",pmac[9],pmac[10]);sscanf(myMAC,"%2lx",&b1);code[3]=(unsigned char) b1;
			sprintf(myMAC,"%c%c",pmac[12],pmac[13]);sscanf(myMAC,"%2lx",&b1);code[4]=(unsigned char) b1;
			sprintf(myMAC,"%c%c",pmac[15],pmac[16]);sscanf(myMAC,"%2lx",&b1);code[5]=(unsigned char) b1;
			for(s=0;s<6;s++)order[s]=s;
			top=5;
			while(top>0)
			{
				for(s=0;s<top;s++)
				{
					if(code[order[s]]<code[order[top]])
					{
						std::swap(order[s],order[top]);
					}
				}
				top--;
			}
			//printf("%.2x%.2x%.2x%.2x%.2x%.2x\n\n",code[order[0]],code[order[1]],code[order[2]],code[order[3]],code[order[4]],code[order[5]]);
			//printf("%.2x%.2x%.2x%.2x\n",code[order[0]],code[order[1]],((code[order[2]]+code[order[3]])/2)&0xff,((code[order[4]]+code[order[5]])/2)&0xff);
			sprintf(myMAC,"%.2x%.2x%.2x%.2x",code[order[0]],code[order[1]],((code[order[2]]+code[order[3]])/2)&0xff,((code[order[4]]+code[order[5]])/2)&0xff);
			sscanf(myMAC,"%lx",&b1);
			back^=b1;
			sprintf(myMAC,"%lx\n",back);
        }
        else {
			std::cerr << "Failed to get MAC address! Do you" << std::endl;
			std::cerr << "have the NetBIOS protocol installed?" << std::endl;
            break;
        }
    }
	return back;
}
#endif

	
extern "C" DLLEXPORT void getmacaddress()
{
    // Get adapter list
    LANA_ENUM AdapterList;
    NCB Ncb;
    memset(&Ncb, 0, sizeof(NCB));
    Ncb.ncb_command = NCBENUM;
    Ncb.ncb_buffer = (unsigned char *)&AdapterList;
    Ncb.ncb_length = sizeof(AdapterList);
    Netbios(&Ncb);

    // Get all of the local ethernet addresses
	std::string sMAC;
    for (int i = 0; i < AdapterList.length; ++i) {
        if (GetAdapterInfo(AdapterList.lana[i], sMAC)) {
			std::cout << "Adapter " << int (AdapterList.lana[i]) <<
				"'s MAC is " << sMAC << std::endl;
        }
        else {
			std::cerr << "Failed to get MAC address! Do you" << std::endl;
			std::cerr << "have the NetBIOS protocol installed?" << std::endl;
            break;
        }
    }
}
#endif
#if defined(sun)
extern "C" DLLEXPORT void getmacaddress()
{
	return;
}
#endif

#define DEFAULTTIMESERVER   "129.6.15.29"   /* time-b.nist.gov */
#define DEFAULTTIMESERVER   "129.6.15.29"   /* time-b.nist.gov */
#if defined( __SYSNT__ ) || defined(MSDOSS)
#ifdef __SYSNT__
#pragma comment(lib,"ws2_32.lib")
#else
#include <unistd.h>
#include <cygwin/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#define INVALID_SOCKET      (-1)            /* borrowed from Windows */
#define closesocket close
#endif
#else
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <arpa/inet.h>
#define INVALID_SOCKET      (-1)            /* borrowed from Windows */
#define closesocket close
#endif
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<ctime>
extern "C" DLLEXPORT int remtime()
{
    char                buf[512];
    long long                 connfd;
    struct sockaddr_in  servaddr;
    unsigned long timeserver = inet_addr(DEFAULTTIMESERVER);
#if defined( __SYSNT__ ) //|| defined(MSDOSS)
	//socket will not work on windows without doing WSAStartup
    WSADATA wsaData;   
    // MAKEWORD(1,1) for Winsock 1.1, MAKEWORD(2,0) for Winsock 2.0:
    if (WSAStartup(MAKEWORD(1,1), &wsaData) != 0)
	{
		if (WSAStartup(MAKEWORD(2,0), &wsaData) != 0)
		{
			fprintf(stderr, "WSAStartup failed.\n");
			return(1);
		}
	}
#endif
    connfd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (connfd == INVALID_SOCKET) 
	{
        printf("Socket error\n");
        return(1);
    }
	memset(&servaddr, 0x00, sizeof servaddr);
	servaddr.sin_family = PF_INET;
	servaddr.sin_addr.s_addr = timeserver;
	servaddr.sin_port = htons(13);	
    if (connect(connfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) 
	{
        printf("Unable to connect to remote host\n");
        return(1);
    }
    int len = 0,n;
    do 
	{
        n = recv(connfd, buf + len, sizeof(buf) - len - 1, 0);
        len += n;
    } 
	while (n > 0);
    closesocket(connfd);
#if defined( __SYSNT__ ) //|| defined(MSDOSS)
	if(WSACleanup()!=0)
	{
		printf("WSACleanup failed\n");
	}
#endif
    if (len && buf[len - 1] == '\n') 
	{
        buf[--len] = '\0';
    } 
	else 
	{
        buf[len] = '\0';
    }
    if (buf[0] == '\n') 
	{
        memmove(buf, buf + 1, len--);
    }
	printf("%s",buf);
	unsigned int tmp,year,mon,mday,hour,min,sec,health;
	if(sscanf(buf, "%u %u-%u-%u %u:%u:%u %u %u %u",&tmp, &year, &mon, &mday, &hour, &min, &sec,&tmp, &tmp, &health)!=10)
	{
		printf("Bad remote time string\n");
		return(1);
	}
	printf("Remote day is %u-%u-%u\n",mday,mon,year+2000);
	int yy=year+2000,back;
	struct	tm	remote;
	remote.tm_sec = sec;
	remote.tm_min = min;
	remote.tm_hour = hour;
	remote.tm_mday = mday;
	remote.tm_mon = mon-1;
	remote.tm_year = yy>1970?yy-1900:yy;
	remote.tm_isdst = 0;
	time_t remote_t = mktime(&remote),here_t;
	time(&here_t);
	printf("%s",ctime(&remote_t));
	printf("%s",ctime(&here_t));
	printf("Number of days different %d\n",(back=(int)((remote_t-here_t)/60/60/24)));			   
	return back;
}
