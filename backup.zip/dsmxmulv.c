/*
	dsmxmulv(n, S, x, y)	sets y = S*x for linear increment vectors x & y
				where S is an order n compactly rowwise stored
				symmetric matrix.

	Robin Becker	26/Feb/1993
*/
#include "ldefns.h"
void dsmxmulv(dimen n, sym_matrix S, vector x, vector y)
{
	dimen	i;
	for(i=1;i<=n;i++, x++, S += i)
		*y++ = BITA_ddot(i,S,-1,x,-1)+didot(n-i,S+i,i+1,x+1,1);
}
